import axios from 'axios';


class LibraryService {



  // Function to make a POST request
  static async login(data: any) {
    let payLoad = JSON.stringify(data);
    const headers = {
      'Cache-Control': 'no-cache',
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': 'http://localhost:4040/users/login'
    };

console.log(data);
    try {
      const response = await axios.post('http://localhost:4040/users/login', payLoad, { headers });
      //const response = await axios.post('http://localhost:4040/users/login', { headers }, data);

      console.log('response.data', response.data);
      return response.data; // Assuming the response contains JSON data
    } catch (error) {
      // Handle error
      console.error('Error while posting data:', error);
      throw error;
    }
  }
}

export default LibraryService;