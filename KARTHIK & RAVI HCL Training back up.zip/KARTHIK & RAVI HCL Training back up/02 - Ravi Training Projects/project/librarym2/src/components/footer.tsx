import React from 'react';
import { MDBContainer } from 'mdb-react-ui-kit'; // Import MDBContainer from MDB React UI Kit

function Footer() {
  return (
    <footer className="py-4 bg-light">
      <MDBContainer className="text-center">
        <div>
            Copyright © 2024 Hcl. All rights reserved.
        </div>
      </MDBContainer>
    </footer>
  );
}

export default Footer;
