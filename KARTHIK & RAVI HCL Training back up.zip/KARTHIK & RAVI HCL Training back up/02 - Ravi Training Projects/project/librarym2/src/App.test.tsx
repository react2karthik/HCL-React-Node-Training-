import React from "react";
import { ReactWrapper, mount, shallow } from "enzyme";
import App from "./App";


test("test sample", () => {
    const wrapper = shallow(<App />);
    console.log(wrapper.debug());
});


