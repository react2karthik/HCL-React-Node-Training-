export const getUser = () => {
    const user: any = sessionStorage.getItem('user');
    return JSON.parse(user);
}
export const getDate = (days = 0) => {
    const currentDate = new Date();
    currentDate.setDate(currentDate.getDate() + days);
    // Get the year, month, and day components
    const year = currentDate.getFullYear();
    const month = ('0' + (currentDate.getMonth() + 1)).slice(-2); // Adding 1 to month because months are zero-indexed
    const day = ('0' + currentDate.getDate()).slice(-2);

    // Construct the formatted date string
    const formattedDate = `${year}-${month}-${day}`;

    return formattedDate;
}