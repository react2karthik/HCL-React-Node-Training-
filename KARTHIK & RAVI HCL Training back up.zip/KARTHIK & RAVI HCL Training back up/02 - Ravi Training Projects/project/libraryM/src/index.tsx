import React from 'react'
import { createRoot } from 'react-dom/client'
import './css/index.css';
import "bootstrap/dist/css/bootstrap.min.css";
import "mdb-react-ui-kit/dist/css/mdb.min.css";
import { BrowserRouter as Router} from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store';
import App from './app';
 
const container = document.getElementById('app-root')!
const root = createRoot(container)
root.render(
    <Provider store={store}><Router><App /></Router></Provider>
    
)