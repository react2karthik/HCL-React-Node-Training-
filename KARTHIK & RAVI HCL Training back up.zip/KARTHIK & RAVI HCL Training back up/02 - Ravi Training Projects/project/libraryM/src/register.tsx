import React, { useState } from 'react';
import {
    MDBContainer, MDBCard, MDBCardBody, MDBRow, MDBCol, 
    MDBTabs, MDBTabsItem, MDBTabsLink, MDBTabsContent, MDBTabsPane
} from 'mdb-react-ui-kit';
import LoginForm from './page/login';
import RegisterForm from './page/register';
import { IregistrationProps } from './interface/interface';

const childImg = '';



const Register = ({setUsername, setIsLoggedIn}:IregistrationProps) => {
    const [activeTab, setActiveTab] = useState('login');
    const handleTabClick = (value: string) => {
        if (value === activeTab) {
            return;
        }

        setActiveTab(value);
    };
    return (
        <MDBContainer fluid className='h-100'>
            <MDBRow className='d-flex justify-content-center align-items-center h-100'>
                <MDBCol>
                    <MDBCard className='my-4'>
                        <MDBRow className='g-0'>
                            <MDBCol md='4'>
                                <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                                    <div>
                                        <MDBTabs pills justify className='mb-3'>
                                            <MDBTabsItem>
                                                <MDBTabsLink
                                                    onClick={() => handleTabClick('login')}
                                                    active={activeTab === 'login'}
                                                >
                                                    Login
                                                </MDBTabsLink>
                                            </MDBTabsItem>
                                            <MDBTabsItem>
                                                <MDBTabsLink
                                                    onClick={() => handleTabClick('register')} active={activeTab === 'register'}
                                                >
                                                    Register
                                                </MDBTabsLink>
                                            </MDBTabsItem>
                                        </MDBTabs>
                                        <MDBTabsContent>
                                            <MDBTabsPane open={activeTab === 'login'}>
                                                <LoginForm setUsername={setUsername} setIsLoggedIn={setIsLoggedIn}/>
                                            </MDBTabsPane>
                                            <MDBTabsPane open={activeTab === 'register'}>
                                                <RegisterForm />
                                            </MDBTabsPane>
                                        </MDBTabsContent>
                                    </div>
                                </MDBCardBody>
                            </MDBCol>
                        </MDBRow>
                    </MDBCard>
                </MDBCol>
            </MDBRow>
        </MDBContainer>
    );
}

export default Register;