export const LOGIN = 'login';
export const SIGN_IN = 'Sign in';
export const BOOKS = 'Books';
export const BORROW_BOOK_HIS = 'Borrowing Book History';
export const BORROW_BOOK = 'Borrow Book';
export const ACCOUNT = 'Account';
export const BORROWED = "Borrowed"
export const RETURN_BOOK = 'Return Book'