
import { call, put, takeLatest } from 'redux-saga/effects'; //takeevery
import { REGISTER_REQUEST, registerSuccess, registerFailed } from '../actions/registerAction';
import { USER_LIST } from '../../constants';
import callApi from '../../services';

function* register(data: any):Generator<any, void, any> {
  try {
    const response:any = yield call(callApi,USER_LIST, data.payload, 'post'); 
    yield put(registerSuccess(response));
  } catch (error) {
    yield put(registerFailed(error));
  }
}

function* registerSaga() {
  yield takeLatest(REGISTER_REQUEST, register);
}

export default registerSaga;

