
import { call, put, takeLatest } from 'redux-saga/effects'; //takeevery
import { LOGIN, loginSuccess, loginFailed } from '../actions/loginAction';
import { USER_LIST } from '../../constants';
import callApi from '../../services';

function* login(data: any):Generator<any, void, any> {
  try {
    const response:any = yield call(callApi,USER_LIST, data.payload, 'get'); 
    yield put(loginSuccess(response));
  } catch (error) {
    yield put(loginFailed(error));
  }
}

function* loginSaga() {
  yield takeLatest(LOGIN, login);
}

export default loginSaga;

