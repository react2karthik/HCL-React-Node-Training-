import { all } from 'redux-saga/effects';
import loginSaga from './loginSaga';
import searchBookSaga from './searchBookSaga'
import registerSaga from './registerSaga';
export default function* rootSaga() {
  yield all([
    loginSaga(),
    searchBookSaga(),
    registerSaga()
  ]);
}
