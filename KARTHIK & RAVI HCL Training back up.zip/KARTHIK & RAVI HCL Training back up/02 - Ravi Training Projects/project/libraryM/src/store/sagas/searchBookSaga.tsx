
import { call, put, takeLatest } from 'redux-saga/effects'; //takeevery
import {SEARCH_BOOK_REQUEST, searchBookSuccess, searchBookFailed} from '../actions/searchBookAction';
import { FETCH_BOOK_LIST } from '../../constants';
import callApi from '../../services';

function* searchBook(data: any):Generator<any, void, any> {
  try {
    const response:any = yield call(callApi,FETCH_BOOK_LIST, data.payload, 'get'); 
    yield put(searchBookSuccess(response));
  } catch (error) {
    yield put(searchBookFailed(error));
  }
}

function* searchBookSaga() {
  yield takeLatest(SEARCH_BOOK_REQUEST, searchBook);
}

export default searchBookSaga;

