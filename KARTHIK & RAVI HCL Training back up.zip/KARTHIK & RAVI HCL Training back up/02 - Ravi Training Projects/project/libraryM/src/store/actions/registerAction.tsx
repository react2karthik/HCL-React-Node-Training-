import { RegisterSubmitForm } from "../../interface/interface";

export const REGISTER_REQUEST = 'REGISTER_REQUEST';
export const REGISTER_SUCCESS = 'REGISTER_SUCCESS';
export const REGISTER_FAILED = 'REGISTER_FAILED';
export const registerRequest = (data:RegisterSubmitForm)=>{
    return {
        payload:{...data, "role":"user"},
        type:REGISTER_REQUEST
    }
}

export const registerSuccess = (data:any)=>{
    return {
        payload:data,
        type:REGISTER_SUCCESS
    }
}

export const registerFailed = (data:any)=>{
    return {
        payload:data,
        type:REGISTER_FAILED
    }
}