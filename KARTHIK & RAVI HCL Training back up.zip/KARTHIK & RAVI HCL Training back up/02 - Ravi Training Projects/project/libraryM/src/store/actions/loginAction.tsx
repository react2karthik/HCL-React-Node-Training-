export const LOGIN = 'LOGIN';
export const LOGIN2 = 'LOGIN2';
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_FAILED = 'LOGIN_FAILED';
export const loginRequest = (data={})=>{
    return {
        payload:data,
        type:LOGIN
    }
}
export const loginSuccess = (data:any)=>{
    return {
        payload:data,
        type:LOGIN_SUCCESS
    }
}
export const loginFailed = (data:any)=>{
    return {
        payload:data,
        type:LOGIN_FAILED
    }
}