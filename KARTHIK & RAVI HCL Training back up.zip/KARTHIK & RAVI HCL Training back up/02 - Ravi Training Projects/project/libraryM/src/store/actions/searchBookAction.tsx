export const SEARCH_BOOK_REQUEST = 'SEARCH_BOOK_REQUEST';
export const SEARCH_BOOK_SUCCESS = 'SEARCH_BOOK_SUCCESS';
export const SEARCH_BOOK_FAILED = 'SEARCH_BOOK_FAILED';
export const searchBookRequest = (data={})=>{
    return {
        payload:data,
        type:SEARCH_BOOK_REQUEST
    }
}
export const searchBookSuccess = (data:any)=>{
    console.log(data, "===data===")
    return {
        payload:data,
        type:SEARCH_BOOK_SUCCESS
    }
}
export const searchBookFailed = (data:any)=>{
    return {
        payload:data,
        type:SEARCH_BOOK_FAILED
    }
}