// reducers/index.ts
import { combineReducers } from 'redux';
import loginReducer from './loginReducer'; 
import searchBookReducer from './searchBookReducer';

const rootReducer = combineReducers({
    loginReducer,
    searchBookReducer
});

export default rootReducer;
