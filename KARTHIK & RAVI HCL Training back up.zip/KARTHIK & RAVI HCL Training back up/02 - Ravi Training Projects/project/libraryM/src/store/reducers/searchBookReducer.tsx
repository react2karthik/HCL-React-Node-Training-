import { SEARCH_BOOK_SUCCESS,  SEARCH_BOOK_FAILED} from "../actions/searchBookAction";
export interface bookState {
  data: any; // Define the structure of your state
}

// Define the initial state
const initialState: bookState = {
  data: []
};const searchBookReducer = (state: any = initialState, action:any) => {
  console.log(state, "Book state")
  switch (action.type) {
    
    case SEARCH_BOOK_SUCCESS:
      return {
        ...state,
        data: action.payload, 
      };
    case SEARCH_BOOK_FAILED:
      return {
        ...state,
        data: null, // Reset the state data in case of failure
      };
    default:
      return state; // Return the current state for any other action
  }
};

export default searchBookReducer;
