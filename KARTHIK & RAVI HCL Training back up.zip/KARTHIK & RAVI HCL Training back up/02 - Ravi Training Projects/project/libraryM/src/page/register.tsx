import React from "react"
import { Formik, Form } from "formik"
import * as yup from 'yup';
import {  MDBBtn } from "mdb-react-ui-kit";
import TextField from "../components/textField";
import { useDispatch } from "react-redux";
import { registerRequest } from "../store/actions/registerAction";
import { RegisterSubmitForm } from "../interface/interface";
const validationSchema = yup.object().shape({
    name: yup.string().required().min(3),
    email: yup.string().email().required(),
    password: yup.string().required().min(3)
  });
const register = () => {
    const Dispatch = useDispatch();
    const submitRegisterHandler = (values:RegisterSubmitForm) =>{
        Dispatch(registerRequest(values));
    }
    const intitialValues = {name:'', email:'', password:''};
    return (
        <Formik validationSchema={validationSchema} initialValues={intitialValues} onSubmit={submitRegisterHandler}>
             {(props) => (
            <Form>
                <TextField className='mb-4 form-control border' name="name" label='Name' />
                <TextField className='mb-4 form-control border' name="email"  label='Email address' />
                <TextField className='mb-4 form-control border' type="password" name="password" label='password' />
                <MDBBtn type='submit' className='mb-4' block>
                    Sign in
                </MDBBtn>
            </Form>
             )}
        </Formik>
    )
}

export default register;