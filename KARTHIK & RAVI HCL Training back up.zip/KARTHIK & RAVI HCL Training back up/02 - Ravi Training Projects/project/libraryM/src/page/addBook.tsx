import React, { useState, ChangeEvent, FormEvent } from 'react';
import { MDBContainer, MDBRow, MDBCol, MDBInput, MDBBtn } from 'mdb-react-ui-kit';
import axios from 'axios';
import { AVAILABLE, FETCH_BOOK_LIST } from '../constants';

interface FormData {
  title: string;
  author: string;
  category: string;
}

const AddBookForm: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    title: '',
    author: '',
    category: '',
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Add logic to handle form submission (e.g., sending data to backend)
    console.log('Form submitted:', formData);
    axios.post(FETCH_BOOK_LIST, {...formData, status:AVAILABLE})
    // Reset form fields
    setFormData({ title: '', author: '', category: '' });
  };

  return (
    <MDBContainer>
      <MDBRow>
        <MDBCol md="6">
          <h2>Add Book</h2>
          <form onSubmit={handleSubmit}>
            <MDBInput
              label="Title"
              id="title"
              name="title"
              type="text"
              value={formData.title}
              onChange={handleChange}
              className="form-control"
              required
            />
            <br/>
            <MDBInput
              label="Author"
              id="author"
              name="author"
              type="text"
              value={formData.author}
              onChange={handleChange}
              className="form-control"
              required
            />
            <br/>
            <MDBInput
              label="Category"
              id="category"
              name="category"
              type="text"
              value={formData.category}
              onChange={handleChange}
              required
            />
            <br/>
            <MDBBtn type="submit">Add Book</MDBBtn>
          </form>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
  );
};

export default AddBookForm;
