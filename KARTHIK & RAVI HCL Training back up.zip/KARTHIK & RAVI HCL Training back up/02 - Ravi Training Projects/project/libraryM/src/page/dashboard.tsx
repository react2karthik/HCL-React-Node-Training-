import React, { useEffect } from 'react';
import { MDBContainer, MDBRow, MDBCol } from 'mdb-react-ui-kit';
import { Outlet, useNavigate } from 'react-router-dom';
import LeftMenu from '../components/leftMenu';

const Dashboard: React.FC = () => {
    const navigate = useNavigate();
    useEffect(()=>{
        if(!sessionStorage.getItem('user')){
            navigate('/');
        }
    },[])
  return (
    <MDBContainer fluid className="p-0">
      <MDBRow className="m-0">
        {/* Left Sidebar */}
        <MDBCol md="3" className="p-0">
            <LeftMenu/>
        </MDBCol>
        
        {/* Main Content Area */}
        <MDBCol md="9" className="p-0">
          <Outlet/>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
  );
};

export default Dashboard;
