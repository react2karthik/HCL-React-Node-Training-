import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import {MDBBtn, MDBTable, MDBTableHead, MDBTableBody, MDBInput} from 'mdb-react-ui-kit';
import { Book } from '../interface/interface';
import { BORROW_BOOK, FETCH_BOOK_LIST, NOT_AVAILABLE } from '../constants';
import { BORROWED } from '../textContent/staticText';
import { getDate, getUser } from '../utils/getUser';
import { useDispatch } from 'react-redux';
import { searchBookRequest } from '../store/actions/searchBookAction';
import { useSelector } from 'react-redux';
import Pagination from '../components/pagination';
let clearInterval: NodeJS.Timeout | undefined;
const BookListPage: React.FC = () => {
  // State to store the list of books
  const [books, setBooks] = useState<Book[]>([]);
  const [allBooks, setAllBooks] = useState<Book[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const Dispatch = useDispatch();
  const bookList = useSelector((state:any)=>{
    return state?.searchBookReducer?.data || []
  })

  //Pagination start
  // Number of items per page
  const itemsPerPage = 5;
  // Current page
  const [currentPage, setCurrentPage] = useState(1);
   // Logic to slice the data based on current page
   const indexOfLastItem = currentPage * itemsPerPage;
   const indexOfFirstItem = indexOfLastItem - itemsPerPage;
   const currentItems = books.slice(indexOfFirstItem, indexOfLastItem);


     // Function to handle page change
  const handlePageChange = (pageNumber: React.SetStateAction<number>) => {
    setCurrentPage(pageNumber);
  };

  // Pagination End

  useEffect(()=>{
    getBookList();
  },[bookList.length])
  const getBookList = async () =>{
    setBooks(bookList);
    setAllBooks(bookList)
  }
  useEffect(()=>{
    //getBookList();
    Dispatch(searchBookRequest());
  },[])
const handleSearch = (e: { target: { value: any; }; })=>{
  const searchValue = e.target.value;
  setSearchTerm(searchValue)
  if(clearInterval){
    clearTimeout(clearInterval);
  }
  clearInterval = setTimeout(()=>{
    let book = allBooks.filter(bookItem=>{
      if(bookItem.title.includes(searchValue)){
        return true;
      }else if(bookItem.author.includes(searchValue)){
        return  true;
      }else if(bookItem.category.includes(searchValue)){
        return true;
      }else{
        return false;
      }
    });
    setCurrentPage(1);
    setBooks(book)
  }, 2000)
} 
const borrowBook = async (book:Book)=>{
  const user = getUser();
  const userId = user.id;
  const bookDate = getDate();
  const dueDate = getDate(15);
  await axios.post(BORROW_BOOK, {...book, userId, status:BORROWED, book_date:bookDate, due_date:dueDate});
  await axios.patch(`${FETCH_BOOK_LIST}/${book.id}`, {status:NOT_AVAILABLE});
  getBookList()
}
  return (
    <>
    <MDBInput
            label="Search"
            type="text"
            value={searchTerm}
            onChange={handleSearch}
          />
        <MDBTable>
          <MDBTableHead>
              <tr>
                  <th scope='col'>Title</th>
                  <th scope='col'>Author</th>
                  <th scope='col'>Status</th>
                  <th scope='col'>Action</th>
              </tr>
          </MDBTableHead>            
            {currentItems.map(book => (
                <MDBTableBody>
                    <tr>
                        <th scope='row'><h5>{book.title}</h5></th>
                        <td>{book.author}</td>
                        <td>{book.status}</td>
                        <td>{book.status == 'Available' ? <span><MDBBtn onClick={() => borrowBook(book)}>Borrow Book</MDBBtn></span>: ''}</td>
                    </tr>
                    </MDBTableBody>
            ))}
        </MDBTable>
        <Pagination currentPage={currentPage} itemsPerPage={itemsPerPage} handlePageChange={handlePageChange} totalNoOfItems={books.length}/> 
        </>
  );
};

export default BookListPage;
