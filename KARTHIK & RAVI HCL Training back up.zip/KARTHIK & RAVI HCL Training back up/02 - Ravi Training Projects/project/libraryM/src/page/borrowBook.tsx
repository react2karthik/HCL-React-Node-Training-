import React, { useEffect, useState } from 'react';
import { MDBContainer, MDBRow, MDBCol, MDBBtn } from 'mdb-react-ui-kit';
import axios from 'axios';
import {BorrowedBook } from '../interface/interface';
import { AVAILABLE, BORROW_BOOK, FETCH_BOOK_LIST, RETURNED } from '../constants';
const BorrowBookForm: React.FC = () => {

  const [books, setBooks] = useState<BorrowedBook[]>([]);
  const [selectedBook, setSelectedBook] = useState('');
  const getBookList = async () =>{
    const bookList:any = await axios.get(BORROW_BOOK);
    setBooks((previousBookList)=>bookList.data || []);
  }
  useEffect(()=>{
    getBookList();
  },[])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setSelectedBook(e.target.value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await axios.patch(`${FETCH_BOOK_LIST}/${selectedBook}`,{status:AVAILABLE});
    await axios.patch(`${BORROW_BOOK}/${selectedBook}`,{status:RETURNED});
    getBookList();

  };

  return (
    <MDBContainer className="mt-5">
        <MDBCol md="6">
          <h2 className="mb-4 text-center">Return Book</h2>
          <form onSubmit={handleSubmit}>
            
            <select name="borrow_book" className="form-control" onChange={handleChange}>
              <option value="">Select a book</option>
              {books.length>0 && books.filter(book=>book.status=='Borrowed').map(book => (
                <option key={book.id} value={book.id.toString()}>{book.title}</option>
              ))}
            </select>
            <br/>
            <MDBBtn color="primary" type="submit">
              Return Book
            </MDBBtn>
          </form>
        </MDBCol>
    </MDBContainer>
  );
};

export default BorrowBookForm;
