import React, { useState, useEffect } from 'react';
import { MDBContainer, MDBRow, MDBCol, MDBListGroup, MDBListGroupItem, MDBBtn, MDBTable, MDBTableHead, MDBTableBody } from 'mdb-react-ui-kit';
import { Book, BorrowedBook } from '../interface/interface';
import { BORROW_BOOK, FETCH_BOOK_LIST } from '../constants';
import axios from 'axios';
import { getUser } from '../utils/getUser';
const BorrowedListPage: React.FC = () => {
  // State to store the list of books
  const [borrowedBook, setBorrowedBook] = useState<BorrowedBook[]>([]);
  const getBorrowedBookList = async () =>{
    //const userId = 1;
    const user = getUser();
    const userId = user.id;
    const borrowedBook:any = await axios.get(BORROW_BOOK);
    const data = borrowedBook.data.filter((borrowedBookItem: { userId: number; })=>borrowedBookItem.userId==userId);
    setBorrowedBook(data);
  }
  // Simulated data for demonstration purposes
  useEffect(() => {
    getBorrowedBookList();
  }, []);

  return (
        <MDBTable>
          <MDBTableHead>
              <tr>
                  <th scope='col'>Title</th>
                  <th scope='col'>Booked Date</th>
                  <th scope='col'>Due Date</th>
                  <th scope='col'>Status</th>
              </tr>
          </MDBTableHead>            
            {borrowedBook.map(book => (
                <MDBTableBody>
                    <tr>
                        <th scope='row'><h5>{book.title}</h5></th>
                        <td>{book.book_date}</td>
                        <td>{book.due_date}</td>
                        <td>{book.status}</td>
                    </tr>
                    </MDBTableBody>
            ))}
        </MDBTable>
  );
};

export default BorrowedListPage;
