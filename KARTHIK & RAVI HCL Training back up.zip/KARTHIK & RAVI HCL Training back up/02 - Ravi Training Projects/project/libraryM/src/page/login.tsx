import React, { createContext, useEffect, useState } from 'react';
import {MDBInput, MDBBtn } from 'mdb-react-ui-kit';
import { useNavigate } from 'react-router-dom';
import { IregistrationProps } from '../interface/interface';
import { useDispatch, useSelector} from 'react-redux';
import { loginRequest } from '../store/actions/loginAction';
import {
  Formik,
  Form,
  Field,
  ErrorMessage
} from 'formik';
import * as yup from 'yup';


const LoginForm= ({setUsername, setIsLoggedIn}:IregistrationProps) => {
  const navigate = useNavigate();
  const Dispatch = useDispatch();
  
  const userList = useSelector((state:any)=>{
    return state?.loginReducer?.data || []
  });
  useEffect(()=>{
    Dispatch(loginRequest());
  },[])
  
  const validationSchema = yup.object().shape({
    email: yup.string().email().required(),
    password: yup.string().required().min(3)
  });
  const handleSubmit = (values:any, {setErrors}:any) => {
      userList.forEach((user:{email:string, password:string})=>{
        if(user.email == values.email && user.password==values.password) {
          sessionStorage.setItem('user', JSON.stringify(user));
          setIsLoggedIn(true)
          setUsername(values.email)
          navigate('/dashboard')
        }else{
          setErrors({'error': "Username or Password is not correct."})
        }
      })      
  };
const initialValues = {email:'', password:''}
  return (
    <Formik
       initialValues={initialValues}
       validationSchema={validationSchema}
       onSubmit={handleSubmit}>
        {(props:any) => (

        
      
    <Form>
      
    <div className="form-outline mb-4">
      {
        console.log(props)
      }
        
        <Field
          className='form-control border'
          type="text"
          name="email"
          id="email"
          placeholder="Enter your Email"
        />
        <ErrorMessage id="emailError" className="text-danger" name="email" component="div" />
        <br/>
        <Field
          className='form-control border'
          type="password"
          name="password"
          placeholder="***"
          id="password"
        />
        <ErrorMessage id="passwordError" className="text-danger"  name="password" component="div" />
        {(props?.errors?.error)?<div className="text-danger"> {props.errors.error} </div>:""}
      <div className="text-center">
        <MDBBtn id="loginBtn" color="primary" className="w-100 mt-3" type="submit">
          Sign in
        </MDBBtn>
      </div>
      </div>
    </Form>
      )}
    </Formik>
  );
};

export default LoginForm;
