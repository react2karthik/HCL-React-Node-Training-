import React, {useEffect, useState } from "react";
import {Routes, Route} from 'react-router-dom';
import Register from './register';
import Dashboard from "./page/dashboard";
import BookList from "./page/books";
import Header from "./components/header";
import BorrowedListPage from "./page/books-histry";
import Footer from "./components/footer";
import BorrowBookPage from "./page/borrowBook";
import AddBookForm from "./page/addBook";
import { getUser } from "./utils/getUser";
import { User } from "./interface/interface";
import { userContext } from "./context/userContext";
function App(){
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    
    const [username, setUsername] = useState('');
    const [role, setRole] = useState('');
    useEffect(()=>{
        const userDetails:User = getUser();
        setRole(userDetails?.role);
    },[])
    
    return(
        <userContext.Provider value={{username}}>
        <Header isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} setUsername={setUsername}/>
        <Routes>
            
            <Route path="/" element={<Register setIsLoggedIn={setIsLoggedIn} setUsername={setUsername}/>}/>
            <Route path="/dashboard" element={<Dashboard/>}>
            <Route index element={<BookList/>}/>
                {role=='admin'?<>
                <Route path="return-book" element={<BorrowBookPage/>}/>
                <Route path="add-book" element={<AddBookForm/>}/>
                </>:<>
                <Route path="borrowing-history" element={<BorrowedListPage/>}/></>}
            </Route>
        </Routes>
        <Footer/>
        </userContext.Provider>
    )
}
 
export default App;