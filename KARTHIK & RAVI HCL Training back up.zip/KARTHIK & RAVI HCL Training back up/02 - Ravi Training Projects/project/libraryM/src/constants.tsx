export const BASE_URL = "http://localhost:3002/";
export const FETCH_BOOK_LIST = `${BASE_URL}bookList`;
export const BORROW_BOOK = `${BASE_URL}borrow-book`;
export const USER_LIST = `${BASE_URL}users`;
export const NOT_AVAILABLE = "Not Available";
export const AVAILABLE = "Available";
export const ADD_BOOK = "Add Book"
export const RETURNED = "Returned"
