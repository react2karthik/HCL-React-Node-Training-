import React from "react";
import { Provider } from 'react-redux';
import { mockStore } from './__mocks__/redux';
import { BrowserRouter as Router } from 'react-router-dom';
import { ReactWrapper, mount, shallow, render } from "enzyme";
import { useSelector, useDispatch } from 'react-redux';
import { act } from 'react-dom/test-utils';
import LoginForm from "./page/login";
import { Formik } from "formik";
jest.mock('react-redux', () => ({
    ...jest.requireActual('react-redux'),
    useSelector: jest.fn()
  }));
  

describe('LoginForm component', () => {
    let wrapper:ReactWrapper;

test("Check email and password field exist on form", () => {
     (useSelector as unknown as jest.Mock).mockReturnValue([      {
        "id": "3",
        "email": "sita@hcl.com",
        "password": "123456",
        "role": "admin"
      }
    ])
    wrapper = mount(
      
        <Provider store={mockStore}>
          <Router><LoginForm setUsername={() => {}} setIsLoggedIn={() => {}} /></Router>
      </Provider>);
    expect(wrapper.find("Field")).toHaveLength(2);
    const inputEmail = wrapper.find('[name="email"]');
    expect(inputEmail.exists()).toBe(true);
    const inputPassword = wrapper.find('[name="password"]');
    expect(inputPassword.exists()).toBe(true);
    expect(useSelector).toHaveBeenCalledTimes(1)
    
});
test("Checking error message for wrong input in email and password", async() => {
    wrapper = mount(
      
        <Provider store={mockStore}>
          <Router><LoginForm setUsername={() => {}} setIsLoggedIn={() => {}} /></Router>
      </Provider>);
    await act(async () => {
        wrapper.find(Formik).simulate('submit');
        //loginBtn.simulate('click')
      });
    wrapper.update();
    //console.log(wrapper.debug())
    const emailError = wrapper.find('#emailError');
    expect(wrapper.find('#emailError').contains('email is a required field')).toBeTruthy();
    expect(wrapper.find('#passwordError').contains('password is a required field')).toBeTruthy();
    
});

});
