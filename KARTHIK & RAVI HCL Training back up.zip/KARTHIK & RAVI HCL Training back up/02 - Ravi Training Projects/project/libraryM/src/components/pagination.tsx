import React, { useContext, useState } from 'react';
import { MDBPagination, MDBPaginationItem, MDBPaginationLink } from 'mdb-react-ui-kit';
const Pagination = ({itemsPerPage, handlePageChange, currentPage, totalNoOfItems}:any) => {
    return (
        <>
            <MDBPagination className="mt-5 margin-bottom-50">
                <MDBPaginationItem disabled={currentPage === 1}>
                    <MDBPaginationLink onClick={() => handlePageChange(currentPage - 1)} aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </MDBPaginationLink>
                </MDBPaginationItem>
                {/* Render pagination items based on total number of items */}
                {Array.from({ length: Math.ceil(totalNoOfItems / itemsPerPage) }).map((_, index) => (
                    <MDBPaginationItem key={index} active={index + 1 === currentPage}>
                        <MDBPaginationLink onClick={() => handlePageChange(index + 1)}>
                            {index + 1}
                        </MDBPaginationLink>
                    </MDBPaginationItem>
                ))}
                <MDBPaginationItem disabled={currentPage === Math.ceil(totalNoOfItems / itemsPerPage)}>
                    <MDBPaginationLink onClick={() => handlePageChange(currentPage + 1)} aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </MDBPaginationLink>
                </MDBPaginationItem>
            </MDBPagination>
        </>)
}

export default Pagination;