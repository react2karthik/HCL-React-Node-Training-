import React from "react";
import { useField } from "formik";
const TextField = ({ label, ...props }: any) => {
    const [field, meta] = useField(props);
    return (
        <div className="form-outline mb-4">
            <label className="form-label">
                {label}
            </label>    
            <input {...field} {...props} />
            
            {meta.touched && meta.error ? (
                <div className="text-danger">{meta.error}</div>
            ) : null}
        </div>
    )
}
export default TextField;