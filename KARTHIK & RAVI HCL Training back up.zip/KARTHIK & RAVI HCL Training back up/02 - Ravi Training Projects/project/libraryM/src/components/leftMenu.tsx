import React, { useEffect, useState } from 'react';
import { MDBListGroup, MDBListGroupItem } from 'mdb-react-ui-kit';
import { Link } from 'react-router-dom';
import {ACCOUNT, BOOKS, BORROW_BOOK, BORROW_BOOK_HIS, RETURN_BOOK} from '../textContent/staticText'
import { ADD_BOOK } from '../constants';
import { getUser } from '../utils/getUser';
import { User } from '../interface/interface';
const LeftMenu: React.FC = () => {
  const [role, setRole] = useState('');
  useEffect(()=>{
      const userDetails:User = getUser();
      setRole(userDetails.role);
  },[])
  return (
    <MDBListGroup className="mb-3">
      <MDBListGroupItem>
        <Link to="/dashboard">{BOOKS}</Link>
      </MDBListGroupItem>
      {role=='user'?<>
      <MDBListGroupItem>
        <Link to="/dashboard/borrowing-history">{BORROW_BOOK_HIS}</Link>
      </MDBListGroupItem>
      </>:<>
      <MDBListGroupItem>
        <Link to="/dashboard/add-book">{ADD_BOOK}</Link>
      </MDBListGroupItem>
      <MDBListGroupItem>
        <Link to="/dashboard/return-book">{RETURN_BOOK}</Link>
      </MDBListGroupItem>
      </>}
      {/* Add more links for other features */}
    </MDBListGroup>
  );
};

export default LeftMenu;
