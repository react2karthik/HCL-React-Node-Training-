import React, { useContext, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { IheaderProps } from '../interface/interface';
import { userContext } from '../context/userContext';
const Header = ({isLoggedIn, setIsLoggedIn, setUsername}:IheaderProps) => {
  const user:any = useContext(userContext);
  const navigate = useNavigate();
  // Example: Function to handle user logout
  const handleLogout = () => {
    // Example: Logic to clear user session and update state
    setIsLoggedIn(false);
    setUsername('');
    navigate('/')

  };

  return (
    <header>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container">
          <Link className="navbar-brand" to="/">Library Management System</Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ms-auto">
              {isLoggedIn ? (
                <>
                  <li className="nav-item">
                    <span className="nav-link">Welcome, {user.username}</span>
                  </li>
                  <li className="nav-item">
                    <button className="nav-link btn btn-link" onClick={handleLogout}>Logout</button>
                  </li>
                </>
              ) : (
                <li className="nav-item">
                  <Link className="nav-link" to="/login">Login</Link>
                </li>
              )}
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;
