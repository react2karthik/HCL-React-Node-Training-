import axios from "axios"

const callApi = async(url:string, payload:any, method='post') =>{
    try {
        let response:any;
        if(method == 'post'){
            response = await axios.post(url, payload);
        }else if(method == 'patch') {
    
        }else{
            response = await axios.get(url);
        }
    
        return response.data
            
    } catch (error:any) {
        throw new Error(error.message);
    }
    
}

export default callApi;