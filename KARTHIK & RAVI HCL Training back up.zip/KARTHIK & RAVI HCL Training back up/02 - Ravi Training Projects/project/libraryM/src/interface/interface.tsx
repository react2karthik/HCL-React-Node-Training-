export interface Book {
    id: number;
    title: string;
    category: string;
    author: string;
    status:string;
  }
export interface BorrowedBook  {
    "id": number;
    "title": string;
    "book_id":number;
    "due_date": string;
    "book_date": string;
    "status":string;
}
export interface IheaderProps {
    isLoggedIn:boolean;
    setIsLoggedIn:Function;
    setUsername:Function;
}  

export interface RegisterSubmitForm {
        name: string;
        email: string;
        password: string;
};
export interface User {
        name: string;
        email: string;
        password: string;
        role:string;
};

export interface IregistrationProps {
    setIsLoggedIn:Function;
    setUsername:Function;
}  
