import express from 'express'
import dotenv from 'dotenv'
import userRouter from './src/routes/user'
import sendResponse from './src/middleware/sendResponse'
import accountRounter from './src/routes/account'
import customerRounter from './src/routes/customer'

const app = express()
dotenv.config()
const port = process.env.PORT || 3000

app.use(express.json())
app.use('/users', userRouter)
app.use('/accounts', accountRounter)
app.use('/customers', customerRounter)
app.use(sendResponse)

app.listen(port, () => {
	console.log(`Express server is listening at http://localhost:${port}`)
})