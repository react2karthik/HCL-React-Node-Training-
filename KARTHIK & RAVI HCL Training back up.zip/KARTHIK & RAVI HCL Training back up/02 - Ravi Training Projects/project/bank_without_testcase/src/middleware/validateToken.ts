import { NextFunction, Request, Response } from 'express'
import  jwt from 'jsonwebtoken'
import failureResponse from '../utils/failureResponse'
import { FAILURE } from '../../constant'

/**
 * Middleware for validating JWT token in the request header.
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next function to be called.
 */
const validateToken = (req:Request, res:Response, next:NextFunction) =>{
	const token = req.header('Authorization')
	if(token){
		try {
			const validToken  = jwt.verify(token, process.env.SECRET_KEY)
			if(validToken['email']){
				req.body.email = validToken['email']
				req.body.userId = validToken['userId']
			}
			next()   
		} catch (error) {
			failureResponse('Invalid Token', FAILURE, '401', 401, next) 
		}
	}else{
		failureResponse('Unauthorize Error', FAILURE, '402', 401, next)
	}
}
export default validateToken