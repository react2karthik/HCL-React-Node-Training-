import { NextFunction, Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import failureResponse from '../utils/failureResponse'
import { FAILURE, INVALID_TOKEN, UNAUTHORISE_ACCESS } from '../../constant'

/**
 * Middleware for validating JWT token in the request header.
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next function to be called.
 */
const validateStaffRole = (req: Request, res: Response, next: NextFunction) => {
	const token = req.header('Authorization')
	if (token) {
		try {
			const validToken = jwt.verify(token, process.env.SECRET_KEY)
			if (validToken['role'] == 'staff') {
				next()
			} else {
				failureResponse(UNAUTHORISE_ACCESS, FAILURE, '401', 401, next)
			}


		} catch (error) {
			failureResponse(INVALID_TOKEN, FAILURE, '401', 401, next)
		}
	} else {
		failureResponse(UNAUTHORISE_ACCESS, FAILURE, '402', 401, next)
	}
}
export default validateStaffRole