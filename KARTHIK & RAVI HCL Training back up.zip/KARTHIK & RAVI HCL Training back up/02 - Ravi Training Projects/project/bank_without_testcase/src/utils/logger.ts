import * as winston from 'winston'
import 'winston-daily-rotate-file'
const transport = new winston.transports.DailyRotateFile({
	filename: 'application-%DATE%.log',
	dirname:'logs',
	datePattern: 'YYYY-MM-DD',
	zippedArchive: true,
	maxSize: '20m',
	maxFiles: '14d' // Retain logs for 14 days
})
const logger = (path:string)=>winston.createLogger({
	level: 'info',
	format: winston.format.combine(
		winston.format.timestamp(),
		winston.format.simple(),
		winston.format.printf(info=>`[${path}  ${info.level} ${info.message}]`)
	),
	transports: [
		transport
	]
})

export default logger