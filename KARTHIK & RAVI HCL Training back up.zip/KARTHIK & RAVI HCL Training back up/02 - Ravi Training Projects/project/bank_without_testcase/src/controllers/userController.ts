import  {Request, Response, NextFunction } from 'express'
import bcrypt from 'bcryptjs'
import  jwt from 'jsonwebtoken'
import * as query from '../services/query'
import {SUCCESS, FAILURE, JWT_TOKEN_EXPIRE, REGISTRATION_SUCCESS, INVALID_USERNAME_PASSWROD, LOGIN_SUCCESS, USER_ALREADY_EXIST,ROLE, HTTP_CODE_401, STATUS_CODE_1005, STATUS_CODE_1004, STATUS_CODE_1003, STATUS_CODE_1002} from '../../constant'
import successResponse from '../utils/successResponse'
import failureResponse from '../utils/failureResponse'
import {IuserData } from '../interface/interfaceList'
import logger from '../utils/logger'
/**
 * Route: '/register' 
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const  register =  async (req:Request, res:Response, next:NextFunction)=>{
	try{
		// Set the creation timestamp for the user
		req.body.created_on = Date.now()

		// Extract necessary information from the request body
		const {name, email, mobile, password, created_on} = req.body
		
		// Create user data object
		const userData:IuserData = {name, email, mobile, password, created_on, role:ROLE}

		// Hash the user's password for security
		userData.password = await bcrypt.hash(userData.password, 10)
		
		// Check if a user with the same email already exists
		const userDetail = await query.getUserByEmail(userData.email)
		if(userDetail.rowLength) {
			throw USER_ALREADY_EXIST
		}

		// Insert the user data into the database
		await query.createUser(userData)

		// Create an account for the user
		//await createAccount(userId, ifscCode, accountType)

		// Send success response
		logger(req.path).info(REGISTRATION_SUCCESS)
		successResponse({email:userData.email}, REGISTRATION_SUCCESS, SUCCESS, '1001', 200, next)

	}catch(err){

		// Send failure response if an error occurs
		
		logger(req.path).error(err)
		failureResponse(err.message, FAILURE, '1005', 401, next)
	}
}




/**
 * Endpoint to authenticate a user.
 * Method: POST
 * Route: '/login'
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const login = async(req:Request, res:Response, next:NextFunction)=>{
	try{

		// Extract email and password from the request body
		const {email, password} = req.body

		// Retrieve user data from the database based on the provided email
		const result = await query.getUserByEmail(email)
		
		// If no user found with the provided email, return failure response
		if(result.rowLength ==0){
			failureResponse(INVALID_USERNAME_PASSWROD, FAILURE, STATUS_CODE_1002, HTTP_CODE_401, next)
		}else{

			// Compare the provided password with the hashed password stored in the database
			const hashPass = result.first().get('password')
			const isPasswordMatched = await bcrypt.compare(password, hashPass)
			// If passwords match, generate JWT token and send success response
			if(isPasswordMatched){
				const token = jwt.sign({ email: email,userId:result.first().get('id'), role:result.first().get('role')}, process.env.SECRET_KEY, {expiresIn:JWT_TOKEN_EXPIRE})
				const data = {token, email}
				successResponse(data, LOGIN_SUCCESS, SUCCESS, STATUS_CODE_1003, HTTP_CODE_401, next)
			}else{

				// If passwords don't match, return failure response
				failureResponse(INVALID_USERNAME_PASSWROD, FAILURE, STATUS_CODE_1004, HTTP_CODE_401, next)
			}     
		}  
	}catch(err){

		// If an error occurs, return failure response
		failureResponse(err.message, FAILURE, STATUS_CODE_1005, HTTP_CODE_401, next)
	}
}
