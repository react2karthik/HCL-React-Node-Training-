import {Request, Response, NextFunction } from 'express'
import successResponse from '../utils/successResponse'
import failureResponse from '../utils/failureResponse'
import { isAccountExist,saveCreateAccount} from '../services/account'
import { ACCOUNT_ALREADY_EXIST, ACCOUNT_CREATED, ACTIVE, FAILURE, HTTP_CODE_200, INITIAL_BALANCE, STATUS_CODE_3001, STATUS_CODE_502, SUCCESS} from '../../constant'
import { Iaccount} from '../interface/interfaceList'
import { AccountAleadyExistError } from '../error/accountAleadyExistError'

/**
 * Function to create a new account for a user.
 * @param {unknown} userId - The ID of the user for whom the account is being created.
 * @param {string} ifscCode - The IFSC code of the bank associated with the account.
 * @param {string} accountType - The type of the account (e.g., savings, current).
 */
export const createAccount =  async (req: Request, res: Response, next: NextFunction) => {
	try {
		const {account_type:accountType, ifsc_code:ifscCode, customer_id:customerId, account_no:accountNo} = req.body
		// Prepare account data object
		const accountData:Iaccount = {
			user_id:customerId,
			account_no:accountNo,
			ifsc_code:ifscCode,
			account_type:accountType,
			balance:INITIAL_BALANCE,
			status:ACTIVE,
			created_on:Date.now(),
			updated_on:Date.now()
		}
		const accountExist = await isAccountExist(accountNo)
		if(accountExist.rowLength>0){
			throw new AccountAleadyExistError(ACCOUNT_ALREADY_EXIST, STATUS_CODE_502)   
		}
		// Insert the account data into the database
		await saveCreateAccount(accountData)	        
		successResponse({}, ACCOUNT_CREATED, SUCCESS, STATUS_CODE_3001, HTTP_CODE_200, next)
	} catch (error) {
		failureResponse(error.message, FAILURE, error.statusCode, HTTP_CODE_200, next)
	}
}




