import {Request, Response, NextFunction } from 'express'
import successResponse from '../utils/successResponse'
import failureResponse from '../utils/failureResponse'
import {deleteBenificiary, getAccountByAccountNoAndIfsc, getAccountByUserIdAndAccountNo, getBalance, getBenificiary, getTransaction, saveBenificiary, saveTransaction, updateBalance} from '../services/account'
import { ACCOUNT_DETAIL_FETCHED, ACCOUNT_NOT_VALID, ACTIVE, BENIFICIARY_ADDED, BENIFICIARY_DELETED_MSG, BENIFICIARY_NOT_VALID, FAILURE, FUND_TRANSFERED, HTTP_CODE_200, INSUFFICIENT_FUND, NO_MESSAGE, NO_RECORD_FOUND, RECORD_FOUND, STATUS_CODE_3001, STATUS_CODE_3002, SUCCESS, TRANSFERER_NOT_VALID } from '../../constant'
import { Ibenificiary, ItransferDetail } from '../interface/interfaceList'
/**
 * Endpoint to retrieve account balance details for a specified user ID.
 * Method: GET
 * Route: '/'
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const getAccountDetails =  async (req: Request, res: Response, next: NextFunction) => {
	try {
		// Attempt to retrieve the balance for the specified user ID from the database
		const result = await getBalance(req.body.userId)
        
		// If the balance is successfully retrieved, send a success response
		successResponse(result.rows, ACCOUNT_DETAIL_FETCHED, SUCCESS, '3001', 200, next)
	} catch (error) {
		// If an error occurs during the retrieval process, send a failure response
		failureResponse(error.message, FAILURE, '3002', 200, next)
	}
}

/**
 * Endpoint to add a beneficiary account for a user.
 * Method: POST
 * Route: '/beneficiary'
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const addBenificiary = async (req:Request, res:Response, next:NextFunction)=>{
	try {
		const {userId, account_no, benificiary_acc_no, ifsc_code} = req.body
		const benificiary:Ibenificiary = {account_no, benificiary_acc_no, ifsc_code, status:ACTIVE, created_on:Date.now()}
		const transfererAcc = await getAccountByUserIdAndAccountNo(userId, account_no)
		if(transfererAcc.rowLength==0){
			throw TRANSFERER_NOT_VALID
		}
		const benificiaryAcc = await getAccountByAccountNoAndIfsc(benificiary_acc_no, ifsc_code)
		if(benificiaryAcc.rowLength==0){
			throw BENIFICIARY_NOT_VALID
		}
		await saveBenificiary(benificiary)
		successResponse({}, BENIFICIARY_ADDED, SUCCESS, '3003', 200, next)
	} catch (error) {
		failureResponse(error.message, FAILURE, '3004', 200, next)
	}
}

/**
 * Endpoint to retrieve beneficiary details for a user's account.
 * Method: GET
 * Route: '/beneficiary/:id'
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const getBenificiaryList =  async (req:Request, res:Response, next:NextFunction)=>{
	try {
		// Extract necessary information from the request
		const {userId} = req.body
		const {accountNumber } = req.params

		// Retrieve details of the transferer's account
		const transfererAcc = await getAccountByUserIdAndAccountNo(userId, accountNumber)

		// Check if the transferer's account exists
		if(transfererAcc.rowLength==0){
			throw ACCOUNT_NOT_VALID
		}

		// Retrieve beneficiary details for the specified account
		const result = await getBenificiary(accountNumber)
		// Check if any beneficiary records are found
		if(result.rowLength == 0){
			throw NO_RECORD_FOUND
		}
		// Send success response with beneficiary details
		successResponse(result.rows, RECORD_FOUND, SUCCESS, '3003', 200, next)
	} catch (error) {
		failureResponse(error.message, FAILURE, '3004', 200, next)
	}
}

export const deleteBenificiaryFromAccount =  async (req:Request, res:Response, next:NextFunction)=>{
	try {
		// Extract necessary information from the request
		const {userId} = req.body
		const {from_acc, benificiary_acc } = req.params

		// Convert the id to a number
		const accountNo = from_acc
		const benificiaryAcc = benificiary_acc

		// Retrieve details of the transferer's account
		const transfererAcc = await getAccountByUserIdAndAccountNo(userId, accountNo)

		// Check if the transferer's account exists
		if(transfererAcc.rowLength==0){
			throw ACCOUNT_NOT_VALID
		}

		// Retrieve beneficiary details for the specified account
		await deleteBenificiary(accountNo, benificiaryAcc)
      
		// Send success response with beneficiary details
		successResponse({}, BENIFICIARY_DELETED_MSG, SUCCESS, '3006', 200, next)
	} catch (error) {
		failureResponse(error.message, FAILURE, '3007', 200, next)
	}
}

/**
 * Endpoint to transfer money between accounts.
 * Method: POST
 * Route: '/transfermoney'
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const fundTransfer =  async (req:Request, res:Response, next:NextFunction)=>{
	try {
		const {userId, from_account_no:fromAccountNo, to_account_no:toAccountNo,amount, ifsc_code:ifscCode} = req.body
		const createdOn = Date.now()
		// Retrieve details of the transferer's account
		const transfererAcc = await getAccountByUserIdAndAccountNo(userId, fromAccountNo)
		// Check if the transferer's account exists
		if(transfererAcc.rowLength==0){
			throw ACCOUNT_NOT_VALID
		}
		// Get the current balance of the transferer's account
		let balance = transfererAcc.first().get('balance')

		// Check if there are sufficient funds in the transferer's account
		if(balance < req.body.amount){
			throw INSUFFICIENT_FUND
		}
        
		// Retrieve details of the beneficiary's account
		const benificiaryAcc = await getAccountByAccountNoAndIfsc(toAccountNo, ifscCode)
		// Check if the beneficiary's account exists
		if(benificiaryAcc.rowLength==0){
			throw BENIFICIARY_NOT_VALID
		}

		// Prepare transfer details for the transferer
		const transferDetail:ItransferDetail = {from_account_no:fromAccountNo, to_account_no:toAccountNo, amount, transaction_type:'debit', user_id:userId, created_on:createdOn}
        
		// Update the balance of the transferer's account
		balance = balance-amount
		updateBalance(userId, fromAccountNo, createdOn, balance)

		// Save the transaction details for the transferer
		saveTransaction(transferDetail)

		// Prepare transfer details for the beneficiary
		const transfereeDetail:ItransferDetail = {from_account_no:toAccountNo, to_account_no:fromAccountNo, amount, transaction_type:'credit', user_id:benificiaryAcc.first().get('user_id'), created_on:createdOn}
		// Update the balance of the beneficiary's account
		balance = benificiaryAcc.first().get('balance')
		balance = balance+amount
		updateBalance(benificiaryAcc.first().get('user_id'), toAccountNo, createdOn, balance)
		// Save the transaction details for the beneficiary
		saveTransaction(transfereeDetail)

		successResponse({}, FUND_TRANSFERED, SUCCESS, '3008', 200, next)
	} catch (error) {
		failureResponse(error.message, FAILURE, '3009', 200, next)
	}
}

/**
 * Endpoint to retrieve transaction details for a specific account.
 * Method: GET
 * Route: '/transaction/:accountno'
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const getTransactions = async (req:Request, res:Response, next:NextFunction)=>{
	try {
		const {userId} = req.body
		const {accountNumber} = req.params
		const result = await getTransaction(userId, accountNumber)
		if(result.rowLength==0){
			throw NO_RECORD_FOUND
		}
		successResponse(result.rows, NO_MESSAGE, SUCCESS, STATUS_CODE_3001, HTTP_CODE_200, next)
	} catch (error) {
		failureResponse(error.message, FAILURE, STATUS_CODE_3002, HTTP_CODE_200, next)
	}
}




