import con from 'cassandra-driver'

// Load environment variables from .env file
import dotenv from 'dotenv'
dotenv.config()

// Create a new Cassandra client instance
const client = new con.Client({
	contactPoints: [process.env.HOST],
	localDataCenter: process.env.DATACENTER,
	keyspace: process.env.KEYS_SPACE
})

export default client
