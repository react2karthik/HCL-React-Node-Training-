import {NextFunction, Request, Response } from 'express'
import {FAILURE, UNEXPECTED_ERROR, UNEXPECTED_STATUS_CODE} from '../../constant'
const sendResponse = (data:any, req:Request, res:Response, next:NextFunction)=>{
	const resp = {
		data:data.data || undefined,
		status:data.status || FAILURE,
		message:data.message || UNEXPECTED_ERROR,
		statusCode:data.statusCode || UNEXPECTED_STATUS_CODE,
	}
	res.status(data.httpCode||200).send(resp)
    
}
export default sendResponse