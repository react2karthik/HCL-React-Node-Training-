export class AccountAleadyExistError {
	statusCode: number
	message: string
	constructor(message:string, statusCode:number) {
		this.message = message // Set the name of the error to the class name
		this.statusCode = statusCode || 500 // Default status code to 500 if not provided
	}
}
  