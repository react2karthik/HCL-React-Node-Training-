import client from '../database/cassendra'
import { Iaccount, Ibenificiary, ItransferDetail } from '../interface/interfaceList'


export const saveCreateAccount = async(data:Iaccount)=>{
	// Extracting column names from the provided object
	const columns = Object.keys(data)
	// Constructing field and column value strings
	const colVals:string[] = columns.map(col=>`:${col}`)
	const fieldsVal = colVals.toString()
	
	const query = `insert into accounts(${columns}) values(${fieldsVal})`
	
	const result = await client.execute(query, data, { prepare: true })
    
	return  result 
}
/**
 * Retrieve the balance and related details of an account associated with a given user ID.
 * @param {unknown} userId - The user ID for which the balance is to be retrieved.
 * @returns {Promise<any>} - A promise resolving to the result of the database query containing the balance and account details.
 */
const getBalance = async(userId:unknown) =>{

	// Construct the query to select balance and account details based on the provided user ID
	const query = `SELECT  balance, account_no,account_type, status, created_on FROM accounts where user_id=${userId}`

	const result = await client.execute(query)
	return  result
}

/**
 * Retrieve the balance and related details of an account associated with a given account number.
 * @param {number} accountNo - The account number for which the balance is to be retrieved.
 * @returns {Promise<any>} - A promise resolving to the result of the database query containing the balance and account details.
 */
const getBalanceByAccountNo = async(accountNo:number) =>{
	const query = `SELECT email, balance, account_no,created_on FROM accounts where account_no=${accountNo} ALLOWING FILTERING`

	const result = await client.execute(query)
	return  result
}

/**
 * Retrieve the balance and related details of an account associated with a given user ID and account number.
 * @param {unknown} userId - The user ID associated with the account.
 * @param {number} accountNo - The account number for which the balance is to be retrieved.
 * @returns {Promise<any>} - A promise resolving to the result of the database query containing the balance and account details.
 */
const getAccountByUserIdAndAccountNo = async(userId:unknown, accountNo:string) =>{
	const query = `SELECT  balance, account_no,created_on FROM accounts where user_id = ${userId} and account_no='${accountNo}' and status='active' ALLOW FILTERING`

	const result = await client.execute(query)
	return  result
}

/**
 * Retrieve the user ID, balance, and related details of an account associated with a given account number and IFSC code.
 * @param {number} accountNo - The account number associated with the account.
 * @param {string} ifscCode - The IFSC code associated with the account.
 * @returns {Promise<any>} - A promise resolving to the result of the database query containing the user ID, balance, and account details.
 */
const getAccountByAccountNoAndIfsc = async(accountNo:number, ifscCode:string) =>{
	const query = `SELECT user_id, balance, account_no,created_on FROM accounts where account_no = '${accountNo}' and ifsc_code='${ifscCode}' and status='active' ALLOW FILTERING`
	console.log(query)
	const result = await client.execute(query)
	return  result
}

/**
 * Save beneficiary details to the database.
 * @param {Ibenificiary} data - The beneficiary data to be saved.
 * @returns {Promise<any>} - A promise resolving to the result of the database operation.
 */
const saveBenificiary = async(data:Ibenificiary) =>{
	// Extracting column names from the provided object
	const columns = Object.keys(data)
	// Constructing field and column value strings
	const colVals:string[] = columns.map(col=>`:${col}`)
	const fieldsVal = colVals.toString()
	
	const query = `insert into benificiary(${columns}) values(${fieldsVal})`
	
	const result = await client.execute(query, data, { prepare: true })
    
	return  result 
}

/**
 * Retrieve beneficiary account numbers and IFSC codes associated with a given account number.
 * @param {number} accountNo - The account number for which beneficiary details are to be retrieved.
 * @returns {Promise<any>} - A promise resolving to the result of the database query containing beneficiary details.
 */
const getBenificiary = async(accountNo:string) =>{
	const query = `SELECT benificiary_acc_no, ifsc_code FROM benificiary where account_no='${accountNo}' and status='active' ALLOW FILTERING`
	const result = await client.execute(query)
	return  result
}

/**
 * Update the balance of an account associated with a given user ID and account number.
 * @param {unknown} userId - The user ID associated with the account.
 * @param {number} accountNumber - The account number for which the balance is to be updated.
 * @param {number} createdOn - The timestamp when the transaction occurred.
 * @param {number} amount - The new balance amount.
 * @returns {Promise<void>} - A promise resolving once the update operation is completed.
 */
const updateBalance = async(userId:unknown, accountNumber:string, createdOn:number, amount:number)=>{
	
	const query = `UPDATE accounts SET balance=${amount} WHERE account_no='${accountNumber}' and user_id=${userId}`

	await client.execute(query)
}

/**
 * Save transaction details to the database.
 * @param {ItransferDetail} transactionDetail - The transaction details to be saved.
 * @returns {Promise<any>} - A promise resolving to the result of the database operation.
 */
const saveTransaction = async(transactionDetail:ItransferDetail)=>{
	// Extracting column names from the provided object
	const columns = Object.keys(transactionDetail)
	// Constructing field and column value strings
	const colVals:string[] = columns.map(col=>`:${col}`)
	const fieldsVal = colVals.toString()
	
	const query = `insert into transaction(id, ${columns}) values(uuid(), ${fieldsVal})`

	const result = await client.execute(query, transactionDetail, { prepare: true })
    
	return  result
}

/**
 * Retrieve transaction details associated with a given user ID and account number.
 * @param {unknown} userId - The user ID associated with the transactions.
 * @param {number} accountNo - The account number for which transactions are to be retrieved.
 * @returns {Promise<any>} - A promise resolving to the result of the database query containing transaction details.
 */
const getTransaction = async(userId:unknown, accountNo:string) =>{
	const query = `SELECT from_account_no, to_account_no, amount, transaction_type, created_on FROM transaction where user_id=${userId} and from_account_no='${accountNo}' ALLOW FILTERING`
	const result = await client.execute(query)
	return  result
}

const deleteBenificiary = async(accountNo:string, benificiaryAcc:string)=>{
	const query = `delete FROM benificiary where account_no='${accountNo}' and benificiary_acc_no='${benificiaryAcc}'`
	await client.execute(query)
}

export const isAccountExist = async(accountNo:string)=>{
	const query = `SELECT user_id FROM accounts where account_no='${accountNo}' ALLOW FILTERING`
	const result = await client.execute(query)
	return  result
} 

export {getBalance, saveBenificiary, getBenificiary, updateBalance, saveTransaction, getBalanceByAccountNo, getAccountByUserIdAndAccountNo, getAccountByAccountNoAndIfsc, getTransaction, deleteBenificiary}


