import Client from '../database/cassendra'
import {IuserData } from '../interface/interfaceList'
import cassandra from 'cassandra-driver'
const Uuid = cassandra.types.Uuid
/**
 * Function for inserting user data into the database.
 * @param {IuserData} userData - The object containing column-value pairs of the user data to be inserted.
 * @returns {Promise<any>} A promise that resolves to the result of the database operation.
 */
export const createUser = async (userData:IuserData)=>{
	// Extracting column names from the provided object
	const id = Uuid.random()
	const columns = ['name', 'email', 'mobile', 'password', 'created_on', 'role']
	// Constructing field and column value strings
	const colVals:string[] = columns.map(col=>`:${col}`)
	const fieldsVal = colVals.toString()
	
	const query = `insert into users(id, ${columns}) values(${id}, ${fieldsVal})`
	
	await Client.execute(query, userData, { prepare: true })
    
	return  id  
}



/**
 * Function for retrieving a user by their email.
 * @param {string} email - The email of the user to retrieve.
 * @returns {Promise<any>} A promise that resolves to the result of the database operation.
 */
export const getUserByEmail = async (email:string)=>{
	// Executing a SELECT query to retrieve a user by their email
	//const result = await Client.execute(`select id, name, email, password from users where email='${email}' ALLOW FILTERING`)
	const query = `select id, password,role from  users where email = '${email}' ALLOW FILTERING`
	// Returning the result of the database operation
	const result = await Client.execute(query)
	return  result  
}

export const getLastAccountNo = async() =>{
	const query = 'SELECT account_no FROM accounts LIMIT 1'
	const result = await Client.execute(query)
	return  result
}