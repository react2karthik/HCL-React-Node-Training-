import {body} from 'express-validator'
const transferMoneyValidationRule = [
	body('from_account_no', 'from_account_no should not be empty').not().isEmpty(),
	body('to_account_no', 'to_account_no should not be empty').not().isEmpty(),
	body('ifsc_code').notEmpty().withMessage('IFSC code is required').isLength({min:4}).withMessage('Minimum 4 charecter is required'),
	body('amount', 'Amount should not be empty').not().isEmpty().isFloat({min:1}).withMessage('Amount should be greater than zero'),
]

export default transferMoneyValidationRule