import {body} from 'express-validator'
const createAccountValidationRule = [
	body('customer_id', 'Customer id should not be empty').not().isEmpty(),
	body('account_no', 'Account no should not be empty').not().isEmpty(),
	body('account_type', 'Account type should not be empty').not().isEmpty(),
	body('ifsc_code').notEmpty().withMessage('IFSC code is required').isLength({min:4}).withMessage('Minimum 4 charecter is required')
]

export default createAccountValidationRule