import {body} from 'express-validator'
const addbenificiaryValidationRule = [
	body('account_no', 'account_no should not be empty').not().isEmpty(),
	body('benificiary_acc_no', 'benificiary_acc_no should not be empty').not().isEmpty(),
	body('ifsc_code').notEmpty().withMessage('IFSC code is required').isLength({min:4}).withMessage('Minimum 4 charecter is required'),
]

export default addbenificiaryValidationRule