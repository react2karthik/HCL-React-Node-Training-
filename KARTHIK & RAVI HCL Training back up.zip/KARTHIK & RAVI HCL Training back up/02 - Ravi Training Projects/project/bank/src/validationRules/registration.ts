import {body} from 'express-validator'
const registrationValidationRule = [
	body('name', 'Name should not be empty').not().isEmpty(),
	body('email', 'Invalid email').isEmail(),
	body('password', 'The minimum password length is 6 characters').isLength({min: 6}),
]

export default registrationValidationRule