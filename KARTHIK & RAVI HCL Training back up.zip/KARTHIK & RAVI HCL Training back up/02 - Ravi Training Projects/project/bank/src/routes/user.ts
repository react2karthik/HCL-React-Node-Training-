import express from 'express'
import registrationValidationRule from '../validationRules/registration'
import {validationRes} from '../middleware/validationResult'
import { login, register } from '../controllers/userController'
import loginValidationRule from '../validationRules/login'

const userRounter = express.Router()
userRounter.post('/register', registrationValidationRule, validationRes, register)
userRounter.post('/login', loginValidationRule, validationRes, login)

export default userRounter