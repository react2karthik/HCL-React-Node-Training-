import express from 'express'
import validateToken from '../middleware/validateToken'
import addbenificiaryValidationRule from '../validationRules/addbenificiary'
import { validationRes } from '../middleware/validationResult'
import transferMoneyValidationRule from '../validationRules/transferMoney'
import { addBenificiary, deleteBenificiaryFromAccount, fundTransfer, getAccountDetails, getBenificiaryList, getTransactions } from '../controllers/customerControler'

const customerRounter = express.Router()
customerRounter.use(validateToken)
customerRounter.get('/balance', getAccountDetails)
customerRounter.post('/benificiary', addbenificiaryValidationRule, validationRes, addBenificiary)
customerRounter.get('/:accountNumber/benificiary', getBenificiaryList)
customerRounter.delete('/benificiary/:from_acc/:benificiary_acc', deleteBenificiaryFromAccount)
customerRounter.post('/transfer-fund', transferMoneyValidationRule, validationRes, fundTransfer)
customerRounter.get('/:accountNumber/transactions', getTransactions)

export default customerRounter
