import express from 'express'
import validateToken from '../middleware/validateToken'

import { validationRes } from '../middleware/validationResult'

import {createAccount} from '../controllers/accountControler'
import createAccountValidationRule from '../validationRules/createAccount'
import validateStaffRole from '../middleware/validateStaffRole'

const accountRounter = express.Router()
accountRounter.use(validateToken)
accountRounter.use(validateStaffRole)
accountRounter.post('/create-account', createAccountValidationRule, validationRes,  createAccount)

export default accountRounter
