import { NextFunction } from 'express'

const successResponse = (data:unknown, message:string, status:string,statusCode:string| number, httpCode:number, next:NextFunction) => {
	next({
		data,
		message,
		status,
		statusCode,
		httpCode
	})
}

export default successResponse