import { NextFunction } from 'express'

type HttpCode = number|undefined
const failureResponse = (message:string, status:string,statusCode:string | number, httpCode:HttpCode, next:NextFunction) => {
	next({
		message,
		status,
		statusCode:statusCode || 502,
		httpCode
	})
}

export default failureResponse