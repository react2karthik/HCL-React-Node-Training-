import { START_ACCOUNT_NO } from '../../constant'
import { getLastAccountNo } from '../services/query'

/**
 * Function to generate a new account number.
 * It retrieves the last account number from the database and increments it by 1.
 * If no account number is found, it starts from a default value.
 * @returns {Promise<number>} - The generated account number.
 */
export const getAccountNo = async()=>{

	// Retrieve the last account number from the database
	const result = await getLastAccountNo()
	let accountNo:number

	// If no account number is found, start from a default value
	if(result.rowLength == 0){
		accountNo = START_ACCOUNT_NO
	}else{

		// Increment the last account number by 1
		accountNo = result.first().get('account_no')+1
	}

	return accountNo
}