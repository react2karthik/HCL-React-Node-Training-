import { expect } from "chai"

describe("testing", ()=>{
    it("test case", ()=>{
        //expect(2+4).lessThanOrEqual(5)      
    })
})