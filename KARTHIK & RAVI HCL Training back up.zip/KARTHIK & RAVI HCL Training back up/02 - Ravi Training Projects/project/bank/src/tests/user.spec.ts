import { assert } from "chai";
const request = require('supertest');
import app from '../../app' // Assuming your Express app is exported from 'src/app.js'

describe('POST /register ', () => {
  it('should return 200 and a success message when registration is successful', (done) => {
    // Define a mock user registration data
    const userData = {
      name: 'testuser',
      email: 'test@example.com',
      password: 'password123',
      mobile:"98989898989"
    };

    // Send a POST request to the /register endpoint
    request(app)
      .post('/users/register')
      .send(userData)
      .expect('Content-Type', /json/)
      .expect(200)
      .end((err: any, res: { body: { success: any; }; }) => {
        if (err) return done(err);

        // Assert that the response body contains a success message
        assert.equal(res.body.success, true);

        // Add additional assertions as needed

        done();
      });
  });
});
