interface IuserData{
    name:string;
    email:string;
    mobile:string;
    password:string;
    role:'user'|'staff'|'customer';
    created_on:string;
}
interface Iaccount{
    user_id:unknown;
    account_no:string;
    ifsc_code:string;
    account_type:string;
    balance:number;
    status:'active'|'inactive';
    created_on:unknown;
    updated_on:unknown;
}

interface Ibenificiary{
    account_no:string;
    benificiary_acc_no:string;
    ifsc_code:string;
    status:'active'|'inactive';
    created_on:unknown;
}

interface ItransferDetail{
    user_id:unknown;
    from_account_no:number;
    to_account_no:number;
    amount:number;   
    transaction_type:'credit'|'debit';
    created_on:unknown;
}

export {IuserData, Iaccount, Ibenificiary, ItransferDetail}