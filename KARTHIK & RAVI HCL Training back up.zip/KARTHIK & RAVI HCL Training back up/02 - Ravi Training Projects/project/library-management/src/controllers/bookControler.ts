import {Request, Response, NextFunction } from 'express'
import successResponse from '../utils/successResponse'
import failureResponse from '../utils/failureResponse'
import {FAILURE,HTTP_CODE_200,HTTP_CODE_500,NO_RECORD_FOUND,RECORD_FOUND,RECORD_SAVED,STATUS_CODE_3001,SUCCESS, UNEXPECTED_ERROR, UNEXPECTED_STATUS_CODE_2002} from '../../constant'

import logger from '../logger/logger'
import { saveBorrowedBook, searchBookByNameOrCategoryOrAuthor, updateInventoryByBookId } from '../services/inventory'
import { generateBorrowId, generateOtp, getCurrentDate } from '../utils/generateCustomId'
import { otpError } from '../error/otpError'

export const searchBook =  async (req: Request, res: Response, next: NextFunction) => {
	try {
		const searchByName = req.query.name || '';
		const searchByCategory = req.query.category || '';
		const searchByAuthor = req.query.author || '';
		const searchBookResult = await searchBookByNameOrCategoryOrAuthor(searchByName, searchByCategory, searchByAuthor);
		if(searchBookResult.rowLength ==0){
			failureResponse(NO_RECORD_FOUND, FAILURE, UNEXPECTED_STATUS_CODE_2002, HTTP_CODE_200, next)
		}else{
			successResponse(searchBookResult.rows, RECORD_FOUND, SUCCESS, STATUS_CODE_3001, HTTP_CODE_200, next)
		}
	} catch (error) {
			logger(req.path).error(UNEXPECTED_ERROR)
			
			failureResponse(UNEXPECTED_ERROR, FAILURE, UNEXPECTED_STATUS_CODE_2002, HTTP_CODE_500, next)
	}
}

export const borrowBook = async(req: Request, res: Response, next: NextFunction) =>{
	try {
		const  {bookId} = req.params;
		const  {email} = req.body;
		const bookIdInt = parseInt(bookId);
		const {userId} = req.body;
		const dueDays =15;
		const borrowedDate = getCurrentDate();
		const dueDate = getCurrentDate(dueDays);
		const otp = generateOtp(email);
		const borrowId = await generateBorrowId()
		const borrowedBookData = {book_id:bookIdInt, user_id:userId, borrowed_date:borrowedDate, due_date:dueDate, otp:otp, status:'pending', borrow_id:borrowId};
		
		await saveBorrowedBook(borrowedBookData);
		await updateInventoryByBookId(bookIdInt, 'not available')
		successResponse('', RECORD_SAVED, SUCCESS, STATUS_CODE_3001, HTTP_CODE_200, next)
	} catch (error) {
		if(error instanceof otpError){
			logger(req.path).error(error.message);
			failureResponse(error.message, FAILURE, error.statusCode, error.httpCode, next)
		}else{
			logger(req.path).error(UNEXPECTED_ERROR);
			failureResponse(UNEXPECTED_ERROR, FAILURE, UNEXPECTED_STATUS_CODE_2002, HTTP_CODE_500, next)
		}
	}
}


