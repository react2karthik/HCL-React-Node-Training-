import  {Request, Response, NextFunction } from 'express'
import bcrypt from 'bcrypt'
import  jwt, { Secret } from 'jsonwebtoken'
import * as query from '../services/query'
import {SUCCESS, FAILURE, JWT_TOKEN_EXPIRE, REGISTRATION_SUCCESS, INVALID_USERNAME_PASSWROD, LOGIN_SUCCESS,ROLE, HTTP_CODE_401, STATUS_CODE_1004, STATUS_CODE_1003, STATUS_CODE_1002, HTTP_CODE_200, UNEXPECTED_STATUS_CODE, HTTP_CODE_500, UNEXPECTED_ERROR, UNEXPECTED_STATUS_CODE_2001} from '../../constant'
import successResponse from '../utils/successResponse'
import failureResponse from '../utils/failureResponse'
import {IuserData } from '../interface/interfaceList'
import { AccountAleadyExistError } from '../error/accountAleadyExistError'
import logger from '../logger/logger'
/**
 * Route: '/register' 
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const  register =  async (req:Request, res:Response, next:NextFunction)=>{
	try{
		// Set the creation timestamp for the user
		req.body.created_on = Date.now()

		// Extract necessary information from the request body
		const {name, email, password, created_on, occupation, gender, dob, highest_qualification} = req.body
		
		// Create user data object
		const userData:IuserData = {name, email, password, occupation, gender,dob, created_on,highest_qualification, role:ROLE}

		// Hash the user's password for security
		userData.password = await bcrypt.hash(userData.password, 10)
		
		// Check if a user with the same email already exists
		const userDetail = await query.getUserByEmail(userData.email)
		if(userDetail.rowLength) {
			throw new AccountAleadyExistError()
		}

		// Insert the user data into the database
		await query.createUser(userData)

		// Create an account for the user

		// Send success response
		logger(req.path).info(REGISTRATION_SUCCESS)
		successResponse({email:userData.email}, REGISTRATION_SUCCESS, SUCCESS, STATUS_CODE_1002, HTTP_CODE_200, next)

	}catch(err){
		
		// Send failure response if an error occurs
		if(err instanceof AccountAleadyExistError){
			console.log(err.message)
			logger(req.path).info(err.message)
			failureResponse(err.message, FAILURE, err.statusCode, err.httpCode, next)
		}else{
			logger(req.path).error(UNEXPECTED_ERROR)
			failureResponse(UNEXPECTED_ERROR, FAILURE, UNEXPECTED_STATUS_CODE, HTTP_CODE_500, next)
		}
	}
}




/**
 * Endpoint to authenticate a user.
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const login = async(req:Request, res:Response, next:NextFunction)=>{
	try{

		// Extract email and password from the request body
		const {email, password} = req.body

		// Retrieve user data from the database based on the provided email
		const result = await query.getUserByEmail(email)
		
		// If no user found with the provided email, return failure response
		if(result.rowLength ==0){
			logger(req.path).info(INVALID_USERNAME_PASSWROD)
			failureResponse(INVALID_USERNAME_PASSWROD, FAILURE, STATUS_CODE_1002, HTTP_CODE_401, next)
		}else{

			// Compare the provided password with the hashed password stored in the database
			const hashPass = result.first().get('password')
			const isPasswordMatched = await bcrypt.compare(password, hashPass)
			// If passwords match, generate JWT token and send success response
			if(isPasswordMatched){
				const secretKey = process.env.SECRET_KEY || 'defaultSecretKey'
				const token = jwt.sign({ email: email,userId:result.first().get('id'), role:result.first().get('role')}, secretKey as Secret, {expiresIn:JWT_TOKEN_EXPIRE})
				const data = {token, email, id:result.first().get('id')}
				logger(req.path).info(LOGIN_SUCCESS)
				successResponse(data, LOGIN_SUCCESS, SUCCESS, STATUS_CODE_1003, HTTP_CODE_200, next)
			}else{

				// If passwords don't match, return failure response
				logger(req.path).info(INVALID_USERNAME_PASSWROD)
				failureResponse(INVALID_USERNAME_PASSWROD, FAILURE, STATUS_CODE_1004, HTTP_CODE_401, next)
			}     
		}  
	}catch(err){
		// If an error occurs, return failure response
		logger(req.path).error(UNEXPECTED_ERROR)
		failureResponse(UNEXPECTED_ERROR, FAILURE, UNEXPECTED_STATUS_CODE_2001, HTTP_CODE_500, next)
	}
}
