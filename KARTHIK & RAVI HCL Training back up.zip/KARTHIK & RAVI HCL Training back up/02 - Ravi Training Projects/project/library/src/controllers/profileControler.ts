import {Request, Response, NextFunction } from 'express'
import successResponse from '../utils/successResponse'
import failureResponse from '../utils/failureResponse'
import {ACCEPTED, ALLOWED_ROLES, FAILURE,HTTP_CODE_200,HTTP_CODE_400,HTTP_CODE_500,INTEREST_ACCEPTED,INTEREST_REJECTED,INTEREST_STORED,INTERST_EXIST,NO_RECORD,NO_RECORD_FOUND,PENDING,RECORD_FOUND,REJECTED,STATUS_CODE_3001,STATUS_CODE_3002,STATUS_CODE_3003,STATUS_CODE_3004,STATUS_CODE_3005,STATUS_CODE_3006,STATUS_CODE_3007,STATUS_CODE_3008,SUCCESS, UNEXPECTED_ERROR, UNEXPECTED_STATUS_CODE_2002} from '../../constant'
import * as query from '../services/query'
import {getProfile, getAllCustomerProfile, saveInterest, getInterestIn, getInterestBy, updateUserInterest, getInterest, checkInterestAleadyExist} from '../services/profiles'
import { Idata, IinterestData } from '../interface/interfaceList'
import { types } from 'cassandra-driver'
import { NoRecordFound } from '../error/noRecordFound'
import { InvalidUser } from '../error/InvalidUser'
import logger from '../logger/logger'

/**
 * Retrieves profiles based on the email provided in the request body.
 * If the user has an allowed role, retrieves all customer profiles.
 * Otherwise, retrieves profiles based on the opposite gender of the user's gender.
 * @param req The Express request object.
 * @param res The Express response object.
 * @param next The Express next function.
 */
export const getProfiles =  async (req: Request, res: Response, next: NextFunction) => {
	try {
		const result = await query.getUserByEmail(req.body.email)
		const gender = result.first().get('gender')=='male'?'female':'male'
		const role = result.first().get('role')
		let profileResult
		if(ALLOWED_ROLES.includes(role)){
			profileResult = await getAllCustomerProfile()
		}else{
			profileResult = await getProfile(gender)
		}
		
		if(profileResult.rowLength == 0){
			logger(req.path).info(NO_RECORD_FOUND)
			failureResponse(NO_RECORD_FOUND, FAILURE, STATUS_CODE_3001, HTTP_CODE_200, next)
		}
		logger(req.path).info(RECORD_FOUND)
		successResponse(profileResult.rows, RECORD_FOUND, SUCCESS, STATUS_CODE_3001, HTTP_CODE_200, next)
	} catch (error) {
			logger(req.path).error(UNEXPECTED_ERROR)
			failureResponse(UNEXPECTED_ERROR, FAILURE, UNEXPECTED_STATUS_CODE_2002, HTTP_CODE_500, next)
	}
}

/**
 * Stores interest data in the database based on the provided parameters.
 * @param req The Express request object containing parameters and body data.
 * @param res The Express response object to send responses.
 * @param next The Express next function to pass control to the next middleware.
 */
export const storeInterest = async (req: Request, res: Response, next: NextFunction) =>{
	try {
		const {userId, intestedIn} = req.params
		const loggedInUserId = req.body.userId
		const comment = req.body.comment
		const showedInterestInData:IinterestData = {user_id:userId, interested_in:intestedIn, comment:comment, interest_showed_on:Date.now(), status:PENDING}
		
		if(loggedInUserId !=userId) {
			throw new InvalidUser()
		}
		const checkInterestSentExist = await checkInterestAleadyExist(userId, intestedIn)
		const checkInterestReceivedExist = await checkInterestAleadyExist(intestedIn, userId)
		if(checkInterestSentExist.rowLength>0 || checkInterestReceivedExist.rowLength>0) {
			logger(req.path).info(INTERST_EXIST)
			failureResponse(INTERST_EXIST, FAILURE, STATUS_CODE_3008, HTTP_CODE_400, next)
		}else{
			saveInterest(showedInterestInData)
			logger(req.path).info(INTEREST_STORED)
			successResponse('', INTEREST_STORED, SUCCESS, STATUS_CODE_3001, HTTP_CODE_200, next)
		}
	} catch (error) {
		if(error instanceof InvalidUser) {
			logger(req.path).info(error.message)
			failureResponse(error.message, FAILURE, error.statusCode, error.httpCode, next)
		}else{
			logger(req.path).error(UNEXPECTED_ERROR)
			failureResponse(UNEXPECTED_ERROR, FAILURE, STATUS_CODE_3002, HTTP_CODE_500, next)
		}
	}
}
/**
 * Retrieves interest data associated with a profile.
 * @param req The Express request object containing parameters and body data.
 * @param res The Express response object to send responses.
 * @param next The Express next function to pass control to the next middleware.
 */
export const getInterestInProfile =  async (req: Request, res: Response, next: NextFunction) => {
	try {
		const {userId} = req.params
		const loggedInUserId = req.body.userId
		if(loggedInUserId !=userId) {
			throw new InvalidUser()
		}
		let data:Idata[] = []
		const result = await getInterestIn(loggedInUserId)
		if(result.rowLength>0){
			data = await prepareUserData(result)
			logger(req.path).info(RECORD_FOUND)
			successResponse(data, RECORD_FOUND, SUCCESS, STATUS_CODE_3003, HTTP_CODE_200, next)
		}else{
			logger(req.path).info(NO_RECORD)
			failureResponse(NO_RECORD, FAILURE, STATUS_CODE_3004, HTTP_CODE_200, next)
		}
	} catch (error) {
		if(error instanceof InvalidUser) {
			logger(req.path).info(error.message)
			failureResponse(error.message, FAILURE, error.statusCode, error.httpCode, next)
		}else{
			logger(req.path).error(UNEXPECTED_ERROR)
			failureResponse(UNEXPECTED_ERROR, FAILURE, STATUS_CODE_3005, HTTP_CODE_500, next)
		}
	}
}

/**
 * Retrieves interest data who all have liked to logged in user.
 * @param req The Express request object containing parameters and body data.
 * @param res The Express response object to send responses.
 * @param next The Express next function to pass control to the next middleware.
 */
export const getInterestByProfile =  async (req: Request, res: Response, next: NextFunction) => {
	try {
		const {userId} = req.params
		const loggedInUserId = req.body.userId
		if(loggedInUserId !=userId) {
			throw new InvalidUser()
		}
		let data:Idata[] = []
		const result = await getInterestBy(loggedInUserId)
		if(result.rowLength>0){
			data = await prepareUserData(result)
			logger(req.path).info(RECORD_FOUND)
			successResponse(data, RECORD_FOUND, SUCCESS, STATUS_CODE_3001, HTTP_CODE_200, next)
		}else{
			logger(req.path).info(NO_RECORD)
			failureResponse(NO_RECORD, FAILURE, STATUS_CODE_3002, HTTP_CODE_200, next)
		}
	} catch (error) {
		
		if(error instanceof InvalidUser) {
			logger(req.path).info(error.message)
			failureResponse(error.message, FAILURE, error.statusCode, error.httpCode, next)
		}else{
			logger(req.path).error(UNEXPECTED_ERROR)
			failureResponse(UNEXPECTED_ERROR, FAILURE, STATUS_CODE_3006, HTTP_CODE_500, next)
		}
	}
}

export const approveInterest = async (req: Request, res: Response, next: NextFunction) => {
	try {
		const {intestedBy} = req.params
		const {userId} = req.body
		const interestDetails = await getInterest(userId, intestedBy)
		if(interestDetails.rowLength == 0) {
			throw new NoRecordFound()
		}		
		updateUserInterest(userId, intestedBy, ACCEPTED)	
		logger(req.path).info(INTEREST_ACCEPTED)	
		successResponse('', INTEREST_ACCEPTED, SUCCESS, STATUS_CODE_3001, HTTP_CODE_200, next)
	} catch (error) {
		if(error instanceof NoRecordFound) {
			logger(req.path).info(error.message)
			failureResponse(error.message, FAILURE, error.statusCode, error.httpCode, next)
		}else{
			logger(req.path).error(UNEXPECTED_ERROR)
			failureResponse(UNEXPECTED_ERROR, FAILURE, STATUS_CODE_3006, HTTP_CODE_500, next)
		}
	}
}
export const rejectInterest = async (req: Request, res: Response, next: NextFunction) => {
	try {
		const {intestedBy} = req.params
		const {userId} = req.body
		const interestDetails = await getInterest(userId, intestedBy)
		if(interestDetails.rowLength == 0) {
			throw new NoRecordFound()
		}
		updateUserInterest(userId, intestedBy, REJECTED)		
		logger(req.path).info(INTEREST_REJECTED)
		successResponse('', INTEREST_REJECTED, SUCCESS, STATUS_CODE_3001, HTTP_CODE_200, next)
	} catch (error) {
		if(error instanceof NoRecordFound) {
			logger(req.path).info(error.message)
			failureResponse(error.message, FAILURE, error.statusCode, error.httpCode, next)
		}else{
			logger(req.path).error(UNEXPECTED_ERROR)
			failureResponse(UNEXPECTED_ERROR, FAILURE, STATUS_CODE_3007, HTTP_CODE_500, next)
		}
	}
}

/**
 * Prepares user data based on the provided ResultSet.
 * @param result The ResultSet containing user data.
 * @returns An array of prepared user data.
 */
const  prepareUserData = async(result: types.ResultSet)=>{
	let data:Idata[] = []
	for (const row of result.rows) {
		const userdata:Idata = {
			name: '',
			interest_showed_on: '',
			status: '',
			comment: '',
			dob: '',
			gender: '',
			id: ''
		}
		userdata.interest_showed_on=row.get('interest_showed_on')
		userdata.status=row.get('status')
		userdata.comment=row.get('comment')
		const useId = row.get('interested_in')?row.get('interested_in'):row.get('user_id')
		const userResult = await query.getUserById(useId)
		userdata.id=userResult.first().get('id')
		userdata.name=userResult.first().get('name')
		userdata.gender=userResult.first().get('gender')
		userdata.dob=`${userResult.first().get('dob').year}-${userResult.first().get('dob').month}-${userResult.first().get('dob').day}`
		
		data = [...data, userdata]
	}

	return data
}
