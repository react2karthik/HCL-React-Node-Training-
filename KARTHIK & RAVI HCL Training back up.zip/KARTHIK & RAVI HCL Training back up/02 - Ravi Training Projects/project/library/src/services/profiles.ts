import client from '../database/cassendra'
import {Gender, IinterestData} from '../interface/interfaceList'

export const getProfile = async(gender:Gender) =>{

	const query = `SELECT id, name, email, dob, gender  FROM users where gender ='${gender}' ALLOW FILTERING`

	const result = await client.execute(query)
	return  result
}
export const  getAllCustomerProfile  = async() =>{

	const query = 'SELECT id, name, email, dob, gender  FROM users where role=\'user\' ALLOW FILTERING'

	const result = await client.execute(query)
	return  result
}

export const saveInterest = async(interestData:IinterestData)=>{
	const columns = ['user_id', 'interested_in', 'comment', 'interest_showed_on', 'status']
	// Constructing field and column value strings
	const colVals:string[] = columns.map(col=>`:${col}`)
	const fieldsVal = colVals.toString()
	
	const query = `insert into users_interest(${columns}) values(${fieldsVal})`
	await client.execute(query, interestData, { prepare: true })
}

export const getInterestIn = async(userId:unknown)=>{
	const query = `SELECT interested_in, comment, interest_showed_on, status FROM users_interest where user_id=${userId}`
	
	return await client.execute(query)
}
export const getInterestBy = async(userId:unknown)=>{
	const query = `SELECT user_id, comment, interest_showed_on, status FROM users_interest where interested_in=${userId} ALLOW FILTERING`
	
	return await client.execute(query)
}
export const updateUserInterest = async(userId:unknown, intestedBy:unknown, status:string)=>{
	const query = `UPDATE users_interest SET status='${status}' where interested_in=${userId} and user_id=${intestedBy}`
	
	return await client.execute(query)
}

export const getInterest = async(userId:unknown, intestedBy:unknown)=>{
	const query = `SELECT user_id, status FROM users_interest where interested_in=${userId} and user_id=${intestedBy} and status='PENDING' ALLOW FILTERING`
	
	return await client.execute(query)
}
export const checkInterestAleadyExist = async (userId:unknown, intestedBy:unknown)=>{
	const query = `SELECT user_id, status FROM users_interest where interested_in=${intestedBy} and user_id=${userId} ALLOW FILTERING`
	
	return await client.execute(query)
}

