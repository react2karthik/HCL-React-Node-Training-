import Client from '../database/cassendra'
import {IuserData } from '../interface/interfaceList'
import cassandra from 'cassandra-driver'
const Uuid = cassandra.types.Uuid
/**
 * Function for inserting user data into the database.
 * @param {IuserData} userData - The object containing column-value pairs of the user data to be inserted.
 * @returns {Promise<any>} A promise that resolves to the result of the database operation.
 */
export const createUser = async (userData:IuserData)=>{
	// Extracting column names from the provided object
	const id = Uuid.random()
	const columns = ['name', 'email', 'dob', 'gender', 'occupation', 'highest_qualification', 'password', 'created_on', 'role']
	// Constructing field and column value strings
	const colVals:string[] = columns.map(col=>`:${col}`)
	const fieldsVal = colVals.toString()
	
	const query = `insert into users(id, ${columns}) values(${id}, ${fieldsVal})`
	console.log(query)
	await Client.execute(query, userData, { prepare: true })
    
	return  id  
}

export const getUserByEmail = async (email:string)=>{
	const query = `select id, password,role, gender from  users where email = '${email}' ALLOW FILTERING`

	const result = await Client.execute(query)
	return  result  
}
export const getUserById = async (id:unknown)=>{
	const query = `select id,name, dob, gender from  users where id=${id} and role='user' ALLOW FILTERING`
	const result = await Client.execute(query)
	return  result  
}

