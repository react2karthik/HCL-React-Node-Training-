import express from 'express'
import validateToken from '../middleware/validateToken'
import { getInterestByProfile, getInterestInProfile, getProfiles, storeInterest, approveInterest, rejectInterest} from '../controllers/profileControler'

const profilesRouter = express.Router()
profilesRouter.use(validateToken)
profilesRouter.get('/', getProfiles)
profilesRouter.post('/:userId/interests/:intestedIn', storeInterest)
profilesRouter.get('/:userId/interested-in', getInterestInProfile)
profilesRouter.get('/:userId/interested-by', getInterestByProfile)
profilesRouter.put('/accepts/interests/:intestedBy', approveInterest)
profilesRouter.put('/rejects/interests/:intestedBy', rejectInterest)

export default profilesRouter
