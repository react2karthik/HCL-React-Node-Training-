import express from 'express'
import registrationValidationRule from '../validationRules/registration'
import {validationRes} from '../middleware/validationResult'
import { login, register } from '../controllers/userController'
import loginValidationRule from '../validationRules/login'

const usersRounter = express.Router()
usersRounter.post('/register', registrationValidationRule, validationRes, register)
usersRounter.post('/login', loginValidationRule, validationRes, login)

export default usersRounter