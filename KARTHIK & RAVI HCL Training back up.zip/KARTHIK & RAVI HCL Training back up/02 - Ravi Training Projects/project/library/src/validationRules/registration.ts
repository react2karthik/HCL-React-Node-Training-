import {body} from 'express-validator'
const registrationValidationRule = [
	body('name', 'Name should not be empty').not().isEmpty(),
	body('email', 'Invalid email').isEmail(),
	body('password', 'The minimum password length is 6 characters').isLength({min: 6}),
	body('highest_qualification', 'Highest qualification should not be empty').not().isEmpty(),
	body('dob').notEmpty().withMessage('Date of birth is required').isDate({ format: 'YYYY-MM-DD' }).withMessage('Invalid date format'),
	body('gender').notEmpty().withMessage('gender is required').isIn(['male', 'female']).withMessage('Invalid gender value'),
	body('occupation').notEmpty().withMessage('occupation is required'),
	
]

export default registrationValidationRule