interface IuserData{
    name:string;
    email:string;
    password:string;
    occupation:string;
    gender:'male'|'female';
    dob:Date;
    highest_qualification:string;
    role:'user'|'staff'|'customer';
    created_on:string;
}
interface IinterestData{
    user_id:unknown;
    interested_in:unknown;
    comment:string;
    interest_showed_on:number;
    status:string;
}

interface Idata{
    id:string;
    name:string;
    interest_showed_on:string,
    status:string,
    comment:string, 
    dob:string,
    gender:string
}
type Gender ='male'|'female';
type StatusCode = string|number;

export {IuserData, Gender, IinterestData, Idata, StatusCode}