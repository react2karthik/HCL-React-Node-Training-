import { HTTP_CODE_404, STATUS_CODE_4000, USER_NOT_VALID } from '../../constant'
import GenricError from './genricError'
export class InvalidUser extends GenricError{
	constructor(){
		super(USER_NOT_VALID, STATUS_CODE_4000, HTTP_CODE_404)
	}
}
  