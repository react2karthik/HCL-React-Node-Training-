import { StatusCode } from '../interface/interfaceList'

class GenricError extends Error {
	statusCode: number|string
	httpCode:number
	constructor(message: string, statusCode:StatusCode = 500, httpCode=200) {
		super(message) // Call the super constructor to set the message property
		this.statusCode = statusCode // Set the statusCode property
		this.httpCode = httpCode
		//Error.captureStackTrace(this, this.constructor); // Capture the stack trace
	}
}

export default GenricError