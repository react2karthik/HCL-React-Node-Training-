import { HTTP_CODE_409, STATUS_CODE_4009, USER_ALREADY_EXIST } from '../../constant'
import GenricError from './genricError'
export class AccountAleadyExistError extends GenricError{
	constructor(){
		super(USER_ALREADY_EXIST, STATUS_CODE_4009, HTTP_CODE_409)
	}
}
  