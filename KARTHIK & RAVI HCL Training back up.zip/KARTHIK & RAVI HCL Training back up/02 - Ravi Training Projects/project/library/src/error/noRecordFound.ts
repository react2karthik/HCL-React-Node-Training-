import { HTTP_CODE_200, NO_RECORD_FOUND, STATUS_CODE_3002 } from '../../constant'
import GenricError from './genricError'
export class NoRecordFound extends GenricError{
	constructor(){
		super(NO_RECORD_FOUND, STATUS_CODE_3002, HTTP_CODE_200)
	}
}
  