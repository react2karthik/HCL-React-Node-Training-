import { NextFunction, Request, Response } from 'express'
import  jwt, { JwtPayload, Secret } from 'jsonwebtoken'
import failureResponse from '../utils/failureResponse'
import { FAILURE, HTTP_CODE_401, HTTP_CODE_403, INVALID_TOKEN, STATUS_CODE_1004, STATUS_CODE_1005, UNAUTHORISE_ACCESS } from '../../constant'

/**
 * Middleware for validating JWT token in the request header.
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next function to be called.
 */
const validateToken = (req:Request, res:Response, next:NextFunction) =>{
	const token = req.header('Authorization')
	if(token){
		try {
			const secretKey = process.env.SECRET_KEY || 'defaultSecretKey'
			const validToken  = jwt.verify(token, secretKey as Secret) as JwtPayload
			if(validToken['email']){
				req.body.email = validToken['email']
				req.body.userId = validToken['userId']
			}
			next()   
		} catch (error) {
			failureResponse(INVALID_TOKEN, FAILURE, STATUS_CODE_1004, HTTP_CODE_401, next) 
		}
	}else{
		failureResponse(UNAUTHORISE_ACCESS, FAILURE, STATUS_CODE_1005, HTTP_CODE_403, next)
	}
}
export default validateToken