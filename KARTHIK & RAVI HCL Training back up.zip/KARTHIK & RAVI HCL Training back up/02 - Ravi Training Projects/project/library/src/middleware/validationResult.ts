import { Request, Response, NextFunction } from 'express'
import {validationResult} from 'express-validator'
import failureResponse from '../utils/failureResponse'
import { FAILURE, HTTP_CODE_400, STATUS_CODE_4000 } from '../../constant'

/**
 * Middleware for handling validation results using express-validator.
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next function to be called.
 */
export const validationRes = (req:Request, res:Response, next:NextFunction)=>{
	const errors = validationResult(req)
	if (errors.isEmpty()) {
		next()
	}else{
		const err = errors.array()
		const errorMsg = err.map(error=>error.msg)
		const errormsgs = errorMsg.join(',')
		failureResponse(errormsgs, FAILURE, STATUS_CODE_4000, HTTP_CODE_400, next) 
	}
}