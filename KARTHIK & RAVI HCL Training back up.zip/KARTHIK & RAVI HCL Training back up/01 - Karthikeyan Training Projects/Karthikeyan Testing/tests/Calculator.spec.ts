import { assert } from 'chai';
import Calculator from '../src/Calculator';

describe('addition of two numbers', () => {
    it('sum of two numbers', () => {
        let calc = new Calculator();
        let result = calc.add(2, 3);
        assert.equal(result, 5);
        console.log('run');
        console.log('result', result);
    })
})