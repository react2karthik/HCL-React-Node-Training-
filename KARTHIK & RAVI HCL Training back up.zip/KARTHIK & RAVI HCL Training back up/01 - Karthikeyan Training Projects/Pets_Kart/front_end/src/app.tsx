import React from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
// import store from './store';
import Header from './components/common/header';
import Footer from './components/common/footer';
import { ContextApiProvider, useApiContext } from './components/context/contest';
import Home from './components/home';
import Register from './components/login_register';
import AddPets from './components/addPets';

import Buy from './components/buy';
import showCart from './components/showCart';

// import Appointment from './components/appointment';
const PrivateRoute: React.FC<{ path: string, component: React.FC }> = ({ path, component }) => {    
    const { isAuthenticated } = useApiContext();
    return isAuthenticated ? <Route path={path} component={component} /> :   <Redirect to="/" />;    
};
 
const App: React.FC = () => {
    return (
        <>
            <ContextApiProvider>
                
                <Router>
                <Header />
                    <Switch>

                        <Route path="/" exact component={Home} />{/*LogiForm LoginFormik*/}
                        <Route path="/login" component={Register} />{/*Register RegisterFormik*/}
                        <Route path="/addPets" component={AddPets} />
                        <Route path='/buy' component={Buy} />
                        <Route path='/showCart' component={showCart} />

                    </Switch>
                </Router>
                <Footer />
            </ContextApiProvider>
        </>
    );
};
 
export default App;