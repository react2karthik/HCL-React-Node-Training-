import { call, put, takeLatest } from 'redux-saga/effects';
import { ADD_PETS_REQUEST, addPetsSuccess, addPetsFailure} from '../actions/addPetsAction';
import { ADDPETSAPI} from '../../constant';
import apiService from '../../services/index';
 
function* addPets(data: any): Generator<any, void, any> {
    try {
        console.log('ddd', data.payload)
        const response: any = yield call(apiService, ADDPETSAPI, data.payload, 'post');//APPOINMENTDETAILSAPI
        yield put(addPetsSuccess(response.data));
    } catch (error: any) {
        yield put(addPetsFailure(error.message))
    }
}
function* addPetsSaga() {
    yield takeLatest(ADD_PETS_REQUEST, addPets)
}
export default addPetsSaga;
 