import { call, put, takeLatest } from 'redux-saga/effects';
import { ADD_CART_REQUEST, addCartSuccess, addCartFailure } from '../actions/addCartAction';
import { ADDCART } from '../../constant';
import callApi from '../../services/index';
 
function* addCart(data: any): Generator<any, void, any> {
    try {
        const response: any = yield call(callApi, ADDCART, data, 'post');        
        yield put(addCartSuccess(response));
    } catch (error: any) {      
        yield put(addCartFailure(error.message))        
    }
}
function* addCartSaga() {
    yield takeLatest(ADD_CART_REQUEST, addCart)
}

export default addCartSaga;
 