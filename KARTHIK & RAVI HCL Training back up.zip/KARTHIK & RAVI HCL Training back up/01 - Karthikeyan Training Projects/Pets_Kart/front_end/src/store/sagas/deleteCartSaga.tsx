import { call, put, takeLatest } from 'redux-saga/effects';
import { DELETE_CART_REQUEST, deleteCartSuccess, deleteCartFailure } from '../actions/deleteCartAction';
import { DELETECART } from '../../constant';
import callApi from '../../services/index';
 
function* deleteCart(): Generator<any, void, any> {
    try {
        console.log('Dellllllllllllllllllllllllllllllllll')
        const response: any = yield call(callApi, DELETECART, null, 'delete');        
        yield put(deleteCartSuccess(response));
    } catch (error: any) {      
        yield put(deleteCartFailure(error.message))        
    }
}
function* deleteCartSaga() {
    console.log('sssssssssssssssssssssssssssddddddd')
    yield takeLatest(DELETE_CART_REQUEST, deleteCart)
}

export default deleteCartSaga;
 