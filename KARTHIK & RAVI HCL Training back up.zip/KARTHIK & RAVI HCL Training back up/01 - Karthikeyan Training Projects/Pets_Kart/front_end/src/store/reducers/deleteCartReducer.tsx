import { DELETE_CART_SUCCESS, DELETE_CART_FAILURE } from '../actions/deleteCartAction';

export interface deleteCartState {
    data: any;
}

const initialState: deleteCartState = {
    data: null
}

const deleteCartReducer = (state: deleteCartState = initialState, action: any) => {
    switch (action.type) {
        
        case DELETE_CART_SUCCESS:
            console.log('ssssssssssssssssssssssssssssssssssssssssssss')
            return {
                ...state,
                data: action.payload
            }
        case DELETE_CART_FAILURE:
            return {
                ...state,
                data: null,
            }
        default:
            return state;
    }
};

export default deleteCartReducer;
