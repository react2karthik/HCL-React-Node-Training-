import { ADD_CART_SUCCESS, ADD_CART_FAILURE } from '../actions/addCartAction';

export interface addCartState {
    data: any;
}

const initialState: addCartState = {
    data: null
}

const addCartReducer = (state: addCartState = initialState, action: any) => {
    switch (action.type) {
        case ADD_CART_SUCCESS:
            return {
                ...state,
                data: action.payload
            }
        case ADD_CART_FAILURE:
            return {
                ...state,
                data: null,
            }
        default:
            return state;
    }
};

export default addCartReducer;
