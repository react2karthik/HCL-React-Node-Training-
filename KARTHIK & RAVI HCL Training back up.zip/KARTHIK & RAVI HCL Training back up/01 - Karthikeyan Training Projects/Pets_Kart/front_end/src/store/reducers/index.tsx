// reducers/index.ts
import { combineReducers } from 'redux';
import loginReducer from './loginReducer'; 
import registerReducer from './registerReducer';
import addCartReducer from './addCartReducer';
import addPetsReducer from './addPetsReducer';
import deleteCartReducer from './deleteCartReducer';

const rootReducer = combineReducers({
    loginReducer, registerReducer, addPetsReducer, addCartReducer, deleteCartReducer
});

export default rootReducer;
