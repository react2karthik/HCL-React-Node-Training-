import { ADD_PETS_SUCCESS, ADD_PETS_FAILURE } from '../actions/addPetsAction';
 
export interface addPetsState {
  data: any;
}
const initialState: addPetsState = {
  data: null
}
const addPetsReducer = (state: addPetsState = initialState, action: any) => {
  switch (action.type) {
    case ADD_PETS_SUCCESS:
      return {
        ...state,
        data: action.payload
      }
    case ADD_PETS_FAILURE:
      return {
        ...state,
        data: null,
      }
    default:
      return state;
  }
};
 
export default addPetsReducer;