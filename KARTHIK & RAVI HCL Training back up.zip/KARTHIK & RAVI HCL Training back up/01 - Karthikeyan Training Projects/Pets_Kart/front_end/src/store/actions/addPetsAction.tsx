export const ADD_PETS_REQUEST = 'ADD_PETS_REQUEST';
export const ADD_PETS_SUCCESS = 'ADD_PETS_SUCCESS';
export const ADD_PETS_FAILURE = 'ADD_PETS_FAILURE';
 
export const addPetsRequest = (payload: any) => ({
  type: ADD_PETS_REQUEST,
  payload,
});
 
export const addPetsSuccess = (userData: any) => ({
  type: ADD_PETS_SUCCESS,
  payload: userData
});
 
export const addPetsFailure = (error: string) => ({
  type: ADD_PETS_FAILURE,
  payload:error,
});