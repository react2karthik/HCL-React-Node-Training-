export const ADD_CART_REQUEST = 'ADD_CART_REQUEST';
export const ADD_CART_SUCCESS = 'ADD_CART_SUCCESS';
export const ADD_CART_FAILURE = 'ADD_CART_FAILURE';
 
export const addCartRequest = (payload: any) => ({
  type: ADD_CART_REQUEST,
  payload,
});
 
export const addCartSuccess = (userData: any) => ({
  type: ADD_CART_SUCCESS,
  payload: userData
});
 
export const addCartFailure = (error: string) => ({
  type: ADD_CART_FAILURE,
  payload:error
});