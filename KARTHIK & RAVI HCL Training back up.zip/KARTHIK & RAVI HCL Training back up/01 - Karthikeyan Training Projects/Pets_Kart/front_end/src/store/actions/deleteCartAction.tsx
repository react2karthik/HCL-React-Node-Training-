export const DELETE_CART_REQUEST = 'DELETE_CART_REQUEST';
export const DELETE_CART_SUCCESS = 'DELETE_CART_SUCCESS';
export const DELETE_CART_FAILURE = 'DELETE_CART_FAILURE';
 
export const deleteCartRequest = () => ({
  type: DELETE_CART_REQUEST,
  payload: null,
});
 
export const deleteCartSuccess = (userData: any) => ({
  type: DELETE_CART_SUCCESS,
  payload: userData
});
 
export const deleteCartFailure = (error: string) => ({
  type: DELETE_CART_FAILURE,
  payload:error
});