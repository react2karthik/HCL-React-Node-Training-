import axios from 'axios';
import { MDBBtn, MDBCard, MDBCardBody, MDBCol, MDBContainer, MDBIcon, MDBRow } from 'mdb-react-ui-kit';
import React, { useState, useEffect } from 'react';
import Pagination from 'react-js-pagination';
import { addCartRequest } from '../store/actions/addCartAction';
import { useDispatch } from 'react-redux';

const Buy: React.FC = () => {
    const dispatch = useDispatch();
    const [petData, setPetData] = useState<any[]>([]);
    const [cart, setCart] = useState<any[]>([]);
    const [activePage, setActivePage] = useState(1);
    const [showToast, setShowToast] = useState(false);
    const itemsPerPage = 4;

    useEffect(() => {
        axios.get('http://localhost:3001/petsDetails')
            .then(response => {
                setPetData(response.data);
            })
            .catch(error => {
                console.error('Error fetching pet data:', error);
            });
    }, []);
    const handleAddCart = (item: any) => {
        const cartT = [...cart, item];
        dispatch(addCartRequest(item));
        setCart(cartT);
        setShowToast(true);
        setTimeout(() => {
            setShowToast(false);
        }, 3000);  
    }

    useEffect(() => {
        // console.log('cart', cart, cart.length)
        axios.get('http://localhost:3001/petsDetails')
            .then(response => {
                const cartDisable = response.data.map((pet: any) => ({
                    ...pet,
                    addCart: cart.some(cartItem => cartItem.id === pet.id)
                }));
                setPetData(cartDisable);
            })
            .catch(error => {
                console.error('Error fetching pet data:', error);
            });
    }, [cart]);
    const handlePageChange = (pageNumber: number) => {
        setActivePage(pageNumber);
    };
    const indexOfLastItem = activePage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = petData.slice(indexOfFirstItem, indexOfLastItem);
    return (
        <>
            <MDBContainer className='mt-2' fluid>
                {showToast && (
                    <div className="toast show bg-success mx-auto" role="alert" aria-live="assertive" aria-atomic="true">
                        <div className="toast-body text-light">
                            Item added to cart!
                        </div>
                    </div>
                )}
                <MDBRow className='g-0'>
                    {currentItems.map((pet) => (
                        <MDBCol key={pet.id} md='3' className='mx-auto'>
                            <MDBCard className='mx-2 mb-2 p-2 shadow-5'>
                                <img src={pet.imageUrl} className="card-img-top w-100 mx-auto h-100" alt={pet.title} />
                                <MDBCardBody className='text-black d-flex flex-column justify-content-center w-100 mx-auto'>
                                    <h5 className="card-title">{pet.petName}</h5>
                                    {/* <p className="card-text">{pet.description}</p> */}
                                    <div className='d-flex justify-content-between align-items-center'>
                                        <span className='fw-bold'><MDBIcon fas icon="rupee-sign" /> {pet.price}</span>
                                        {/* <MDBBtn className={`btn btn-primary btn-rounded${pet.sold ? '' : ' disabled'}`} data-mdb-ripple-init disabled={pet.sold}>Sold</MDBBtn> */}
                                        <MDBBtn  className="btn btn-success mx-2"
                                            data-mdb-ripple-init
                                            onClick={() => handleAddCart(pet)}
                                            disabled={pet.addCart}
                                        >
                                            <MDBIcon fas icon="shopping-cart" className="mx-2" />
                                            Add to Cart
                                        </MDBBtn>
                                    </div>
                                </MDBCardBody>
                            </MDBCard>
                        </MDBCol>
                    ))}
                </MDBRow>
                <div className="d-flex justify-content-center mt-3">
                    <Pagination
                        activePage={activePage}
                        itemsCountPerPage={itemsPerPage}
                        totalItemsCount={petData.length}
                        pageRangeDisplayed={5}
                        onChange={handlePageChange}
                        itemClass="page-item"
                        linkClass="page-link"
                    />
                </div>
 
            </MDBContainer>
 
        </>
    )
}
 
export default Buy;

function dispatch(arg0: { type: string; payload: any; }) {
    throw new Error('Function not implemented.');
}
