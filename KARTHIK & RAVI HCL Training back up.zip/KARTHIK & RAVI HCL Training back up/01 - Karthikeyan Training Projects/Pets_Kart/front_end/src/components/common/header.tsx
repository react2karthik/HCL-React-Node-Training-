import React, { useState, useEffect } from 'react';
import {
  MDBNavbar,
  MDBBtn,
  MDBContainer, MDBNavbarBrand, MDBIcon, MDBNavbarItem, MDBNavbarLink
} from 'mdb-react-ui-kit';
import { Link, useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { deleteCartRequest } from '../../store/actions/deleteCartAction';

const headerImg = require('../../images/headerLogo.webp').default;

const Header: React.FC = (setPassIsLoggedIn: any) => {
  const dispatch = useDispatch();
  const cart = useSelector((state: any) => state?.addCartReducer?.data);
  const [cartCount, setCartCount] = useState(0);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const history = useHistory();
  console.log("jjjjjjjjjjjjjjjjjjjjjj", cart, cartCount)

  useEffect(() => {
    getHeader();
  }, [window.localStorage])

  useEffect(() => {
    axios.get('http://localhost:3001/cart')
      .then(response => {
        setCartCount(response.data.length);
      })
      .catch(error => {
        console.error('Error fetching pet data:', error);
      });
  }, [cart]);
  // useEffect(() => {
  //   const count = 
  //   setCartCount(8);
  // }, [cartCount])


  const clearCart = async () => {
    console.log('clear cart ??????????????????????????????????')
    await dispatch(deleteCartRequest())
  }
  const signOut = async() => {
    localStorage.clear();
    //window.location.href = '/';
    await clearCart();
    //history.push("/login");
  }
  const getHeader = () => {

    console.log(window.localStorage.getItem('name'), 'kkkkkkkkkkkkkkkkkkkk')
    if (window.localStorage.getItem('name') != null) {
      return <div>Welcome {window.localStorage.getItem('name')} !!
        <MDBBtn className='primary btn-sm' onClick={signOut}>Sign Out</MDBBtn>
        <div className='navStyle'>
          <MDBIcon fas icon="shopping-cart" value={cartCount} className='badge1' />
        </div>
      </div>

    } else {
      return null;
    }
  }
  return (
    <MDBNavbar light className='header'>
      <MDBContainer tag="form" fluid >
        <MDBNavbarBrand className='text-white'>
          <img src={headerImg} alt='Logo' height='90px' className='d-inline-block align-top me-2' />
          Pets Cart
        </MDBNavbarBrand>

        {getHeader()}


      </MDBContainer>
    </MDBNavbar>
  );
}

export default Header;
