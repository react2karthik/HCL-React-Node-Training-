import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCol, MDBRow, MDBInput, MDBCheckbox, MDBIcon } from 'mdb-react-ui-kit';
import { Formik, Field, Form, ErrorMessage } from 'Formik';
import AlertComponent from './common/alert';
import * as Yup from 'yup';
import { useHistory } from 'react-router';
import axios from 'axios';
import { addPetsRequest } from '../store/actions/addPetsAction';

const AddPets: React.FC = () => {
    const coun = useSelector((state: any) => state.addPetsReducer?.data);
    const dispatch = useDispatch();
    const history = useHistory();



    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alerttype, setAlertType] = useState('danger');
    const [drList, setDrList] = useState([]);

    // useEffect(() => {
    //     axios.get('http://localhost:3001/petDetails').then((res) => {
    //         const drNames = res.data.map((x: any) =>  <option value={x.drName}>{x.drName}  {`   -   [  ${x.expertIn}  ]`} </option>);
    //         setDrList(drNames);
    //     })
    // }, []);

    const initialValues = {
        petName: '',
        imageUrl: '',
        price: ''
    }
    const validationSchema = Yup.object({
        petName: Yup.string().required('Pet name is required'),
        imageUrl: Yup.string().required('Image Url is required'),
        price: Yup.string().required('Price is required')
    });

    const handleSubmit = async (values: any,{ resetForm }: { resetForm: () => void }) => {
        alert(JSON.stringify(values, null, 2));
        dispatch(addPetsRequest(values));
        setShowAlert(true);
        setAlertMessage('Pets added Succesfully!!');
        setAlertType('success');
        resetForm();
        setTimeout(() => {
            history.push('/buy')
        }, 2000);
        
    };

    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false); // Hide the alert after 2 minutes
        }, 3500);

        return () => clearTimeout(timer);
    }, [showAlert]);

    return (
        <>
            <div>
                {showAlert && (
                    <AlertComponent type={alerttype} message={alertMessage} />
                )}
                <h4 className='text-center mt-4 text-primary'>Add Pets..</h4>
                <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit} resetForm>
                    {({ values, handleChange }) => (
                        <Form>
                            <MDBContainer>
                                <MDBRow className='g-0'>
                                    <MDBCol md='12' className='mx-auto'>
                                        <MDBCard className='mx-2 mb-2 p-2 shadow-5'>
                                            <MDBCardBody className='text-black d-flex flex-column justify-content-center w-50 mx-auto'>
                                                <label htmlFor="petName" className='text-primary'>Pet Name *</label>
                                                <Field type="text" id="petName" name="petName" />
                                                <ErrorMessage name="petName" component="div" className="text-danger" />

                                                <label htmlFor="imageUrl" className='text-primary mt-2'>Image Url *</label>
                                                <Field type="text" id="imageUrl" name="imageUrl" />
                                                <ErrorMessage name="imageUrl" component="div" className="text-danger" />
                                                
                                                <label htmlFor="price" className='text-primary mt-2'>Price*</label>
                                                <Field type="text" id="price" name="price" />
                                                <ErrorMessage name="price" component="div" className="text-danger" />

                                                <MDBBtn className='w-100 mt-4 bg-gradient text-white' size="lg" type="submit">Book Appointment</MDBBtn>
                                            </MDBCardBody>
                                        </MDBCard>
                                    </MDBCol>
                                </MDBRow>
                            </MDBContainer>
                        </Form>
                    )}
                </Formik>
            </div>
        </>
    )
}

export default AddPets;