import axios from 'axios';
import { MDBBtn, MDBCard, MDBCardBody, MDBCol, MDBContainer, MDBIcon, MDBRow, MDBTable, MDBTableBody, MDBTableHead } from 'mdb-react-ui-kit';
import React, { useState, useEffect } from 'react';

const showCart: React.FC = () => {
    const [cartBuy, setCartBuy] = useState<any[]>([]);
    useEffect(() => {
        axios.get('http://localhost:3001/cart')
            .then(response => {
                setCartBuy(response.data);
            })
            .catch(error => {
                console.error('Error fetching pet data:', error);
            });
    }, []);
    return (
        <>
            <MDBContainer>
            <h6 className='text-center mt-4 text-primary'>Your Cart</h6>
                <MDBRow className="mt-2 g-0">
                    <MDBCol className="table-bordered ml-auto mt-2 mb-2" md='12'>
                        <MDBTable className="table-bordered border rounded-5" bordered borderColor="primary" responsive>
                            <MDBTableHead>
                                <tr>
                                    <th scope='col' className='fw-bold'>Image</th>
                                    <th scope='col' className='fw-bold'>Pet Name </th>
                                    <th scope='col' className='fw-bold'>Price</th>

                                </tr>
                            </MDBTableHead>
                            <MDBTableBody>
                                {cartBuy.map((cartBuy, index) => (
                                    <tr key={index}>
                                        <td className='fw-bold text-muted'><img src={cartBuy?.payload?.imageUrl} alt='Logo' height='90px' className='d-inline-block align-top me-2' /></td>
                                        <td className='fw-bold text-muted'>{cartBuy?.payload?.petName}</td>
                                        <td className='fw-bold text-muted'>{cartBuy?.payload?.price}</td>

                                    </tr>
                                ))}
                            </MDBTableBody>
                        </MDBTable>
                    </MDBCol>
                </MDBRow>
                <MDBRow>

                </MDBRow>

            </MDBContainer>
        </>
    )
}

export default showCart;