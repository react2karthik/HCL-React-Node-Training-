import { Request, Response, NextFunction } from "express";
import dotenv from 'dotenv';
import { UnAuthorizedAccess } from "../error/unAuthorizedError";
import constances from '../constants/constant';
import jwt from 'jsonwebtoken';

dotenv.config();

/**
 * authenticationMiddleware
 * 
 * this method is is used to authentication, authorization the loged-in user
 * @param req - any
 * @param res - response
 * @param next - next()
 */
const authenticationMiddleware = (req: any, res: Response, next: NextFunction) => {

    const token = req.header('Authorization');

    if (!token) {
        throw new UnAuthorizedAccess(constances.ACCESS_DENIED_MESSAGE, constances.ACCESS_DENIED_CODE);
    } else {
        const decoded: any = jwt.verify(token, process.env.SECRET_KEY || '');

        req.userId = decoded.userId;
        req.role = decoded.role;
        next();
    }
}

export default authenticationMiddleware;
