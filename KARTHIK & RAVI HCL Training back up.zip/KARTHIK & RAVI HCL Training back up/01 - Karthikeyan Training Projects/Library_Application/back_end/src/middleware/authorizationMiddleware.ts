import { Response, NextFunction } from "express";

function authorizationMiddleware(role: string) {
    return (req: any, res: Response, next: NextFunction) => {
        console.log(req);
        console.log("my id", req.userId, "role", role, "req role", req.role)
        if (req.role === role) {
            next();
        } else {
            res.set('Access-Control-Allow-Origin', '*');
            

            res.json({
                message: 'you dont have access to add books',
                statusCode: 403,
                status: 'failed'
            });
        }
    };
}

export default authorizationMiddleware;