import { Request, Response, NextFunction } from 'express'

interface IErrorObject {
    message: string,
    status: string,
    statusCode: number,
    data: null,
    path: string
}


//Error middleware
const errorMiddleware = (err: any, req: Request, res: Response, next: NextFunction) => {

    const errObj: IErrorObject = {
        message: err.message,
        status: 'failure',
        statusCode: err.statusCode,
        data: null,
        path: req.path
    }
    res.set('Access-Control-Allow-Origin', '*');
    res.json(errObj);
    next();
}
export default errorMiddleware;