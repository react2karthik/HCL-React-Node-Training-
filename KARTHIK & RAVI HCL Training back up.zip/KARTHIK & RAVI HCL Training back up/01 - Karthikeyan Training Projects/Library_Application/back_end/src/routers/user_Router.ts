import express, { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import logger from '../config/logger';
import { IUser, IBook } from '../modal/types';
import constances from '../constants/constant';
import userValidator from '../validators/userValidators';
import loginValidator from '../validators/loginValidators';
import authenticationMiddleware from '../middleware/authenticationMiddleware';
import authorizationMiddleware from '../middleware/authorizationMiddleware';
import { UnAuthorizedAccess } from '../error/unAuthorizedError';
import validateMiddleware from '../middleware/validateMiddleware';
import { login, createUser, addBooks, addBarrowBook, searchBooks } from '../services/user_Service';

dotenv.config();

const userRouter: express.Router = express.Router();

/**
 * Method: userRouter.get()
 * this GET method is used to generate auth token if credentials are valid.
 */
userRouter.post('/register', userValidator(), validateMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { name, email, password, phone } = req.body;

    try {
        const hassedPassword = await bcrypt.hash(password, 10);
        const userDetails : IUser = { name, email, hassedPassword, phone }
        const result = await createUser(userDetails);

        logger(path).info(constances.USER_PROFILE_ADDED_SUCCESS_MESSAGE);

        res.json({
            message: constances.USER_PROFILE_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.USER_ADDED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

userRouter.get('/search-book/:searchby/:searchtxt', async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { searchtxt, searchby} = req.params;
    try {

        const result: any = await searchBooks(searchby, searchtxt);
        
        logger(path).info(constances.USER_INTREST_POSTED_SUCCESS_MESSAGE);
        console.log('==========================',  searchby, searchtxt, result)
        if(result.rows) {
            res.json({
                data: result.rows,
                message: constances.USER_INTREST_POSTED_SUCCESS_MESSAGE,
                statusCode: constances.USER_INTREST_POSTED_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            });
        } else {
            res.json({
                message: constances.BOOK_SEARCH_FAIL_MESSAGE,
                statusCode: constances.BOOK_SEARCH_FAIL_CODE,
                status: constances.FAILED_MESAGE
            });
        }
    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

/**
 * Method: userRouter.get()
 * this GET method is used to generate auth token if credentials are valid.
 */
userRouter.post('/:admin/inventory/book', authenticationMiddleware, authorizationMiddleware('admin'), async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { admin } = req.params;
    console.log('dddddddddddddddddd', admin)
    const { author, book_name, category_name, quantity }: IBook = req.body;
    const bookDetails: IBook = { author, book_name, category_name, quantity };
console.log('bbbbbbbbbbbbbbbbbbbbbb', bookDetails)
    try {

        await addBooks(bookDetails);
        console.log('aaaaaaaaaaaaaaaaaa')
        logger(path).info(constances.USER_INTREST_POSTED_SUCCESS_MESSAGE);
        
        res.json({
            message: constances.USER_INTREST_POSTED_SUCCESS_MESSAGE,
            statusCode: constances.USER_INTREST_POSTED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

/**
 * Method: userRouter.get()
 * this GET method is used to generate auth token if credentials are valid.
 */
userRouter.post('/:user_id/book/:book_id', async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { user_id, book_id } = req.params;
    const { book_return_by } = req.body;

    try {

        await addBarrowBook(user_id, book_id);
        
        logger(path).info(constances.USER_INTREST_POSTED_SUCCESS_MESSAGE);
        
        res.json({
            message: constances.USER_INTREST_POSTED_SUCCESS_MESSAGE,
            statusCode: constances.USER_INTREST_POSTED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

/**
 * --------------------------------------------------------------------------
 * user router
 * this POST method is used to generate auth token if credentials are valid.
 * --------------------------------------------------------------------------
 */
userRouter.post('/login', loginValidator(), validateMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { email, password } = req.body;
    console.log('777777777777777777777777777777777777777777777777777mmm', req.body)
    const result = await login(email);
    console.log('777777777777777777777777777777777777777777777777777ppp')
    if (result.first() != null) {
        const { id, role, name } = result.first();
        const isMatching = await bcrypt.compare(password, result.first().get('password'));

        if (isMatching) {
            const token = jwt.sign({email, userId: id, role }, process.env.SECRET_KEY || '', { expiresIn: '1h' });
            
            logger(path).info(constances.USER_CREDENTIALS_SUCCESS_MESSAGE);
            res.set('Access-Control-Allow-Origin', '*');
            res.json({
                status: 'success',
                name,
                email,
                token
            })
        } else {
            res.json({
                message: constances.USER_NOT_EXIST_MESSAGE,
                statusCode: constances.USER_NOT_EXIST_CODE,
                status: constances.FAILED_MESAGE,
                data: email
            })
        }
    } else {
        logger(path).info(constances.USER_NOT_EXIST_MESSAGE);
        console.log('nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn')
        res.json({
            message: constances.USER_NOT_EXIST_MESSAGE,
            statusCode: constances.USER_NOT_EXIST_CODE,
            status: constances.FAILED_MESAGE,
            data: email
        })
    }
});

export default userRouter;