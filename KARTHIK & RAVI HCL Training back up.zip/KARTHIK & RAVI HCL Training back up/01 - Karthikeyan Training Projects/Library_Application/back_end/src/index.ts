import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import appLogger from './middleware/appLogger';
import printData from './middleware/printData';
import errorMiddleware from './middleware/errorMiddleware';
import userRouter from './routers/user_Router';

const app: express.Application = express();
dotenv.config();
const port = process.env.PORT || 4040;

app.use(express.json());
app.use(appLogger);
app.use(printData);
app.use(cors({origin: true, credentials: true}));
//app.use(cors());
// user routers
app.use('/users', userRouter);

// error middleware
app.use(errorMiddleware)

app.listen(port, () => {
    console.log(`---------------------------------- Server started at port number : ${port} ----------------------------------`);
});

export default app;




