/**
 * user data model
 */
export interface IUser {

    name: string,
    email: string,
    phone: number,
    hassedPassword: string,
}

/**
 * showingInterest data model
 */
export interface IBook {
    author: string,
    book_name: string,
    category_name: string,
    quantity: number
}

/**
 * data model
 */
export interface IData {
    name: string,
    interest_showed_on: string,
    status: string,
    comment: string,
    age: string
}        