
const constances = {
    SUCCESS_MESAGE: 'success',
    FAILED_MESAGE: 'failed',
    ACCESS_DENIED_MESSAGE: 'ACCESS DENIED', 
    ACCESS_DENIED_CODE: 232,
    

    USER_PROFILE_ADDED_SUCCESS_MESSAGE: 'User profile registed successfully',
    USER_ADDED_SUCCESS_CODE: 3001,

    USER_PROFILE_FETCHED_SUCCESS_MESSAGE: 'Users profile fetched successfully',
    USER_PROFILE_FETCHED_SUCCESS_CODE: 3002,

    USER_INTREST_POSTED_SUCCESS_MESSAGE: 'User intrest posted succeddfully',
    USER_INTREST_POSTED_SUCCESS_CODE: 3005,

    USER_STATUS_UPDATE_SUCCESS_MESSAGE: 'User status, comments Updated successfully', 
    USER_STATUS_UPDATE_SUCCESS_CODE: 3004,  

    USER_CREDENTIALS_SUCCESS_MESSAGE: 'User login credentials are valid',
    USER_CREDENTIALS_SUCCESS_CODE: 3012,

    USER_NOT_EXIST_MESSAGE: 'User login credentials are invalid',
    USER_NOT_EXIST_CODE: 3006,

    USER_UPDATE_FAIL_MESSAGE: 'Id not found in users table to update user details', 
    USER_UPDATE_FAIL_CODE: 3007, 

    BOOK_SEARCH_FAIL_MESSAGE: 'Book details not found for given search criteria', 
    BOOK_SEARCH_FAIL_CODE: 3020, 

    PROFILE_FECTHED_SUCCESS_MESSAGE: 'profile details fetched successfully',
    PROFILE_FECTHED_SUCCESS_CODE: 3016,

    OTP_API_URL: "https://prod-22.centralindia.logic.azure.com:443/workflows/067405cbeb4247ee8f7f271951d6a684/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=JMcI-3xRVFLRhOnmXgYlrnRRw9Lzql8oDzkcAOEGMus"
}

export default constances;