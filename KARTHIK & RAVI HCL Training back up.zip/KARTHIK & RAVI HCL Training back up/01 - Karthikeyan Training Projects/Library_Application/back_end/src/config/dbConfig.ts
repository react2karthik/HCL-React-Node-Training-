import dotenv from 'dotenv';
import { Client } from 'cassandra-driver';
dotenv.config();

const client = new Client({
    contactPoints: [process.env.HOST_NAME || '127.0.0.1'],
    localDataCenter: process.env.DATA_CENTER || 'datacenter1',
    keyspace: process.env.KEY_SPACE || 'library_application'
});

client.shutdown(() => {
    console.log('DataBase Shutdown Successfully !');
});

client.connect(() => {
    console.log('DataBase Connected Successfully ! ');
});

export default client;
