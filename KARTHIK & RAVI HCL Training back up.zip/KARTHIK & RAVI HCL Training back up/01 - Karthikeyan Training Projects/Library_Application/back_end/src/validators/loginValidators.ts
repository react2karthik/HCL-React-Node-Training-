import { body } from "express-validator";

/**
 * This loginValidator method is used to validate login credentials & retuns error messages array
 * email, password is require to login
 * 
 * @returns - error messages array
 */
const loginValidator = () => {
    return [
        body("email").exists().withMessage("email is required"),
        body("password").exists().withMessage("password is required"),
    ]
}

export default loginValidator;