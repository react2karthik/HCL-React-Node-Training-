import { body } from "express-validator";

/**
 * This loginValidator method is used to validate login credentials & retuns error messages array
 * email, password is require to login
 * 
 * @returns - error messages array
 */
const loginValidator = () => {
    return [
        body("author_name").exists().withMessage("email is required"),
        body("book_name").exists().withMessage("password is required"),
        body("category_name").exists().withMessage("password is required"),
        body("quantity").exists().withMessage("password is required")
    ]
}

export default loginValidator;