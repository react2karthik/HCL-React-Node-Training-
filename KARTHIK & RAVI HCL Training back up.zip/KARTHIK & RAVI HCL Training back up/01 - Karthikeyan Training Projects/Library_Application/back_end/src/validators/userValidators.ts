import { body } from "express-validator";

/**
 * This userValidator method is used to validate userObject() & retuns error messages array
 * name, customer_id, email, phone, password
 * 
 * @returns - error messages array
 */
const userValidator = () => {
    return [
        body("name").exists().withMessage("Name is required"),
        body("email").exists().withMessage("email is required"),
        body("phone").exists().withMessage("phone is required"),
        body("password").exists().withMessage("password is required")
    ]
}

export default userValidator;