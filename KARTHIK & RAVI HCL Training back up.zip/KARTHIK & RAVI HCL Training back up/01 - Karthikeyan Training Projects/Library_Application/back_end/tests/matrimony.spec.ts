import assert from "assert";
import { expect } from "chai";
import sinon, { SinonSpy, SinonStub } from 'sinon';
import { describe } from "mocha";
import axios from "axios";
import nock from "nock";

let generateToken: any = {};
const baseUrl: string = 'http://localhost:3030/';
describe('fetch login api token', () => {

    it('POST: login A with credentials', async () => {
        let mockPostData = {
            email: "1mail@gmail.com",
            password: "password1"
        }
        await axios.post('http://localhost:3030/users/login', mockPostData).then((response) => {
            generateToken = response;
            assert.equal(generateToken.status, 200);
        })
    });

    it('POST: user register API Data', async () => {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${generateToken.data.data}`
        }
        let body = {
            name: "testuser",
            gender: "male",
            dob: "1991-09-16",
            qualification: "MCA",
            phone: 7604932489,
            email: "test@gmail.com",
            password: "test",
            occupation: "business"
        }
        await axios.post('http://localhost:3030/users/register', body, { headers: headers }).then((response) => {
            assert.equal(response.data.message, 'User profile registed successfully');
            assert.equal(response.data.statusCode, 3001);
        })
    })

    it('GET: get all profile API Data', async () => {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': generateToken.data.data
        }

        let result = await axios.get('http://localhost:3030/profiles/', { headers: headers })
            .then((response) => {
                assert.equal(response.data.message, 'profile details fetched successfully');
                assert.equal(response.data.status, 'Success');
                assert.equal(response.data.statusCode, 3016);
            })

    });

    it('Authorisation key not passed', async () => {
        const headers = {
            'Content-Type': 'application/json',
        };

        try {
            const response = await axios.get('http://localhost:3030/profiles', { headers });
        } catch (error: any) {
            assert.equal(error.response.data.status, 'failure');
            assert.equal(error.response.data.message, 'ACCESS DENIED');
            assert.equal(error.response.data.statusCode, 232);
        }
    });

    it('Authorisation key not passed using nock', async () => {
        const headers = {
            'Content-Type': 'application/json',
        };

        try {
            const response = await axios.get('http://localhost:3030/profiles', { headers });
        } catch (error: any) {
            assert.equal(error.response.data.status, 'failure');
            assert.equal(error.response.data.message, 'ACCESS DENIED');
            assert.equal(error.response.data.statusCode, 232);
        }
    });

    it('Authorisation key not passed using nock', async () => {
        const headers = {
            'Content-Type': 'application/json',
        };
        const respData = { message: "Unauthoriza Error", status: "Failed", statusCode: 1005 }
        nock(baseUrl).get('/profiles').reply(200, respData);
    })
})