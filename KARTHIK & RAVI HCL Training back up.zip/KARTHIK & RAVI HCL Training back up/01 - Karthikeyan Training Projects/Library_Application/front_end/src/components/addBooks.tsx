import React, { useState, useEffect } from 'react';
import { IBooks } from '../model/types';
import { MDBBtn, MDBInput } from 'mdb-react-ui-kit';
import { useHistory } from 'react-router-dom';
import LibraryService from '../services/libraryService';
import AlertComponent from '../components/common/alert';


import Header from './common/Header';

const AddBooks: React.FC = () => {
    const history = useHistory();
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alerttype, setAlertType] = useState('danger');
    const [validationErrors, setValidationErrors] = useState<any>({});


    const [books, setBookValue] = useState<IBooks>({
        author: '',
        book_name: '',
        category_name: '',
        quantity: ''
    })


    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false); // Hide the alert after 2 minutes
        }, 3500);

        return () => clearTimeout(timer);
    }, [showAlert]);

    const [isLoggedIn, setIsLoggedIn] = useState(true);
    //const navigate = useNavigate();


    const handleSignOut = () => {
        // Implement sign out logic here
        setIsLoggedIn(false);
        //navigate('/Register')
    };

    const handleBookChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        setBookValue({ ...books, [e.target.name]: e.target.value })
    }
  
    const onAddBooksClick = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
        e.preventDefault();
        const errors: any = {};
        console.log(JSON.stringify(books));

        if (!books.author.trim()) {
            errors.author = "Author name is required";
        } 
        if (!books.book_name.trim()) {
            errors.book_name = "Book Name is required";
        }
        if (!books.category_name.trim()) {
            errors.category_name = "Category Name is required";
        }
        if (!books.quantity) {
            errors.quantity = "Quantity is required";
        }

        setValidationErrors(errors);

        if (Object.keys(errors).length === 0 && errors.constructor === Object) {

            await serviceAddBooks(books);
        }
    }

    const serviceAddBooks = async (data: any) => {

        // const loginData = {
        //     email: data.loginEmail,
        //     password: data.loginPassword
        // }

        try {
            //const data = { /* Your data object here */ };
            const response = await LibraryService.addBooks(JSON.stringify(data));
            console.log('nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn', response.data.status)
            if (response && response.data?.status && response.data?.status == 'success') {
                
                setAlertType('success');
                setAlertMessage(response.data.message);
                setShowAlert(true);
            } else if (response && response?.data?.status && response?.data?.status == 'failed') {
                console.log('xxxxxxxxxxxxxxxxxxxxxsssssssssssssssssss', response.data.status);

                setAlertType('danger');
                setAlertMessage(response.data.message);
                setShowAlert(true);

            }

        } catch (error) {
            // Handle error
            console.error('Error while posting data:', error);
            return error;
        }
    };

    return (
        <div >
            <Header onSignOut={handleSignOut} />
            {showAlert && (
                <AlertComponent type={alerttype} message={alertMessage} />
            )}
            <div className='col-md-4 mt-4 offset-4'>

            <h4>Add Books </h4>
            <form onSubmit={onAddBooksClick}>
                <MDBInput className='mb-4' value={books.author} name='author' id='author' label='Author *' onChange={handleBookChange} />
                {validationErrors.author && <p className="text-danger">{validationErrors.author}</p>}
                
                <MDBInput className='mb-4' value={books.book_name} name='book_name' id='book_name' label='Book Name *' onChange={handleBookChange} />
                {validationErrors.email && <p className="text-danger">{validationErrors.book_name}</p>}
                
                <MDBInput className='mb-4' value={books.category_name} name='category_name' id='category_name' label='Category Name *' onChange={handleBookChange} />
                {validationErrors.password && <p className="text-danger">{validationErrors.category_name}</p>}
                
                <MDBInput className='mb-4' value={books.quantity} name='quantity' id='quantity' label='quantity *' onChange={handleBookChange} />
                {validationErrors.quantity && <p className="text-danger">{validationErrors.quantity}</p>}

                <MDBBtn type='submit' className='mb-4' block>
                    Add books
                </MDBBtn>
            </form>
            </div>
        </div>
    )

}

export default AddBooks;