import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useApiContext } from '../components/context/contest';
import {
    MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCardImage, MDBRow, MDBCol, MDBInput, MDBCheckbox,
    MDBTabs, MDBTabsItem, MDBTabsLink, MDBTabsContent, MDBTabsPane, MDBValidationItem
} from 'mdb-react-ui-kit';
import LibraryService from '../services/libraryService';
import AlertComponent from '../components/common/alert';
import * as Yup from 'yup';
import { Formik, Field, Form, ErrorMessage, useFormik } from 'Formik';
import { LoginSubmitForm, RegisterSubmitForm } from '../model/types'
const childImg = require('../images/child.jpg').default;


const Register = () => {
    const history = useHistory();
    //const history = useHistory();
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');

    const [alerttype, setAlertType] = useState('danger');
    const [validationErrors, setValidationErrors] = useState<any>({});
    const [login, setLoginValue] = useState<LoginSubmitForm>({
        loginEmail: '',
        loginPassword: ''
    });

    const [register, setRegisterValue] = useState<RegisterSubmitForm>({
        name: '',
        email: '',
        password: '',
        repeatPassword: '',
        mobile: '',
    })


const validationRegister = Yup.object({
        name: Yup.string().required('Name is required'),
        email: Yup.string().required('Eamil is required').email(),
        password: Yup.string().required('Password is required').min(6).max(40),
        phone: Yup.string().required('Phone number is required').max(10)
    })
 

const registerFormik = useFormik({
        initialValues: {
            name: '',
            email: '',
            password: '',
            phone: ''
        },
        onSubmit: values => {
            alert(JSON.stringify(values, null, 2));
        },
    });
    const intValue = {
        email: '',
        password: ''
    }
    const validSeg = Yup.object({
        email: Yup.string().required('Eamil is required').email(),
        password: Yup.string().required('Password is required').min(6).max(40)
    })

    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false); // Hide the alert after 2 minutes
        }, 3500);

        return () => clearTimeout(timer);
    }, [showAlert]);

    const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        setLoginValue({ ...login, [e.target.name]: e.target.value })
    }

    const handleRegisterChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        setRegisterValue({ ...register, [e.target.name]: e.target.value })
    }

    const [activeTab, setActiveTab] = useState('login');

    const { teamColor, setTeamColor } = useApiContext();
    const { textTeamColor, setTextTeamColor } = useApiContext();
    const changeColor = (color: string) => {
        setTeamColor(color);
    };
    const handleTabClick = (value: string) => {
        if (value === activeTab) {
            return;
        }
        setValidationErrors({});
        setActiveTab(value);
    };

    const onLoginClick = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
        e.preventDefault();
        const errors: any = {};
        console.log(JSON.stringify(login));

        if (!login.loginEmail.trim()) {
            errors.loginEmail = "Email is required";
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(login.loginEmail)) {
            errors.loginEmail = "Email is not valid";
        }
        if (!login.loginPassword) {
            errors.loginPassword = "Password is required";
        } else if (login.loginPassword.length < 1) {
            errors.loginPassword = "Password should be at least 6 characters";
        }

        setValidationErrors(errors);

        if (Object.keys(errors).length === 0 && errors.constructor === Object) {

            await servicePost_Login(login);
        }
    }

    const servicePost_Login = async (data: any) => {

        const loginData = {
            email: data.loginEmail,
            password: data.loginPassword
        }

        try {
            //const data = { /* Your data object here */ };
            const response = await LibraryService.login(JSON.stringify(loginData));
            console.log('nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn')
            if (response && response.data?.status && response.data?.status == 'success') {
                localStorage.setItem('token', response.data.token);
                localStorage.setItem('email', response.data.email);
                localStorage.setItem('name', response.data.name);
                history.push('/borrowedBooks');
                console.log('login', response.data.token)
            } else if (response && response?.data?.status && response?.data?.status == 'failed') {
                console.log('xxxxxxxxxxxxxxxxxxxxxsssssssssssssssssss', response.data.status);
                setAlertType('danger');
                setAlertMessage(response.data.message);
                setShowAlert(true);

            }

        } catch (error) {
            // Handle error
            console.error('Error while posting data:', error);
            return error;
        }
    };

    const servicePost_Register = async (data: any) => {

        const registerData = {
            name: data.name,
            email: data.email,
            password: data.password,
            phone: data.mobile
        }

        try {
            //const data = { /* Your data object here */ };
            const response = await LibraryService.register(JSON.stringify(registerData));
            console.log('///////////////', response.data.status);

            if (response && response.data.status == 'success') {
                //localStorage.setItem("token", response.data.token);
                console.log('ddddddddddddddddddddLLLLLLLLLLLLLLLLLLLLLL');
                setAlertMessage("User registration succefuly now login.");
                setRegisterValue({ name: '', email: '', password: '', repeatPassword: '', mobile: '' });
                setAlertType('success');
                setShowAlert(true);
                handleTabClick('login')
                console.log('register', response.data.state);

            }
        } catch (error) {
            // Handle error
            setAlertMessage("Email and password are required.");
            setShowAlert(true);
            console.error('Error while posting data:', error);
            return error;
        }
    };

    const onRegisterClick = async (value: any) => {
  
        const errors: any = {};
        console.log(JSON.stringify(login));

        if (!register.name) {
            errors.name = "Name is required";
        }
        if (!register.email.trim()) {
            errors.email = "Email is required";
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(register.email)) {
            errors.email = "Email is not valid";
        }
        if (!register.password) {
            errors.password = "Password is required";
        } else if (register.password.length < 6) {
            errors.password = "Password should be at least 6 characters";
        }
        if (!register.repeatPassword) {
            errors.repeatPassword = "Repeat Password is required";
        }
        if (register.password != register.repeatPassword) {
            errors.repeatPassword = "Password & Repeat Password must be same";
        }
        if (!register.mobile) {
            errors.mobile = "Mobile number is required";
        }

        setValidationErrors(errors);

        if (Object.keys(errors).length === 0 && errors.constructor === Object) {
            console.log('came here11111111111111111111111111')
            await servicePost_Register(register);
        }
    }
    return (
        <div>
            {showAlert && (
                <AlertComponent type={alerttype} message={alertMessage} />
            )}
            <MDBContainer fluid className='h-100'>
                <MDBRow className='d-flex justify-content-center align-items-center h-100'>
                    <MDBCol>
                        <MDBCard className='my-4'>
                            <MDBRow className='g-0'>
                                <MDBCol md='8' className="d-none d-md-block">
                                    <MDBCardImage src={childImg} alt="Sample photo" className="rounded-start" fluid />
                                </MDBCol>
                                <MDBCol md='4'>
                                    <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                                        <h3 className="mb-5 text-uppercase fw-bold">Library Management</h3>
                                        <div>
                                            <MDBTabs pills justify className='mb-3'>
                                                <MDBTabsItem>
                                                    <MDBTabsLink
                                                        onClick={() => handleTabClick('login')}
                                                        active={activeTab === 'login'}
                                                    >
                                                        Login
                                                    </MDBTabsLink>
                                                </MDBTabsItem>
                                                <MDBTabsItem>
                                                    <MDBTabsLink
                                                        onClick={() => handleTabClick('register')} active={activeTab === 'register'}
                                                    >
                                                        Register
                                                    </MDBTabsLink>
                                                </MDBTabsItem>
                                            </MDBTabs>
                                            <MDBTabsContent>
                                                <MDBTabsPane open={activeTab === 'login'}>
                                                    <Formik initialValues={intValue} validationSchema={validSeg} onSubmit={(values, actions) => { onLoginClick }}>
                                                        {({ values, handleChange }) => (
                                                            <form>

                                                                <MDBContainer fluid className='h-100'>
                                                                    <MDBRow className='g-0'>
                                                                        <MDBCol md='12'>
                                                                            <MDBCard className='my-4' style={{ backgroundColor: teamColor, color: textTeamColor }}>
                                                                                <MDBRow className='g-0'>
                                                                                    <MDBCol md='12'>

                                                                                        {showAlert && (
                                                                                            <AlertComponent type="danger" message={alertMessage} />
                                                                                        )}

                                                                                        <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                                                                                            <label htmlFor="email">Email</label>
                                                                                            <Field type="text" id="email" name="email" onChange={handleChange('email')} className='mb-4' />
                                                                                            <ErrorMessage name="email" component="div" className="text-danger" />
                                                                                            <label htmlFor="email">Password</label>
                                                                                            <Field type="text" id="password" name="password" onChange={handleChange('password')} className='mb-4' />
                                                                                            <ErrorMessage name="password" component="div" className="text-danger" />
                                                                                            <div className="d-flex justify-content-center align-items-center mt-2">
                                                                                                <MDBBtn type='submit' className="bg-success bg-gradient text-white">
                                                                                                    Sign in
                                                                                                </MDBBtn>

                                                                                            </div>
                                                                                        </MDBCardBody>
                                                                                    </MDBCol>
                                                                                </MDBRow>

                                                                            </MDBCard>
                                                                        </MDBCol>
                                                                    </MDBRow>
                                                                </MDBContainer>
                                                            </form>
                                                        )}
                                                    </Formik>
                                                    {/* <form onSubmit={onLoginClick}>

                                                        <MDBInput className='mb-4' type='text' value={login.loginEmail} name='loginEmail' id='loginEmail' label='Email address *' onChange={handleLoginChange} />
                                                        {validationErrors.loginEmail && <p className="text-danger">{validationErrors.loginEmail}</p>}

                                                        <MDBInput className='mb-4' type='password' value={login.loginPassword} name='loginPassword' id='loginPassword' label='Password *' onChange={handleLoginChange} />
                                                        {validationErrors.loginPassword && <p className="text-danger">{validationErrors.loginPassword}</p>}
                                                        <MDBRow className='mb-4'>
                                                            <MDBCol className='d-flex justify-content-center'>
                                                                <MDBCheckbox id='loginRememberMe' label='Remember me' defaultChecked />
                                                            </MDBCol>
                                                            <MDBCol>
                                                                <a href='#!'>Forgot password?</a>
                                                            </MDBCol>
                                                        </MDBRow>
                                                        <MDBBtn type='submit' className='mb-4' block>
                                                            Sign in
                                                        </MDBBtn>
                                                        <div className='text-center'>
                                                            <p>
                                                                Not a member? <a href='#!'>Register</a>
                                                            </p>
                                                        </div>
                                                    </form> */}
                                                </MDBTabsPane>
                                                <MDBTabsPane open={activeTab === 'register'}>
                                                    <Formik initialValues={registerFormik.initialValues} validationSchema={validationRegister} onSubmit={onRegisterClick}>
                                                        {({ values, handleChange }) => (
                                                            <Form>
                                                                <MDBContainer fluid className='h-100'>
                                                                    <MDBRow className='g-0'>
                                                                        <MDBCol md='12'>
                                                                            <MDBCard className='my-4'>

                                                                                <MDBRow className='g-0'>

                                                                                    <MDBCol md='12'>
                                                                                      
                                                                                        <MDBCardBody className='text-black d-flex flex-column justify-content-center'>

                                                                                            <label htmlFor="name">Name *</label>
                                                                                            <Field type="text" id="name" name="name" className='mb-4' />
                                                                                            <ErrorMessage name="name" component="div" className="text-danger" />
                                                                                            <label htmlFor="email">Email *</label>
                                                                                            
                                                                                            <Field type="text" id="email" name="email" className='mb-4' />
                                                                                            <ErrorMessage name="email" component="div" className="text-danger" />
                                                                                            <label htmlFor="password">Password *</label>
                                                                                            <Field type="text" id="password" name="password" className='mb-4' />
                                                                                            <ErrorMessage name="password" component="div" className="text-danger" />
                                                                                            <label htmlFor="phone">Phone *</label>
                                                                                            <Field type="text" id="phone" name="phone" className='mb-4' />
                                                                                            <ErrorMessage name="phone" component="div" className="text-danger" />
                                                                                            
                                                                                            <div className="d-flex justify-content-center align-items-center mt-4">

                                                                                                <MDBBtn type='submit' className="mx-1 bg-success bg-gradient text-white">
                                                                                                    Add Register
                                                                                                </MDBBtn>
                                                                                            </div>
                                                                                        </MDBCardBody>
                                                                                    </MDBCol>
                                                                                </MDBRow>

                                                                            </MDBCard>
                                                                        </MDBCol>
                                                                    </MDBRow>
                                                                </MDBContainer>
                                                            </Form>
                                                        )}
                                                    </Formik>
                                                    {/* <form onSubmit={onRegisterClick}>
                                                        <MDBInput className='mb-4' value={register.name} name='name' id='registerName' label='Name *' onChange={handleRegisterChange} />
                                                        {validationErrors.name && <p className="text-danger">{validationErrors.name}</p>}
                                                        <MDBInput className='mb-4' value={register.email} name='email' id='registerEmail' label='Email address *' onChange={handleRegisterChange} />
                                                        {validationErrors.email && <p className="text-danger">{validationErrors.email}</p>}
                                                        <MDBInput className='mb-4' value={register.password} name='password' type='password' id='registerPassword' label='Password *' onChange={handleRegisterChange} />
                                                        {validationErrors.password && <p className="text-danger">{validationErrors.password}</p>}
                                                        <MDBInput className='mb-4' value={register.repeatPassword} name='repeatPassword' type='password' id='registerConformPassword' label='Repeat password *' onChange={handleRegisterChange} />
                                                        {validationErrors.repeatPassword && <p className="text-danger">{validationErrors.repeatPassword}</p>}
                                                        <MDBInput className='mb-4' value={register.mobile} name='mobile' id='registerMobile' label='Mobile *' onChange={handleRegisterChange} />
                                                        {validationErrors.mobile && <p className="text-danger">{validationErrors.mobile}</p>}
                                                        <MDBCheckbox
                                                            wrapperClass='d-flex justify-content-center mb-4'
                                                            id='registerCheckbox'
                                                            label='I have read and agree to the terms'
                                                            defaultChecked
                                                        />
                                                        <MDBBtn type='submit' className='mb-4' block>
                                                            Sign in
                                                        </MDBBtn>
                                                    </form> */}
                                                </MDBTabsPane>
                                            </MDBTabsContent>
                                        </div>
                                    </MDBCardBody>
                                </MDBCol>
                            </MDBRow>
                        </MDBCard>
                    </MDBCol>
                </MDBRow>
            </MDBContainer>
        </div>
    );
}

export default Register;