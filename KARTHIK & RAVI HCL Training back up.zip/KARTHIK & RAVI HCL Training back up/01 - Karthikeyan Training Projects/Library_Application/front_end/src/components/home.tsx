import React from "react";
import { useHistory } from 'react-router-dom';
const libraryImg = require('../images/homeLibrary.jpg').default;

export default function Home() {
  const history = useHistory();
  const onContinueClick = () => {
    history.push('/login');
  }
  return (
    <div className="p-5 text-center bg-image rounded-3" style={{ backgroundImage: `url(${libraryImg})`, height: 800 }}>
      <div className="mask" style={{ backgroundColor: 'rgba(0, 0, 0, 0.6)' }}>
        <div className="d-flex justify-content-center align-items-center h-100">
          <div className="text-white">
            <h1 className="mb-3">WELCOME TO OUR LIBRARY</h1>
            <br/>
            <h4 className="mb-3">Subheading</h4>
            <a className="btn btn-outline-light btn-lg" href="#!" role="button" onClick={onContinueClick}>let's continue</a>
          </div>
        </div>
      </div>
    </div>
  )
};
