import React, { useState } from 'react';
import { IBookModuls } from '../model/types';
import { MDBTable, MDBTableHead, MDBTableBody, MDBContainer, MDBBtn, MDBRow, MDBCol } from 'mdb-react-ui-kit';
import { MDBDropdown, MDBDropdownMenu, MDBDropdownToggle, MDBDropdownItem } from 'mdb-react-ui-kit';
const data = require('../jsonData/bookData.json');
import Header from './common/Header';


const SearchBooks: React.FC = () => {
    const usersBook: any = data;

    const [bookData, setbookData] = useState(usersBook);
    const [searchTxt, setSearchTxt] = useState('');
    const [isLoggedIn, setIsLoggedIn] = useState(true);
    //const navigate = useNavigate();
  
    const handleSignOut = () => {
      // Implement sign out logic here
      setIsLoggedIn(false);
      //navigate('/Register')
    };

    const handleItemClick = async (booksItems: string) => {
        // console.log('booksItems 888888888888', booksItems, bookData);
        // const filteredByBooks = bookData.filter(book => book.author == 'Ashu');
        // console.log('1111111111111111111111122222222222222222222', filteredByBooks);
        // setbookData(filteredByBooks);
    };

    const typeChange = () => {
        const e: any = document.getElementById("searchType");


        var value = e.options[e.selectedIndex].value;
        console.log(value)
    }


    const onSearchChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        if (e.target.value == '') setbookData(usersBook);
        setSearchTxt(e.target.value);
        console.log(e.target.value);
    }
    const onSearchClick = async () => {
        const e: any = document.getElementById("searchType");


        const x = e.options[e.selectedIndex].value;
        let filteredData;

        filteredData = bookData.filter((book: any) => { return book[x].toLowerCase() == searchTxt.toLowerCase() });
        setbookData(filteredData);
    };

    //-------------------------
    const pageSize = 5;
    const [currentPage, setCurrentPage] = useState(1);

    // Calculate the indexes of the current page
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, bookData.length);

    // Get the data for the current page
    const currentData = bookData.slice(startIndex, endIndex);
    console.log('1111111111111111111111111', currentData);
    // Handler for changing the page
    const onPageChange = (page: number) => {
        setCurrentPage(page);
    };
    //-------------------------------
    return (
        <>

            {/* <div className='d-flex'>

                <div className="container">
                    <div className="row mt-5">
                        <div className="col-md-6 offset-md-3">

                            <div className='d-flex'>
                                <div>

                                    <select className="form-select form-select-lg mb-3 w-100" aria-label=".form-select-lg example" id="searchType" onChange={() => typeChange()}>
                                        <option value="0">Select Search By Type</option>
                                        <option value="author">author</option>
                                        <option value="book_name">book_name</option>
                                        <option value="category_name">category_name</option>
                                    </select>
                                </div>
                                <div className="input-group mb-3">
                                    <input onChange={(e) => onSearchChange(e)} type="text" className="form-control" placeholder="Search..." aria-label="Search" aria-describedby="basic-addon2" />
                                    <button onClick={onSearchClick} type="button" id="search" className="btn btn-outline-secondary">
                                        <i className="material-icons">search</i>
                                    </button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div> */}
            <div>
                <Header onSignOut={handleSignOut} />
                <MDBContainer fluid>
                    <MDBRow className="mt-5 g-0">
                        <MDBCol className="offset-md-3" md='6'>
                            <div className='d-flex align-items-center'>
                                <>
                                    <select className="btn btn-primary dropdown-toggle px-2" aria-label=".form-select-lg example" id="searchType" onChange={() => typeChange()}>
                                        <option value="0">Select Search By Type</option>
                                        <option value="author">author</option>
                                        <option value="book_name">book_name</option>
                                        <option value="category_name">category_name</option>
                                    </select>
                                </>
                                <div className="input-group mx-2">
                                    <input onChange={(e) => onSearchChange(e)} type="text" className="form-control" placeholder="Search..." aria-label="Search" aria-describedby="basic-addon2" />
                                    <button onClick={onSearchClick} type="button" id="search" className="btn btn-primary">
                                        <i className="material-icons">search</i>
                                    </button>
                                </div>
                            </div>
                        </MDBCol>
                    </MDBRow>
                </MDBContainer>


                <MDBTable>
                    <MDBTableHead>
                        <tr>
                            <th scope='col'>Book id</th>
                            <th scope='col'>Author</th>
                            <th scope='col'>Book Name</th>
                            <th scope='col'>Category Name</th>
                            <th scope='col'>Quantity</th>
                        </tr>
                    </MDBTableHead>
                    <MDBTableBody>
                        {currentData?.map((user: any, index: number) => (
                            <tr key={index}>
                                <td>{user?.book_id}</td>
                                <td>{user?.author}</td>
                                <td>{user?.book_name}</td>
                                <td>{user?.category_name}</td>
                                <td>{user?.quantity}</td>
                            </tr>
                        ))}
                    </MDBTableBody>
                </MDBTable>
                <nav aria-label='Page navigation example'>
                    <ul className='pagination justify-content-center'>
                        <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                            <button className='page-link' onClick={() => onPageChange(currentPage - 1)} tabIndex={-1} disabled={currentPage === 1}>
                                Previous
                            </button>
                        </li>
                        {/* Render page numbers */}
                        {[...Array(Math.ceil(bookData.length / pageSize)).keys()].map((page) => (
                            <li key={page} className={`page-item ${currentPage === page + 1 ? 'active' : ''}`}>
                                <button className='page-link' onClick={() => onPageChange(page + 1)}>
                                    {page + 1}
                                </button>
                            </li>
                        ))}
                        <li className={`page-item ${currentPage === Math.ceil(bookData.length / pageSize) ? 'disabled' : ''}`}>
                            <button className='page-link' onClick={() => onPageChange(currentPage + 1)}>
                                Next
                            </button>
                        </li>
                    </ul>
                </nav>
            </div>
        </>
    )
}

export default SearchBooks