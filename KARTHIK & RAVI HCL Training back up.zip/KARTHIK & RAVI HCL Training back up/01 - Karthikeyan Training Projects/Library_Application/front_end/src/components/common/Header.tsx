import React, { useState, useEffect } from 'react';
import { MDBIcon } from 'mdb-react-ui-kit';
import '../css/header.css';
import FloatingNavBar from './floatingNavBar';

const Header = ({ onSignOut }: any) => {
  //const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSignOutOpen, setIsSignOutOpen] = useState(false);
  const [className, setClassName] = useState('x');

  useEffect(() => {
    // Your effect logic
  }, [isMenuOpen]);

  // Function to toggle menu visibility
  const toggleMenu = () => {
    const newClassName = className === 'x' ? 'floater' : 'x';
    setClassName(newClassName);
    setIsMenuOpen(!isMenuOpen);
    console.log(isMenuOpen)
  };
  const toggleSignOut = () => {
    setIsSignOutOpen(!isSignOutOpen);
    console.log(isSignOutOpen)
  };
  const signOut = () => {
    toggleSignOut();
    //navigate('/') 
  };
  const getMessage = () => {
    let time = new Date().getHours();
    return ', Good ' + (time < 12 ? 'Morning' : time < 18 ? 'Afternoon' : 'Evening');
  }

  return (
    <header style={styles.header}>

      {/* {isMenuOpen && (<div className="floater"><FloatingNavBar /><MDBIcon className='ms-1' icon='angle-double-left' size='2x' onClick={toggleMenu} /></div>)} */}
      {/* {isMenuOpen && (<div className={className}><FloatingNavBar /><MDBIcon className='ms-1' icon='angle-double-left' size='2x' onClick={toggleMenu} /></div>)}
      {!isMenuOpen && (<MDBIcon className='ms-1' icon='angle-double-right' size='2x' onClick={toggleMenu} />)} */}
      <div className={className}><FloatingNavBar /><MDBIcon className='ms-1' icon='angle-double-left' size='2x' onClick={toggleMenu} /></div>

      <div className="y">
        <MDBIcon className='ms-1' icon='angle-double-right' size='2x' onClick={toggleMenu} />
        <h3 style={styles.logo}>Library management</h3>
      </div>
      <div className='d-flex align-items-center' style={styles.avatarDiv}>
        <img
          src='https://mdbootstrap.com/img/new/avatars/8.jpg'
          style={{ width: '45px', height: '45px' }}
          className='rounded-circle'
          onClick={toggleSignOut}
        />
        {isSignOutOpen && (
          <div className="menu">

            <button className="dropdown-item p-2 bg-body-secondary" onClick={signOut} type="button">Sign out !!</button>

          </div>)}
        <div className='ms-3'>
          <p className='fw-bold mb-1'> Hi ! {localStorage.getItem('name')} {getMessage()}</p>
          <p className='text-muted mb-0'>{localStorage.getItem('email')}</p>
        </div>
      </div>

    </header>
  );
};

const styles = {

  avatarDiv: {
    marginLeft: 'auto'
  },
  header: {
    border: '1px solid red',
    backgroundColor: '#e6e6e6',
    color: '#000000',
    padding: '10px',
    display: 'flex',
    // justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    margin: 15,
  },
  // signOutButton: {
  //   backgroundColor: '#fff',
  //   color: '#333',
  //   border: 'none',
  //   padding: '5px 10px',
  //   borderRadius: '5px',
  //   cursor: 'pointer',
  //   fontSize: '1em',
  // },
};

export default Header;