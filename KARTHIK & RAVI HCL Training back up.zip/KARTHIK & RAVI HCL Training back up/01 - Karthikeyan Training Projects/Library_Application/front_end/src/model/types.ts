export interface IBookModuls {
    author: string,
    book_id: number,
    book_name: string,
    category_name: string,
    quantity: number
}

export interface IAlert {
    type: string;
    message: string;
}

export interface IBooks {
    author: string;
    book_name: string;
    category_name: string;
    quantity: number | string;
};

export interface LoginSubmitForm {
    loginEmail: string;
    loginPassword: string;
};

export interface RegisterSubmitForm {
    name: string;
    email: string;
    password: string;
    repeatPassword: string;
    mobile: any;

};