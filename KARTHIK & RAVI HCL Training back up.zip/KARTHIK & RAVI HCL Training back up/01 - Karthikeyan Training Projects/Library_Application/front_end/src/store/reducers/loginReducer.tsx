import { LOGIN_SUCCESS, LOGIN_FAILED} from '../actions/loginAction'; 

// Define the initial state interface
export interface loginState {
  data: any; // Define the structure of your state
}

// Define the initial state
const initialState: loginState = {
  data: null
};

// Define the reducer function
const loginReducer = (state: loginState = initialState, action:any) => {
  switch (action.type) {
    case LOGIN_SUCCESS:
      return {
        ...state,
        data: action.payload, 
      };
    case LOGIN_FAILED:
      return {
        ...state,
        data: null, // Reset the state data in case of failure
      };
    default:
      return state; // Return the current state for any other action
  }
};

export default loginReducer;
