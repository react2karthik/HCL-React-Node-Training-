
import { call, put, takeLatest } from 'redux-saga/effects'; //takeevery
import { LOGIN, LOGIN2, loginSuccess, loginFailed } from '../actions/loginAction';
import { LOGINAPI } from '../../constant';
import callApi from '../../services';

function* login(data: any):Generator<any, void, any> {
  try {
    console.log('data >>>>>>>>>>>>>>>>>>', data);
    const response:any = yield call(callApi, LOGINAPI, data.payload, 'get'); 
    yield put(loginSuccess(response));
  } catch (error) {
    yield put(loginFailed(error));
  }
}

function* loginSaga() {
  yield takeLatest(LOGIN2, login);
}

export default loginSaga;

