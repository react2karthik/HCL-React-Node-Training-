import React from "react";
import Register from './components/register';
import Home from './components/home';
import BorrowedBooks from './components/borrowedBooks';
import SearchBooks from './components/searchBooks';
import AddBooks from './components/addBooks'
import { ContextApiProvider, useApiContext } from './components/context/contest';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
const PrivateRoute: React.FC<{ path: string, component: React.FC }> = ({ path, component }) => {    
    const { isAuthenticated } = useApiContext();console.log('0------------',isAuthenticated);
    return isAuthenticated ? <Route path={path} component={component} /> :   <Redirect to="/" />;
    console.log('6666666666666666666666---')
};
// import { BrowserRouter,Routes,Route } from "react-router-dom";
// import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';



// import UseForm from './useForm';
// import Login from './login';
const App: React.FC = () => {
    return (
        <div className="app">
             <ContextApiProvider>
            <Router>
                <Switch>
                    <Route exact path="/" component={Home} />
                    <Route exact path="/login" component={Register} />
                    <Route exact path="/register" component={Register} />
                    <Route exact path="/borrowedbooks" component={BorrowedBooks} />
                    <Route exact path="/searchbooks" component={SearchBooks} />
                    <Route exact path="/addBooks" component={AddBooks} />
                </Switch>
            </Router>
            </ContextApiProvider>
        </div>
    )
}

export default App;




 