import React from "react";
import { useDispatch, useSelector,Provider } from 'react-redux';
import { shallow, mount, render } from 'enzyme';
import store from "./store/index";
import LibraryService from './services/libraryService';
import Register from "./components/register";
jest.mock('./services/libraryService', () => {
  return {...jest.requireActual('./services/libraryService'),
  login: jest.fn(),
  Register: jest.fn()
  }
});
test('test register from ',()=>{
    const wrapper = mount(<Provider store={store}>
                 <Register />
           
               </Provider>);
    console.log(wrapper.html());
    console.log(wrapper);
   //expect(wrapper).toMatchSnapshot();
   expect(wrapper.find('Field')).toHaveLength(5);
})
test('has bootstrap form controls', () => {
 
    const wrapper = mount(<Provider store={store}>
        <RegisterFormik />
      </Provider>);
 
    expect(wrapper.find('.text-danger')).toHaveLength(8);
 
  });
  it("Test click event", () => {
 
    const mockCallBack = jest.fn();
 
   const button1 = shallow((<button onClick={mockCallBack}>Submit</button>));
 
   button1.find('button').simulate('click');
 
   expect(mockCallBack.mock.calls.length).toEqual(1);
 
});