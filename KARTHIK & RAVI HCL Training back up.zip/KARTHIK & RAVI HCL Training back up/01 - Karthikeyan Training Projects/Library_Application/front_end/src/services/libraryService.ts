import axios from 'axios';

class LibraryService {
  static baseUrl = 'http://localhost:4040/users/'
  static headers = {
    'Cache-Control': 'no-cache',
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Authorization': localStorage.getItem('token')
  };
  

  static async login(body: any) {
    console.log('99999999999', body)
    const url = `${this.baseUrl}login`;

    try {
      const response = await axios.post(url, body, { headers: LibraryService.headers }).then((res) => res).catch((err) => { console.log('vvvvvvvvvvvvvv',err); return err; });
      console.log('response response response response', response);
      return response; // Assuming the response contains JSON data
    } catch (error) {
      // Handle error
      console.error('Error while posting data:', error);
      throw error;
    }
  }
  static async addBooks(data: any) {
    console.log('99999999999', data)
    LibraryService.headers.Authorization = localStorage.getItem('token')
    const url = `${this.baseUrl}5/inventory/book`;

    try {
      const response = await axios.post(url, data, { headers: LibraryService.headers }).then((res) => res).catch((err) => { console.log('vvvvvvvvvvvvvv',err); return err; });
      console.log('response response response response', response);
      return response; // Assuming the response contains JSON data
    } catch (error) {
      // Handle error
      console.error('Error while posting data:', error);
      throw error;
    }
  }
  static async register(body: any) {
    console.log('99999999999yy', body)
    const url = `${this.baseUrl}register`;

    try {
      const response = await axios.post(url, body, { headers: LibraryService.headers }).then((res) => res).catch((err) => err);
      return response; // Assuming the response contains JSON data
    } catch (error) {
      // Handle error
      console.error('Error while posting data:', error);
      throw error;
    }
  }
}

export default LibraryService;