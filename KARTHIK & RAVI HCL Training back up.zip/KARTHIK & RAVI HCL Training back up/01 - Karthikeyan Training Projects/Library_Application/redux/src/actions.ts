
export const addValue = (payload: number) => ({
    type: 'ADD',
    payload,
});

export const subValue = (payload: number) => ({
    type: 'SUB',
    payload,
});
export const logIn = (payload: string) => ({
    type: 'logIn',
    payload,
});
