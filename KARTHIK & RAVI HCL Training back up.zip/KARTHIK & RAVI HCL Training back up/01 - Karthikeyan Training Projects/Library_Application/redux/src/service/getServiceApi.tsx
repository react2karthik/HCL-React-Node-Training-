import axios, { AxiosResponse } from 'axios';
import { put, takeLatest, call } from 'redux-saga/effects';
const baseUrl = 'http://localhost:5000/users/';
const headers = {
    'Cache-Control': 'no-cache',
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': 'http://localhost:5000/users/login',
    'Authorization': localStorage.getItem('token') || ''
};
async function apiGetService(url: string, payload: any, method = 'get') {
    console.log('headers', headers)
    try {
        const config = {
            headers: headers
        };
        const response =  await axios.get(url,payload)
        //const response: AxiosResponse = yield call(axios.post, `${baseUrl}login`, payload, config);//await axios.post(baseUrl + 'login', payload);
        console.log('Response:', response);
        return response;
    } catch (error) {
        throw error;
    }
};
export default apiGetService
