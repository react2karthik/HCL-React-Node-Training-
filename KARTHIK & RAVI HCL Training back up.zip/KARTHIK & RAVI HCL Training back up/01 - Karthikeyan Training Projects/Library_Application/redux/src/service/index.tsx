import axios, { AxiosResponse } from 'axios';
import { put, takeLatest, call } from 'redux-saga/effects';
const baseUrl = 'http://localhost:5000/users/';
const headers = {
    'Cache-Control': 'no-cache',
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': 'http://localhost:5000/users/login',
    'Authorization': localStorage.getItem('token') || ''
};
async function apiService(url: string, payload: any, method = 'post') {
    console.log('headers', headers)
    try {
        const config = {
            headers: headers
        };
        const response =  await axios.post(url,payload)
        //const response: AxiosResponse = yield call(axios.post, `${baseUrl}login`, payload, config);//await axios.post(baseUrl + 'login', payload);
        console.log('Response:', response);
        return response;
    } catch (error) {
        throw error;
    }
};
export default apiService;

// import axios,{AxiosResponse} from "axios";
// import { call } from 'redux-saga/effects';

// const baseUrl = 'http://localhost:5000/users/'
// const headers = {
//     'Cache-Control': 'no-cache',
//     'Content-Type': 'application/json',
//     'Access-Control-Allow-Origin': 'http://localhost:5000/users/login',
//     'Authorization': localStorage.getItem('token') || ''
// };
// // const apiService = async (url: string, payload: any, method = 'post') => {
// //     try {
// //        const response = await axios.post(url,payload);
// //        console.log('11111111111111111',response);
// //        return response;

// //     } catch (error: any) {
// //         throw new Error(error.message);
// //     }

// // }
// function* apiService(url: string, payload: any, method = 'post') {
//     try {
//         // Set headers in axios request config
//         const config = {
//             headers: headers
//         };

//         // Make the API request based on the specified method (default is 'post')
//         const response:AxiosResponse = yield call(axios.post, `${baseUrl}login`, payload, config);

//         // Log the response data
//         console.log('Response:', response);

//         // Return the response
//         return response;
//     } catch (error: any) {
//         // Throw an error if there's any problem with the request
//         throw new Error(error.message);
//     }
// }
// export default apiService;
// authService.ts


