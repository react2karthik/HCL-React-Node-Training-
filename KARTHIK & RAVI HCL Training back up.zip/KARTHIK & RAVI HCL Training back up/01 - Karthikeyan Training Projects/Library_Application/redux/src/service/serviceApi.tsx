import axios from 'axios';
class LibraryService {
    static baseUrl = 'http://localhost:5000/users/'
    static headers = {
        'Cache-Control': 'no-cache',
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': 'http://localhost:5000/users/login',
        'Authorization':localStorage.getItem('token')
    };
    static async login(body: any) {
        const url = `${this.baseUrl}login`;
        try {
            const response = await axios.post(url, body, { headers: LibraryService.headers }).then((res) => res).catch((err) => err);        
            return response;
        } catch (error) {
            throw error;
        }
    }
    // static async register(body: any) {
    //     const url = `${this.baseUrl}register`;
    //     try {
    //         const response = await axios.post(url, body, { headers: LibraryService.headers }).then((res) => res).catch((err) => err);
    //         return response;
    //     } catch (error) {
    //         throw error;
    //     }
    // }
    // static async addBook(body: any) {
    //     LibraryService.headers.Authorization = localStorage.getItem('token')
    //     const url = `${this.baseUrl}3a54de46-c950-4351-a070-a2604865aae1/inventory/book`;
    //     try {
    //         const response = await axios.post(url, body, { headers: LibraryService.headers }).then((res) => res).catch((err) => err);
    //         return response;
    //     } catch (error) {
    //         throw error;
    //     }
    // }
}
export default LibraryService
