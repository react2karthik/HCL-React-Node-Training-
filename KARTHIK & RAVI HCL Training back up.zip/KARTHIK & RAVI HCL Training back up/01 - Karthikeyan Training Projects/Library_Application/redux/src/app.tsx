import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
// import store from './store';
import Login from './components/login';
import Register from './components/register';
import Dashboard from './components/dashboard';
import AddBookInventory from './components/addbook';

const App: React.FC = () => {
    return (
        // <Provider store={store}>
            <Router>
                <Switch>
                    <Route path="/" exact  component={Login} />
                    <Route path="/register" component={Register} />
                    <Route path="/dashboard" component={Dashboard} />
                    <Route path="/addbook" component={AddBookInventory} />
                </Switch>
            </Router>
        // </Provider>
    );
};

export default App;

// import React from 'react';
// import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
// import { AuthProvider } from './components/authContext';
// import Login from './components/login';
// import Register from './components/register';

// const App: React.FC = () => {
//   return (
//     <AuthProvider>
//       <Router>
//         <Switch>
//           <Route path="/login" component={Login} />
//           <Route path="/register" component={Register} />
//         </Switch>
//       </Router>
//     </AuthProvider>
//   );
// };

// export default App;
