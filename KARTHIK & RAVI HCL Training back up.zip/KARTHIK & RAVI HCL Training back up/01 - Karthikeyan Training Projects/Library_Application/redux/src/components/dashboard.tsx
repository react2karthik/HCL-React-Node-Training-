import React, { useState, useEffect } from 'react';
import { MDBTable, MDBTableHead, MDBTableBody, MDBContainer, MDBBtn, MDBRow, MDBCol, MDBBreadcrumb, MDBBreadcrumbItem, MDBDropdownItem, MDBDropdown, MDBDropdownToggle, MDBDropdownMenu } from 'mdb-react-ui-kit';
import { useHistory, useLocation } from 'react-router-dom';
import {IBookModuls} from '../models/bookDetailModuls';
import {getBookDetailsRequest} from '../redux/action/bookDetailAction';
import { useDispatch, useSelector } from 'react-redux';

const Dashboard: React.FC = () => {
    const [bookData, setbookData] = useState<IBookModuls>({
        author:'',
        book_name:'',
        category_name:'',
        quantity:''
    });
    const dispatch = useDispatch();
    const bookDetails = useSelector((state: any) => {
        console.log('qqqqqqqqqqqq',state)
        return state?.bookDetailReducer?.data  
    });
console.log('222222222222222222',dispatch(getBookDetailsRequest(bookDetails)))
    useEffect(() => {
        // Fetch book details when component mounts
        dispatch(getBookDetailsRequest(bookDetails));
    }, [bookDetails?.statue]);
    return (
        <>
            <MDBContainer   >
                <MDBRow className="mt-2 g-0 ">
                    <MDBCol className="table-bordered ml-auto mt-2 mb-2" md='120'>
                        <MDBTable className="table-bordered">
                            <MDBTableHead>
                                <tr>
                                    <th scope='col' className='fw-bold'>Book id</th>
                                    <th scope='col' className='fw-bold'>Author</th>
                                    <th scope='col' className='fw-bold'>Book Name</th>
                                    <th scope='col' className='fw-bold'>Category Name</th>
                                    <th scope='col' className='fw-bold'>Quantity</th>
                                </tr>
                            </MDBTableHead>
                            <MDBTableBody>
                                {/* {currentData?.map((user: any, index: number) => (
                                <tr key={index}>
                                    <td>{user?.book_id}</td>
                                    <td>{user?.author}</td>
                                    <td>{user?.book_name}</td>
                                    <td>{user?.category_name}</td>
                                    <td>{user?.quantity}</td>
                                </tr>
                            ))} */}
                            </MDBTableBody>
                        </MDBTable>
                    </MDBCol>
                </MDBRow>
            </MDBContainer>
        </>
    )
}
export default Dashboard;