import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MDBInput, MDBCol, MDBRow, MDBCheckbox, MDBBtn, MDBContainer, MDBCard, MDBCardBody } from 'mdb-react-ui-kit';
import LibraryService from './../service/serviceApi';
import { useHistory } from 'react-router-dom';
import { ILoginModel } from './../models/loginModuls';
import AlertComponent from './form/alertFiled';
import { loginRequest } from '../redux/action/loginAction';
const Login: React.FC = () => {
  const [loginState, setLogin] = useState<ILoginModel>({
    email:'',
    password:''
  })
  const [validationErrors, setValidationErrors] = useState<any>({});
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const history = useHistory();
  const dispatch = useDispatch();
  const loginRespons = useSelector((state:any)=>{
    return state?.loginReducer?.data;
  })
  useEffect(()=>{
    servicePostLogin(loginRespons)
  },[loginRespons?.status])
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const { name, value } = e.target;
    setLogin(prevState => ({
      ...prevState,
      [name]: value
    }));
  }

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowAlert(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, [showAlert]);
  
  const servicePostLogin = (response: any) => {   
    try {        
        if (response && response.status === 'success') {
            localStorage.setItem("token", response.token);
            history.push('/dashboard');                 
        }else{
            setAlertMessage("Login failed. Please check your credentials.");
            setShowAlert(true);
        }
    } catch (error:any) {
        setAlertMessage("User id or password is mismatch. . Please try again later.");
        setShowAlert(true);
    }
};
  const handleLogin = (e: React.FormEvent<HTMLFormElement>) => {
    const errors: any = {};
    e.preventDefault();
    if (!loginState.email.trim() || !loginState.password) {
      sessionStorage.setItem('login', JSON.stringify(loginState))
      setAlertMessage("Email and password are required.");
      setShowAlert(true);
    }
    setValidationErrors(errors);     
     dispatch(loginRequest(loginState));
  }

  return (
    <>
      <form onSubmit={handleLogin}>
        <MDBContainer fluid className='h-100'>
          <MDBRow className='g-0'>
            <MDBCol md='8' className='mx-auto'>
              <MDBCard className='my-4'>
                <MDBRow className='g-0'>
                  <MDBCol md='8' className='mx-auto'>
                    <h4 className='text-success'>Library Management Login Form</h4>
                    {showAlert && (
                      <AlertComponent type="danger" message={alertMessage} />
                    )}
                    <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                      <MDBInput className='mb-4' type='email' name="email" id='form1Example1' label='Email address *' onChange={handleChange} />
                      {validationErrors.email && <p className="text-danger">{validationErrors.email}</p>}
                      <MDBInput className='mt-4' name="password" type='password' id='form1Example2' label='Password *' onChange={handleChange} />
                      {validationErrors.password && <p className="text-danger">{validationErrors.password}</p>}
                      <p className='d-flex justify-content-center align-item-center mt-2 text-primary'>If your are in member please sing  or not a member please register</p>
                      <div className="d-flex justify-content-center align-items-center mt-2">
                        <MDBBtn type='submit' className="bg-success bg-gradient text-white">
                          Sign in
                        </MDBBtn>

                      </div>
                    </MDBCardBody>
                  </MDBCol>
                </MDBRow>

              </MDBCard>
            </MDBCol>
          </MDBRow>

        </MDBContainer>
      </form>
    </>
  );
}

export default Login;






















// // Login.tsx
// import React, { useState } from 'react';
// import { useAuth } from './authContext';

// const Login: React.FC = () => {
//   const { login } = useAuth();
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');

//   const handleLogin = () => {
//     // Perform login logic here (e.g., call API)
//     // If login is successful, call the login function from AuthContext
//     login();
//   };

//   return (
//     <div>
//       <h2>Login</h2>
//       <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
//       <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
//       <button onClick={handleLogin}>Login</button>
//     </div>
//   );
// };

// export default Login;
