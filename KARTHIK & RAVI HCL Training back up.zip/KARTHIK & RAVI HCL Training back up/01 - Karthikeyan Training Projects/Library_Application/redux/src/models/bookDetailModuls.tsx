export interface IBookModuls {  
    author:string,
    //book_id:number,
    book_name:string,
    category_name:string,
    quantity:number | string
}