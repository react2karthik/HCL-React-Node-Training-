export interface IRegisterModuls{
    name: string;
    email: string;
    password: string;
    phone: any;
}