export interface AlertModuls {
    type:string;// 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark'
    message: string;
  }