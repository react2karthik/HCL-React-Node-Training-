import { BOOKADDED_SUCCESS, BOOKADDED_FAILED } from '../action/addBookAction';
export interface addBookState {
    data: any;
}
const initialState: addBookState = {
    data: null
}
const addBookReducer = (state: addBookState = initialState, action: any) => {
    switch (action.type) {
        case BOOKADDED_SUCCESS:
            return {
                ...state,
                data: action.payload
            }
        case BOOKADDED_FAILED:
            return {
                ...state,
                data: null,
            }
        default:
            return state;
    }
}
export default addBookReducer;