export const GETBOOKDETAILS = 'GETBOOKDETAILS';
export const GETBOOKDETAILS_SUCCESS = 'GETBOOKDETAILS_SUCCESS';
export const GETBOOKDETAILS_FAILED = 'GETBOOKDETAILS_FAILED';
export const getBookDetailsRequest = (payload: any) =>({
    type: 'GETBOOKDETAILS',
    payload,
})

export const getBookDetailsSuccess = (data: any) => ({
    type: 'GETBOOKDETAILS_SUCCESS',
    payload: data ,
})
export const getBookDetailsFailed  = (error: string) => ({
    type: 'GETBOOKDETAILS_FAILED',
    payload: error,
})