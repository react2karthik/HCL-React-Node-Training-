export const LOGIN = 'LOGIN';
// export const LOGIN2 = 'LOGIN2';
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_FAILED = 'LOGIN_FAILED';
export const loginRequest = (payload: any)=>({
    // return {
        type:'LOGIN',
        payload ,     
    // }
})
export const loginSuccess = (userData: any)=>({
    // return {
        type: 'LOGIN_SUCCESS',
        payload: userData,
    // }
})
export const loginFailed = (error: string)=>({
    // return {
        type: 'LOGIN_FAILURE',
        payload: error,
    // }
})