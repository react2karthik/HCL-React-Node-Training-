export const BOOKADDED = 'BOOKADDED';
export const BOOKADDED_SUCCESS = 'BOOKADDED_SUCCESS';
export const BOOKADDED_FAILED = 'BOOKADDED_FAILED';
export const bookaddedRequest = (payload: any) => ({
    type: 'BOOKADDED',
    payload,
})
export const bookadddedSuccess = (userData: any) => ({
    type: 'BOOKADDED_SUCCESS',
    payload: userData,
})
export const bookadddedFailed = (error: string) => ({
    type: 'BOOKADDED_FAILED',
    payload: error,
})