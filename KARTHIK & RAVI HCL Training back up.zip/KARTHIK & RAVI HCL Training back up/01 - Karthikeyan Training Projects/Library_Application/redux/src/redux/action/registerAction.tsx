export const REGISTER = 'REGISTER';
export const REGISTER_SUCCESS = 'REGISTER_SUCCESS';
export const REGISTER_FAILED = 'REGISTER_FAILED';
export const registerRequest = (payload: any) => ({
    type: 'REGISTER',
    payload,
})
export const registerSuccess = (userData: any) => ({
    type: 'REGISTER_SUCCESS',
    payload: userData,
})
export const registerFailed = (error: string) => ({
    type: 'REGISTER_FAILED',
    payload: error,
})