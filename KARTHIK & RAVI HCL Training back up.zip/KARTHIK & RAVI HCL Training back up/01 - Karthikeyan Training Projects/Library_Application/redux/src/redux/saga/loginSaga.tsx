import { call, put, takeLatest } from 'redux-saga/effects'; //takeevery
import { LOGIN, loginSuccess, loginFailed } from '../action/loginAction';
import { LOGINAPI } from '../../constant';
import apiService from '../../service/index';

function* login(data: any): Generator<any, void, any> {
    console.log('GGGGGGGGGGGGGGGGGGGG', data)
    try {
        const response: any = yield call(apiService, LOGINAPI, data.payload, 'get');
        console.log('0000000000', response);
        yield put(loginSuccess(response.data));
        //const userData = { email: data.payload.email }; // Replace this with actual user data from the API
        //console.log('9999999999999999999999', userData)
        // yield put(loginSuccess(userData));

    } catch (error) {
        // yield put(loginFailure(error.message));
        yield error;
    }
}

function* loginSaga() {
    yield takeLatest(LOGIN, login);
}

export default loginSaga;