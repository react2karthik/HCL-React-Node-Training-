import { call, put, takeLatest } from 'redux-saga/effects'; //takeevery
import { GETBOOKDETAILS, getBookDetailsSuccess, getBookDetailsFailed } from '../action/bookDetailAction';
import { FETCHBOOKDETAILSAPI } from '../../constant';
import apiGetService from '../../service/getServiceApi';
import axios from 'axios';
function* fetchBookDeatils(data: any): Generator<any, void, any> {   
    console.log('8888888888888888888888888p',data) 
    try {//any = yield call(apiGetService, FETCHBOOKDETAILSAPI, data.payload, 'get');
        // console.log('000000000000000000000',response) yield axios.get('your_api_endpoint_here');
        const response=yield axios.get('your_api_endpoint_here');
        console.log('8888888888888888888888888p',response)
        yield put(getBookDetailsSuccess(response.data));
    } catch (error:any) {
         yield put(getBookDetailsFailed(error.message));
    }
}

function* bookDetailsSaga() {
    yield takeLatest(GETBOOKDETAILS, fetchBookDeatils);
}

export default bookDetailsSaga;