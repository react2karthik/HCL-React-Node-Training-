import {call,put,takeLatest} from 'redux-saga/effects';
import {BOOKADDED,bookadddedSuccess,bookadddedFailed} from '../action/addBookAction';
import {FETCHADDBOOKDETAILSAPI} from '../../constant';
import apiService  from '../../service/index';

function* bookadded(data:any):Generator<any,void,any>{
    try{
        const response:any = yield call(apiService,FETCHADDBOOKDETAILSAPI,data.payload,'get');
        yield put(bookadddedSuccess(response.data));
    }catch(error:any){
        yield put(bookadddedFailed(error.message))
    }
}
function*  bookaddedSaga(){
    yield takeLatest(BOOKADDED,bookadded)
}
export default bookaddedSaga;