import {call,put,takeLatest} from 'redux-saga/effects';
import {REGISTER,registerSuccess,registerFailed} from '../action/registerAction';
import {REGISTERAPI} from '../../constant';
import apiService  from '../../service/index';

function* register(data:any):Generator<any,void,any>{
    try{
        const response:any = yield call(apiService,REGISTERAPI,data.payload,'get');
        yield put(registerSuccess(response.data));
    }catch(error:any){
        yield put(registerFailed(error.message))
    }
}
function*  registerSaga(){
    yield takeLatest(REGISTER,register)
}
export default registerSaga;