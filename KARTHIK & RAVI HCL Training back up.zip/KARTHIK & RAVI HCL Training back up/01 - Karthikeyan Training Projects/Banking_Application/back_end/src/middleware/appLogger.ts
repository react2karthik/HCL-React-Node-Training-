import { Request, Response, NextFunction } from "express";

const appLogger = (req: Request, res: Response, next: NextFunction) => {

    console.log('---------------------------------  appLogger Middleware called  ---------------------------------  ');

    next();

}

export default appLogger;