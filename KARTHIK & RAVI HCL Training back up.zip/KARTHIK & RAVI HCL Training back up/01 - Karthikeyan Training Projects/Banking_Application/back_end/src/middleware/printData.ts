import { Request, Response, NextFunction } from 'express';
 
const printData = (req: Request, res: Response, next: NextFunction) => {
    console.log('------------------- Print Data Middleware called -------------------');
 
    console.log('Params  ', req.params);
    console.log('Path    ', req.path);
    console.log('Body    ', req.body);
 
    next();
}
 
export default printData;