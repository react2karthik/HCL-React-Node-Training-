
const constances = {
    SUCCESS_MESAGE: 'Success',
    FAILED_MESAGE: 'Failed',
    ACCESS_DENIED_MESSAGE: 'ACCESS DENIED', 
    ACCESS_DENIED_CODE: 232,


    USER_ADDED_SUCCESS_MESSAGE: 'User Added successfully',
    USER_ADDED_SUCCESS_CODE: 3001,

    USER_FECTHED_SUCCESS_MESSAGE: 'Users fetched successfully',
    USER_FECTHED_SUCCESS_CODE: 3002,

    USER_DELETE_SUCCESS_MESAGE: 'User deleted successfully',
    USER_DELETE_SUCCESS_CODE: 3003,

    USER_UPDATE_SUCCESS_MESSAGE: 'User Updated successfully', 
    USER_UPDATE_SUCCESS_CODE: 3004,  

    USER_NOT_FOUND_MESSAGE: 'No User found to delete',
    USER_NOT_FOUND_CODE: 3005,

    USER_NOT_EXIST_MESSAGE: 'User not exist',
    USER_NOT_EXIST_CODE: 3006,

    USER_UPDATE_FAIL_MESSAGE: 'Id not found in users table to update user details', 
    USER_UPDATE_FAIL_CODE: 3007, 

    BENEFICIARIE_ADDED_SUCCESS_MESSAGE: 'Beneficiarie Added successfully',
    BENEFICIARIE_ADDED_SUCCESS_CODE: 3008,

    BENEFICIARIE_FECTHED_SUCCESS_MESSAGE: 'Beneficiaries fetched successfully',
    BENEFICIARIE_FECTHED_SUCCESS_CODE: 3009,

    BENEFICIARIE_DELETE_SUCCESS_MESAGE: 'Beneficiarie deleted successfully',
    BENEFICIARIE_DELETE_SUCCESS_CODE: 3010,

    BENEFICIARIE_UPDATE_SUCCESS_MESSAGE: 'Beneficiarie Updated successfully', 
    BENEFICIARIE_UPDATE_SUCCESS_CODE: 3011,  

    BENEFICIARIE_NOT_FOUND_MESSAGE: 'No Beneficiarie found to delete',
    BENEFICIARIE_NOT_FOUND_CODE: 3012,

    BENEFICIARIE_NOT_EXIST_MESSAGE: 'Beneficiarie not exist',
    BENEFICIARIE_NOT_EXIST_CODE: 3013,

    BENEFICIARIE_UPDATE_FAIL_MESSAGE: 'Id not found in Beneficiaries table to update Beneficiarie details', 
    BENEFICIARIE_UPDATE_FAIL_CODE: 3014, 

    
    TRANSACTION_ADDED_SUCCESS_MESSAGE: 'Transaction detail Added successfully',
    TRANSACTION_ADDED_SUCCESS_CODE: 3015,

    TRANSACTION_FECTHED_SUCCESS_MESSAGE: 'Transaction detail  fetched successfully',
    TRANSACTION_FECTHED_SUCCESS_CODE: 3016,

    TRANSACTION_DELETE_SUCCESS_MESAGE: 'Transaction detail deleted successfully',
    TRANSACTION_DELETE_SUCCESS_CODE: 3017,

    TRANSACTION_UPDATE_SUCCESS_MESSAGE: 'Transaction detail Updated successfully', 
    TRANSACTION_UPDATE_SUCCESS_CODE: 3018,  

    TRANSACTION_NOT_FOUND_MESSAGE: 'No Transaction detail found to delete',
    TRANSACTION_NOT_FOUND_CODE: 3019,

    TRANSACTION_NOT_EXIST_MESSAGE: 'Transaction detail not exist',
    TRANSACTION_NOT_EXIST_CODE: 3020,

    TRANSACTION_UPDATE_FAIL_MESSAGE: 'Id not found in Transaction detail  table to update Transaction details', 
    TRANSACTION_UPDATE_FAIL_CODE: 3021, 

    ACCOUNT_ADDED_SUCCESS_MESSAGE: 'Account detail Added successfully',
    ACCOUNT_ADDED_SUCCESS_CODE: 3022,

    ACCOUNT_FECTHED_SUCCESS_MESSAGE: 'Account detail  fetched successfully',
    ACCOUNT_FECTHED_SUCCESS_CODE: 3023,

    ACCOUNT_DELETE_SUCCESS_MESAGE: 'Account detail deleted successfully',
    ACCOUNT_DELETE_SUCCESS_CODE: 3024,

    ACCOUNT_UPDATE_SUCCESS_MESSAGE: 'Account detail Updated successfully', 
    ACCOUNT_UPDATE_SUCCESS_CODE: 3025,  

    ACCOUNT_NOT_FOUND_MESSAGE: 'No Account detail found to delete',
    ACCOUNT_NOT_FOUND_CODE: 3026,

    ACCOUNT_NOT_EXIST_MESSAGE: 'Account detail not exist',
    ACCOUNT_NOT_EXIST_CODE: 3027,

    ACCOUNT_UPDATE_FAIL_MESSAGE: 'Id not found in Account detail  table to update Transaction details', 
    ACCOUNT_UPDATE_FAIL_CODE: 3028, 
}

export default constances;