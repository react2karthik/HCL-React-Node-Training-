

class Calculator {
    add(a: number, b: number) {
        return a + b;
    }
}



export default Calculator;