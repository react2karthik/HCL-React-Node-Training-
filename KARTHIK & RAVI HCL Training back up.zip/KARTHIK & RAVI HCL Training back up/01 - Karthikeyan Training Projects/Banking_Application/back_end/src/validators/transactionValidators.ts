import { body } from "express-validator";

/**
 * This transactionValidator method is used to validate transactionObject() & retuns error messages array
 * amount,comments, credit_to, debit_from, from_account_no, from_bank_name, from_isfc_code, status, status_message, 
 * to_account_no, to_bank_name, to_isfc_code, transaction_date
 * 
 * @returns - error messages array
 */
export const transactionValidator = () => {
    return [
        body("amount").exists().withMessage("amount is required"),
        body("comments").exists().withMessage("comments is required"),
        body("credit_to").exists().withMessage("credit_to is required"),
        body("debit_from").exists().withMessage("debit_from is required"),
        body("from_account_no").exists().withMessage("from_account_no is required"),
        body("from_bank_name").exists().withMessage("from_bank_name is required"),
        body("from_isfc_code").exists().withMessage("from_isfc_code is required"),
        body("status").exists().withMessage("status is required"),
        body("status_message").exists().withMessage("status_message is required"),
        body("to_account_no").exists().withMessage("to_account_no is required"),
        body("to_bank_name").exists().withMessage("to_bank_name is required"),
        body("to_isfc_code").exists().withMessage("to_isfc_code is required"),
        body("transaction_date").exists().withMessage("transaction_date is required")
    ]
}

export const fundTranferValidator = () => {
    return [
        body("amount").exists().withMessage("amount is required"),
        body("comments").exists().withMessage("comments is required"),
        body("customer_id").exists().withMessage("customer_id is required"),
        body("to_ifsc_code").exists().withMessage("to_isfc_code is required"),
        body("to_account_no").exists().withMessage("to_account_no is required"),
        body("from_account_no").exists().withMessage("from_account_no is required"),
        body("from_ifsc_code").exists().withMessage("from_isfc_code is required"),
    ]
}
