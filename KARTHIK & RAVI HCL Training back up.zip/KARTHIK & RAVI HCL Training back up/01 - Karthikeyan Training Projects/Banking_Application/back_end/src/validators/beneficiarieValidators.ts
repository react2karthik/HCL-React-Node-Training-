import { body } from "express-validator";

/**
 * This beneficiarieValidators method is used to validate beneficiarieObject() & retuns error messages array
 * beneficiarie_name, customer_id, beneficiarie_acountc_no, beneficiarie_bank_name, beneficiarie_ifsc_code, is_active
 * 
 * @returns - error messages array
 */
const beneficiarieValidators = () => {
    return [
        body("beneficiarie_name").exists().withMessage("beneficiarie_name Name is required"),
        body("customer_id").exists().withMessage("customer_id is required"),
        body("beneficiarie_acountc_no").exists().withMessage("beneficiarie_acountc_no is required"),
        body("beneficiarie_bank_name").exists().withMessage("beneficiarie_bank_name is required"),
        body("beneficiarie_ifsc_code").exists().withMessage("beneficiarie_ifsc_code is required"),
        body("is_active").exists().withMessage("is_active is required")
    ]
};

export default beneficiarieValidators;
