import { body } from "express-validator";

/**
 * This accountValidator method is used to validate accountObject() & retuns error messages array
 * name, branch, balance, opened_on, bank_name, ifsc_code, account_no, is_active, customer_id, account_type, user_address
 * 
 * @returns - error messages array
 */
const accountValidator = () => {
    return [
        body("name").exists().withMessage("Name is required"),
        body("branch").exists().withMessage("branch is required"),
        body("balance").exists().withMessage("balance is required"),
        body("opened_on").exists().withMessage("opened_on is required"),
        body("bank_name").exists().withMessage("bank_name is required"),
        body("ifsc_code").exists().withMessage("ifsc_code is required"),
        body("account_no").exists().withMessage("account_no is required"),
        body("is_active").exists().withMessage("is_active is required"),
        body("customer_id").exists().withMessage("customer_id is required"),
        body("account_type").exists().withMessage("account_type is required"),
        body("user_address").exists().withMessage("user_address is required")
    ]
}




export default accountValidator;

