export class InsufficientBalanceError extends Error {
    statusCode: number;

    constructor(msg: string, code: number) {
        super();
        this.message = msg;
        this.statusCode = code;
    }
}