import express, { Request, Response, NextFunction } from 'express';

import { IFundtransfer, ITransaction } from '../modal/types';
import constances from '../constants/constant';
import authMiddleware from '../middleware/authMiddleware';
import validateMiddleware from '../middleware/validateMiddleware';
import { fundTranferValidator, transactionValidator } from '../validators/transactionValidators';
import { fundTransfer, getAllTransaction, getTransactionDetailById, deleteTransactionDetailById, updateTransactionDetailById } 
from '../services/transaction_Service';

const transactionRouter: express.Router = express.Router();

/**
 * transaction Router
 * this POST method is used to insert transaction info into transaction_details table.
 */
// transactionRouter.post('/', transactionValidator(),  validateMiddleware, authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

//     const { amount, comments, credit_to, debit_from, from_account_no, from_bank_name, from_isfc_code, status, 
//         status_message, to_account_no, to_bank_name, to_isfc_code, transaction_date }: ITransaction = req.body;

//     const transactionData: ITransaction = { amount, comments, credit_to, debit_from, from_account_no, from_bank_name, from_isfc_code, status, 
//         status_message, to_account_no, to_bank_name, to_isfc_code, transaction_date };

//     try {
//         await insertTransaction(transactionData);
//         res.json({
//             message: constances.TRANSACTION_ADDED_SUCCESS_MESSAGE,
//             statusCode: constances.TRANSACTION_ADDED_SUCCESS_CODE,
//             statue: constances.SUCCESS_MESAGE
//         });

//     } catch (error) {
//         next(error)
//     }
// });

/**
 * transaction Router
 * this GET method is used to get transaction info from transaction_details table.
 */
transactionRouter.get('/', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    try {
        const data = await getAllTransaction();
        res.json({
            data,
            message: constances.TRANSACTION_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.TRANSACTION_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        next(error);
    }
});

/**
 * transaction Router
 * this PUT method is used to Update transaction info in transaction_details table.
 */
transactionRouter.put('/:id', transactionValidator(), validateMiddleware, authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const { amount, comments, credit_to, debit_from, from_account_no, from_bank_name, from_isfc_code, status, 
        status_message, to_account_no, to_bank_name, to_isfc_code, transaction_date  }: ITransaction = req.body;
    const transactionData: ITransaction = { amount, comments, credit_to, debit_from, from_account_no, from_bank_name, from_isfc_code, status, 
        status_message, to_account_no, to_bank_name, to_isfc_code, transaction_date };

    const data = await getTransactionDetailById(id);

    try {
        if (data.count != 0) {
            await updateTransactionDetailById(id, transactionData);
            res.json({
                message: constances.TRANSACTION_UPDATE_SUCCESS_MESSAGE,
                statusCode: constances.TRANSACTION_UPDATE_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.TRANSACTION_UPDATE_FAIL_MESSAGE,
                statusCode: constances.TRANSACTION_UPDATE_FAIL_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }

});

/**
 * transaction Router
 * this DELETE method is used to delete transaction info from transaction_details table.
 */
transactionRouter.delete('/:id', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const data = await getTransactionDetailById(id);

    try {
        if (data.count != 0) {
            await deleteTransactionDetailById(id);
            res.json({
                message: constances.TRANSACTION_DELETE_SUCCESS_MESAGE,
                statusCode: constances.TRANSACTION_DELETE_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.TRANSACTION_NOT_FOUND_MESSAGE,
                statusCode: constances.TRANSACTION_NOT_FOUND_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }
});

/**
 * transaction Router
 * this POST method is used to fund transaction info from transaction_details table.
 */
transactionRouter.post('/fund-transfer', fundTranferValidator(),  validateMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { amount, comments, customer_id, from_account_no, from_ifsc_code, to_account_no, to_ifsc_code }: IFundtransfer = req.body;

    const transactionData: IFundtransfer = { amount, comments, customer_id, from_account_no, from_ifsc_code, to_account_no, to_ifsc_code };

    try {
        const result = await fundTransfer(transactionData);
        res.json({
            message: constances.TRANSACTION_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.TRANSACTION_ADDED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        next(error)
    }
});

export default transactionRouter;