import express, { Request, Response, NextFunction } from 'express';

import { IAccount } from '../modal/types';
import constances from '../constants/constant';
import authMiddleware from '../middleware/authMiddleware';
import accountValidator from '../validators/accountValidator';
import validateMiddleware from '../middleware/validateMiddleware';
import { addAccount, getAccounts, getAccountById, deleteAccount, updateAccount } from '../services/account_Service';

const accountRouter: express.Router = express.Router();

/**
 * account Router
 * this POST method is used to insert account info into account_details table.
 */
accountRouter.post('/', accountValidator(), validateMiddleware, authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { account_no, account_type, balance, bank_name, branch, customer_id, ifsc_code, is_active, name, 
        opened_on, user_address }: IAccount = req.body;
    const accountDetails: IAccount = { account_no, account_type, balance, bank_name, branch, customer_id, ifsc_code, 
        is_active, name, opened_on, user_address };

    try {
        await addAccount(accountDetails);
        res.json({
            message: constances.ACCOUNT_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.ACCOUNT_ADDED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        next(error)
    }

});

/**
 * account Router
 * this GET method is used to fetch account info from account_details table.
 */
accountRouter.get('/', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    try {
        const data = await getAccounts();
        res.json({
            data,
            message: constances.ACCOUNT_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.ACCOUNT_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        next(error);
    }
});

/**
 * account Router
 * this PUT method is used to update account info into account_details table.
 */
accountRouter.put('/:id', accountValidator(), validateMiddleware, authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const { account_no, account_type, balance, bank_name, branch, customer_id, ifsc_code, is_active, name, 
        opened_on, user_address }: IAccount = req.body;
    const accountDetails: IAccount = { account_no, account_type, balance, bank_name, branch, customer_id, ifsc_code, 
        is_active, name, opened_on, user_address };
    const data = await getAccountById(id);

    try {
        if (data.count != 0) {
            await updateAccount(id, accountDetails);
            res.json({
                message: constances.ACCOUNT_UPDATE_SUCCESS_MESSAGE,
                statusCode: constances.ACCOUNT_UPDATE_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.ACCOUNT_UPDATE_FAIL_MESSAGE,
                statusCode: constances.ACCOUNT_UPDATE_FAIL_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }

});

/**
 * account Router
 * this DELETE method is used to delete account info from account_details table.
 */
accountRouter.delete('/:id', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const data = await getAccountById(id);

    try {
        if (data.count != 0) {
            await deleteAccount(id);
            res.json({
                message: constances.ACCOUNT_DELETE_SUCCESS_MESAGE,
                statusCode: constances.ACCOUNT_DELETE_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.ACCOUNT_NOT_FOUND_MESSAGE,
                statusCode: constances.ACCOUNT_NOT_FOUND_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }
});

export default accountRouter;


