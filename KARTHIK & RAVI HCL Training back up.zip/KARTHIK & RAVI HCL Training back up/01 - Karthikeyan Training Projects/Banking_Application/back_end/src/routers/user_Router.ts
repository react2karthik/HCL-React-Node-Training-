import express, { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';

import { IUser } from '../modal/types';
import constances from '../constants/constant';
import userValidator from '../validators/userValidators';
import authMiddleware from '../middleware/authMiddleware';
import { UnAuthorizedAccess } from '../error/unAuthorizedError';
import validateMiddleware from '../middleware/validateMiddleware';
import { getUsers, getUserById, deleteUserById, updateUserById, login, createUser } from '../services/user_Service';

dotenv.config();

const userRouter: express.Router = express.Router();

/**
 * user router
 * this POST method is used to insert user info in to user_details table.
 */
userRouter.post('/addUser', userValidator(), validateMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { name, customer_id, email, password, phone, role } = req.body;
    try {
        const hassedPassword = await bcrypt.hash(password, 10);
        const result = await createUser(name, customer_id, email, hassedPassword, phone, role);
        res.json({
            message: constances.USER_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.USER_ADDED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE,
            data: result
        });

    } catch (error) {
        next(error);
    }
});

/**
 * user router
 * this POST method is used to generate auth token if credentials are valid.
 */
userRouter.post('/login', async (req: Request, res: Response, next: NextFunction) => {

    const { email, password } = req.body;
    const result = await login(email);
    
    if (result.first() != null) {

        const isMatching = await bcrypt.compare(password, result.first().get('password'));

        if (isMatching) {
            const token = jwt.sign({ email }, process.env.SECRET_KEY || '', { expiresIn: '1h' });
            res.json({
                status: 'success',
                data: token
            })
        } else {
            try {
                throw new UnAuthorizedAccess(constances.ACCESS_DENIED_MESSAGE, constances.ACCESS_DENIED_CODE);
            } catch (error) {
                next(error);
            }
        }
    } else {
        res.json({
            message: constances.USER_NOT_EXIST_MESSAGE,
            statusCode: constances.USER_NOT_EXIST_CODE,
            statue: constances.FAILED_MESAGE,
            data: email
        })
    }
});

/**
 * user router
 * this GET method is used to get user info from user_details table.
 */
userRouter.get('/', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    try {
        const data = await getUsers();
        res.json({
            data,
            message: constances.USER_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.USER_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        next(error);
    }
});

/**
 * user router
 * this PUT method is used to update user info in user_details table.
 */
userRouter.put('/:id', userValidator(), validateMiddleware, authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    
    const { id } = req.params;
    const { name, customer_id, email, password, phone }: IUser = req.body;
    const userData: IUser = { id, name, customer_id, email, password, phone };

    const data = await getUserById(id);

    try {
        if (data.count != 0) {
            await updateUserById(userData);
            res.json({
                message: constances.USER_UPDATE_SUCCESS_MESSAGE,
                statusCode: constances.USER_UPDATE_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.USER_UPDATE_FAIL_MESSAGE,
                statusCode: constances.USER_UPDATE_FAIL_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }

});

/**
 * user router
 * this DELETE method is used to delete user info from user_details table.
 */
userRouter.delete('/:id', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const data = await getUserById(id);

    try {
        if (data.count != 0) {
            await deleteUserById(id);
            res.json({
                message: constances.USER_DELETE_SUCCESS_MESAGE,
                statusCode: constances.USER_DELETE_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.USER_NOT_FOUND_MESSAGE,
                statusCode: constances.USER_NOT_FOUND_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }
});

export default userRouter;

// CREATE type beneficiarie(id int, name text, ac_no int, bank text, isfc text);

// create table users(id uuid primary key,name text, email text, password text, beneficiaries list<FROZEN <beneficiarie>>);

// insert into users(id, name, email, password) values(uuid(), 'karthik', 'ea@gmail.com', 'password');

// update users set beneficiaries=[{id: 1, name: 'jl', ac_no: 323232, bank: 'hdfc', isfc: 'ewqeqw'}, {id: 1, name: 'jl', ac_no: 323232, bank: 'hdfc', isfc: 'ewqeqw'}] where id=db24b5f7-d20d-4aec-aff3-90541e99c436;
