import express, { Request, Response, NextFunction } from 'express';

import constances from '../constants/constant';
import { IBeneficiarie } from '../modal/types';
import authMiddleware from '../middleware/authMiddleware';
import validateMiddleware from '../middleware/validateMiddleware';
import beneficiarieValidators from '../validators/beneficiarieValidators';
import { addBeneficiarie, getAllBeneficiaries, updateBeneficiarie, getBeneficiarieById, deleteBeneficiarie, getBeneficiaries } from '../services/beneficiarie_Service';



const beneficiarieRouter: express.Router = express.Router();

/**
 * beneficiarie router
 * POST - this post is used to add new Beneficiarie into Beneficiarie_details table
 */
beneficiarieRouter.post('/', beneficiarieValidators(), validateMiddleware, authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { beneficiarie_name, customer_id, beneficiarie_acountc_no, beneficiarie_bank_name, beneficiarie_ifsc_code, 
        is_active } = req.body;

    const beneficiarie_Data: IBeneficiarie = { beneficiarie_name, customer_id, beneficiarie_acountc_no, beneficiarie_bank_name, 
        beneficiarie_ifsc_code, is_active };

    try {
        const result = await addBeneficiarie(beneficiarie_Data);
        res.json({
            message: constances.BENEFICIARIE_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.BENEFICIARIE_ADDED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE,
            data: result
        });

    } catch (error) {
        next(error);
    }
});

/**
 * beneficiarie router
 * GET - this get is used to fetch Beneficiarie info from Beneficiarie_details table
 */
beneficiarieRouter.get('/', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    try {
        const data = await getAllBeneficiaries();
        res.json({
            data,
            message: constances.BENEFICIARIE_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.BENEFICIARIE_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        next(error);
    }
});

beneficiarieRouter.get('/mybeneficiarie/:customerid', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { customerid } = req.params;
    try {
        const data = await getBeneficiaries(customerid);
        res.json({
            data,
            message: constances.BENEFICIARIE_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.BENEFICIARIE_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        next(error);
    }
});

/**
 * beneficiarie router
 * PUT - this method is used to update Beneficiarie info into Beneficiarie_details table
 */
beneficiarieRouter.put('/:id', beneficiarieValidators(), validateMiddleware, authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const { customer_id, beneficiarie_name, beneficiarie_acountc_no, beneficiarie_bank_name, 
        beneficiarie_ifsc_code, is_active }: IBeneficiarie = req.body;

    const beneficiarieData : IBeneficiarie = { customer_id, beneficiarie_name, beneficiarie_acountc_no, beneficiarie_bank_name, 
        beneficiarie_ifsc_code, is_active };
    const data = await getBeneficiarieById(id);

    try {
        if (data.count != 0) {
            await updateBeneficiarie(id, beneficiarieData);
            res.json({
                message: constances.BENEFICIARIE_UPDATE_SUCCESS_MESSAGE,
                statusCode: constances.BENEFICIARIE_UPDATE_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.BENEFICIARIE_UPDATE_FAIL_MESSAGE,
                statusCode: constances.BENEFICIARIE_UPDATE_FAIL_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }
});

/**
 * beneficiarie Router
 * this DELETE method is used to delete beneficiarie info from beneficiarie_details table.
 */
beneficiarieRouter.delete('/:id', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const data = await getBeneficiarieById(id);

    try {
        if (data.count != 0) {
            await deleteBeneficiarie(id);
            res.json({
                message: constances.BENEFICIARIE_DELETE_SUCCESS_MESAGE,
                statusCode: constances.BENEFICIARIE_DELETE_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.BENEFICIARIE_NOT_EXIST_MESSAGE,
                statusCode: constances.BENEFICIARIE_NOT_EXIST_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }
});

export default beneficiarieRouter;