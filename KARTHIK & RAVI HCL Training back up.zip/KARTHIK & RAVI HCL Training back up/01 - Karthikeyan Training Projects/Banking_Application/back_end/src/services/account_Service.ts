import client from '../config/dbConfig';
import { IAccount } from '../modal/types';
import { NoDataFoundError } from "../error/noDataError";

/**
 * account service - addAccount () 
 * this method is used to add account details into account_details table.
 * @param A  - account_details Object
 */
const addAccount = async (A: IAccount) => {

    const query = `insert into account_details(id, name, customer_id, account_no, account_type, opened_on, balance, bank_name, 
        branch, ifsc_code, user_address, is_active) values (uuid(), '${A.name}', ${A.customer_id}, ${A.account_no}, '${A.account_type}', 
        '${A.opened_on}', ${A.balance}, '${A.bank_name}', '${A.branch}', '${A.ifsc_code}', '${A.user_address}', ${A.is_active})`;

    await client.execute(query);

}


/**
 * account service - getAccounts () 
 * this method is used to get account details from account_details table.
 * @returns - account_details Object
 */
const getAccounts = async () => {

    const result = await client.execute('select * from account_details')

    if (result.rowLength === 0)
        throw new NoDataFoundError('No account Details Found', 20000);
    else
        return result.rows;
}


/**
 * account service - updateAccount () 
 * this method is used to update account details into account_details table using Id.
 * @param id - account_details Id.
 * @param A  - account_details Object
 */
const updateAccount = async (id: string, A: IAccount) => {

    const query = `update account_details set name='${A.name}', customer_id=${A.customer_id}, account_no=${A.account_no}, account_type='${A.account_type}', 
    opened_on='${A.opened_on}', balance=${A.balance}, bank_name='${A.bank_name}', branch='${A.branch}', ifsc_code='${A.ifsc_code}', 
    user_address='${A.user_address}' where id=${id}`;

    await client.execute(query);
}

/**
 * account service - getAccountById () 
 * this method is used to get account details from account_details table using Id.
 * @param id - account_details Id.
 * @returns  - account_details Object
 */
const getAccountById = async (id: string | number) => {

    const query = `select count(id) as count from account_details where id=${id}`;
    const result = await client.execute(query);

    return result.first();
}

/**
 * account service - deleteAccount () 
 * this method is used to delete Beneficiarie from Beneficiarie_details table using Id.
 * @param id - account Id.
 */
const deleteAccount = async (id: string | number) => {

    const query = `update account_details set is_active=false where id=${id}`;

    await client.execute(query);
}

export { 
    addAccount, 
    getAccounts,
    updateAccount,
    deleteAccount,
    getAccountById
};

// id int primary key, category_id int, product_id int, added_by text, added_on date, quantity int, price int