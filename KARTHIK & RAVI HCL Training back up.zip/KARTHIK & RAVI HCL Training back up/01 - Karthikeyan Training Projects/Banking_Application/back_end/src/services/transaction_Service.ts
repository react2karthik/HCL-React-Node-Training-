import client from '../config/dbConfig';
import dotenv from 'dotenv';
import constances from '../constants/constant';
import { IFundtransfer, ITransaction } from '../modal/types';
import { NoDataFoundError } from "../error/noDataError";
import { InsufficientBalanceError } from "../error/insufficientBalanceError";

/**
 * Transaction Details service - insertTransaction () 
 * this method is used to add Transaction into  Transaction_details table.
 * @param T - transaction_Detail Object
 */
const insertTransaction = async (T: ITransaction) => {

    const query = `insert into transaction_details (id, amount, credit_to, debit_from, from_account_no, from_bank_name, from_isfc_code, status, 
        status_message, to_account_no, to_bank_name, to_isfc_code, transaction_date, comments) values(uuid(), ${T.amount}, 
        '${T.credit_to}', '${T.debit_from}', ${T.from_account_no}, '${T.from_bank_name}', '${T.from_isfc_code}', '${T.status}', '${T.status_message}',
         ${T.to_account_no}, '${T.to_bank_name}', '${T.to_isfc_code}', toTimeStamp(now()), '${T.comments}')`;


    await client.execute(query);
}

/**
 * Transaction Details service - getAllTransaction () 
 * this method is used to get Transaction into  Transaction_details table.
 * @returns - transaction_Detail Object
 */
const getAllTransaction = async () => {

    const result = await client.execute('select * from transaction_details')

    if (result.rowLength === 0)
        throw new NoDataFoundError('No transaction details found', 10000);
    else
        return result.rows;
}


/**
 * Transaction Details service - updateTransactionDetailById () 
 * this method is used to update Transaction into  Transaction_details table using ID.
 * @param T - transaction_Detail Object
 */
const updateTransactionDetailById = async (id: string, T: ITransaction) => {

    const query = `update transaction_details set amount=${T.amount}, credit_to='${T.credit_to}', debit_from='${T.debit_from}',
    from_account_no=${T.from_account_no}, from_bank_name='${T.from_bank_name}', from_isfc_code='${T.from_isfc_code}', 
    status='${T.status}', status_message='${T.status_message}', to_account_no=${T.to_account_no}, to_bank_name='${T.to_bank_name}',
    to_isfc_code='${T.to_isfc_code}', transaction_date='${T.transaction_date}', comments='${T.comments}' where id=${id}`;

    await client.execute(query);
}


/**
 * Transaction Details service - getTransactionDetailById () 
 * this method is used to get Transaction from  Transaction_details table using ID.
 * @param id - Transaction ID
 */
const getTransactionDetailById = async (id: string) => {
    const query = `select count(id) as count from transaction_details where id=${id}`;

    const result = await client.execute(query);

    return result.first();
}


/**
 * Transaction Details service - deleteTransactionDetailById () 
 * this method is used to delete Transaction from  Transaction_details table using ID.
 * @param id - Transaction ID
 */
const deleteTransactionDetailById = async (id: string | number) => {

    const query = `delete from transaction_details where id=${id}`;

    await client.execute(query);
}

/**
 * Method: getBankDetails 
 * This getBankDetails method is used to get account details while fund transfer.
 * @param accountNo 
 * @param ifscCode 
 * @returns 
 */
const getBankDetails = async (accountNo: number, ifscCode: string) => {

    const query = `select name, bank_name, balance, account_type from account_details where ifsc_code='${ifscCode}' and account_no=${accountNo}  ALLOW FILTERING`;
    const result = await client.execute(query);

    return result.first();
}

/**
 * Method: updateAccountBalance 
 * This updateAccountBalance method is used to update account details while fund transfer.
 * @param ifscCode 
 * @param accountNo 
 * @param amount 
 * @param isDebit 
 * @param F 
 */
const updateAccountBalance = async (ifscCode: string, accountNo: number, amount: number, isDebit: boolean, F: IFundtransfer) => {

    let query = `select id, balance from account_details where ifsc_code='${ifscCode}' and account_no=${accountNo} ALLOW FILTERING`;
    const result = await client.execute(query);
    try {
        if (result.first().count != 0) {
            const { id, balance } = result.first();
            const newBalance = isDebit ? balance - amount : balance + amount;

            query = `update account_details set balance=${newBalance} where id=${id}`;
            await client.execute(query);
        }
    } catch {
        if (isDebit == false) {
            await updateAccountBalance(F.from_ifsc_code, F.from_account_no, F.amount, false, F);
        }
        throw new NoDataFoundError(`No account details found for IFSC_Code: ${ifscCode} and account_no: ${accountNo}`, 10000);
    }
}
/**
 * this fundTransfer method is used to transfer amount between two accounts
 * @param F - fundTransfer Object
 */
const fundTransfer = async (F: IFundtransfer) => {

    const bankDetails = await getBankDetails(F.from_account_no, F.from_ifsc_code);

    if (bankDetails != null) {

        const { name, bank_name, balance, account_type } = bankDetails;
        const minimumBalance = (account_type == 'savings' ? process.env.SAVINGS_ACCOUNT_MIN_BALANCE : process.env.CURRENT_ACCOUNT_MIN_BALANCE);
        const availableBalance = balance - Number(minimumBalance);

        if (availableBalance - F.amount < 0) {
            throw new InsufficientBalanceError(`Insufficient Balance for fund transfer from account_no: ${F.from_account_no}`, 20000);
        } else {

            const result = await getBankDetails(F.to_account_no, F.to_ifsc_code);
            await updateAccountBalance(F.from_ifsc_code, F.from_account_no, F.amount, true, F);
            await updateAccountBalance(F.to_ifsc_code, F.to_account_no, F.amount, false, F);


            const query = `insert into transaction_details (id, amount, credit_to, debit_from, from_account_no, from_bank_name, from_ifsc_code, status, 
                status_message, to_account_no, to_bank_name, to_ifsc_code, transaction_date, comments) values(uuid(), ${F.amount}, 
                '${result.name}', '${name}', ${F.from_account_no}, '${bank_name}', '${F.from_ifsc_code}', '${constances.SUCCESS_MESAGE}', '${constances.SUCCESS_MESAGE}',
                 ${F.to_account_no}, '${result.bank_name}', '${F.to_ifsc_code}', toTimeStamp(now()), '${F.comments}')`;

            await client.execute(query);
        }
    } else {
        throw new NoDataFoundError(`No account details found for IFSC_Code: ${F.from_ifsc_code} and account_no: ${F.from_account_no}`, 10000);
    }
}

export {
    fundTransfer,
    insertTransaction,
    getAllTransaction,
    getTransactionDetailById,
    deleteTransactionDetailById,
    updateTransactionDetailById
};