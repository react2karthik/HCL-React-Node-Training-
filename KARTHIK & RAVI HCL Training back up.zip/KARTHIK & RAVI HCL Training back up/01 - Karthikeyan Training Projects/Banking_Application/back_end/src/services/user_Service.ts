import client from '../config/dbConfig';
import { IUser } from '../modal/types';
import { NoDataFoundError } from "../error/noDataError";

/**
 * User service - login () 
 * this method is used to validate user email and password.
 * @param email - user email id. 
 * @returns - token for authorization (jwt token)
 */

const login = async (email: string) => {

    const query = `select email, password from user_details where email='${email}' ALLOW FILTERING`;

    const result = await client.execute(query);

    return result;
}

/**
 * User service - createUser () 
 * this method is used to insert user info like name, email and password into user table.
 * @param id -user Id
 * @param name - user name
 * @param email - user email
 * @param hassedPassword - user encrypted password
 * @returns - retuns status object
 */
const createUser = async (name: string, customer_id: string, email: string, hassedPassword: string, phone: number, role: string) => {

    console.log(name, customer_id, email, hassedPassword, phone);
    const query = `insert into user_details(id, name, customer_id, email, password, phone, role) values(uuid(), '${name}', ${customer_id}, '${email}', '${hassedPassword}', ${phone}, '${role}')`;
    const result = await client.execute(query);

    return result;
}

/**
 * User service - getUsers () 
 * this method is used to fetch user info like name, email and password from user table.
 * @returns - user info Object
 */
const getUsers = async () => {

    const result = await client.execute('select * from user_details')

    if (result.rowLength === 0)
        throw new NoDataFoundError('No User Details Found', 20000);
    else
        return result.rows;
}

/**
 * User service - updateUserById () 
 * this method is used to update user info like name, email and password in user table.
 * @param User - user info Object
 */
const updateUserById = async (User: IUser) => {

    const query = `update user_details set name='${User.name}', customer_id=${User.customer_id}, email='${User.email}',
    password='${User.password}' where id=${User.id}`;

    await client.execute(query);
}

/**
 * User service - getUserById () 
 * this method is used to fetch user info like name, email and password from user table using User Id.
 * @param id - user Id
 * @returns - user info Object
 */
const getUserById = async (id: string | number) => {

    const query = `select count(id) as count from user_details where id=${id}`;

    const result = await client.execute(query);

    return result.first();
}

/**
 * User service - deleteUserById () 
 * this method is used to delete user from user table using User Id.
 * @param id - user Id
 */
const deleteUserById = async (id: string | number) => {

    const query = `delete from user_details where id=${id}`;

    await client.execute(query);
}

export { 
    login,
    getUsers,
    createUser,
    getUserById, 
    deleteUserById,
    updateUserById
};

// create table user_details(id uuid primary key,customer_id int, name text, email text, password text, phone Bigint);

//  create table account_details(id uuid primary key, customer_id int, name text, account_no int,account_type text, opened_on date, balance int, bank_name text, branch text, ifsc_code text, user_address text, is_active boolean);

// create table transaction_details(id uuid primary key, amount int, credit_to text, debit_from text, from_account_no bigint, from_bank_name text, 
//     from_isfc_code text, status text, status_message text, to_account_no bigint, to_bank_name text, to_isfc_code text, 
//     comments text, transaction_date timeStamp)

// create table beneficiarie_details(id uuid primary key, customer_id int, beneficiarie_name text, beneficiarie_acountc_no int, 
//     beneficiarie_bank_name text, beneficiarie_ifsc_code text, is_active boolean);