import client from '../config/dbConfig';

import { IBeneficiarie } from '../modal/types';
import { NoDataFoundError } from "../error/noDataError";

/**
 * beneficiarie service - addBeneficiarie() 
 * this post is used to add new Beneficiarie into Beneficiarie_details table
 * @param B - beneficiarie_details Object
 */
const addBeneficiarie = async (B: IBeneficiarie) => {

    const query = `insert into beneficiarie_details(id, beneficiarie_name, customer_id, beneficiarie_acountc_no, 
        beneficiarie_bank_name, beneficiarie_ifsc_code, is_active) values (uuid(), '${B.beneficiarie_name}', ${B.customer_id}, 
        ${B.beneficiarie_acountc_no}, '${B.beneficiarie_bank_name}', '${B.beneficiarie_ifsc_code}', ${B.is_active})`;

    await client.execute(query);
}

/**
 * Beneficiarie service - getAllBeneficiaries() 
 * this GET is used to fetch all  Beneficiarie from Beneficiarie_details table
 * @returns - returns beneficiarie_details Object
 */
const getAllBeneficiaries = async () => {

    const result = await client.execute('select * from beneficiarie_details')

    if (result.rowLength === 0)
        throw new NoDataFoundError('No Beneficiarie Details Found', 20000);
    else
        return result.rows;
}

/**
 * Beneficiarie service - getAllBeneficiaries() 
 * this GET is used to fetch all  Beneficiarie from Beneficiarie_details table
 * @returns - returns beneficiarie_details Object
 */
const getBeneficiaries = async (customerId: string) => {

    const result = await client.execute(`select * from beneficiarie_details where customer_id=${customerId} and is_active=true ALLOW FILTERING`)

    if (result.rowLength === 0)
        throw new NoDataFoundError('No Beneficiarie Details Found', 20000);
    else
        return result.rows;
}

/**
 * Beneficiarie service - updateBeneficiarie() 
 * this PUT is used to update Beneficiarie in Beneficiarie_details table using ID.
 * @param id - - beneficiarie ID
 * @param B - beneficiarie_details Object
 */
const updateBeneficiarie = async (id: string, B: IBeneficiarie) => {

    const query = `update beneficiarie_details set beneficiarie_name='${B.beneficiarie_name}', customer_id=${B.customer_id}, 
    beneficiarie_acountc_no=${B.beneficiarie_acountc_no}, beneficiarie_bank_name='${B.beneficiarie_bank_name}', 
    beneficiarie_ifsc_code='${B.beneficiarie_ifsc_code}', is_active=${B.is_active} where id=${id}`;

    await client.execute(query);
}

/**
 * beneficiarie service - getBeneficiarieById ()
 * this method is used to get Beneficiarie from Beneficiarie_details table using ID.
 * @param id - Beneficiarie Id.
 * @returns  - Beneficiarie Details Object
 */
const getBeneficiarieById = async (id: string | number) => {

    const query = `select count(id) as count from beneficiarie_details where id=${id}`;

    const result = await client.execute(query);

    return result.first();
}

/**
 * beneficiarie service - deleteBeneficiarie ()
 * this method is used to Delet Beneficiarie from Beneficiarie_details table using ID.
 * @param id - Beneficiarie Id.
 */
const deleteBeneficiarie = async (id: string | number) => {

    const query = `update beneficiarie_details set is_active=false where id=${id}`;

    await client.execute(query);
}

export { 
    addBeneficiarie,
    updateBeneficiarie,
    deleteBeneficiarie,
    getAllBeneficiaries,
    getBeneficiarieById,
    getBeneficiaries
};

// id int primary key, category_id int, product_id int, added_by text, added_on date, quantity int, price int