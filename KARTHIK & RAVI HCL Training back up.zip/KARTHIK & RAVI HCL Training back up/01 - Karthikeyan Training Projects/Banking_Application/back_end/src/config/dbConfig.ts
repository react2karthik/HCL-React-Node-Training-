import dotenv from 'dotenv';
import { Client } from 'cassandra-driver';
dotenv.config();

const client = new Client({
    contactPoints: [process.env.HOST_NAME || '127.0.0.1'],
    localDataCenter: process.env.DATA_CENTER || 'datacenter1',
    keyspace: process.env.KEY_SPACE || 'online_banking'
});

client.shutdown(() => {
    console.log('---------------------------- Cassandra DataBase Shutdown Successfully ! ----------------------------');
});

client.connect(() => {
    console.log('---------------------------- Cassandra DataBase Connected Successfully ! ----------------------------');
});

export default client;
