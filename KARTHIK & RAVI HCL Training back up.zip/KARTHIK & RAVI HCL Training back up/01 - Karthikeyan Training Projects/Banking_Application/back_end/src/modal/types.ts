export interface IAccount {
    name: string,
    branch: string,
    balance: number,
    opened_on: string,
    bank_name: string,
    ifsc_code: string,
    account_no: number,
    is_active: boolean,
    customer_id: number,
    account_type: string,
    user_address: string
}
export interface IFundtransfer {
    amount: number,
    comments: string,
    customer_id: number,
    to_ifsc_code: string,
    to_account_no: number,
    from_ifsc_code: string,
    from_account_no: number
}
export interface ITransaction {
    amount: number,
    comments: string,
    credit_to: string,
    debit_from: string,
    from_account_no: number,
    from_bank_name: string,
    from_isfc_code: string,
    status: string,
    status_message: string,
    to_account_no: number,
    to_bank_name: string,
    to_isfc_code: string,
    transaction_date: string
}

export interface IBeneficiarie {
    beneficiarie_name: string,
    customer_id: number,
    beneficiarie_acountc_no: number,
    beneficiarie_bank_name: string,
    beneficiarie_ifsc_code: string,
    is_active: boolean
}

export interface IUser {
    id: string,
    customer_id: string,
    name: string,
    email: string,
    phone: string,
    password: string
}
