export interface IAlert {
    type: string;
    message: string;
}

export interface IAppointmentModuls { 
    id: number; 
    patientName: string;
    doctorName: string;
    appointmentDate: string;
    reason: string;
}

export interface LoginSubmitForm {
    loginEmail: string;
    loginPassword: string;
};

export interface RegisterSubmitForm {
    name: string;
    email: string;
    password: string;
    repeatPassword: string;
    mobile: any;

};