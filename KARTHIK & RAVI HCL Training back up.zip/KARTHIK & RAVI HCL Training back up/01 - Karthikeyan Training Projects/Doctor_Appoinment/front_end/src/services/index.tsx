import axios from "axios"

const callApi = async (url: string, payload: any, method: any) => {
    console.log(url, payload);
    try {
        let response: any;
        if (method == 'post') {
            console.log('url 11111111111111111111111', url);
            console.log('data 222222222222222222', payload)
            response = await axios.post(url, payload)
        } else if (method == 'get') {
            url = `http://localhost:3001/patientDetails?email=${payload.email}&password=${payload.password}`
            console.log(url)
            response = await axios.get(url);
            console.log('res123456', response.data)
        } else {
            response = await axios.get(url);
        }

        return response.data

    } catch (error: any) {
        throw new Error(error.message);
    }

}

export default callApi;