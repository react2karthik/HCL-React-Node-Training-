import React from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
// import store from './store';
import Header from './components/common/header';
import Footer from './components/common/footer';
import { ContextApiProvider, useApiContext } from './components/context/contest';
import Home from './components/home';
import Register from './components/register';
import Appointment from './components/appoiment';
import AppointmentDetails from './components/appoinmentDetails';
import AppointmentAdminView from './components/appoinmentAdminView';

// import Appointment from './components/appointment';
const PrivateRoute: React.FC<{ path: string, component: React.FC }> = ({ path, component }) => {    
    const { isAuthenticated } = useApiContext();
    return isAuthenticated ? <Route path={path} component={component} /> :   <Redirect to="/" />;    
};
 
const App: React.FC = () => {
    return (
        <>
            <ContextApiProvider>
                
                <Router>
                <Header />
                    <Switch>

                        <Route path="/" exact component={Home} />{/*LogiForm LoginFormik*/}
                        <Route path="/login" component={Register} />{/*Register RegisterFormik*/}
                        <Route path="/appointment" component={Appointment} />
                        <Route path="/appointmentDetails" component={AppointmentDetails} />
                        <Route path="/adminView" component={AppointmentAdminView} />

                    </Switch>
                </Router>
                <Footer />
            </ContextApiProvider>
        </>
    );
};
 
export default App;