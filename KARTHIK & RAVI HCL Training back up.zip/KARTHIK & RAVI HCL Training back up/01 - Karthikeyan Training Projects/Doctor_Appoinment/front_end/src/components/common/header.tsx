import React,{useState,useEffect} from 'react';
import {
  MDBNavbar,
  MDBBtn,
  MDBContainer,MDBNavbarBrand
} from 'mdb-react-ui-kit';
import { Link, useHistory } from 'react-router-dom';

const headerImg = require('../../images/headerLogo.png').default;
// import logo from '../../assets/logo.png'; // Import your logo file
// const logo = require('../../assets/logo.png')
const Header: React.FC = (setPassIsLoggedIn:any ) => {
  const [isLoggedIn,setIsLoggedIn] = useState(false);
  const history = useHistory();
 
  useEffect(()=> {
getHeader();
  },[window.localStorage])

  const signOut = () => {
    localStorage.clear(); 
    //window.location.href = '/';
    history.push("/login");
  }
  const getHeader = () => {
    console.log(window.localStorage.getItem('name'), 'kkkkkkkkkkkkkkkkkkkk')
    if(window.localStorage.getItem('name') != null) {
      return <div>Welcome {window.localStorage.getItem('name')} !! 
      <Link to='/login' > some stuff </Link>
      <MDBBtn className='primary btn-sm' onClick={signOut}>Sign Out</MDBBtn>
      </div>
      
    } else {
      return null;
    }
  }
  return (
    <MDBNavbar light bgColor='light'>
      <MDBContainer tag="form" fluid >
         <MDBNavbarBrand>
          <img src={headerImg} alt='Logo' height='90px' className='d-inline-block align-top me-2' />
         
        </MDBNavbarBrand>

        { getHeader() }
      </MDBContainer>
    </MDBNavbar>
  );
}
export default Header;