import React from 'react';
import { IAlert } from '../../model/types'

const AlertComponent: React.FC<IAlert> = ({type, message}) => {
    return (
        <div className={`alert alert-${type}`} role="alert">
            {message}
        </div>
    );
}

export default AlertComponent;