import React from "react";
import { useHistory } from 'react-router-dom';
import {
  MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCardImage, MDBRow, MDBCol, MDBInput, MDBCheckbox,
  MDBTabs, MDBTabsItem, MDBTabsLink, MDBTabsContent, MDBTabsPane, MDBValidationItem
} from 'mdb-react-ui-kit';
const libraryImg = require('../images/dr.png').default;

export default function Home() {
  const history = useHistory();
  const onContinueClick = () => {
    history.push('/login');
  }
  return (
    <div className="p-5 text-center bg-image rounded-3" style={{ backgroundImage: `url(${libraryImg})`, height: 800 }}>
      <MDBBtn type='submit' className="mx-1 bg-gradient text-white appoinment-Btn" onClick={onContinueClick}>
        Book Your Appoinment
      </MDBBtn>
    </div>
  )
};
