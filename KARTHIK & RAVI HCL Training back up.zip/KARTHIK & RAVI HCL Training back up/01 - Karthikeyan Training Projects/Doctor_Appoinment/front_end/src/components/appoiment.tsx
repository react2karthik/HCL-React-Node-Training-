import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCol, MDBRow, MDBInput, MDBCheckbox, MDBIcon } from 'mdb-react-ui-kit';
import { Formik, Field, Form, ErrorMessage } from 'Formik';
import AlertComponent from '../components/common/alert';
import * as Yup from 'yup';
import { useHistory } from 'react-router';
import axios from 'axios';
import { appointmentRequest } from '../store/actions/appoinmentAction';

const Appointment: React.FC = () => {
    const coun = useSelector((state: any) => state);
    const dispatch = useDispatch();
    const history = useHistory();



    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alerttype, setAlertType] = useState('danger');
    const [drList, setDrList] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:3001/doctorDetails').then((res) => {
            const drNames = res.data.map((x: any) =>  <option value={x.drName}>{x.drName}  {`   -   [  ${x.expertIn}  ]`} </option>);
            setDrList(drNames);
        })
    }, []);

    const initialValues = {
        patientName: '',
        doctorName: '',
        appointmentDate: new Date().toISOString().slice(0, 16),
        reason: '',
        email: window.localStorage.getItem('email')
    }
    const validationSchema = Yup.object({
        patientName: Yup.string().required('Patient name is required'),
        doctorName: Yup.string().required('Doctor name is required'),
        appointmentDate: Yup.date().required('Appointment date is required').min(new Date(), 'Appointment date must be in the future'),
        reason: Yup.string().required('Reason for appointment is required')
    });

    const handleSubmit = async (values: any,{ resetForm }: { resetForm: () => void }) => {
        alert(JSON.stringify(values, null, 2));
        dispatch(appointmentRequest(values));
        setShowAlert(true);
        setAlertMessage('Appoinment booked Succesfully!!');
        setAlertType('success');
        resetForm();
        setTimeout(() => {
            history.push('/appointmentDetails')
        }, 2000);
        
    };

    // const resetForm = () => {
    //     resetForm();
    // };
    // function handleSubmit(values, { resetForm }) {
    //     // handle form submission
    //     resetForm();
    //   }

    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false); // Hide the alert after 2 minutes
        }, 3500);

        return () => clearTimeout(timer);
    }, [showAlert]);

    return (
        <>
            <div>
                {showAlert && (
                    <AlertComponent type={alerttype} message={alertMessage} />
                )}
                <h4 className='text-center mt-4 text-primary'>Book Your Appointment..</h4>
                <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit} resetForm>
                    {({ values, handleChange }) => (
                        <Form>
                            <MDBContainer>
                                <MDBRow className='g-0'>
                                    <MDBCol md='12' className='mx-auto'>
                                        <MDBCard className='mx-2 mb-2 p-2 shadow-5'>
                                            <MDBCardBody className='text-black d-flex flex-column justify-content-center w-50 mx-auto'>
                                                <label htmlFor="patientName" className='text-primary'>Patient Name *</label>
                                                <Field type="text" id="patientName" name="patientName" />
                                                <ErrorMessage name="patientName" component="div" className="text-danger" />
                                                {/* <label htmlFor="doctorName" className='text-primary mt-2'>Doctor Name*</label>
                                                <Field type="text" id="doctorName" name="doctorName" /> */}

                                                <div className="w-100">
                                                <label htmlFor="doctorName" className='text-primary mt-2'>Doctor Name*</label>
                                                    <select className="form-select" name="doctorName" onChange={handleChange}>
                                                        <option value="">Select Doctor</option>
                                                        {drList}
                                                    </select>
                                                    <ErrorMessage name="gender" component="div" className="text-danger" />
                                                </div>
                                                <ErrorMessage name="doctorName" component="div" className="text-danger" />
                                                <label htmlFor="appointmentDate" className='text-primary mt-2'>Appointment Date *</label>
                                                <Field type="datetime-local" id="appointmentDate" name="appointmentDate" />
                                                <ErrorMessage name="appointmentDate" component="div" className="text-danger" />
                                                <label htmlFor="reason" className='text-primary mt-2'>Reason for Appointment*</label>
                                                <Field as="textarea" id="reason" name="reason" />
                                                <ErrorMessage name="reason" component="div" className="text-danger" />
                                                <MDBBtn className='w-100 mt-4 bg-gradient text-white' size="lg" type="submit">Book Appointment</MDBBtn>
                                            </MDBCardBody>
                                        </MDBCard>
                                    </MDBCol>
                                </MDBRow>
                            </MDBContainer>
                        </Form>
                    )}
                </Formik>
            </div>
        </>
    )
}

export default Appointment