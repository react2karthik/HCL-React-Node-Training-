import React, { useState, useEffect } from 'react';
import { MDBTable, MDBTableHead, MDBTableBody, MDBContainer, MDBBtn, MDBRow, MDBCol, MDBBreadcrumb, MDBBreadcrumbItem, MDBDropdownItem, MDBDropdown, MDBDropdownToggle, MDBDropdownMenu, MDBCard, MDBCardBody } from 'mdb-react-ui-kit';
import { useHistory, useLocation } from 'react-router-dom';
import axios from 'axios';
import { IAppointmentModuls } from '../model/types';

const AppointmentDetails: React.FC = () => {
    const [appointments, setAppointments] = useState<IAppointmentModuls[]>([]);

    useEffect(() => {
        axios.get<IAppointmentModuls[]>(`http://localhost:3001/appoinmentDetails?email=${window.localStorage.getItem('email')}`)
            .then(response => {
                console.log('!!!!!!!!!!!!!!!!!!!!!!!!!11', response.data)
                setAppointments(response.data);
            })
            .catch(error => {
                console.error('Error fetching appointments:', error);
            });
    }, []);

    console.log(appointments);

    const generateAppoinmentCard = () => {
        const cards = appointments.map((details) => {
            return (
                <MDBCol md='4' className='mx-auto mb-4'>
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">Appointment With: {details.doctorName}</h5>
                            <p className="card-text">Date & Time:  {details.appointmentDate} </p>
                            <button type="button" className="btn btn-danger btn-sm mx-3" data-mdb-ripple-init>Cancel </button>
                            <button type="button" className="btn btn-primary btn-sm" data-mdb-ripple-init>Reschedule </button>
                        </div>
                    </div>
                </MDBCol>
            )
        })

        return cards;
    }
    return (

        <>
            <h4 className="appoinmentHeader text-primary">Your Doctor Appointment Informations</h4>
            <MDBContainer>
                <MDBRow>

                    {generateAppoinmentCard()}

                </MDBRow>

            </MDBContainer>
        </>
    )
}

export default AppointmentDetails;