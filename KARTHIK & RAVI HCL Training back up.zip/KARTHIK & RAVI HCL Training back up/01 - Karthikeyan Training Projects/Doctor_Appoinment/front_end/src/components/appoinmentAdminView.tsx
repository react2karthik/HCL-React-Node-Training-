// import React, { useState, useEffect } from 'react';
// import { MDBTable, MDBTableHead, MDBTableBody, MDBContainer, MDBBtn, MDBRow, MDBCol, MDBBreadcrumb, MDBBreadcrumbItem, MDBDropdownItem, MDBDropdown, MDBDropdownToggle, MDBDropdownMenu } from 'mdb-react-ui-kit';
// import { useHistory, useLocation } from 'react-router-dom';
// import axios from 'axios';
// import { IAppointmentModuls } from '../model/types';

// const AppointmentAdminView: React.FC = () => {
//     const [appointments, setAppointments] = useState<IAppointmentModuls[]>([]);
//     useEffect(() => {
//         axios.get<IAppointmentModuls[]>('http://localhost:3001/appoinmentDetails')
//             .then(response => {
//                 setAppointments(response.data);
//             })
//             .catch(error => {
//                 console.error('Error fetching appointments:', error);
//             });
//     }, []);
//     return (
//         <>
//             <h4 className="appoinmentHeader text-primary">Appointments Information</h4>
//             <MDBContainer   >
//                 <MDBRow className="mt-2 g-0 ">

//                     <MDBCol className="table-bordered ml-auto mt-2 mb-2" md='120'>

//                         <MDBTable className="table-bordered">
//                             <MDBTableHead>
//                                 <tr>
//                                     <th scope='col' className='fw-bold'>PatientName</th>
//                                     <th scope='col' className='fw-bold'>DoctorName</th>
//                                     <th scope='col' className='fw-bold'>AppointmentDate</th>
//                                     <th scope='col' className='fw-bold'>Reason</th>
//                                 </tr>
//                             </MDBTableHead>
//                             <MDBTableBody>
//                                 {appointments?.map((appointment, index) => (
//                                     <tr key={index}>
//                                         {/* <td>{user?.book_id}</td> */}
//                                         <td>{appointment?.patientName}</td>
//                                         <td>{appointment?.doctorName}</td>
//                                         <td>{appointment?.appointmentDate}</td>
//                                         <td>{appointment?.reason}</td>
//                                     </tr>
//                                 ))}
//                             </MDBTableBody>
//                         </MDBTable>
//                     </MDBCol>
//                 </MDBRow>

//             </MDBContainer >
//         </>
//     )
// }


import React, { useState, useEffect } from 'react';
import { MDBTable, MDBTableHead, MDBTableBody, MDBContainer, MDBRow, MDBCol,MDBBtn } from 'mdb-react-ui-kit';
import axios from 'axios';
import { IAppointmentModuls } from '../model/types';  
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
const AppointmentAdminView: React.FC = () => {
    const [appointments, setAppointments] = useState<IAppointmentModuls[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage] = useState(5);
    useEffect(() => {
        axios.get<IAppointmentModuls[]>('http://localhost:3001/appoinmentDetails')
          .then(response => {
            setAppointments(response.data);
          })
          .catch(error => {
            console.error('Error fetching appointments:', error);
          });
      }, []);
    const totalPages = Math.ceil(appointments.length / itemsPerPage);
    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = appointments.slice(indexOfFirstItem, indexOfLastItem);
    const dispatch = useDispatch();
    const history = useHistory();
    const cancelAppointment = (id: number) => {
        alert(id);
        const updatedAppointments = appointments.filter(appointment => appointment.id !== id);
        setAppointments(updatedAppointments);
    };
 
    return(
        <MDBContainer>
            <MDBRow className="mt-2 g-0">
                <MDBCol className="table-bordered ml-auto mt-2 mb-2" md='12'>
                    <MDBTable className="table-bordered border" bordered borderColor="primary" responsive>
                        <MDBTableHead>
                            <tr>
                            <th scope='col' className='fw-bold'>Id</th>
                                <th scope='col' className='fw-bold'>Patient Name</th>
                                <th scope='col' className='fw-bold'>Doctor Name</th>
                                <th scope='col' className='fw-bold'>Appointment Date</th>
                                <th scope='col' className='fw-bold'>Reason</th>
                            </tr>
                        </MDBTableHead>
                        <MDBTableBody>
                            {currentItems.map((appointment, index) => (
                                <tr key={index}>
                                    <td>{appointment.id}</td>
                                    <td>{appointment.patientName}</td>
                                    <td>{appointment.doctorName}</td>
                                    <td>{appointment.appointmentDate}</td>
                                    <td>{appointment.reason}</td>
                                    <td>
                                        <MDBBtn onClick={() => cancelAppointment(appointment.id)}>Cancel</MDBBtn>
                                    </td>
                                </tr>
                            ))}
                        </MDBTableBody>
                    </MDBTable>
                </MDBCol>
            </MDBRow>
            <MDBRow>
                <MDBCol className="text-center">
                    <nav>
                        <ul className="pagination justify-content-center">
                            {Array.from({ length: totalPages }, (_, index) => (
                                <li key={index} className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}>
                                    <button className="page-link" onClick={() => handlePageChange(index + 1)}>
                                        {index + 1}
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </nav>
                </MDBCol>
            </MDBRow>
        </MDBContainer>
    );
}

export default AppointmentAdminView;
