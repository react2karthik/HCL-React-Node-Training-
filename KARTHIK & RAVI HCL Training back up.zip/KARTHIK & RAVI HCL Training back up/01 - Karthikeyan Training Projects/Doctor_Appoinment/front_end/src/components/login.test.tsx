import React from "react";
import { useDispatch, useSelector, Provider } from 'react-redux';
import { shallow, mount, render, ReactWrapper } from 'enzyme';
import configureStore from 'redux-mock-store';

import Register from "./register";
import { loginRequest, loginSuccess, loginFailed } from '../store/actions/loginAction'

const mockStore: any = configureStore([]);

describe('LoginForm component', () => {

    let store: ReturnType<typeof mockStore>;
    let wrapper: ReactWrapper;

    beforeEach(() => {
        store = mockStore({
            auth: {
                userData: null,
            },
        });

        wrapper = mount(
            <Provider store={store}>
                <Register />
            </Provider>
        )
        console.log(wrapper);
        //console.log(wrapper.html());
    })
    it('test login from check Field', () => {
        // expect(wrapper).toMatchSnapshot();
        expect(wrapper.find('Field')).toHaveLength(6);
    })
    it('test loginfrom check form', () => {
        expect(wrapper.find('form')).toHaveLength(2);
    });
    it('check update email input value on change', () => {
        const emailInput = wrapper.find('input[name="email"]');
        emailInput.simulate('change', { target: { name: 'email', value: 'kumar@gmail.com' } });
        expect(wrapper.find('input[name="email"]').prop('value')).toEqual('kumar@gmail.com');
    });
    it('check update password input value on change', () => {
        const passwordInput = wrapper.find('input[name="password"]');
        passwordInput.simulate('change', { target: { name: 'password', value: '123123' } });
        expect(wrapper.find('input[name="password"]').prop('value')).toEqual('123123');
    });
    it('check dispatch login action working', () => {
        const email = 'kumar@gmail.com';
        const password = '123123';
        const action = loginRequest({ email, password });
        expect(action).toEqual({
            type: 'LOGIN',
            payload: { email, password },
        });
    });
    it('should handle login failure', () => {
        const action = loginFailed('Invalid credentials');
        store.dispatch(action);
        const actions = store.getActions();
        expect(actions).toEqual([action]);
    });
    it('should handle login success', () => {
        const userData = { id: 1, name: 'Siva', email: 'siva@gmail.com' };
        const action = loginSuccess(userData);
        store.dispatch(action);
        const actions = store.getActions();
        expect(actions).toEqual([action]);
    });
});