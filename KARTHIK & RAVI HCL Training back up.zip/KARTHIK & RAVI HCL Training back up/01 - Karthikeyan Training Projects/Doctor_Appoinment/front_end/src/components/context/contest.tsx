import React, { createContext, useState, useContext, ReactNode } from 'react';
//import { ContextType } from '../../models/contextTypeModuls';
interface ContextType {
    isAuthenticated: boolean;
    login: () => void;
    logout: () => void;
    teamColor: string;
    setTeamColor: (color: string) => void;
    textTeamColor:string;
    setTextTeamColor: (color: string) => void;
}
const ContextApi = createContext<ContextType | undefined>(undefined);
interface ContextApiProviderProps {
    children: ReactNode;
}
export const ContextApiProvider: React.FC<ContextApiProviderProps> = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [teamColor, setTeamColor] = useState('#ffffff');
    const [textTeamColor,setTextTeamColor] = useState('')
    const login = () => {
        setIsAuthenticated(true)
    }
    const logout = () => {
        setIsAuthenticated(false)
    }
    return (
        <ContextApi.Provider value={{ isAuthenticated, login, logout,teamColor,setTeamColor,textTeamColor,setTextTeamColor}}>
            {children}
        </ContextApi.Provider>
    )
}
 
export const useApiContext = () => {
    const context = useContext(ContextApi);
    if (!context) {
        throw new Error('useApi context have login error')
    }
    return context;
}