import React, { useState, useEffect } from 'react';
import {
    MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCardImage, MDBRow, MDBCol, MDBInput, MDBCheckbox,
    MDBTabs, MDBTabsItem, MDBTabsLink, MDBTabsContent, MDBTabsPane, MDBValidationItem
} from 'mdb-react-ui-kit';
import AlertComponent from '../components/common/alert';
import * as Yup from 'yup';
import { Formik, Field, Form, ErrorMessage, useFormik } from 'Formik';
import { useDispatch, useSelector } from 'react-redux';
import { loginRequest } from '../store/actions/loginAction';
import { registerRequest } from '../store/actions/registerAction';
import { useHistory } from 'react-router';

const drImg = require('../images/dr3.jpg').default;


const Register = () => {
    const loginInfo = useSelector((state: any) => state.loginReducer?.data);
    const registerInfo = useSelector((state: any) => state.registerReducer?.data);
    const dispatch = useDispatch();
    const history = useHistory();

    
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alerttype, setAlertType] = useState('danger');

    const [activeTab, setActiveTab] = useState('login');


    const handleTabClick = (value: string) => {
        if (value === activeTab) {
            return;
        }
        //setValidationErrors({});
        setActiveTab(value);
    };

    const initialValue = {
        email: '',
        password: ''
    }
    const initialValidation = Yup.object({
        email: Yup.string().required('Email is required').email(),
        password: Yup.string().required('Password is required').min(6, 'Password must be at least 6 characters').max(40, 'Password must not exceed 40 characters')
    })

    const initialRegValues = {
        name: '',
        email: '',
        password: '',
        phone: '',
        age: '',
    };
    const initialRegValidation = Yup.object({
        name: Yup.string().required('Name is required'),
        email: Yup.string().required('Email is required').email(),
        password: Yup.string().required('Password is required').min(6, 'Password must be at least 6 characters').max(40, 'Password must not exceed 40 characters'),
        //phone: Yup.string().required('Phone number is required').max(10, 'Phone number must not exceed 10 characters'),
        age: Yup.string().required('Age is required'),
        //gender: Yup.string().required('Gender is required')
    });

    const handleRegister = async (values: any) => {
        alert(JSON.stringify(values, null, 2));
        dispatch(registerRequest(values));
    };
    const handleLogin = async (values: any) => {
        dispatch(loginRequest(values));
    }



    useEffect(() => {
        console.log('useEffect 78 >>>>>>>>>>>>>>>>>>>>', loginInfo);
        if(loginInfo?.length > 0) {
            window.localStorage.setItem('name', loginInfo[0].name);
            window.localStorage.setItem('email', loginInfo[0].email);

            history.push('/appointment');
        } else {
            // setAlertMessage('invalid credentials');
            // setShowAlert(true);
        }
        
    }, [loginInfo]);

    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false); // Hide the alert after 2 minutes
        }, 3500);

        return () => clearTimeout(timer);
    }, [showAlert]);

    useEffect(() => {
        console.log('useEffect 999999 >>>>>>>>>>>>>>>>>>>>', registerInfo);
        if(registerInfo?.id) {
            setAlertType('success');
            setShowAlert(true);
            setAlertMessage('Registed succefully, Please login with email & password.');
        }         
    }, [registerInfo]);

    return (
        <div>
            {showAlert && (
                <AlertComponent type={alerttype} message={alertMessage} />
            )}
            <MDBContainer fluid className='h-100'>
                <MDBRow className='d-flex justify-content-center align-items-center h-100'>
                    <MDBCol>
                        <MDBCard>
                            <MDBRow className='g-0'>
                                <MDBCol md='8' className="d-none d-md-block text-center">
                                    <MDBCardImage src={drImg} alt="Sample photo" className="rounded-start w-100" fluid />
                                </MDBCol>
                                <MDBCol md='4'>
                                    <MDBCardBody className='text-black d-flex flex-column justify-content-center'>

                                        <div>
                                            <MDBTabs pills justify className='mb-3'>
                                                <MDBTabsItem>
                                                    <MDBTabsLink
                                                        onClick={() => handleTabClick('login')}
                                                        active={activeTab === 'login'}
                                                    >
                                                        Login
                                                    </MDBTabsLink>
                                                </MDBTabsItem>
                                                <MDBTabsItem>
                                                    <MDBTabsLink
                                                        onClick={() => handleTabClick('register')} active={activeTab === 'register'}
                                                    >
                                                        Register
                                                    </MDBTabsLink>
                                                </MDBTabsItem>
                                            </MDBTabs>
                                            <MDBTabsContent>
                                                <MDBTabsPane open={activeTab === 'login'}>
                                                <h6 className='text-center mt-4 text-primary'>Login</h6>
                                                    <Formik initialValues={initialValue} validationSchema={initialValidation} onSubmit={handleLogin}>
                                                        {({ values, handleChange }) => (
                                                            <Form>
                                                                <MDBContainer>
                                                                    <MDBRow className='g-0'>
                                                                        <MDBCol md='12'>
                                                                            <MDBCard className='mx-2 mb-2 p-2 shadow-5'>
                                                                                <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                                                                                    <label htmlFor="email" className='text-primary'>Email*</label>
                                                                                    <Field type="text" id="email" name="email" className='mb-4' />
                                                                                    <ErrorMessage name="email" component="div" className="text-danger" />
                                                                                    <label htmlFor="password" className='text-primary'>Password*</label>
                                                                                    <Field type="password" id="password" name="password" className='mb-4' />
                                                                                    <ErrorMessage name="password" component="div" className="text-danger" />


                                                                                    <div className="d-flex justify-content-center align-items-center mt-2">
                                                                                        <MDBBtn type='submit' className="bg-gradient text-white">
                                                                                            Sign in
                                                                                        </MDBBtn>

                                                                                    </div>
                                                                                </MDBCardBody>
                                                                            </MDBCard>
                                                                        </MDBCol>
                                                                    </MDBRow>
                                                                </MDBContainer>
                                                            </Form>
                                                        )}
                                                    </Formik>
                                                </MDBTabsPane>
                                                <MDBTabsPane open={activeTab === 'register'}>

                                                <h6 className='text-center mt-4 text-primary'>Registration</h6>
                                                    <Formik initialValues={initialRegValues} validationSchema={initialRegValidation} onSubmit={handleRegister}>

                                                        {({ values, handleChange }) => (
                                                            <Form>
                                                                <MDBContainer>
                                                                    <MDBRow className='g-0'>
                                                                        <MDBCol md='12'>
                                                                            <MDBCard className='shadow-5'>
                                                                                <MDBCardBody className='text-black d-flex flex-column justify-content-center'>

                                                                                    <MDBCol md="12" className='register_label'>



                                                                                        <label htmlFor="name" className='text-primary'>Name*</label>

                                                                                        <Field className='mb-4 w-100' label='Name' id='name' type='text' name='name' />

                                                                                        <ErrorMessage name="name" component="div" className="text-danger" />

                                                                                        <label htmlFor="email1" className='text-primary'>Email*</label>

                                                                                        <Field className='mb-4 w-100' label='Email' id='email1' type='email' name='email1' />

                                                                                        <ErrorMessage name="email1" component="div" className="text-danger" />

                                                                                        <label htmlFor="Password1" className='text-primary'>Password*</label>

                                                                                        <Field className='mb-4 w-100' label='Password' id='password1' type='password' name='password1' />

                                                                                        <ErrorMessage name="password1" component="div" className="text-danger" />

                                                                                        <label htmlFor="age" className='text-primary'>Age*</label>

                                                                                        <Field className='mb-4 w-100' label='Age' id='age' type='age' name='age' />

                                                                                        <ErrorMessage name="age" component="div" className="text-danger" />

                                                                                        {/* <label htmlFor="phone">Phone</label>

                                                                                        <Field className='mb-4 w-100' label='Phone' id='phone' type='number' name='phone' />

                                                                                        <ErrorMessage name="phone" component="div" className="text-danger" /> */}

                                                                                        <div className="mb-3 w-100">

                                                                                            <select className="form-select" name="gender">

                                                                                                <option value="">Select Gender</option>

                                                                                                <option value="male">Male</option>

                                                                                                <option value="female">Female</option>

                                                                                                <option value="other">Other</option>

                                                                                            </select>

                                                                                            <ErrorMessage name="gender" component="div" className="text-danger" />

                                                                                        </div>

                                                                                       

                                                                                        <div className="d-flex justify-content-center align-items-center mt-2">
                                                                                       
                                                                                        <MDBBtn className='bg-gradient text-white' type="submit">Register</MDBBtn>

                                                                                    </div>
                                                                                    </MDBCol>

                                                                                </MDBCardBody>

                                                                            </MDBCard>

                                                                        </MDBCol>



                                                                    </MDBRow>

                                                                </MDBContainer>

                                                            </Form>

                                                        )}

                                                    </Formik>

                                                </MDBTabsPane>
                                            </MDBTabsContent>
                                        </div>
                                    </MDBCardBody>
                                </MDBCol>
                            </MDBRow>
                        </MDBCard>
                    </MDBCol>
                </MDBRow>
            </MDBContainer>
        </div>
    );
}

export default Register;