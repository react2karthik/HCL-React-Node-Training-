import { call, put, takeLatest } from 'redux-saga/effects';
import { APPOINTMENT_REQUEST, appointmentSuccess, appointmentFailure } from '../actions/appoinmentAction';
import { APPOINMENTAPI } from '../../constant';
import apiService from '../../services/index';
 
function* appointment(data: any): Generator<any, void, any> {
    try {
        const response: any = yield call(apiService, APPOINMENTAPI, data.payload, 'post');//APPOINMENTDETAILSAPI
        yield put(appointmentSuccess(response.data));
    } catch (error: any) {
        yield put(appointmentFailure(error.message))
    }
}
function* appointmentSaga() {
    yield takeLatest(APPOINTMENT_REQUEST, appointment)
}
export default appointmentSaga;
 