
import { call, put, takeLatest } from 'redux-saga/effects'; //takeevery
import { LOGIN, loginSuccess, loginFailed } from '../actions/loginAction';
import { LOGINAPI } from '../../constant';
import callApi from '../../services';

function* login(data: any):Generator<any, void, any> {
  try {
    console.log('data >>>>>>>>>>>>>>>>>>', data);
    const response:any = yield call(callApi, LOGINAPI, data.payload, 'get'); 
    yield put(loginSuccess(response));
  } catch (error) {
    yield put(loginFailed(error));
  }
}

function* loginSaga() {
  yield takeLatest(LOGIN, login);
}

export default loginSaga;




// import { toast } from 'react-toastify';
// import db from '../../db.json';

// function* handleLogin(action: any): Generator<any, void, any> {
//   try {
//    const { email, password } = action.payload;
//    console.log(action.payload,"miii")
// console.log(db.patients,"testtt")
//    // Check if the email and password exist in the db.json data
//    const user = db.patients.find((u: any) => u.email == email && u.password == password);
//    let stringifyData = JSON.stringify(user);
// console.log("my user",user)
// localStorage.setItem("patientData",stringifyData)
//    if (user) {
//      yield put(loginSuccess(email));
//      toast.success('Login successful');
//    } else {
//      yield put(loginFailure());
//      toast.error('Invalid email or password');
//    }
//   } catch (error) {
//    console.error('Login error:', error);
//    yield put(loginFailure());
//    toast.error('An error occurred');
//   }
// }
// function* authSaga(): Generator<any, void, any> {
//   yield takeLatest(LOGIN, handleLogin);
// }
// export default authSaga;
