import { call, put, takeLatest } from 'redux-saga/effects';
import { REGISTER_REQUEST, registerSuccess, registerFailure } from '../actions/registerAction';
import { REGISTERAPI } from '../../constant';
import apiService from '../../services/index';

function* register(data: any): Generator<any, void, any> {
    try {
        const response: any = yield call(apiService, REGISTERAPI, data.payload, 'post');
        console.log('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz', response)
        yield put(registerSuccess(response));
    } catch (error: any) {
        console.log('fail fail')
        yield put(registerFailure(error.message))
    }
}
function* registerSaga() {
    yield takeLatest(REGISTER_REQUEST, register)
}
export default registerSaga;
