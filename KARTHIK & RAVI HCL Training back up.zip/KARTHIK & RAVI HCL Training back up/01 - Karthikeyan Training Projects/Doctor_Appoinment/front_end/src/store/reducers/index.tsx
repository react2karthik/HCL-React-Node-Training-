// reducers/index.ts
import { combineReducers } from 'redux';
import loginReducer from './loginReducer'; 
import registerReducer from './registerReducer';
import appointmentReducer from './appoinmentReducer';

const rootReducer = combineReducers({
    loginReducer, registerReducer, appointmentReducer
});

export default rootReducer;
