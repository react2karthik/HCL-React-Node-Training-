import { mount,  shallow} from "enzyme";
import React from "react";
import App from './app';

test('checking the acomponent is present or not', () => {
const wraper = shallow(<App />);

console.log('wraper debug', wraper.debug());
expect(wraper).toMatchSnapshot();
});

