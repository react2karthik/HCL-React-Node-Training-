POST: http://localhost:3030/users/register

{
    "name": "latha",
    "gender": "female",
    "dob": "1976-02-16",
    "qualification": "10th pass",
    "phone": 3566666779,
    "email": "latha@gmail.com",
    "password": "passwordlatha",
    "occupation": "daily labor"
}
--------------------------------------------------------------------------------------------------------------------------
POST: http://localhost:3030/users/login
{
	// male user
    "email": "1mail@gmail.com",  
    "password": "password1"
}
{
	//female user 
    "email": "2mail@gmail.com",  
    "password": "password2"
}
{
    //admin user 
    "email": "admin@gmail.com",  
    "password": "admin"
}
{
    //other user 
    "email": "others@gmail.com",  
    "password": "password2"
}
-----------------------------------------------------------------------------------------------------------------------------

GET:  http://localhost:3030/profiles

GET:  http://localhost:3030/profiles/:userID

-----------------------------------------------------------------------------------------------------------------------------
POST: http://:userID/intrests/:intrestedID
-----------------------------------------------------------------------------------------------------------------------------
GET:  http://:userID/interested-in     http://5b0fba1a-2db7-4133-b807-552aeb420caa/interested-in
GET:  http://:userID/interested-by
-----------------------------------------------------------------------------------------------------------------------------
PUT:  http://:userID/comment/:toUserID


Step 1: explain about use case
Step 2: what is the tech stack using - typescript, node, express, cassandra, chai & mocha
Step 3: explain feature in this use case, with data contract 
Step 4: 
     4.1 while talking about user registraion show validation message
     4.2 enter valid enter info and register
     4.3 after registration explain success response
     4.4 if you register same user detail throw error saying user alread exist
     4.5 explain byrcypt for password hashing 
     5
     5.1 explain with invalid login credential and show validation messages
     5.2 explain profile api 
     5.3 explain male user profile view
     5.4 explain female user profile view
     5.5 explain admin profile view
     5.5 unit test case using chai and mocha
step 6: what are the best practices we followed in our project
     6.1 express validator, error handling, logger winston module for logger, eslint rules, 
     6.2 external thirdpart API 
     6.3 any sugesion

