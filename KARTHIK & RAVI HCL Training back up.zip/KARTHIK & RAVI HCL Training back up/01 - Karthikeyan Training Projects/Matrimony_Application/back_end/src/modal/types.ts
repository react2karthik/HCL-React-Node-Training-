/**
 * user data model
 */
export interface IUser {
    dob: string,
    gender: string,
    name: string,
    email: string,
    phone: number,
    occupation: string,
    qualification: string,
    hassedPassword: string,
}

/**
 * showingInterest data model
 */
export interface IShowingInterest {
    id: string,
    user_id: string,
    interested_in: string,
    status: string,
    comments: string,
    showed_interest_on: string
}

/**
 * data model
 */
export interface IData {
    name: string,
    interest_showed_on: string,
    status: string,
    comment: string,
    age: string
}        