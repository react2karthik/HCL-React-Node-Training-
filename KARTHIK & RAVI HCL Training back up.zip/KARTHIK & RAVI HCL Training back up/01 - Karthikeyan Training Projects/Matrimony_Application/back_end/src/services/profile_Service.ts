import client from '../config/dbConfig';
import { NoDataFoundError } from "../error/noDataError";

/**
 * Profile Details service - getAllProfiles () 
 * this method is used to get Profile into  Profile_details table.
 * @returns - Profile_Detail Object
 */
const getAllProfiles = async () => {

    const result = await client.execute(`select name, age, gender, occupation, dob, email, phone, qualification from user_details`);

    if (result.rowLength === 0)
        throw new NoDataFoundError('No Profile details found', 10000);
    else
        return result.rows;
}

/**
 * Profile Details service - getAllProfiles (userId: string) 
 * this method is used to get Profile into  Profile_details table.
 * @param userId 
 * @returns - Profile_Detail Object
 */
const getProfileBasedOnMyGender = async (userId: string) => {

    let result = await client.execute(`select gender from user_details where id=${userId}`);
    const gender = getOppositeGender(result.first().get('gender'))
    const query = `select name, age, gender, occupation, dob, email, phone, qualification from user_details where gender IN (${gender}) and role='user' ALLOW FILTERING`;

    result = await client.execute(query);

    if (result.rowLength === 0)
        throw new NoDataFoundError('No Profile details found', 10000);
    else
        return result.rows;
}

/**
 * --------------------------------------------------------------------------
 * Profile Details service - getOppositeGender (gender: string) 
 * this method is used to get opposit gender.
 * @param gender - male / female / others
 * @returns - male / female / others
 * ---------------------------------------------------------------------------
 */
const getOppositeGender = (gender: string) => {
    if (gender == 'others') { return `'male', 'female', 'others'`; }
    if (gender == 'male') { return `'female'`; }
    if (gender == 'female') { return `'male'`; }
}

/**
 * ---------------------------------------------------------------------------
 * Profile Details service - getProfileDetailById (userId: string) 
 * this method is used to get Profile from  Profile_details table using ID.
 * @param id - Profile ID
 * ---------------------------------------------------------------------------
 */
const getProfileBasedOnId = async (userId: string) => {

    const query = `select name, age, gender, occupation, dob, email, phone, qualification from user_details where id=${userId} ALLOW FILTERING`;
    const result = await client.execute(query);

    if (result.rowLength === 0)
        throw new NoDataFoundError('No Profile details found', 10000);
    else
        return result.rows;
}

export {
    getAllProfiles,
    getProfileBasedOnId,
    getProfileBasedOnMyGender
};

