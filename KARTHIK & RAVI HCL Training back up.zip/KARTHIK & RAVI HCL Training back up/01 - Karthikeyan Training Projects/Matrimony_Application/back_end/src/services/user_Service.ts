import client from '../config/dbConfig';
import { IUser, IData } from '../modal/types';
import { NoDataFoundError } from "../error/noDataError";
import { types } from 'cassandra-driver';

/**
 * ----------------------------------------------------------------------------------------------------
 * User service - login () 
 * this method is used to validate user email and password.
 * @param email - user email id. 
 * @returns - token for authorization (jwt token)
 * ----------------------------------------------------------------------------------------------------
 */
const login = async (email: string) => {

    const query = `select email, password, id, role from user_details where email='${email}' ALLOW FILTERING`;
    const result = await client.execute(query);

    return result;
}

/**
 * ----------------------------------------------------------------------------------------------------
 * User service - createUser () 
 * this method is used to insert user info like name, email and password into user table.
 * @param id -user Id
 * @param name - user name
 * @param email - user email
 * @param hassedPassword - user encrypted password
 * @returns - retuns status object
 * ----------------------------------------------------------------------------------------------------
 */
const createUser = async (User: IUser) => {

    const currentAge = await getUserAge(User.dob);
    const query = `insert into user_details(id, name, age, gender, email, password, dob, phone, occupation, qualification, role) 
    values(uuid(), '${User.name}', ${currentAge}, '${User.gender}', '${User.email}', '${User.hassedPassword}', '${User.dob}', ${User.phone}, '${User.occupation}', '${User.qualification}', 'user')`;

    const result = await client.execute(query);

    return result;
}

/**
 * ----------------------------------------------------------------------------------------------------
 * Method: showIntrest()
 * this method is used to insert intrested details in to showed_interest_details
 * @param userID - user_id
 * @param intrestedID - intrested in user_id
 * @returns - success / failure object
 * ----------------------------------------------------------------------------------------------------
 */
const showIntrest = async (userID: string, intrestedID: string) => {

    const query = `insert into showed_interest_details(id, user_id, showed_interest_on, interested_in, comments, status) 
    values(uuid(), ${userID}, toTimestamp(now()), ${intrestedID}, 'PENDING', 'PENDING')`;

    const result = await client.execute(query);

    return result;
}

/**
 * ----------------------------------------------------------------------------------------------------
 * Method: getinterestedInProfile()
 * this method is used to select intrestedIN details in from showed_interest_details
 * @param userID - user_id
 * @returns - retuns user interestedIn Object().
 * ----------------------------------------------------------------------------------------------------
 */
const getinterestedInProfile = async (userID: string) => {

    const query = `select interested_in, comments, status, showed_interest_on from showed_interest_details where user_id=${userID} allow filtering`;
    
    const result = await client.execute(query);

    if (result.rowLength === 0) {
        throw new NoDataFoundError('No Profile details found', 10000);
    } else {
        const generatedData = await generateData(result);

        return generatedData;
    }
}

/**
 * ----------------------------------------------------------------------------------------------------
 * Method: getinterestedByProfile()
 * this method is used to select intrestedBy details in from showed_interest_details
 * @param userID - user_id
 * @returns - retuns user interestedBy Object().
 * ----------------------------------------------------------------------------------------------------
 */
const getinterestedByProfile = async (userID: string) => {

    const query = `select user_id, comments, status from showed_interest_details where interested_in=${userID} allow filtering`;

    const result = await client.execute(query);

    if (result.rowLength === 0) {
        throw new NoDataFoundError('No Profile details found', 10000);
    } else {
        const generatedData = await generateData(result);
        return generatedData;
    }
}

/**
 * ---------------------------------------------------------------------------------------------------- 
 * Method: getUserAge()
 * this method is used to get the age of the user by their DOB.
 * @param dob - date of birth 
 * @returns - age of the user
 * ----------------------------------------------------------------------------------------------------
 */
const getUserAge = async (dob: any) => {

    const from = dob.split("-");
    const birthdateTimeStamp: any = new Date(from[0], from[1] - 1, from[2]);
    const currentDate: any = new Date();
    const diff = currentDate - birthdateTimeStamp;
    // This is the difference in milliseconds
    const currentAge = Math.floor(diff / 31557600000);
    console.log(currentAge);

    return currentAge;
}

/**
 * ---------------------------------------------------------------------------------------------------- 
 * Method: getUserByID(userID)
 * this method will return user information from user_details table.
 * @param userID - user_id
 * @returns - retuns user name, age, dob, email, gender, occupation, qualification from user_details table.
 * ---------------------------------------------------------------------------------------------------- 
*/
const getUserByID = async (userID: string) => {
    const query = `select name, age, dob, email, gender, occupation, qualification, phone from user_details where id=${userID} ALLOW FILTERING`;
    const result = await client.execute(query);

    return result;
}

/**
 * ---------------------------------------------------------------------------------------------------- 
 * Method: sendCommend()
 * this method is used to update commnets & status in showed_interest_details table.
 * @param userID - userID who need to comment
 * @param toUserID - this userID receives comments and feedback 
 * @param comment - comment text
 * @param statusTxt - accepted, rejected, pending
 * @returns - retuns success/ failure object()
 * ---------------------------------------------------------------------------------------------------- 
 */
const sendCommend = async (userID: string, toUserID: string, comment: string, statusTxt: string) => {
    const query = `select id from showed_interest_details where user_id=${toUserID} and interested_in=${userID} ALLOW FILTERING`;
    const result = await client.execute(query);

    if (result.rowLength === 0)
        throw new NoDataFoundError('No Profile details found', 10000);
    else {
        const { id } = result.first();
        const query = `update showed_interest_details set comments='${comment}', status='${statusTxt}' where id=${id}`;
        const result1 = await client.execute(query);

        return result1;
    }
}

/**
 * Method: generateData()
 * this method will join user_details & showed_intrest table return new resultSet.
 * @param result - user Object()
 * @returns - result Object()
 */
const generateData = async (result: types.ResultSet) => {
    let data: IData[] = [];
    for (const row of result.rows) {

        const userData: IData = { name: '', interest_showed_on: '', status: '', comment: '', age: '' };
        const date = new Date(row.get('showed_interest_on'));
        const userid = row.get('interested_in') == undefined ? row.get('user_id') : row.get('interested_in')
        const userResult = await getUserByID(userid);

        userData.interest_showed_on = date.toLocaleString();
        userData.status = row.get('status');
        userData.comment = row.get('comments');
        userData.name = userResult.first().get('name');
        userData.age = userResult.first().get('age');

        data = [...data, userData];
    }

    return data;
}

/**
 * Method: generateHTMLTable()
 * this method is used to generate HTMLTable to show profile information.
 */
const generateHTMLTable = (data: any) => {
    let table = `<table style='background-color:c2c2a3' width='700px' border='1px' cellpadding='3px' cellspacing='2px'>`;
    table += '<tr><th>Name</th><th>Age</th><th>interest_showed_on</th><th>status</th><th>comment</th></tr>';
    data.forEach((item: { name: any; age: any; interest_showed_on: any; status: any; comment: any; }) => {
        table += `<tr><td>${item.name}</td><td>${item.age}</td><td>${item.interest_showed_on}</td><td>${item.status}</td><td>${item.comment}</td></tr>`;
    });
    table += '</table>';

    return table;
}

export {
    login,
    createUser,
    sendCommend,
    showIntrest,
    generateHTMLTable,
    getinterestedInProfile,
    getinterestedByProfile
};
