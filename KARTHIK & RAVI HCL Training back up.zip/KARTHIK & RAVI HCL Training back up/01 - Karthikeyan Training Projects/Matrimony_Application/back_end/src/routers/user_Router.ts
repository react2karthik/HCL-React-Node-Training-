import express, { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import logger from '../config/logger';
import { IUser } from '../modal/types';
import constances from '../constants/constant';
import userValidator from '../validators/userValidators';
import loginValidator from '../validators/loginValidators';
import authMiddleware from '../middleware/authMiddleware';
import { UnAuthorizedAccess } from '../error/unAuthorizedError';
import validateMiddleware from '../middleware/validateMiddleware';
import { login, createUser, showIntrest, getinterestedInProfile, getinterestedByProfile, generateHTMLTable, sendCommend } 
from '../services/user_Service';

dotenv.config();

const userRouter: express.Router = express.Router();

/**
 * --------------------------------------------------------------------------
 * Method: userRouter.get()
 * this GET method is used to generate auth token if credentials are valid.
 * --------------------------------------------------------------------------
 */
userRouter.post('/register', userValidator(), validateMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { name, dob, gender, email, qualification, occupation, password, phone } = req.body;

    try {
        const hassedPassword = await bcrypt.hash(password, 10);
        const userDetails : IUser = { name, dob, gender, email, qualification, hassedPassword, phone, occupation }
        const result = await createUser(userDetails);

        logger(path).info(constances.USER_PROFILE_ADDED_SUCCESS_MESSAGE);

        res.json({
            message: constances.USER_PROFILE_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.USER_ADDED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

/**
 * ---------------------------------------------------------------------------
 * Method: userRouter.get()
 * this GET method is used to generate auth token if credentials are valid.
 * ---------------------------------------------------------------------------
 */
userRouter.post('/:userID/intrests/:intrestedID',  async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { userID, intrestedID } = req.params;

    try {
  
        await showIntrest(userID, intrestedID);
        
        logger(path).info(constances.USER_INTREST_POSTED_SUCCESS_MESSAGE);
        
        res.json({
            message: constances.USER_INTREST_POSTED_SUCCESS_MESSAGE,
            statusCode: constances.USER_INTREST_POSTED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

/**
 * --------------------------------------------------------------------------
 * Method: userRouter.get()
 * this GET method is used to generate auth token if credentials are valid.
 * --------------------------------------------------------------------------
 */
userRouter.get('/:userID/interested-in', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { userID } = req.params;

    try {
  
        const result = await getinterestedInProfile(userID);
        const table = await generateHTMLTable(result);

        logger(path).info(constances.USER_PROFILE_FETCHED_SUCCESS_MESSAGE);

        res.json({
            data: result,
            message: constances.USER_PROFILE_FETCHED_SUCCESS_MESSAGE,
            statusCode: constances.USER_PROFILE_FETCHED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE,
            table
        });

    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

/**
 *-------------------------------------------------------------------------
 * Method: userRouter.get()
 * this GET method is used to generate auth token if credentials are valid.
 * ------------------------------------------------------------------------
 */
userRouter.get('/:userID/interested-by', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { userID } = req.params;

    try {
  
        const result = await getinterestedByProfile(userID);
        const table = await generateHTMLTable(result);

        logger(path).info(constances.USER_PROFILE_FETCHED_SUCCESS_MESSAGE);

        res.json({
            data: result,
            message: constances.USER_PROFILE_FETCHED_SUCCESS_MESSAGE,
            statusCode: constances.USER_PROFILE_FETCHED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE,
            table
        });

    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

/**
 * ---------------------------------------------------------------------------
 * Method: userRouter.put()
 * this POST method is used to generate auth token if credentials are valid.
 * ---------------------------------------------------------------------------
 */
userRouter.put('/:userID/comment/:toUserID', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { userID, toUserID } = req.params;
    const { comments, status } = req.body;

    try {
  
        await sendCommend(userID, toUserID, comments, status);

        logger(path).info(constances.USER_STATUS_UPDATE_SUCCESS_MESSAGE);

        res.json({
            message: constances.USER_STATUS_UPDATE_SUCCESS_MESSAGE,
            statusCode: constances.USER_STATUS_UPDATE_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE,
        });

    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

/**
 * --------------------------------------------------------------------------
 * user router
 * this POST method is used to generate auth token if credentials are valid.
 * --------------------------------------------------------------------------
 */
userRouter.post('/login', loginValidator(), validateMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { email, password } = req.body;
    const result = await login(email);

    if (result.first() != null) {
        const { id, role } = result.first();
        const isMatching = await bcrypt.compare(password, result.first().get('password'));

        if (isMatching) {
            const token = jwt.sign({email, userId: id, role }, process.env.SECRET_KEY || '', { expiresIn: '1h' });
            
            logger(path).info(constances.USER_CREDENTIALS_SUCCESS_MESSAGE);

            res.json({
                status: 'success',
                data: token
            })
        } else {
            try {
                throw new UnAuthorizedAccess(constances.ACCESS_DENIED_MESSAGE, constances.ACCESS_DENIED_CODE);
            } catch (error) {
                logger(path).error(error);
                next(error);
            }
        }
    } else {
        logger(path).info(constances.USER_NOT_EXIST_MESSAGE);

        res.json({
            message: constances.USER_NOT_EXIST_MESSAGE,
            statusCode: constances.USER_NOT_EXIST_CODE,
            statue: constances.FAILED_MESAGE,
            data: email
        })
    }
});

export default userRouter;