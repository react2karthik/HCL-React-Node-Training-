import express, { Response, NextFunction } from 'express';
import logger from '../config/logger';
import constances from '../constants/constant';
import authMiddleware from '../middleware/authMiddleware';
import { getAllProfiles, getProfileBasedOnId, getProfileBasedOnMyGender } from '../services/profile_Service';

const profileRouter: express.Router = express.Router();

/**
 * -------------------------------------------------------------------------------
 * profile Router
 * this GET method is used to get all profile information from user_details table.
 * -------------------------------------------------------------------------------
 */
profileRouter.get('/',authMiddleware, async (req: any, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { userId, role } = req;

    try {
        let data;
        if(role != 'admin') {
            data = await getProfileBasedOnMyGender(userId);
        } else {
            data = await getAllProfiles();
        }

        logger(path).info(constances.PROFILE_FECTHED_SUCCESS_MESSAGE);

        res.json({
            data,
            message: constances.PROFILE_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.PROFILE_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

/**
 * --------------------------------------------------------------------------------------------
 * profile Router
 * this GET method is used to get one profile information from user_details table using userID.
 * --------------------------------------------------------------------------------------------
 */
profileRouter.get('/:userID',authMiddleware, async (req: any, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { userID } = req.params;

    try {
        const data = await getProfileBasedOnId(userID);

        logger(path).info(constances.PROFILE_FECTHED_SUCCESS_MESSAGE);

        res.json({
            data,
            message: constances.PROFILE_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.PROFILE_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});

export default profileRouter;