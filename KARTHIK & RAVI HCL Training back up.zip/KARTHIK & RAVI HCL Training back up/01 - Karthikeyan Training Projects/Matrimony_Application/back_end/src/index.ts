import express from 'express';
import dotenv from 'dotenv';
import appLogger from './middleware/appLogger';
import printData from './middleware/printData';
import errorMiddleware from './middleware/errorMiddleware';
import userRouter from './routers/user_Router';
import profileRouter from './routers/profile_Router';


const app: express.Application = express();
dotenv.config();
const port = process.env.PORT || 4000;

app.use(express.json());
app.use(appLogger);
app.use(printData);

// online banking routers
app.use('/users', userRouter);
app.use('/profiles', profileRouter);

// error middleware
app.use(errorMiddleware)

app.listen(port, () => {
    console.log(`---------------------------------- Server started at port number : ${port} ----------------------------------`);
});

export default app;




