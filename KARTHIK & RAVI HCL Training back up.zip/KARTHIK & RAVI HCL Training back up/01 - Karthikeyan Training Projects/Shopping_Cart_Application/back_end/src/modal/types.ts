export interface IEmployee {
    id: string,
    name: string,
    age: number,
    salary: number,
    empCode: string,
    reportsTo: string
}

export interface IUser {
    id: string,
    name: string,
    email: string,
    password: string,
    phone: number
}

export interface IProduct {
    id: string,
    product_name: string,
    product_description: string,
    category_id: number,
    expiry_date: string,
    manufacturing_date: string,
    price: number,
    quantity: number
}

export interface ICategory {
    id: string,
    category_name: string,
    category_description: string
}

export interface IOrder {
    id: string,
    product_id: string,
    category_id: string,
    order_by: string,
    order_on: string,
    status: string,
    transaction_id: string
}

export interface ICart {
    id: string,
    product_id: string,
    category_id: string,
    added_by: string,
    added_on: string,
    price: string,
    quantity: string
}
