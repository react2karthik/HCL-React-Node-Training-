import express from 'express';
import dotenv from 'dotenv';
import appLogger from './middleware/appLogger';
import printData from './middleware/printData';
import errorMiddleware from './middleware/errorMiddleware';
import userRouter from './routers/userRouter';
import productRouter from './routers/productRouter';
import cartRouter from './routers/cartRouter';
import categoryRouter from './routers/categoryRouter';
import orderRouter from './routers/orderRouter';
//import employeeRouter from './routers/employeeRouter';
import errorRouter from './routers/errorRouter';

const app: express.Application = express();
dotenv.config();
const port = process.env.PORT || 4000;

app.use(express.json());
app.use(appLogger);
app.use(printData);

app.use('/user', userRouter);
app.use('/order', orderRouter);
app.use('/cart', cartRouter);
app.use('/product', productRouter);
app.use('/category', categoryRouter);
//app.use('/employee', employeeRouter);
app.use('/error', errorRouter);

app.use(errorMiddleware)

app.listen(port, () => {
    console.log(`---------------------------------- Server started at port number : ${port} ----------------------------------`);
})




