
export const NO_CATEGORY_FOUND_MESSAGE: string = 'No category found';
export const NO_CATEGORY_FOUND_CODE: number = 1000;

export const NO_CATEGORY_FOUND_SEARCH_MESSAGE: string = 'No category found for given search criteria';
export const NO_CATEGORY_FOUND_SEARCH_CODE: number = 1001

export const CREATE_CATEGORY_SUCCESS_MESAGE: string = 'New category added successfully'; 
export const CREATE_CATEGORY_SUCCESS_CODE: number = 1003;

export const DELETE_CATEGORY_SUCCESS_MESAGE: string = 'Category deleted successfully';
export const DELETE_CATEGORY_SUCCESS_CODE: number = 1002;

export const CATEGORY_FECTHED_SUCCESS_MESSAGE: string ='Categories fetched successfully';
export const CATEGORY_FECTHED_SUCCESS_CODE: number = 2001;

const constances = {
    SUCCESS_MESAGE: 'Success',
    FAILED_MESAGE: 'Failed',

    USER_NOT_EXIST_MESSAGE: 'USer not exist',
    USER_NOT_EXIST_CODE: 3433,

    ACCESS_DENIED_MESSAGE: 'ACCESS DENIED', 
    ACCESS_DENIED_CODE: 232,
    NO_CATEGORY_FOUND_MESSAGE: 'No category found',
    NO_CATEGORY_FOUND_CODE: 1000,
    CATEGORY_ADDED_SUCCESS_MESSAGE: 'Category Added successfully',
    CATEGORY_ADDED_SUCCESS_CODE: 1001,
    ORDER_ADDED_SUCCESS_MESSAGE: 'Order Added successfully',
    ORDER_ADDED_SUCCESS_CODE: 2001,
    USER_ADDED_SUCCESS_MESSAGE: 'User Added successfully',
    USER_ADDED_SUCCESS_CODE: 3001,
    CATEGORY_FECTHED_SUCCESS_MESSAGE: 'Categories fetched successfully',
    CATEGORY_FECTHED_SUCCESS_CODE: 1002,
    ORDER_FECTHED_SUCCESS_MESSAGE: 'Order fetched successfully',
    ORDER_FECTHED_SUCCESS_CODE: 2002,
    USER_FECTHED_SUCCESS_MESSAGE: 'Users fetched successfully',
    USER_FECTHED_SUCCESS_CODE: 3002,
    CATEGORY_FOUND_SEARCH_MESSAGE: 'category found for given search criteria',
    CATEGORY_FOUND_SEARCH_CODE: 1003,
    NO_CATEGORY_FOUND_SEARCH_MESSAGE: 'No category found for given search criteria',
    NO_CATEGORY_FOUND_SEARCH_CODE: 1004,
    DELETE_CATEGORY_SUCCESS_MESAGE: 'Category deleted successfully',
    DELETE_CATEGORY_SUCCESS_CODE: 1005,
    UPDATE_CATEGORY_SUCCESS_MESSAGE: 'Category Updated successfully', 
    UPDATE_CATEGORY_SUCCESS_CODE: 1006,  
    UPDATE_CATEGORY_FAIL_MESSAGE: 'Id not found in category table to Update category', 
    UPDATE_CATEGORY_FAIL_CODE: 1007, 
    UPDATE_ORDER_SUCCESS_MESSAGE: 'Order Updated successfully', 
    UPDATE_ORDER_SUCCESS_CODE: 1008,  
    UPDATE_ORDER_FAIL_MESSAGE: 'Id not found in order_details table to Update order details', 
    UPDATE_ORDER_FAIL_CODE: 1009, 
    DELETE_ORDER_SUCCESS_MESAGE: 'Order deleted successfully',
    DELETE_ORDER_SUCCESS_CODE: 1010,
    NO_ORDER_FOUND_MESSAGE: 'No order found',
    NO_ORDER_FOUND_CODE: 1011,
    NO_USER_FOUND_MESSAGE: 'No User found to delete',
    NO_USER_FOUND_CODE: 3003,
    DELETE_USER_SUCCESS_MESAGE: 'User deleted successfully',
    DELETE_USER_SUCCESS_CODE: 3004,
    UPDATE_USER_SUCCESS_MESSAGE: 'User Updated successfully', 
    UPDATE_USER_SUCCESS_CODE: 3008,  
    UPDATE_USER_FAIL_MESSAGE: 'Id not found in users table to update user details', 
    UPDATE_USER_FAIL_CODE: 3009, 

    PRODUCT_ADDED_SUCCESS_MESSAGE: 'Product Added successfully',
    PRODUCT_ADDED_SUCCESS_CODE: 4001,
    PRODUCT_FECTHED_SUCCESS_MESSAGE: 'Product fetched successfully',
    PRODUCT_FECTHED_SUCCESS_CODE: 4002,
    DELETE_PRODUCT_SUCCESS_MESAGE: 'Product deleted successfully',
    DELETE_PRODUCT_SUCCESS_CODE: 4003,
    NO_PRODUCT_FOUND_MESSAGE: 'No Product found to delete',
    NO_PRODUCT_FOUND_CODE: 4004,
    UPDATE_PRODUCT_SUCCESS_MESSAGE: 'Product Updated successfully',
    UPDATE_PRODUCT_SUCCESS_CODE: 4004,
    UPDATE_PRODUCT_FAIL_MESSAGE: 'Id not found in product table to update product details', 
    UPDATE_PRODUCT_FAIL_CODE: 4006,

    CART_ADDED_SUCCESS_MESSAGE: 'Cart Added successfully',
    CART_ADDED_SUCCESS_CODE: 5001,
    CART_FECTHED_SUCCESS_MESSAGE: 'Product fetched successfully',
    CART_FECTHED_SUCCESS_CODE: 5002,
    DELETE_CART_SUCCESS_MESAGE: 'Cart deleted successfully',
    DELETE_CART_SUCCESS_CODE: 5003,
    NO_CART_FOUND_MESSAGE: 'id not found in Cart table to delete',
    NO_CART_FOUND_CODE: 5004,
    UPDATE_CART_SUCCESS_MESSAGE: 'Cart Updated successfully',
    UPDATE_CART_SUCCESS_CODE: 5005, 
    UPDATE_CART_FAIL_MESSAGE: 'Id not found in cart table to update cart details', 
    UPDATE_CART_FAIL_CODE: 5006

}

export default constances;


// order data
// {
//     "id": 4,
//     "category_id": 3,
//     "order_by": "sridar",
//     "order_on": "2024-02-29",
//     "product_id": 2,
//     "status": "Pending",
//     "transaction_id": 234
// }