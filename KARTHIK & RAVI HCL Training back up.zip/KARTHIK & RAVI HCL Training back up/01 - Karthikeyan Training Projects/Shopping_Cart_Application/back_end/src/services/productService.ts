import client from '../config/dbConfig';
import { NoDataFoundError } from "../error/noDataError";
import { IProduct } from '../modal/types';

/**
 * product Service - insertProduct method.
 * this method is used to insert new product information into product table.
 */
const insertProduct = async (Product: IProduct) => {

    const query = `insert into product(id, product_name, product_description, category_id, expiry_date, manufacturing_date, price, quantity) values (${Product.id}, '${Product.product_name}', '${Product.product_description}', ${Product.category_id}, '${Product.expiry_date}', '${Product.manufacturing_date}', ${Product.price}, ${Product.quantity})`;

    await client.execute(query);

}

/**
 * product Service - getAllProducts method.
 * this method is used to get all  product information from product table.
 */
const getAllProducts = async () => {

    const result = await client.execute('select id, product_name, product_description, category_id, expiry_date, manufacturing_date, price, quantity from product')

    if (result.rowLength === 0)
        throw new NoDataFoundError('No Product Details Found', 20000);
    else
        return result.rows;
}

/**
 * product Service - updateProductById method.
 * this method is used to update product information using ID from product table.
 */
const updateProductById = async (Pro: IProduct) => {

    const query = `update product set product_name='${Pro.product_name}', product_description='${Pro.product_description}', category_id=${Pro.category_id}, quantity=${Pro.quantity}, expiry_date='${Pro.expiry_date}', manufacturing_date='${Pro.manufacturing_date}', price=${Pro.price} where id=${Pro.id}`;

    await client.execute(query);
}

/**
 * product Service - getProductById method.
 * this method is used to fetch product information using ID from product table.
 */
const getProductById = async (id: string | number) => {

    const query = `select count(id) as count from product where id=${id}`;
    const result = await client.execute(query);

    return result.first();
}

/**
 * product Service - deleteProductById method.
 * this method is used to delete product information using ID from product table.
 */
const deleteProductById = async (id: string | number) => {

    const query = `delete from product where id=${id}`;

    await client.execute(query);
}

export { 
    insertProduct, 
    getAllProducts,
    getProductById,
    deleteProductById,
    updateProductById
};

// id int primary key, category_id int, product_id int, added_by text, added_on date, quantity int, price int