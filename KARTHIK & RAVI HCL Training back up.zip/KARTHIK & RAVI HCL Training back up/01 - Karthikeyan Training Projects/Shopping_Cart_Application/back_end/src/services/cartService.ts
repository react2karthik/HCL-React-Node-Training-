import client from '../config/dbConfig';
import { NoDataFoundError } from "../error/noDataError";
import { ICart } from '../modal/types';

/**
 * cart Service - insertCart method.
 * this method is used to insert cart into cart table.
 */
const insertCart = async (Cart: ICart) => {

    const query = `insert into cart(id, category_id, product_id, added_by, added_on, quantity, price) values (${Cart.id}, ${Cart.category_id}, ${Cart.product_id}, '${Cart.added_by}', '${Cart.added_on}', ${Cart.quantity}, ${Cart.price})`;
    
    await client.execute(query);

}

/**
 * cart Service - getAllCarts method.
 * this method is used to get all cart from cart table.
 * @returns 
 */
const getAllCarts = async () => {

    const result = await client.execute('select id, category_id, product_id, added_by, added_on, quantity, price from cart')

    if (result.rowLength === 0)
        throw new NoDataFoundError('No Cart Details Found', 20000);
    else
        return result.rows;
}

/**
 * cart Service - updateCartById method.
 * this method is used to update cart into cart table using cardID.
 * @param Crt 
 */
const updateCartById = async (Crt: ICart) => {

    const query = `update cart set product_id=${Crt.product_id}, category_id=${Crt.category_id}, quantity=${Crt.quantity}, added_by='${Crt.added_by}', added_on='${Crt.added_on}', price=${Crt.price} where id=${Crt.id}`;

    await client.execute(query);
}

/**
 * cart Service - getCartById method.
 * this method is used to get cart from cart table using cardID.
 */
const getCartById = async (id: string | number) => {

    const query = `select count(id) as count from cart where id=${id}`;

    const result = await client.execute(query);

    return result.first();
}

/**
 * cart Service - deleteCartById method.
 * this method is used to delete cart into cart table using cardID.
 */
const deleteCartById = async (id: string | number) => {

    const query = `delete from cart where id=${id}`;

    await client.execute(query);
}

export { 
    insertCart, 
    getAllCarts,
    getCartById,
    deleteCartById,
    updateCartById
    // getProductById,
    // deleteProductById,
    // updateProductById
};

// id int primary key, category_id int, product_id int, added_by text, added_on date, quantity int, price int