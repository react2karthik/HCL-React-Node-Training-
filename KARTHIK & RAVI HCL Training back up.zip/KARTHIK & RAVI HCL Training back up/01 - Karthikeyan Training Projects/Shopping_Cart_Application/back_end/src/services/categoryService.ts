import client from '../config/dbConfig';
import { NoDataFoundError } from "../error/noDataError";
import { ICategory } from '../modal/types';

/**
 * category Service - insertCategory method.
 * this method is used to insert category into category table.
 */
const insertCategory = async (category: ICategory) => {

    const query = `insert into category(id, category_name, category_description) values
    (uuid(),'${category.category_name}','${category.category_description}')`;

    await client.execute(query);

}

/**
 * category Service - getCategoryByName method.
 * this method is used to get category from category table using category name.
 */
const getCategoryByName = async (searchTxt: string) => {

    const query = `select * from category where category_name='${searchTxt}' ALLOW FILTERING`;
    const result = await client.execute(query);

    if (result.rowLength === 0) {
        throw new NoDataFoundError('No Category found for given category name', 1000);
    } else {
        return result.rows;
    }

}

/**
 * category Service -  getAllCategory method.
 * this method is used to get all category from category table.
 */
const getAllCategory = async () => {

    const result = await client.execute('select id, category_name, category_description from category')

    if (result.rowLength === 0)
        throw new NoDataFoundError('No category found', 1000);
    else
        return result.rows;
}

/**
 * category Service -  updateCategoryById method.
 * this method is used to update category from category table using categoryID.
 */
const updateCategoryById = async (category: ICategory) => {

    const query = `update category set category_name='${category.category_name}', 
    category_description='${category.category_description}' where id=${category.id}`;

    await client.execute(query);
}

/**
 * category Service - getCategoryById method.
 * this method is used to get category from category table using categoryID.
 */
const getCategoryById = async (id: string | number) => {
    const query = `select count(id) as count from category where id=${id}`;

    const result = await client.execute(query);

    return result.first();
}


/**
 * category Service - deleteCategoryById method.
 * this method is used to delete category from category table using categoryID.
 */
const deleteCategoryById = async (id: string | number) => {

    const query = `delete from category where id=${id}`;

    await client.execute(query);
}

export { insertCategory, getAllCategory, updateCategoryById, getCategoryByName, getCategoryById, deleteCategoryById };