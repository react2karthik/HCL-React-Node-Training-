import client from '../config/dbConfig';
import { NoDataFoundError } from "../error/noDataError";
import { IOrder } from '../modal/types';

/**
 * order Service - insertOrder method.
 * this method is used to insert order into order table.
 */
const insertOrder = async (order: IOrder) => {

    const query = `insert into order_details(id, category_id, order_by, order_on, product_id, status, transaction_id) values(${order.id}, ${order.category_id}, '${order.order_by}', '${order.order_on}', ${order.product_id}, '${order.status}', ${order.transaction_id} )`;

    await client.execute(query);

}

/**
 * order Service - getAllOrder method.
 * this method is used to get all order from order table.
 */
const getAllOrder = async () => {

    const result = await client.execute('select id, category_id, order_by, order_on, product_id, status, transaction_id from order_details')

    if (result.rowLength === 0)
        throw new NoDataFoundError('No Order Details Found', 10000);
    else
        return result.rows;
}

/**
 * order Service - updateOrderById method.
 * this method is used to update order into order table using orderID.
 */
const updateOrderById = async (Order: IOrder) => {

    const query = `update order_details set category_id=${Order.category_id}, 
    order_by='${Order.order_by}', order_on='${Order.order_on}', product_id=${Order.product_id}, 
    status='${Order.status}', transaction_id=${Order.transaction_id} where id=${Order.id}`;

    await client.execute(query);
}

/**
 * order Service - getOrderById method.
 * this method is used to get order from order table using orderID.
 */
const getOrderById = async (id: string | number) => {
    const query = `select count(id) as count from order_details where id=${id}`;

    const result = await client.execute(query);

    return result.first();
}

/**
 * order Service - deleteOrderById method.
 * this method is used to delete order from order table using orderID.
 */
const deleteOrderById = async (id: string | number) => {

    const query = `delete from order_details where id=${id}`;

    await client.execute(query);
}

export { 
    insertOrder, 
    getAllOrder,
    getOrderById,
    updateOrderById,
    deleteOrderById
};