import client from '../config/dbConfig';
import { NoDataFoundError } from "../error/noDataError";
import { IUser } from '../modal/types';

// const insertUser = async (user: IUser) => {

//     const query = `insert into users(id, name, email, password, phone) values(${user.id}, '${user.name}', '${user.email}', '${user.password}', ${user.phone} )`;

//     await client.execute(query);

// }

/**
 * user Service - getAllUsers method.
 * this method is used to fetch all user information from user table.
 */
const getAllUsers = async () => {

    const result = await client.execute('select id, name, email, password, phone from users')

    if (result.rowLength === 0)
        throw new NoDataFoundError('No User Details Found', 20000);
    else
        return result.rows;
}

/**
 * user Service - updateUserById method.
 * this method is used to update user information into user table using userID.
 */
const updateUserById = async (User: IUser) => {

    const query = `update users set name='${User.name}', email='${User.email}',
    password='${User.password}', phone=${User.phone} where id=${User.id}`;

    await client.execute(query);
}

/**
 * user Service - getUserById method.
 * this method is used to fetch user information from user table using userID.
 */
const getUserById = async (id: string | number) => {

    const query = `select count(id) as count from users where id=${id}`;

    const result = await client.execute(query);

    return result.first();
}

/**
 * user Service - deleteUserById method.
 * this method is used to delete user information from user table using userID.
 */
const deleteUserById = async (id: string | number) => {

    const query = `delete from users where id=${id}`;

    await client.execute(query);
}

/**
 * user Service - registerUser method.
 * this method is used to insert new user information into user table.
 */
const registerUser = async (id: string, name: string, email: string, hassedPassword: string, phone: number) => {

    const query = `insert into users(id, name, email, password, phone) values(${id}, '${name}', '${email}', '${hassedPassword}', ${phone})`;
    const result = await client.execute(query);

    return result;
}

/**
 * user Service - loginUser method.
 * this method is used to get email, password from user table using emailID.
 */
const loginUser = async (email: string) => {

    const query = `select email, password from users where email='${email}' ALLOW FILTERING`;

    const result = await client.execute(query);

    return result;
}

export { 
    //insertUser, 
    getAllUsers,
    getUserById, 
    deleteUserById,
    updateUserById,
    loginUser,
    registerUser
};