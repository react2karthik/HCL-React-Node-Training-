import { body } from "express-validator";

const productValidator = () => {
    return [
        body('id').exists().withMessage('Products id need'),
        body('name').exists().withMessage('Products Name need'),
        body('price').exists().withMessage('Product Price need'),
        body('description').exists().withMessage("Description need").bail().isLength({min:2,max:255}).withMessage("PSW should be min 2 and max 255 char"),
        body('image').exists().withMessage('Please provide image url')
    ]
}

export default productValidator;
