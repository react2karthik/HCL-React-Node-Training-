import { body } from "express-validator";

const categoryValidator = () => {
    return [
        //body("id").exists().withMessage("category id is required"),
        body("category_name").exists().withMessage("category Name is required"),
        body("category_description").exists().withMessage("category Description is required")
    ]
}

export default categoryValidator;