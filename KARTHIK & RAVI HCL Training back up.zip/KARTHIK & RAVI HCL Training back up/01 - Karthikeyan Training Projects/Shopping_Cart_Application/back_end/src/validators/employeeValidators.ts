import { body } from "express-validator";

const employeeValidator = () => {
    return [
        body("name").exists().withMessage("Name is required"),
        body("age").exists().withMessage("age is required").bail().isNumeric().withMessage("age is number"),
        body("salary").exists().withMessage("Salary is required").bail().isNumeric().withMessage("salary is number"),
        body("empCode").exists().withMessage("Employee code is required"),
        body("reportsTo").exists().withMessage("Reports to is required")
    ]
}

export default employeeValidator;