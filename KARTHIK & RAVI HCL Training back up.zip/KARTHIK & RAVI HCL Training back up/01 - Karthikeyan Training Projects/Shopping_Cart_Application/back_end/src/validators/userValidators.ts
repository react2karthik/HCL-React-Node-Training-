import { body } from "express-validator";

const userValidator = () => {
    return [
        body("name").exists().withMessage("Name is required"),
        body("age").exists().withMessage("age is required")
    ]
}

export default userValidator;