import express, { Request, Response, NextFunction } from 'express';
import { insertOrder, getAllOrder, getOrderById, updateOrderById , deleteOrderById} from '../services/orderService';
import authMiddleware from '../middleware/authMiddleware';
import categoryValidator from '../validators/categoryValidators';
// import validateMiddleware from '../middleware/validateMiddleware';
// import { NoDataFoundError } from '../error/noDataError';
import constances from '../constants/constant';
import { IOrder } from '../modal/types';
// import { NextFunction } from 'express-serve-static-core';

const orderRouter: express.Router = express.Router();

/**
 * order Router - post method.
 * this method is used to insert new order data into order_details table.
 */
orderRouter.post('/', categoryValidator(), authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id, category_id, order_by, order_on, product_id, status, transaction_id  }: IOrder = req.body;
    const orderData: IOrder = { id, category_id, order_by, order_on, product_id, status, transaction_id };

    try {
        await insertOrder(orderData);
        res.json({
            message: constances.ORDER_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.ORDER_ADDED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        next(error)
    }

});

/**
 * order Router - get method.
 * this method is used to get all order data from order_details table.
 */
orderRouter.get('/', async (req: Request, res: Response, next: NextFunction) => {

    try {
        const data = await getAllOrder();
        res.json({
            data,
            message: constances.ORDER_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.ORDER_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        next(error);
    }
});

/**
 * order Router - put method.
 * this method is used to update order data based on ID in order_details table.
 */
orderRouter.put('/update/:id', categoryValidator(), async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const { category_id, order_by, order_on, product_id, status, transaction_id  }: IOrder = req.body;
    const orderData: IOrder = { id, category_id, order_by, order_on, product_id, status, transaction_id };
    const data = await getOrderById(id);

    try {
        if (data.count != 0) {
            await updateOrderById(orderData);
            res.json({
                message: constances.UPDATE_ORDER_SUCCESS_MESSAGE,
                statusCode: constances.UPDATE_ORDER_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.UPDATE_ORDER_FAIL_MESSAGE,
                statusCode: constances.UPDATE_ORDER_FAIL_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }

});


/**
 * order Router - delete method.
 * this method is used to delete order data using ID in order_details table.
 */
orderRouter.delete('/:id', async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const data = await getOrderById(id);

    try {
        if (data.count != 0) {
            await deleteOrderById(id);
            res.json({
                message: constances.DELETE_ORDER_SUCCESS_MESAGE,
                statusCode: constances.DELETE_ORDER_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.NO_ORDER_FOUND_MESSAGE,
                statusCode: constances.NO_ORDER_FOUND_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }
});

export default orderRouter;