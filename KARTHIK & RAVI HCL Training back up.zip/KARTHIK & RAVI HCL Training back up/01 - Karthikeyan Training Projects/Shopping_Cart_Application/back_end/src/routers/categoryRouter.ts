import express, { Request, Response, NextFunction } from 'express';
import { insertCategory, getAllCategory, updateCategoryById, deleteCategoryById, getCategoryById, getCategoryByName } from '../services/categoryService';
import categoryValidator from '../validators/categoryValidators';
//import validateMiddleware from '../middleware/validateMiddleware';
import authMiddleware from '../middleware/authMiddleware';
//import { NoDataFoundError } from '../error/noDataError';
import constances from '../constants/constant';
import { ICategory } from '../modal/types';
// import { NextFunction } from 'express-serve-static-core';

const categoryRouter: express.Router = express.Router();

/**
 * Category Router - post method.
 * This method is used to insert new Category data into category table.
 */
categoryRouter.post('/', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id, category_name, category_description } = req.body;
    const category: ICategory = { id, category_name, category_description };

    try {

        await insertCategory(category);
        res.json({
            message: constances.CATEGORY_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.CATEGORY_ADDED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        next(error)
    }

});

/**
 * Category Router - get method.
 * This method is used to get all Category data from category table.
 */
categoryRouter.get('/', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    try {
        const data = await getAllCategory();
        res.json({
            data,
            message: constances.CATEGORY_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.CATEGORY_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        next(error);
    }
});

/**
 * Category Router - get method.
 * This method is used to get Category data based on Category Name in to category table.
 */
categoryRouter.get('/search', async (req: Request, res: Response, next: NextFunction) => {
    
    const searchTxt: any = req.query.name;

    try {
        const data = await getCategoryByName(searchTxt);
        if (data.length === 0) {
            res.json({
                data,
                message: constances.NO_CATEGORY_FOUND_SEARCH_MESSAGE,
                statusCode: constances.NO_CATEGORY_FOUND_SEARCH_CODE,
                status: constances.FAILED_MESAGE
            })
        } else {
            res.json({
                data,
                message: constances.CATEGORY_FOUND_SEARCH_MESSAGE,
                statusCode: constances.CATEGORY_FOUND_SEARCH_CODE,
                status: constances.SUCCESS_MESAGE
            })
        }

    } catch (error) {
        next(error);
    }
});

/**
 * Category Router - put method.
 * This method is used to update Category data based on Category ID in to category table.
 */
categoryRouter.put('/update/:id', categoryValidator(), async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const { category_name, category_description }: ICategory = req.body;
    const category: ICategory = { id, category_name, category_description };
    const data = await getCategoryById(id);

    try {
        if (data.count != 0) {
            await updateCategoryById(category);
            res.json({
                message: constances.UPDATE_CATEGORY_SUCCESS_MESSAGE,
                statusCode: constances.UPDATE_CATEGORY_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.UPDATE_CATEGORY_FAIL_MESSAGE,
                statusCode: constances.UPDATE_CATEGORY_FAIL_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }

});

/**
 * Category Router - delete method.
 * This method is used to delete Category data based on Category ID in to category table.
 */
categoryRouter.delete('/:id', async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const data = await getCategoryById(id);

    try {
        if (data.count != 0) {
            await deleteCategoryById(id);
            res.json({
                message: constances.DELETE_CATEGORY_SUCCESS_MESAGE,
                statusCode: constances.DELETE_CATEGORY_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.NO_CATEGORY_FOUND_MESSAGE,
                statusCode: constances.NO_CATEGORY_FOUND_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }
});

export default categoryRouter;