import express, { Request, Response, NextFunction } from 'express';
import { insertProduct, getAllProducts, getProductById, deleteProductById, updateProductById } from '../services/productService';
import categoryValidator from '../validators/categoryValidators';
import authMiddleware from '../middleware/authMiddleware';
// import validateMiddleware from '../middleware/validateMiddleware';
// import { NoDataFoundError } from '../error/noDataError';
import constances from '../constants/constant';
import { IProduct } from '../modal/types';
// import { NextFunction } from 'express-serve-static-core';

const productRouter: express.Router = express.Router();

/**
 * product Router - post method.
 * this method is used to insert new product into product table.
 */
productRouter.post('/', categoryValidator(), authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id, product_name, product_description, category_id, expiry_date, manufacturing_date, price, quantity }: IProduct = req.body;
    const productData: IProduct = { id, product_name, product_description, category_id, expiry_date, manufacturing_date, price, quantity };

    try {
        await insertProduct(productData);
        res.json({
            message: constances.PRODUCT_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.PRODUCT_ADDED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        next(error)
    }

});

/**
 * product Router - get method.
 * this method is used to fetch all product information from product table.
 */
productRouter.get('/', async (req: Request, res: Response, next: NextFunction) => {

    try {
        const data = await getAllProducts();
        res.json({
            data,
            message: constances.PRODUCT_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.PRODUCT_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        next(error);
    }
});

/**
 * product Router - put method.
 * this method is used to update product information using ID into product table.
 */
productRouter.put('/update/:id', categoryValidator(), async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const { product_name, product_description, category_id, expiry_date, manufacturing_date, price, quantity }: IProduct = req.body;
    const productData: IProduct = { id, product_name, product_description, category_id, expiry_date, manufacturing_date, price, quantity };
    const data = await getProductById(id);

    try {
        if (data.count != 0) {
            await updateProductById(productData);
            res.json({
                message: constances.UPDATE_PRODUCT_SUCCESS_MESSAGE,
                statusCode: constances.UPDATE_PRODUCT_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.UPDATE_PRODUCT_FAIL_MESSAGE,
                statusCode: constances.UPDATE_PRODUCT_FAIL_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }

});

/**
 * product Router - delete method.
 * this method is used to delete product information using ID from product table.
 */
productRouter.delete('/:id', async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const data = await getProductById(id);

    try {
        if (data.count != 0) {
            await deleteProductById(id);
            res.json({
                message: constances.DELETE_PRODUCT_SUCCESS_MESAGE,
                statusCode: constances.DELETE_PRODUCT_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.NO_PRODUCT_FOUND_MESSAGE,
                statusCode: constances.NO_PRODUCT_FOUND_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }
});

export default productRouter;