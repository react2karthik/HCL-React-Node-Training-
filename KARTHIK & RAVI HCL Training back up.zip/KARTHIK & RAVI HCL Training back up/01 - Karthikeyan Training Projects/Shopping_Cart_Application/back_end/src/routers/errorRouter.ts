import express, { Request, Response, NextFunction } from 'express';
import request from 'request';
// import { NoDataFoundError } from '../error/noDataError';
// import { error } from 'console';

const errorRouter: express.Router = express.Router();

/**
 * error Router - get method.
 * This method is used to insert new Category data into category table.
 */
errorRouter.get('/async/:id', (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    request(`https://reqres.in/api/users/${id}`, (_error: any, response: any) => {
            const data = JSON.parse(response.body);

            try {
                if (Object.keys(data).length === 0) {
                    //throw new NoDataFoundError('No data found custom error handelar', 404);
                    //throw new Error('No data found');
                    res.json({
                        message: 'No data found',
                        status: 'failure',
                        statusCode: 2001,
                        data: null
                    });
                } else {
                    res.json({
                        message: 'data fetched succesfully',
                        status: 'success',
                        statusCode: 2002,
                        data
                    });
                }
            } catch (error) {
                next(error);
            }

        })
});

export default errorRouter;
