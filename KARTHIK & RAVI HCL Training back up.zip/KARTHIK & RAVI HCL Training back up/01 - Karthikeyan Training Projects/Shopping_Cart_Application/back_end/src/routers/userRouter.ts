import express, { Request, Response, NextFunction } from 'express';
import { getAllUsers, getUserById, deleteUserById, updateUserById, loginUser, registerUser } from '../services/userService';
import authMiddleware from '../middleware/authMiddleware';
import dotenv from 'dotenv';


// getAllOrder, getOrderById, updateOrderById , deleteOrderById
import categoryValidator from '../validators/categoryValidators';
// import validateMiddleware from '../middleware/validateMiddleware';
// import { NoDataFoundError } from '../error/noDataError';
import constances from '../constants/constant';
import { IUser } from '../modal/types';
// import { NextFunction } from 'express-serve-static-core';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { UnAuthorizedAccess } from '../error/unAuthorizedError';
dotenv.config();
const userRouter: express.Router = express.Router();

/**
 * user Router - post method.
 * this method is used to insert product information into user table.
 */
userRouter.post('/register', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id, name, email, password, phone } = req.body;
    try {
        const hassedPassword = await bcrypt.hash(password, 10);
        // const userData: IUser = { id, name, email, password, phone };
        const result = await registerUser(id, name, email, hassedPassword, phone);
        res.json({
            message: constances.USER_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.USER_ADDED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE,
            data: result
        });

    } catch (error) {
        next(error);
    }

});

/**
 * user Router - post method.
 * this method is used to insert product information into user table.
 */
userRouter.post('/login', async (req: Request, res: Response, next: NextFunction) => {

    const { email, password } = req.body;
    const result = await loginUser(email);
    
    if (result.first() != null) {

        const isMatching = await bcrypt.compare(password, result.first().get('password'));

        if (isMatching) {
            const token = jwt.sign({ email }, process.env.SECRET_KEY || '', { expiresIn: '1h' });
            res.json({
                status: 'success',
                data: token
            })
        } else {
            try {
                throw new UnAuthorizedAccess(constances.ACCESS_DENIED_MESSAGE, constances.ACCESS_DENIED_CODE);
            } catch (error) {
                next(error);
            }
        }
    } else {
        res.json({
            message: constances.USER_NOT_EXIST_MESSAGE,
            statusCode: constances.USER_NOT_EXIST_CODE,
            statue: constances.FAILED_MESAGE,
            data: email
        })
    }

    // try {
    //     await insertUser(userData);
    //     res.json({
    //         message: constances.USER_ADDED_SUCCESS_MESSAGE,
    //         statusCode: constances.USER_ADDED_SUCCESS_CODE,
    //         statue: constances.SUCCESS_MESAGE
    //     });

    // } catch (error) {
    //     next(error)
    // }

});

/**
 * user Router - get method.
 * this method is used to user information from user table.
 */
userRouter.get('/', async (req: Request, res: Response, next: NextFunction) => {

    try {
        const data = await getAllUsers();
        res.json({
            data,
            message: constances.USER_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.USER_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        next(error);
    }
});

/**
 * user Router - put method.
 * this method is used to update user information into user table.
 */
userRouter.put('/update/:id', categoryValidator(), async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const { name, email, password, phone }: IUser = req.body;
    const userData: IUser = { id, name, email, password, phone };
    const data = await getUserById(id);

    try {
        if (data.count != 0) {
            await updateUserById(userData);
            res.json({
                message: constances.UPDATE_USER_SUCCESS_MESSAGE,
                statusCode: constances.UPDATE_USER_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.UPDATE_USER_FAIL_MESSAGE,
                statusCode: constances.UPDATE_USER_FAIL_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }

});

/**
 * user Router - delete method.
 * this method is used to delet user information from user table using userID.
 */
userRouter.delete('/:id', async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const data = await getUserById(id);

    try {
        if (data.count != 0) {
            await deleteUserById(id);
            res.json({
                message: constances.DELETE_USER_SUCCESS_MESAGE,
                statusCode: constances.DELETE_USER_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.NO_USER_FOUND_MESSAGE,
                statusCode: constances.NO_USER_FOUND_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }
});

export default userRouter;