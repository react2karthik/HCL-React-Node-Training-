import express, { Request, Response, NextFunction } from 'express';
import { insertCart, getAllCarts, getCartById, deleteCartById, updateCartById } from '../services/cartService';

// getAllOrder, getOrderById, updateOrderById , deleteOrderById
import categoryValidator from '../validators/categoryValidators';
import authMiddleware from '../middleware/authMiddleware';
// import validateMiddleware from '../middleware/validateMiddleware';
// import { NoDataFoundError } from '../error/noDataError';
import constances from '../constants/constant';
import { ICart } from '../modal/types';
// import { NextFunction } from 'express-serve-static-core';

const cartRouter: express.Router = express.Router();

/**
 * Cart Router - post method.
 * This method is used to insert card data in to cart table.
 */
cartRouter.post('/', categoryValidator(), authMiddleware, async (req: Request, res: Response, next: NextFunction) => {

    const { id, product_id, category_id, added_by, added_on, price, quantity }: ICart = req.body;

    const cartData: ICart = { id, product_id, category_id, added_by, added_on, price, quantity };

    try {
        await insertCart(cartData);
        res.json({
            message: constances.CART_ADDED_SUCCESS_MESSAGE,
            statusCode: constances.CART_ADDED_SUCCESS_CODE,
            statue: constances.SUCCESS_MESAGE
        });

    } catch (error) {
        next(error)
    }

});

/**
 * Cart Router - get method.
 * This method is used to get all card data in to cart table.
 */
cartRouter.get('/', async (req: Request, res: Response, next: NextFunction) => {
    try {
        const data = await getAllCarts();
        res.json({
            data,
            message: constances.CART_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.CART_FECTHED_SUCCESS_CODE,
            status: constances.SUCCESS_MESAGE
        })
    } catch (error) {
        next(error);
    }
});

/**
 * Cart Router - put method.
 * This method is used to update card data based on cart ID in to cart table.
 */
cartRouter.put('/update/:id', categoryValidator(), async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const { product_id, category_id, added_by, added_on, price, quantity }: ICart = req.body;
    const cartData: ICart = { id, product_id, category_id, added_by, added_on, price, quantity };
    const data = await getCartById(id);

    try {
        if (data.count != 0) {
            await updateCartById(cartData);
            res.json({
                message: constances.UPDATE_CART_SUCCESS_MESSAGE,
                statusCode: constances.UPDATE_CART_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.UPDATE_CART_FAIL_MESSAGE,
                statusCode: constances.UPDATE_CART_FAIL_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }

});

/**
 * Cart Router - delete method.
 * This method is used to delete card data based on cart ID in to cart table.
 */
cartRouter.delete('/:id', async (req: Request, res: Response, next: NextFunction) => {

    const { id } = req.params;
    const data = await getCartById(id);

    try {
        if (data.count != 0) {
            await deleteCartById(id);
            res.json({
                message: constances.DELETE_CART_SUCCESS_MESAGE,
                statusCode: constances.DELETE_CART_SUCCESS_CODE,
                status: constances.SUCCESS_MESAGE
            })
        } else {
            res.json({
                message: constances.NO_CART_FOUND_MESSAGE,
                statusCode: constances.NO_CART_FOUND_CODE,
                status: constances.FAILED_MESAGE
            })
        }
    } catch (error) {
        next(error)
    }
});

export default cartRouter;