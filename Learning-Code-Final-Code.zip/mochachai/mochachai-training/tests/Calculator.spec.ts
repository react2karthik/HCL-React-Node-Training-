import { assert } from "chai";
import Caluclator from "../src/Calculatore";
//const calc =new Caluclator();
describe('addition of two number',()=>{
    //before ,beforeEach,afterEach,after;
    before('before',()=>{
        console.log('before');
    })
    beforeEach('beforeEach',()=>{
        //console.log('beforeEach');
        const calc =new Caluclator();
    })
    afterEach('afterEach',()=>{
        console.log('afterEach');
    })
    after('before',()=>{
        console.log('after');
    })
    it('sum of 2 no',()=>{   
        //arrange
        const calc =new Caluclator();
        //act
        const result =  calc.add(2,3);
        //assert        
        assert.equal(result,5);
    })
    it('subtract of 2 no',()=>{   
        //arrange
        const calc =new Caluclator();
        //act
        const result =  calc.subtract(6,2);
        //assert        
        assert.equal(result,4);
    })
    it('multiply of 2 no',()=>{   
        //arrange
        const calc =new Caluclator();
        //act
        const result =  calc.multiply(2,3);
        //assert        
        assert.equal(result,6);
    })
})