import { expect,should,assert } from "chai";

describe("chai testing",()=>{
    //expect ,assert , should
    it("expect testing",()=>{
        //arrange

        const name:string = "sridhar";
        const age:number = 31;
        const objectData:Object={name:"sridhar",age:31};
        const arrayData:Array<number> = [1,2,3];
        const booleanData :Boolean =  true;
        //act
        //assert
        expect(name).to.be.ok;//undefined or null
        expect(name).to.be.equal("sridhar");
        expect(name).to.be.a("string");
        expect(objectData).to.have.property("name").equal("sridhar");
        expect(arrayData).to.have.length(3).that.include(2);
        expect(booleanData).to.be.true;

    })
    //should
    it("should testing",()=>{
        //arrange

        const name:string = "sridhar";
        const age:number = 31;
        const objectData:Object={name:"sridhar",age:31};
        const arrayData:Array<number> = [1,2,3,4];
        const booleanData :Boolean =  true;
        //act
        should();
        //assert
        name.should.be.ok;//undefined or null
        name.should.be.equal("sridhar");
        name.should.be.a("string");
        objectData.should.have.property("name").equal("sridhar");
        arrayData.should.have.length(4).that.include(2);
        booleanData.should.be.true;

    })
    
    //assert
    it("assert testing",()=>{
        //arrange

        const name:string = "sridhar";
        const age:number = 31;
        const objectData:Object={name:"sridhar",age:31};
        const arrayData:Array<number> = [1,2,3,4];
        const booleanData :Boolean =  true;
        //act
        //assert
        assert.isOk(name);
        assert.equal(name,"sridhar");
        assert.deepEqual(objectData,{name:"sridhar",age:31});
        assert.include(arrayData,2);
        assert.equal(booleanData,true);
    })
})