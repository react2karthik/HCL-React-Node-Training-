import { assert,expect } from "chai";
import Caluclator from "../src/Calculatore";
import sinon,{SinonSpy,SinonStub} from 'sinon';
import { describe } from "mocha";
import axios from "axios";
describe('adding of two number',()=>{
    let spy:SinonSpy;
    let stub : SinonStub;
    it('spies mock and stub',()=>{
        const calc = new  Caluclator();
        //spy = sinon.spy(calc,'add');
        stub= sinon.stub(calc,'add').returns(5)
        const result = calc.add(2,3);
        //expect(spy).to.be.true;
        //expect(stub).to.be.true;
        stub.restore();
        assert.strictEqual(result,5);
    });
})
describe('fetch  api data',()=>{
    it('spies mock and stub',async()=>{
        const calc =  new Caluclator();
        const result = await calc.getUserPosts();
        let mockData= {
            "userId":1,
            "id":1,
            "title":'delectus aut autem',
            "completed":false,
        }
        console.log("resultresult",result.status)
        assert.deepEqual(result,mockData);
        console.log("mockData",mockData);
        //assert.equal(result.status,200)
    })
    it('poste call api',async()=>{
        let mockPostData = {
            title:"temporibus sit alias delectus eligendi possimus magni",
            body:"doloremque ex facilis sit sint culpa\nsoluta assumenda eligendi non ut eius\nsequi ducimus vel quasi\nveritatis est dolores",
            userId:10,
            id:1
        }
        let postResult = await axios.post('https://jsonplaceholder.typicode.com/posts',mockPostData);
        console.log("post",postResult);
        assert.equal(postResult.status,201)
    })
})