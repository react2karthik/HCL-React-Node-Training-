import axios from 'axios';
class Caluclator {
    add(a:number,b:number){
        return a+b;
    }
    subtract(a:number,b:number){
        return a-b;
    }
    multiply(a:number,b:number){
        return a*b;
    }
    async getUserPosts(){
        return await fetch('https://jsonplaceholder.typicode.com/todos/1')
        .then(response=>response.json());
    }
    async postUser(postUser:any){
        const returna = await axios.post('https://jsonplaceholder.typicode.com/post',postUser);
        console.log("returnareturna",returna)
    }
}

export default Caluclator