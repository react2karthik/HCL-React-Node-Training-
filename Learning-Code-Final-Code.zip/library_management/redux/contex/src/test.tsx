import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addValue, subValue } from './actions';
import LoginTest from './loginTest';

const Test: React.FC = () => {
    // const dispatch = useDispatch();
    // const value = useSelector((state: any) => state.value);

    return (
        <>
        <p>Hi sridhar</p>
            {/* <div>
                {`Test is ${value}`}
            </div>
            <button onClick={() => dispatch(addValue(500))}>
                Add
            </button>
            <button onClick={() => dispatch(subValue(200))}>
                Sub
            </button> */}
            {/* <LoginTest /> */}
        </>
    );
};

export default Test;


// import React, { useReducer } from 'react';
// const Test: React.FC = () => {
//     const saveReducer = (state:any, action:any) => {//action
//         switch (action.type) {
//             case 'ADD':
//                  return state + action.payload
//            case 'SUB' :
//               return state - action.payload
//             default:
//                 return state
//         }
//     }
//     const [state, dispatch] = useReducer(saveReducer,1000)
//     return (
//         <>
//             <div>
//                 {`Test is ${state}`}
//             </div>
//             <button onClick={()=>dispatch({type:'ADD',payload:500})}>
//                 Add
//             </button>
//             <button onClick={()=>dispatch({type:'SUB',payload:200})}>
//                 Sub
//             </button>
//         </>
//     );
// }

// export default Test;