import { createStore } from 'redux';
const initialState = {
    value: 1000,
};
const logInForm = {
    email:'sridhar@gmail.com',
    password:'sridhar'
}
const saveReducer = (state = initialState, action: any) => {
    switch (action.type) {
        case 'ADD':
            return { ...state, value: state.value + action.payload };
        case 'SUB':
            return { ...state, value: state.value - action.payload };
        default:
            return state;
    }
};
// const loginReducer = (state = logInForm,action:any) =>{
//     switch (action.type){
//         case 'logIn':
//             return {...state,value:state.email + action.payload}
//     }
// }
const store = createStore(saveReducer);

export default store;
