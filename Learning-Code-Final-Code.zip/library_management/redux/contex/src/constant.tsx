export const LOGINAPI = 'http://localhost:5000/users/login'
export const REGISTERAPI = 'http://localhost:5000/users/register'
export const FETCHADDBOOKDETAILSAPI = 'http://localhost:5000/users/3a54de46-c950-4351-a070-a2604865aae1/inventory/book'
export const FETCHBOOKDETAILSAPI = 'http://localhost:5000/users/getAllbook'
