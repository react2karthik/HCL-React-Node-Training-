import React from "react";
import { MDBFooter } from 'mdb-react-ui-kit';

const Footer: React.FC = () => {
    return (
        <>
            <MDBFooter className='text-center fixed-bottom' color='white' bgColor='dark'>
                <div className='text-center p-3' style={{ backgroundColor: 'rgba(0, 0, 0, 0.2)' }}>
                    © {new Date().getFullYear()} Copyright:
                    <a className='text-white' href='#'>
                        Library Management
                    </a>
                </div>
            </MDBFooter>
        </>
    )
}
export default Footer;