import React from "react";
import { useDispatch, useSelector, Provider } from 'react-redux';
import { shallow, mount, render,ReactWrapper } from 'enzyme';
import apiService from '../../service/index';
import LoginFormik from "../login/loginFormik";
import store from "../../store";
import RegisterFormik from "./registerFormik";
import configureStore from 'redux-mock-store';
const mockStore = configureStore([]);
jest.mock('../../service/index',()=>{
  return{
    ...jest.requireActual('../../service/index'),
    RegisterFormik:jest.fn(),
  }
})
describe('Register Form component', () => {
  let store: ReturnType<typeof mockStore>;
  let wrapper: ReactWrapper;
  beforeEach(() => {
    store = mockStore({
      auth: {
        userData: null,
      },
    });
    wrapper = mount(
      <Provider store={store}>
      <RegisterFormik />
    </Provider>
    )
    console.log(wrapper);
    //console.log(wrapper.html());
  })
  it('test register from ', () => {
    expect(wrapper.find('Field')).toHaveLength(5);
  })
  it('has bootstrap form controls', () => {  
    expect(wrapper.find('.text-danger')).toHaveLength(8);  
  });
  it("Test click event", () => {  
    const mockCallBack = jest.fn();  
    console.log('------------------------------',mockCallBack);
    const button1 = shallow((<button onClick={mockCallBack}>Submit</button>));  
    button1.find('button').simulate('click');  
    expect(mockCallBack.mock.calls.length).toEqual(1);  
  });
});

