import React, { useState, useEffect } from "react";
import { IRegisterModuls } from '../../models/registerModuls';
import { useDispatch, useSelector } from 'react-redux';
import { registerRequest } from '../../redux/action/registerAction';
import { MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCardImage, MDBRow, MDBCol, MDBInput, MDBRadio, MDBCheckbox, MDBIcon, MDBTabs, MDBTabsItem, MDBTabsLink, MDBTabsContent, MDBTabsPane } from 'mdb-react-ui-kit';
import AlertComponent from '../form/alertFiled';
import { useHistory } from 'react-router-dom';
import { Formik, Field, Form, ErrorMessage, useFormik } from 'Formik';
import * as Yup from 'yup';
const RegisterFormik: React.FC = () => {
    const registerFormik = useFormik({
        initialValues: {
            name: '',
            email: '',
            password: '',
            phone: ''
        },
        onSubmit: values => {
            alert(JSON.stringify(values, null, 2));
        },
    });
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [stateType, setStateType] = useState('danger');
    const history = useHistory();
    const dispatch = useDispatch();
    const validationRegister = Yup.object({
        name: Yup.string().required('Name is required'),
        email: Yup.string().required('Eamil is required').email(),
        password: Yup.string().required('Password is required').min(6).max(40),
        phone: Yup.string().required('Phone number is required').max(10)
    })
    const registerRespons = useSelector((state: any) => {
        return state?.registerReducer?.data;
    })
    useEffect(() => {
        servicePostLogin(registerRespons)
    }, [registerRespons?.statue])
    const servicePostLogin = (response: any) => {
        try {
            if (response && response.statue === "Success") {
                setStateType('success');
                setAlertMessage("Register successful. Redirecting to login page...");
                setShowAlert(true);
                setTimeout(() => {
                    history.push('/');
                }, 3000);
            }

        } catch (error: any) {
            setAlertMessage("Register failed.Please try again later.");
            setShowAlert(true);
        }
    };
    const handleRegister = async (value: any) => {
        dispatch(registerRequest(value));
    }

    return (
        <>
            <Formik initialValues={registerFormik.initialValues} validationSchema={validationRegister} onSubmit={handleRegister}>
                {({ values, handleChange }) => (
                    <Form>
                        <MDBContainer fluid className='h-100'>
                            <MDBRow className='g-0'>
                                <MDBCol md='8' className='mx-auto'>
                                    <MDBCard className='my-4'>

                                        <MDBRow className='g-0'>

                                            <MDBCol md='8' className='mx-auto'>
                                                <h4 className='text-success'>Library Management Register Form</h4>
                                                {showAlert && (
                                                    <AlertComponent type={stateType} message={alertMessage} />

                                                )}

                                                <MDBCardBody className='text-black d-flex flex-column justify-content-center'>

                                                    <label htmlFor="name">Name *</label>
                                                    <Field type="text" id="name" name="name" className='mb-4' />
                                                    <ErrorMessage name="name" component="div" className="text-danger" />
                                                    <label htmlFor="email">Email *</label>
                                                    {/* <Field name="email" type='text'  id='email'>
                                                        {(field: any) => (
                                                            <>
                                                                <MDBInput
                                                                    className='mb-4'
                                                                    label='Email address *'
                                                                    {...field}
                                                                />
                                                                <ErrorMessage name="email" component="div" className="text-danger" />
                                                            </>
                                                        )}
                                                    </Field> */}
                                                    <Field type="text" id="email" name="email" className='mb-4' />
                                                    <ErrorMessage name="email" component="div" className="text-danger" />
                                                    <label htmlFor="password">Password *</label>
                                                    <Field type="text" id="password" name="password" className='mb-4' />
                                                    <ErrorMessage name="password" component="div" className="text-danger" />
                                                    <label htmlFor="phone">Phone *</label>
                                                    <Field type="text" id="phone" name="phone" className='mb-4' />
                                                    <ErrorMessage name="phone" component="div" className="text-danger" />
                                                    <label htmlFor="phone">Drop *</label>
                                                    <Field
                                                        className="form-control"
                                                        as="select"
                                                        //onChange={onItemTypeDropdownSelected}
                                                        name="itemType"
                                                    >
                                                        {/* {options} */}
                                                        <option>Hi</option>
                                                        <option>1</option>
                                                        <option>2</option>
                                                    </Field>
                                                    <div className="d-flex justify-content-center align-items-center mt-4">

                                                        <MDBBtn type='submit' className="mx-1 bg-success bg-gradient text-white">
                                                            Add Register
                                                        </MDBBtn>
                                                    </div>
                                                </MDBCardBody>
                                            </MDBCol>
                                        </MDBRow>

                                    </MDBCard>
                                </MDBCol>
                            </MDBRow>
                        </MDBContainer>
                    </Form>
                )}
            </Formik>

        </>
    )
}

export default RegisterFormik
{/* <form onSubmit={registerFormik.handleSubmit}>
<MDBContainer fluid className='h-100'>
    <MDBRow className='g-0'>
        <MDBCol md='8' className='mx-auto'>
            <MDBCard className='my-4'>

                <MDBRow className='g-0'>

                    <MDBCol md='8' className='mx-auto'>
                        <h4 className='text-success'>Library Management Register Form</h4>
                        {showAlert && (
                            <AlertComponent type={stateType} message={alertMessage} />

                        )}

                        <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                            <label htmlFor="name">Name</label>
                            <input
                                id="name"
                                name="name"
                                type="text"
                                onChange={registerFormik.handleChange}
                                value={registerFormik.values.name}
                            />
                            {registerFormik.errors.name && registerFormik.touched.name && (
                                <span className="error-message">{registerFormik.errors.name}</span>
                            )}
                            <Field type="text" id="email" name="email" className='mb-4' />
                            <ErrorMessage name="email" component="div" className="text-danger" />
                            <Field type="text" id="email" name="email" className='mb-4' />
                            <ErrorMessage name="email" component="div" className="text-danger" /> 

                             <MDBInput className='mb-4' type='name' id="name" name="name"
                                onChange={registerFormik.handleChange} value={registerFormik.values.name}                                            /> 
                             <ErrorMessage name="name" component="div" className="text-danger" /> 
                            <MDBInput className='mb-4' type='name' id="name" name="name"
                                onChange={registerFormik.handleChange} value={registerFormik.values.name}                                            />


                            <MDBInput className='mb-4' type='email' name="email" id='form1Example2' label='Email address *' onChange={registerFormik.handleChange} value={registerFormik.values.email} />
                            <MDBInput className='mt-4' name="password" type='password' id='form1Example3' label='Password *' onChange={registerFormik.handleChange} value={registerFormik.values.password} />
                            <MDBInput className='mt-4' name="phone" type='text' id='form4Example4' label='phone *' onChange={registerFormik.handleChange} value={registerFormik.values.phone} /> 

                            <div className="d-flex justify-content-center align-items-center mt-4">

                                <MDBBtn type='submit' className="mx-1 bg-success bg-gradient text-white">
                                    Add Register
                                </MDBBtn>
                            </div>
                        </MDBCardBody>
                    </MDBCol>
                </MDBRow>

            </MDBCard>
        </MDBCol>
    </MDBRow>
</MDBContainer>
</form> */}
{/* <Formik initialValues={registerFormik} validationSchema={validationRegister} onSubmit={handleRegister}>
                <Form>
                    <MDBContainer fluid className='h-100'>
                        <MDBRow className='g-0'>
                            <MDBCol md='8' className='mx-auto'>
                                <MDBCard className='my-4'>

                                    <MDBRow className='g-0'>

                                        <MDBCol md='8' className='mx-auto'>
                                            <h4 className='text-success'>Library Management Register Form</h4>
                                            {showAlert && (
                                                <AlertComponent type={stateType} message={alertMessage} />

                                            )}

                                            <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                                                <Field name="email">
                                                    {({field }) => (
                                                        <>
                                                            <MDBInput
                                                                className='mb-4'
                                                                type='email'
                                                                id='form1Example2'
                                                                label='Email address *'
                                                                {...field}
                                                            />
                                                            <ErrorMessage name="email" component="div" className="text-danger" />
                                                        </>
                                                    )}
                                                </Field>
                                            </MDBCardBody>
                                        </MDBCol>
                                    </MDBRow>

                                </MDBCard>
                            </MDBCol>
                        </MDBRow>
                    </MDBContainer>
                </Form>
            </Formik> */}