import React, { useState, useEffect } from 'react';
import { MDBInput, MDBCol, MDBRow, MDBCheckbox, MDBBtn, MDBContainer, MDBCard, MDBCardBody } from 'mdb-react-ui-kit';
import { useHistory } from 'react-router-dom';
import { IBookModuls } from '../models/bookDetailModuls';
import axios from 'axios';
import AlertComponent from '../components/form/alertFiled';
// const data = require('../../jsonData/bookData.json');
import { useDispatch, useSelector } from 'react-redux';
import { bookaddedRequest } from '../redux/action/addBookAction';

const AddBookInventory: React.FC = () => {
    const [addBookState, setAddBook] = useState<IBookModuls>({
        author: '',
        book_name: '',
        category_name: '',
        quantity: ''
    })
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        const { name, value } = e.target;
        setAddBook(prevState => ({
        ...prevState,
        [name]: value
        }));
    }
    const [validationErrors, setValidationErrors] = useState<any>({});
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [stateType, setStateType] = useState('danger');
    const dispatch = useDispatch();

    const addedBookRespons = useSelector((state:any)=>{
        return state?.addBookReducer?.data;
    })

    useEffect(() => {
        serviceAddBook(addedBookRespons)
    }, [addedBookRespons?.statue])
    
    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false);
            setStateType('danger');
        }, 1500);

        return () => clearTimeout(timer);
    }, [showAlert]);
    const serviceAddBook = (response: any) => { 
        try { 
            if (response && response.statue === "Success") {               
                history.push('/');                 
            }            
        } catch (error:any) {
            setAlertMessage("Book added  failed");
            setShowAlert(true);
        }
    };
    const handleAdd = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
        e.preventDefault();
        const errors: any = {};
        if (!addBookState.author.trim() || !addBookState.book_name.trim() || !addBookState.category_name.trim() || !addBookState.quantity) {
            setAlertMessage("All Input are required");
            setShowAlert(true);
            setStateType('danger');
            return;
        }
        setValidationErrors(errors);
        dispatch(bookaddedRequest(addBookState));
    }
    const handleCancel = () => {
        history.push('/');
    }
    const history = useHistory();
   
    return (
        <>
            <form onSubmit={handleAdd}>
                <MDBContainer fluid className=''>
                  
                    <MDBRow className='g-0'>

                        <MDBCol md='8' className='mx-auto'>
                            {showAlert && (
                                <AlertComponent type={stateType} message={alertMessage} />
                            )}
                            <MDBCard className='my-4'>

                                <MDBRow className='g-0'>

                                    <MDBCol md='8' className='mx-auto'>
                                        <h4 className='text-success'>Add New Book Form</h4>
                                        <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                                            <MDBInput className='mb-4' type='text' name="author" id='form1Example1' label='Author Name *' onChange={handleChange} />
                                            {validationErrors.author && <p className="text-danger">{validationErrors.author}</p>}
                                            <MDBInput className='mt-4' name="book_name" type='text' id='form1Example2' label='Book Name *' onChange={handleChange} />
                                            {validationErrors.book_name && <p className="text-danger">{validationErrors.book_name}</p>}
                                            <MDBInput className='mt-4' name="category_name" type='text' id='form1Example2' label='Category Name *' onChange={handleChange} />
                                            {validationErrors.category_name && <p className="text-danger">{validationErrors.category_name}</p>}
                                            <MDBInput className='mt-4' name="quantity" type='text' id='form1Example2' label='Quantity *' onChange={handleChange} />
                                            {validationErrors.quantity && <p className="text-danger">{validationErrors.quantity}</p>}
                                            <div className="d-flex justify-content-center align-items-center mt-2">
                                                <MDBBtn type='submit' className="bg-success bg-gradient text-white mx-2">
                                                    Add
                                                </MDBBtn>
                                                <MDBBtn className="bg-primary bg-gradient text-white" onClick={handleCancel}>
                                                    Cancel
                                                </MDBBtn>
                                            </div>
                                        </MDBCardBody>
                                    </MDBCol>
                                </MDBRow>

                            </MDBCard>
                        </MDBCol>
                    </MDBRow>

                </MDBContainer>
            </form>
        </>
    );
}

export default AddBookInventory;
