// import React from "react";
// import { useDispatch, useSelector, Provider } from 'react-redux';
// import { shallow, mount, render, ReactWrapper } from 'enzyme';
// import Dashboard from "./dashboard";
// import { ContextApiProvider } from "../../src/components/context/context";
// import configureStore from 'redux-mock-store';
// import { Route } from "react-router";
// const mockStore:any = configureStore([]);
// jest.mock('react-redux', () => ({
//     ...jest.requireActual('react-redux'),
//     useSelector: jest.fn()
// }));


// describe('Dashboard component', () => {
//     let store: ReturnType<typeof mockStore>;
//     let wrapper: ReactWrapper;
//     beforeEach(() => {
//         store = mockStore({
//             auth: {
//                 userData: null,
//             },
//         });
//         wrapper = mount(
//             <ContextApiProvider>
//             <Dashboard />
//           </ContextApiProvider>
//         )
//         console.log(wrapper);
//         //console.log(wrapper.html());
//     })

// });