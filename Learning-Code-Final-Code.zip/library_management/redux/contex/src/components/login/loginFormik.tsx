import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MDBInput, MDBCol, MDBRow, MDBCheckbox, MDBBtn, MDBContainer, MDBCard, MDBCardBody } from 'mdb-react-ui-kit';
import LibraryService from '../../service/serviceApi';
import { useHistory } from 'react-router-dom';
import { ILoginModel } from '../../models/loginModuls';
import AlertComponent from '../form/alertFiled';
import { loginRequest } from '../../redux/action/loginAction';
import { useApiContext } from '../context/context';
import * as Yup from 'yup';
import { Formik, Field, Form, ErrorMessage } from 'Formik';

const LoginFormik: React.FC = () => {
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const history = useHistory();
  const dispatch = useDispatch();
  // const loginRespons = useSelector((state: any) => {
  //   return state?.loginReducer?.data;
  // })  
  const loginRespons = useSelector((state: any) => state?.loginReducer?.data);
  const { login } = useApiContext()
  useEffect(() => {
    servicePostLogin(loginRespons)
  }, [loginRespons?.status])
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowAlert(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, [showAlert]);

  const servicePostLogin = (response: any) => {
    try {
      if (response && response.status === 'success') {
        localStorage.setItem("token", response.token);
        history.push('/dashboard',{ successMessage: "Login successful." });
      } else {
        // console.log('error22222222222222222222222222222222-')
        setAlertMessage("Login failed. Please check your credentials.");
        setShowAlert(true);
      }
    } catch (error: any) {
        // console.log('error111111111111111-',error)
      setAlertMessage("User id or password is mismatch. . Please try again later.");
      setShowAlert(true);
    }
  };
  const handleLogin = async (value:any) => { 
    //const errors: any = {}; 
    dispatch(loginRequest(value));
    login();
    // if (Object.keys(errors).length === 0 && errors.constructor === Object) {
    //     await servicePostLogin(value);                   
    // }
  } 
  const intValue = {
    email: '',
    password: ''
  }
  const validSeg = Yup.object({
    email: Yup.string().required('Eamil is required').email(),
    password: Yup.string().required('Password is required').min(6).max(40)
  })
  return (
    <>
      <Formik initialValues={intValue} validationSchema={validSeg} onSubmit={handleLogin}>
        {({ values, handleChange }) => (
          <Form>
            <MDBContainer fluid className='h-100'>
              <MDBRow className='g-0'>
                <MDBCol md='8' className='mx-auto'>
                  <MDBCard className='my-4'>
                    <MDBRow className='g-0'>
                      <MDBCol md='8' className='mx-auto'>
                        <h4 className='text-success'>Library Management Login Form</h4>
                        {showAlert && (
                          <AlertComponent type="danger" message={alertMessage} />
                        )}

                        <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                          <label htmlFor="email">Email</label>
                          <Field type="text" id="email" name="email" className='mb-4' />
                          <ErrorMessage name="email" component="div" className="text-danger" />
                          <label htmlFor="email">Password</label>
                          <Field type="text" id="password" name="password" className='mb-4'  />
                          <ErrorMessage name="password" component="div" className="text-danger" />

                          <p className='d-flex justify-content-center align-item-center mt-2 text-primary'>If your are in member please sing  or not a member please register</p>
                          <div className="d-flex justify-content-center align-items-center mt-2">
                            <MDBBtn type='submit' className="bg-success bg-gradient text-white">
                              Sign in
                            </MDBBtn>

                          </div>
                        </MDBCardBody>
                      </MDBCol>
                    </MDBRow>

                  </MDBCard>
                </MDBCol>
              </MDBRow>
            </MDBContainer>
          </Form>
        )}
      </Formik>      
          
    </>
  );
}

export default LoginFormik;






















// // Login.tsx
// import React, { useState } from 'react';
// import { useAuth } from './authContext';

// const Login: React.FC = () => {
//   const { login } = useAuth();
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');

//   const handleLogin = () => {
//     // Perform login logic here (e.g., call API)
//     // If login is successful, call the login function from AuthContext
//     login();
//   };

//   return (
//     <div>
//       <h2>Login</h2>
//       <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
//       <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
//       <button onClick={handleLogin}>Login</button>
//     </div>
//   );
// };

// export default Login;
