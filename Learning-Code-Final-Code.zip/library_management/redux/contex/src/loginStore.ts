import { createStore } from 'redux';

const logInForm = {
    email: 'sridhar@gmail.com',
    password: 'sridhar'
}

const loginReducer = (state = logInForm, action: any) => {
    switch (action.type) {
        case 'logIn':
            return { ...state, value: state.email }
    }
}
const store = createStore(loginReducer);

export default store;
