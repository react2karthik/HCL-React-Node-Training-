import React, { useState, useEffect } from 'react';
import {  useDispatch, useSelector } from 'react-redux';
import { MDBInput, MDBCol, MDBRow, MDBCheckbox, MDBBtn, MDBContainer, MDBCard, MDBCardBody } from 'mdb-react-ui-kit';
import { useHistory } from 'react-router-dom';
import { ILoginModel } from '../src/models/loginModuls';
import AlertComponent from '../src/components/form/alertFiled';
//import {loginRequest} from '../redux/action/loginAction';

interface LoginForm {
  login: ILoginModel
};
const LoginTest: React.FC = () => {
  const [loginState, setLogin] = useState<LoginForm>({
    login: {
      email: '',
      password: '',
    }
  })
  const [validationErrors, setValidationErrors] = useState<any>({});
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const dispatch = useDispatch();
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const { name, value } = e.target;
    setLogin(prevState => ({
      ...prevState,
      [name]: value
    }))
  }
  const userList = useSelector((state:any)=>{
    return state?.loginReducer?.data || []
  });
 
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowAlert(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, [showAlert]);
  const handleLogin = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    const errors: any = {};
    if (!loginState.login.email.trim() || !loginState.login.password) {
      setAlertMessage("Email and password are required.");
      setShowAlert(true);
      sessionStorage.setItem('user',JSON.stringify(loginState.login));
      return;
    }


    setValidationErrors(errors);
    if (Object.keys(errors).length === 0 && errors.constructor === Object) {
      // await servicePostLogin(loginState);
    }
  }
  const history = useHistory();
  const handleClick = () => {
    history.push('/register')
  }
  

  return (
    <>
      <form onSubmit={handleLogin}>
        <MDBContainer fluid className='h-100'>
          <MDBRow className='g-0'>
            <MDBCol md='8' className='mx-auto'>
              <MDBCard className='my-4'>
                <MDBRow className='g-0'>
                  <MDBCol md='8' className='mx-auto'>
                    <h4 className='text-success'>Library Management Login Form</h4>
                    {showAlert && (
                      <AlertComponent type="danger" message={alertMessage} />
                    )}
                    <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                      <MDBInput className='mb-4' type='email' name="email" id='form1Example1' label='Email address *' onChange={handleChange} />
                      {validationErrors.email && <p className="text-danger">{validationErrors.email}</p>}
                      <MDBInput className='mt-4' name="password" type='password' id='form1Example2' label='Password *' onChange={handleChange} />
                      {validationErrors.password && <p className="text-danger">{validationErrors.password}</p>}
                      <p className='d-flex justify-content-center align-item-center mt-2 text-primary'>If your are in member please sing  or not a member please register</p>
                      <div className="d-flex justify-content-center align-items-center mt-2">
                        <MDBBtn type='submit' className="bg-success bg-gradient text-white">
                          Sign in
                        </MDBBtn>
                        {/* <MDBBtn onClick={handleClick} className="mx-1 bg-primary bg-gradient text-white">
                                                    Register
                                                </MDBBtn> */}
                      </div>
                    </MDBCardBody>
                  </MDBCol>
                </MDBRow>

              </MDBCard>
            </MDBCol>
          </MDBRow>

        </MDBContainer>
      </form>
    </>
  );
}

export default LoginTest;
