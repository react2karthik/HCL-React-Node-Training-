export const SEARCH = 'SEARCH';
export const SEARCH_SUCCESS = 'SEARCH_SUCCESS';
export const SEARCH_ERROR = 'SEARCH_ERROR';
export const searchRequest = (searchBy: string, searchTxt: string) => ({
    type: 'SEARCH',
    payload: { searchBy, searchTxt },
});
export const searchSuccess = (searchResult: any) => ({
    type: 'SEARCH_SUCCESS',
    payload: { searchResult },
});
export const searchError = (error: any) => ({
    type: 'SEARCH_ERROR',
    payload: { error },
  });
