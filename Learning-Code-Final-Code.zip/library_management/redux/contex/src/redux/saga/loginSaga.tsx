import { call, put, takeLatest } from 'redux-saga/effects'; //takeevery
import { LOGIN, loginSuccess, loginFailed } from '../action/loginAction';
import { LOGINAPI } from '../../constant';
import apiService from '../../service/index';

function* login(data: any): Generator<any, void, any> {
    try {
        const response: any = yield call(apiService, LOGINAPI, data.payload, 'get');
        yield put(loginSuccess(response.data));        
    } catch (error:any) {
        yield put(loginFailed(error.message));
    }
}

function* loginSaga() {
    yield takeLatest(LOGIN, login);
}

export default loginSaga;