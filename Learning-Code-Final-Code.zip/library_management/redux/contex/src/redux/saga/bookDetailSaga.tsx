import { call, put, takeLatest } from 'redux-saga/effects'; //takeevery
import { GETBOOKDETAILS, getBookDetailsSuccess, getBookDetailsFailed } from '../action/bookDetailAction';
import { FETCHBOOKDETAILSAPI } from '../../constant';
import apiGetService from '../../service/getServiceApi';
import axios from 'axios';
function* fetchBookDeatils(data: any): Generator<any, void, any> {   
    try {
        const response:any = yield call(apiGetService, FETCHBOOKDETAILSAPI);
        yield put(getBookDetailsSuccess(response.data));
    } catch (error:any) {
         yield put(getBookDetailsFailed(error.message));
    }
}

function* bookDetailsSaga() {
    yield takeLatest(GETBOOKDETAILS, fetchBookDeatils);
}

export default bookDetailsSaga;