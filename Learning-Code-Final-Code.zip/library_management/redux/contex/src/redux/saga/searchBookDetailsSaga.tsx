import {call,put,takeLatest} from 'redux-saga/effects';
import {SEARCH,searchSuccess,searchError} from '../action/searchBookAction';
import {FETCHBOOKDETAILSAPI} from '../../constant';
import apiGetService  from '../../service/getServiceApi';

function* searchBook(data: any): Generator<any, void, any> {   
  try {
      const response:any = yield call(apiGetService, FETCHBOOKDETAILSAPI);
      yield put(searchSuccess(response.data));
  } catch (error:any) {
       yield put(searchError(error.message));
  }
}
// function* searchBook(action: { type: string, payload: { searchBy: string, searchTxt: string } }) {
//     try {
       
//       const { searchBy, searchTxt } = action.payload;
//       const searchBookResult = yield call(apiGetService,FETCHBOOKDETAILSAPI, searchBy, searchTxt);
//     } catch (error) {
//       yield put({ type: 'SEARCH_ERROR', error });
//     }
//   }
  

function*  searchBookSaga(){
    yield takeLatest(SEARCH,searchBook)
}
export default searchBookSaga;