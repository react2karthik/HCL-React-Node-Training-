import { combineReducers } from 'redux';
import loginReducer from './loginReducer';
import registerReducer from './registerReducer' ;
import bookDetailReducer from './bookDetailReducer';
import addBookReducer from './addBookDetailReducer';
import seachBookReducer from './searchBookReducer'
const rootReducer = combineReducers({
    loginReducer,
    registerReducer,
    bookDetailReducer,
    addBookReducer,
    seachBookReducer
});
 
export default rootReducer;