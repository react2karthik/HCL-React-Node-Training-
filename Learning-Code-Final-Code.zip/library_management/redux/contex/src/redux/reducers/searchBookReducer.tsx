import { SEARCH_SUCCESS, SEARCH_ERROR } from '../action/searchBookAction';

export interface searchBookState {
    searchResult: any;
    error: any;
}
const initialState: searchBookState = {
    searchResult: null,
    error: null,
};
const seachBookReducer = (state = initialState, action:any) => {
    switch (action.type) {
        case SEARCH_SUCCESS:
            return {
                ...state,searchResult: action.payload.searchResult
            };
        case SEARCH_ERROR:
            return {
                ...state,searchResult: null
            };
        default:
            return state;
    }

}
export default seachBookReducer;
