import {GETBOOKDETAILS_SUCCESS,GETBOOKDETAILS_FAILED} from '../action/bookDetailAction';

export interface bookDetailState {
    data:any;
}
const initialState: bookDetailState = {
    data:null,
};

const bookDetailReducer = (state:bookDetailState=initialState,action:any)=>{
    switch (action.type) {
        case GETBOOKDETAILS_SUCCESS:return{
            ...state,data:action.payload
        }
        case GETBOOKDETAILS_FAILED:return{
            ...state,data:null
        }
        default:
            return state;
    }
}
export default bookDetailReducer;