# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)




const validate = values => {
        const errors = {};
        const regExpEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        const regExPhone = new RegExp(/(\+*\d{1,})*([ |(])*(\d{3})[^\d]*(\d{3})[^\d]*(\d{4})/);
        const regExName = new RegExp(/^[a-zA-Z\s]*[a-zA-Z][a-zA-Z0-9\s]*$/);
        const regExAddress = new RegExp(/^[a-zA-Z0-9#&,()\-\\s/.' "]*$/); // Modified regex for address

        const fieldValidations = {
            businessEmail: { regex: regExpEmail, message: 'Please enter a valid business email' },
            businessPhone: { regex: regExPhone, message: 'Please enter a valid business phone number' },
            firstName: { regex: regExName, message: 'Please enter a valid first name ( alphanumeric characters only)' },
            lastName: { regex: regExName, message: 'Please enter a valid last name ( alphanumeric characters only)' },
            jobTitle: { regex: regExName, message: 'Please enter a valid job title ( alphanumeric characters only)' },
            street1: {
                regex: regExAddress,
                message: 'Please enter a valid street 1 (alphanumeric characters, #, &, (, ), -, /, #, space)'
            },
            street2: {
                regex: regExAddress,
                message: 'Please enter a valid street 2 (alphanumeric characters, #, &, (, ), -, /, #, space)'
            },
            city: { regex: regExName, message: 'Please enter a valid city ( alphanumeric characters only)' },
            fe_firstname: { regex: regExName, message: 'Please enter a valid first name ( alphanumeric characters only)' },
            fe_lastname: { regex: regExName, message: 'Please enter a valid last name ( alphanumeric characters only)' },
            fe_email: { regex: regExpEmail, message: 'Please enter a valid business email' },
            fe_job_title: { regex: regExName, message: 'Please enter a valid job title ( alphanumeric characters only)' }
        };

        const emailList = [];

        Object.keys(values).forEach(key => {
            if (key === 'businessEmail') {
                emailList.push(values.businessEmail);
            }

            if (key === 'ln_fe') {
                values[key].forEach((user, index) => {
                    Object.keys(user).forEach(userKey => {
                        if (user[userKey] === '') {
                            let element = document.getElementsByName(`${userKey}-${index}`)[0];
                            let attributeValue = element.getAttribute('errormessage');
                            if (attributeValue) {
                                errors[`${userKey}-${index}`] = attributeValue;
                            }
                        } else if (user[userKey] && fieldValidations[userKey] && !fieldValidations[userKey].regex.test(user[userKey])) {
                            errors[`${userKey}-${index}`] = `Addon User ${index + 1} ` + fieldValidations[userKey].message;
                        }

                        if (userKey === 'fe_email') {
                            const email = user[userKey];
                            emailList.push(email);
                        }
                    });
                });
            } else if (!values[key]) {
                let element = document.getElementsByName(key)[0];
                let attributeValue = element.getAttribute('errormessage');
                if (attributeValue) {
                    errors[key] = attributeValue;
                }
            } else if (fieldValidations[key] && !fieldValidations[key].regex.test(values[key])) {
                errors[key] = fieldValidations[key].message;
            }
        });

        //Check for unique email in non-ln_fe values
        const emailIndices = emailList.reduce((acc, email, index) => {
            acc[email] = acc[email] || [];

            acc[email].push(index);

            return acc;
        }, {});

        const duplicates = Object.entries(emailIndices)
            .filter(([email, indices]) => indices.length > 1)
            .reduce((acc, [email, indices]) => ({ ...acc, [email]: indices }), {});

        Object.entries(duplicates).map(([email, indices]) => {
            indices.map(index => {
                if (index === 0) {
                    errors.businessEmail = `Business email '${email}' should be unique`;
                } else {
                    errors[`fe_email-${index - 1}`] = `Addon User ${index} Business Email '${email}' should be unique`;
                }
            });
        });

        return errors;
    };

--
Thanks & Regards,
R.Sridhar
9688792155

