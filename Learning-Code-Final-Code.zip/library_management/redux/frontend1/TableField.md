// import React, { useState } from 'react';
// import { MDBDataTable, MDBInput } from 'mdb-react-ui-kit';

// const DataTableWithSearch: React.FC = () => {
//   const [searchValue, setSearchValue] = useState('');

//   // Sample data for demonstration
//   const data = {
//     columns: [
//       {
//         label: 'ID',
//         field: 'id',
//         width: 150,
//       },
//       {
//         label: 'Name',
//         field: 'name',
//         width: 270,
//       },
//       {
//         label: 'Email',
//         field: 'email',
//         width: 200,
//       },
//       {
//         label: 'Age',
//         field: 'age',
//         width: 100,
//       },
//       {
//         label: 'Country',
//         field: 'country',
//         width: 100,
//       },
//     ],
//     rows: [
//       {
//         id: 1,
//         name: 'John Doe',
//         email: 'john@example.com',
//         age: 30,
//         country: 'USA',
//       },
//       {
//         id: 2,
//         name: 'Jane Smith',
//         email: 'jane@example.com',
//         age: 25,
//         country: 'Canada',
//       },
//       // Add more rows as needed
//     ],
//   };

//   // Function to filter data based on search input
//   const filteredRows = data.rows.filter((row: any) => {
//     return (
//       row.id.toString().includes(searchValue) ||
//       row.name.toLowerCase().includes(searchValue.toLowerCase()) ||
//       row.email.toLowerCase().includes(searchValue.toLowerCase()) ||
//       row.age.toString().includes(searchValue) ||
//       row.country.toLowerCase().includes(searchValue.toLowerCase())
//     );
//   });

//   // Define DataTable attributes
//   const datatableOptions = {
//     searching: false, // We'll use our custom search field
//     sortable: true,
//     responsive: true,
//   };

//   return (
//     <div>
//       {/* Search input */}
//       <MDBInput
//         type="text"
//         label="Search"
//         value={searchValue}
//         onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchValue(e.target.value)}
//       />

//       {/* DataTable */}
//       <MDBDataTable
//         data={{
//           ...data,
//           rows: filteredRows,
//         }}
//         {...datatableOptions}
//       />
//     </div>
//   );
// };

// export default DataTableWithSearch;
import React, { useState } from 'react';
import DataTable from 'react-data-table-component';
import { Input } from 'mdb-react-ui-kit';

const DataTableWithSearch: React.FC = () => {
  const [searchValue, setSearchValue] = useState('');

  // Sample data for demonstration
  const data = [
    {
      id: 1,
      name: 'John Doe',
      email: 'john@example.com',
      age: 30,
      country: 'USA',
    },
    {
      id: 2,
      name: 'Jane Smith',
      email: 'jane@example.com',
      age: 25,
      country: 'Canada',
    },
    // Add more rows as needed
  ];

  // Columns configuration for DataTable
  const columns = [
    {
      name: 'ID',
      selector: 'id',
      sortable: true,
    },
    {
      name: 'Name',
      selector: 'name',
      sortable: true,
    },
    {
      name: 'Email',
      selector: 'email',
      sortable: true,
    },
    {
      name: 'Age',
      selector: 'age',
      sortable: true,
    },
    {
      name: 'Country',
      selector: 'country',
      sortable: true,
    },
  ];

  // Function to filter data based on search input
  const filteredData = data.filter(row =>
    Object.values(row).some(val => typeof val === 'string' && val.toLowerCase().includes(searchValue.toLowerCase()))
  );

  return (
    <div>
      {/* Search input */}
      <Input
        type="text"
        label="Search"
        value={searchValue}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchValue(e.target.value)}
      />

      {/* DataTable */}
      <DataTable
        columns={columns}
        data={filteredData}
        pagination
      />
    </div>
  );
};

export default DataTableWithSearch;
const handleSearch = () => {
        const filteredBySearch = bookData.filter(book => {
            const searchString = book.author.toLowerCase() + book.book_name.toLowerCase() + book.category_name.toLowerCase();
            return searchString.includes(searchTerm.toLowerCase());
        });
        setFilteredData(filteredBySearch);
    };
    <div className="input-group">
                    <input type="text" className="form-control" placeholder="Search..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                    <button className="btn btn-outline-secondary" type="button" onClick={handleSearch}>
                        Search
                    </button>
                </div>

