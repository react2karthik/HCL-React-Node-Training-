import React from "react";
import LoginForm from './components/loginForm/loginForm';
import { BrowserRouter as Router,Route, Switch } from "react-router-dom";
// import { BrowserRouter,Router,Route ,Routes} from "react-router-dom";
import Register from "./components/registerForm/registerForm";
import Dashboard from "./components/dashboard";
import AddBookInventory from './components/dashboard/addBookInventory'
import BorrowedBook from "./components/dashboard/borrowedBook";
import Footer from "./components/footer/footer";
import Header from "./components/header/header";
// import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import { HashRouter as Router,Route } from 'react-router-dom';

const App: React.FC = () => {
    return (
        <div className="app">
            <Header />           
            <Router>
                <Switch>
                    <Route exact path='/' component={LoginForm }></Route>
                    <Route exact path='/register' component={Register }></Route>
                    <Route exact path='/dashboard' component={Dashboard}></Route>
                    <Route exact path='/addBookInventory' component= {AddBookInventory}></Route>
                    <Route exact path='/borrowedBook' component= {BorrowedBook}></Route>
                </Switch>
            </Router>
            {/* <BrowserRouter>
                <Routes>
                
                    <Route path='/' element={<LoginForm />}></Route>
                    <Route path='/user/login' element={<Register />}></Route>
                    <Route path='/user/dashboard'element={<Dashboard />}></Route>
                    <Route path='/user/addBookInventory' element={<AddBookInventory />}></Route>
                    <Route path='/user/borrowedBook' element={<BorrowedBook />}></Route>
                
                    </Routes>
            </BrowserRouter> */}
            {/* <Router basename="/login" element={<LoginForm />}>

            </Router> */}
            {/* <Router>
            <Route path="/" component={LoginForm} />
            </Router> */}
            {/* <Route path="/" element={<LoginForm />} /> */}
                {/* <Route path="/login" component={Login} /> */}
            <Footer />
        </div>
    )
}

export default App;