import React from 'react';
import { MDBTable, MDBTableHead, MDBTableBody, MDBInput } from 'mdb-react-ui-kit';

interface TableRow {
  id: number;
  book_id: string;
  author: string;
  book_name: string;
  category_name: string,
  quantity: number
}

interface TableProps {
  data: TableRow[];
}
const DynamicTable: React.FC<TableProps> = ({ data }) => {
  return (
    <MDBTable className="table-bordered">
      <MDBTableHead>
        <tr>
          <th scope='col' className='fw-bold'>Book id</th>
          <th scope='col' className='fw-bold'>Author</th>
          <th scope='col' className='fw-bold'>Book Name</th>
          <th scope='col' className='fw-bold'>Category Name</th>
          <th scope='col' className='fw-bold'>Quantity</th>
        </tr>
      </MDBTableHead>
      <MDBTableBody>
        {data.map((row) => (
          <tr key={row.book_id}>
            <td>{row?.book_id}</td>
            <td>{row?.author}</td>
            <td>{row?.book_name}</td>
            <td>{row?.category_name}</td>
            <td>{row?.quantity}</td>
          </tr>
        ))}
      </MDBTableBody>
    </MDBTable>
  );
}

export default DynamicTable;