import React, { useState, ChangeEvent } from 'react'
interface InputFieldProps {
    data: string;
    dataTy:any;
}
const PaginationField: React.FC<InputFieldProps> = ({ data,dataTy}) => {
    // const  InputField = ({ value, label, placeholder, type, onChange }) =>{
    const pageSize = 5;
    const [currentPage, setCurrentPage] = useState(1);

    // Calculate the indexes of the current page
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, data.length);

    // Get the data for the current page
    const currentData = data.slice(startIndex, endIndex);
    console.log('1111111111111111111111111', currentData);
    // Handler for changing the page
    const onPageChange = (page: number) => {
        setCurrentPage(page);
    };
    return (
        <>
            <nav aria-label='Page navigation example'>
                <ul className='pagination justify-content-center'>
                    <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                        <button className='page-link' onClick={() => onPageChange(currentPage - 1)} tabIndex={-1} disabled={currentPage === 1}>
                            Previous
                        </button>
                    </li>
                    {/* Render page numbers */}
                    {[...Array(Math.ceil(data.length / pageSize)).keys()].map((page) => (
                        <li key={page} className={`page-item ${currentPage === page + 1 ? 'active' : ''}`}>
                            <button className='page-link' onClick={() => onPageChange(page + 1)}>
                                {page + 1}
                            </button>
                        </li>
                    ))}
                    <li className={`page-item ${currentPage === Math.ceil(data.length / pageSize) ? 'disabled' : ''}`}>
                        <button className='page-link' onClick={() => onPageChange(currentPage + 1)}>
                            Next
                        </button>
                    </li>
                </ul>
            </nav>
        </>
    )
}

export default PaginationField