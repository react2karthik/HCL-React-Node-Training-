import React, { useState,ChangeEvent } from 'react'
interface InputFieldProps {
  name:string;
  value: string;
  label?: string;
  placeholder?: string;
  type?: string;
  onChange: (event: ChangeEvent<HTMLInputElement>) => void;
}
const  InputField: React.FC<InputFieldProps> = ({ value, name,label, placeholder, type = 'text', onChange }) =>{
// const  InputField = ({ value, label, placeholder, type, onChange }) =>{
  return (    
    <div className='form-group'>
        {label && <label htmlFor="input-field" className='form-label'>{label}</label>}
        <input
          type={type}
          name={name}
          value={value}
          className="form-control"
          placeholder={placeholder}
          onChange={onChange}
        />
    </div>
  )
}
 
export default InputField