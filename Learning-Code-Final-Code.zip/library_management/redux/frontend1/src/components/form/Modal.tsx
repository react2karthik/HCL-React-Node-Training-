
// import React, { useState } from 'react';
// import {
//   MDBBtn,
//   MDBModal,
//   MDBModalDialog,
//   MDBModalContent,
//   MDBModalHeader,
//   MDBModalTitle,
//   MDBModalBody,
//   MDBModalFooter,
// } from 'mdb-react-ui-kit';
// import { ModalProps } from '../../models/modalPopup';
// const Modal: React.FC<ModalProps> = ({ isOpen }) => {
//   const [basicModal, setBasicModal] = useState(false);

//   const toggleOpen = () => setBasicModal(!basicModal);

//   return (
//     <>
//       {/* <MDBBtn onClick={toggleOpen}>LAUNCH DEMO MODAL</MDBBtn> */}
//       <MDBModal open={basicModal} setOpen={setBasicModal} tabIndex='-1'>
//         <MDBModalDialog>
//           <MDBModalContent>
//             <MDBModalHeader>
//               <MDBModalTitle>Modal title</MDBModalTitle>
//               <MDBBtn className='btn-close' color='none' onClick={toggleOpen}></MDBBtn>
//             </MDBModalHeader>
//             <MDBModalBody>...</MDBModalBody>

//             <MDBModalFooter>
//               <MDBBtn color='secondary' onClick={toggleOpen}>
//                 Close
//               </MDBBtn>
//               <MDBBtn>Save changes</MDBBtn>
//             </MDBModalFooter>
//           </MDBModalContent>
//         </MDBModalDialog>
//       </MDBModal>
//     </>
//   );
// }

// export default  Modal;
import React, { useState } from 'react';
import {
  MDBBtn,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
  MDBModalFooter,
} from 'mdb-react-ui-kit';

// Define props interface
interface ModalProps {
  // buttonText: string;
  modalTitleText:string;
  toggleOpen: () => void;
  setOpen:boolean
}

const Modal: React.FC<ModalProps> = ({ modalTitleText,toggleOpen,setOpen }) => {
  const [basicModal, setBasicModal] = useState(false);

  // const toggleOpen = () => setBasicModal(!basicModal);

  return (
    <>
      {/* <MDBBtn onClick={toggleOpen}>{buttonText}</MDBBtn> */}
      <MDBModal open={basicModal} setOpen={setBasicModal} tabIndex='-1'>
        <MDBModalDialog>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>{modalTitleText}</MDBModalTitle>
              <MDBBtn className='btn-close' color='none' onClick={toggleOpen}></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
                    
            </MDBModalBody>

            <MDBModalFooter>
              <MDBBtn color='secondary' onClick={toggleOpen}>
                Close
              </MDBBtn>
              <MDBBtn>Save changes</MDBBtn>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
    </>
  );
}

export default Modal;
