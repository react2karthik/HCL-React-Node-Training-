import React from 'react';
import {
  MDBNavbar,
  MDBContainer,
  MDBBreadcrumb,
  MDBBreadcrumbItem
} from 'mdb-react-ui-kit';
interface AppProps {
  homeLink?: string;
  libraryLink?: string;
  dataLink?: string;
  bookInventory?:string
}

const BreadCrumbFiled: React.FC<AppProps> = ({ homeLink, libraryLink, dataLink,bookInventory }) => {
  return (
    <MDBNavbar expand='lg' light bgColor='light'>
      <MDBContainer fluid>
        <nav aria-label='breadcrumb'>
          <MDBBreadcrumb>
            <MDBBreadcrumbItem>
              <a href={homeLink}>Login</a>
            </MDBBreadcrumbItem>
            {libraryLink && (
            <MDBBreadcrumbItem>
              <a href={libraryLink}>Register</a>
            </MDBBreadcrumbItem>
            )}
            <MDBBreadcrumbItem active aria-current='page'>
              <a href={dataLink}>Dashboard</a>
            </MDBBreadcrumbItem>
            {bookInventory&&(
                <MDBBreadcrumbItem active aria-current='page'>
                    <a href={bookInventory}>Book Inventory</a>
              </MDBBreadcrumbItem>
            )}
          </MDBBreadcrumb>
        </nav>
      </MDBContainer>
    </MDBNavbar>
  );
}

export default BreadCrumbFiled;
