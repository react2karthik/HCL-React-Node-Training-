import React, { useState } from 'react';
import {
  MDBBtn,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
  MDBModalFooter,
} from 'mdb-react-ui-kit';

// Define props interface
interface MMMMMMProps {
  buttonText: string;
}

const MMMMMM: React.FC<MMMMMMProps> = ({ buttonText }) => {
  const [basicModal, setBasicModal] = useState(false);

  const toggleOpen = () => setBasicModal(!basicModal);

  return (
    <>
      <MDBBtn onClick={toggleOpen}>{buttonText}</MDBBtn>
      <MDBModal open={basicModal} setOpen={setBasicModal} tabIndex='-1'>
        <MDBModalDialog>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Modal title</MDBModalTitle>
              <MDBBtn className='btn-close' color='none' onClick={toggleOpen}></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>...</MDBModalBody>

            <MDBModalFooter>
              <MDBBtn color='secondary' onClick={toggleOpen}>
                Close
              </MDBBtn>
              <MDBBtn>Save changes</MDBBtn>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
    </>
  );
}

export default MMMMMM;

{/* <section className="pb-4">
  <div className="border rounded-5">
    <section className="w-100 p-4">
      <div className="input-group mb-4">
        <input type="text" className="form-control" id="advanced-search-input" placeholder="phrase in:field1,field2" />
        <button className="btn btn-primary" id="advanced-search-button" type="button">
          <i className="fa fa-search" />
        </button>
      </div>
      <div id="datatable-advanced-search" className="datatable">
        <div className="datatable-inner table-responsive ps ps--active-x ps--active-y" style={{overflow: 'auto', position: 'relative'}}>
          <table className="table datatable-table">
            <thead className="datatable-header">
              <tr>
                <th style={{cursor: 'pointer'}} scope="col"><i data-mdb-sort="name" className="datatable-sort-icon fas fa-arrow-up" /> Name</th>
                <th style={{}} scope="col"> Position</th>
                <th style={{}} scope="col"> Office</th>
                <th style={{}} scope="col"> Age</th>
                <th style={{cursor: 'pointer'}} scope="col"><i data-mdb-sort="date" className="datatable-sort-icon fas fa-arrow-up" /> Start date</th>
                <th style={{}} scope="col"> Salary</th>
              </tr>
            </thead>
            <tbody className="datatable-body">
              <tr scope="row" data-mdb-index={0}><td style={{}} className data-mdb-field="name" false>Tiger Nixon</td><td style={{}} className data-mdb-field="position" false>System Architect</td><td style={{}} className data-mdb-field="office" false>Edinburgh</td><td style={{}} className data-mdb-field="age" false>61</td><td style={{}} className data-mdb-field="date" false>2011/04/25</td><td style={{}} className data-mdb-field="salary" false>$320,800</td></tr>
              <tr scope="row" data-mdb-index={1}><td style={{}} className data-mdb-field="name" false>Garrett Winters</td><td style={{}} className data-mdb-field="position" false>Accountant</td><td style={{}} className data-mdb-field="office" false>Tokyo</td><td style={{}} className data-mdb-field="age" false>63</td><td style={{}} className data-mdb-field="date" false>2011/07/25</td><td style={{}} className data-mdb-field="salary" false>$170,750</td></tr>
              <tr scope="row" data-mdb-index={2}><td style={{}} className data-mdb-field="name" false>Ashton Cox</td><td style={{}} className data-mdb-field="position" false>Junior Technical Author</td><td style={{}} className data-mdb-field="office" false>San Francisco</td><td style={{}} className data-mdb-field="age" false>66</td><td style={{}} className data-mdb-field="date" false>2009/01/12</td><td style={{}} className data-mdb-field="salary" false>$86,000</td></tr>
              <tr scope="row" data-mdb-index={3}><td style={{}} className data-mdb-field="name" false>Cedric Kelly</td><td style={{}} className data-mdb-field="position" false>Senior Javascript Developer</td><td style={{}} className data-mdb-field="office" false>Edinburgh</td><td style={{}} className data-mdb-field="age" false>22</td><td style={{}} className data-mdb-field="date" false>2012/03/29</td><td style={{}} className data-mdb-field="salary" false>$433,060</td></tr>
              <tr scope="row" data-mdb-index={4}><td style={{}} className data-mdb-field="name" false>Airi Satou</td><td style={{}} className data-mdb-field="position" false>Accountant</td><td style={{}} className data-mdb-field="office" false>Tokyo</td><td style={{}} className data-mdb-field="age" false>33</td><td style={{}} className data-mdb-field="date" false>2008/11/28</td><td style={{}} className data-mdb-field="salary" false>$162,700</td></tr>
              <tr scope="row" data-mdb-index={5}><td style={{}} className data-mdb-field="name" false>Brielle Williamson</td><td style={{}} className data-mdb-field="position" false>Integration Specialist</td><td style={{}} className data-mdb-field="office" false>New York</td><td style={{}} className data-mdb-field="age" false>61</td><td style={{}} className data-mdb-field="date" false>2012/12/02</td><td style={{}} className data-mdb-field="salary" false>$372,000</td></tr>
              <tr scope="row" data-mdb-index={6}><td style={{}} className data-mdb-field="name" false>Herrod Chandler</td><td style={{}} className data-mdb-field="position" false>Sales Assistant</td><td style={{}} className data-mdb-field="office" false>San Francisco</td><td style={{}} className data-mdb-field="age" false>59</td><td style={{}} className data-mdb-field="date" false>2012/08/06</td><td style={{}} className data-mdb-field="salary" false>$137,500</td></tr>
              <tr scope="row" data-mdb-index={7}><td style={{}} className data-mdb-field="name" false>Rhona Davidson</td><td style={{}} className data-mdb-field="position" false>Integration Specialist</td><td style={{}} className data-mdb-field="office" false>Tokyo</td><td style={{}} className data-mdb-field="age" false>55</td><td style={{}} className data-mdb-field="date" false>2010/10/14</td><td style={{}} className data-mdb-field="salary" false>$327,900</td></tr>
              <tr scope="row" data-mdb-index={8}><td style={{}} className data-mdb-field="name" false>Colleen Hurst</td><td style={{}} className data-mdb-field="position" false>Javascript Developer</td><td style={{}} className data-mdb-field="office" false>San Francisco</td><td style={{}} className data-mdb-field="age" false>39</td><td style={{}} className data-mdb-field="date" false>2009/09/15</td><td style={{}} className data-mdb-field="salary" false>$205,500</td></tr>
              <tr scope="row" data-mdb-index={9}><td style={{}} className data-mdb-field="name" false>Sonya Frost</td><td style={{}} className data-mdb-field="position" false>Software Engineer</td><td style={{}} className data-mdb-field="office" false>Edinburgh</td><td style={{}} className data-mdb-field="age" false>23</td><td style={{}} className data-mdb-field="date" false>2008/12/13</td><td style={{}} className data-mdb-field="salary" false>$103,600</td></tr>
            </tbody>
          </table>
          <div className="ps__rail-x" style={{width: 816, left: 0, bottom: 0}}><div className="ps__thumb-x" tabIndex={0} style={{left: 0, width: 815}} /></div><div className="ps__rail-y" style={{top: 0, height: 627, right: 0}}><div className="ps__thumb-y" tabIndex={0} style={{top: 0, height: 626}} /></div></div>
        <div className="datatable-pagination">
          <div className="datatable-select-wrapper">
            <p className="datatable-select-text">Rows per page:</p>
            <div id="select-wrapper-690704" className="select-wrapper"><div className="form-outline"><input className="form-control select-input placeholder-active active" type="text" role="listbox" aria-multiselectable="false" aria-disabled="false" aria-haspopup="true" aria-expanded="false" readOnly="true" /><span className="select-arrow" /><div className="form-notch"><div className="form-notch-leading" style={{width: 9}} /><div className="form-notch-middle" style={{width: 0}} /><div className="form-notch-trailing" /></div><div className="form-label select-fake-value">10</div></div><select name="entries" className="datatable-select select select-initialized">
                <option value={10} selected>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={200}>200</option>
              </select></div>
          </div>
          <div className="datatable-pagination-nav">
            1 - 10 of 14
          </div>
          <div className="datatable-pagination-buttons">
            <button data-mdb-ripple-color="dark" className="btn btn-link datatable-pagination-button datatable-pagination-left" disabled="true"><i className="fa fa-chevron-left" /></button>
            <button data-mdb-ripple-color="dark" className="btn btn-link datatable-pagination-button datatable-pagination-right"><i className="fa fa-chevron-right" /></button>
          </div>
        </div>
      </div>
    </section>
    <div className="p-4 text-center border-top mobile-hidden">
      <a className="btn btn-link px-3" data-mdb-toggle="modal" role="button" aria-expanded="false" aria-controls="example4" data-ripple-color="hsl(0, 0%, 67%)" data-mdb-target="#apiRestrictedModal" type="button" style={{}}>
        <i className="fas fa-code me-md-2" />
        <span className="d-none d-md-inline-block">
          Show code
        </span>
      </a>
    </div>
  </div>
</section> */}

