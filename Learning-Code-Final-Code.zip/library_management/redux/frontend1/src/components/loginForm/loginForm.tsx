import React, { useState,useEffect } from 'react';
import { MDBInput, MDBCol, MDBRow, MDBCheckbox, MDBBtn, MDBContainer, MDBCard, MDBCardBody } from 'mdb-react-ui-kit';
import LibraryService from '../../service/serviceApi';
import { useHistory } from 'react-router-dom';
import { ILoginModel } from '../../models/loginModuls';
// import { MDBIcon } from 'mdb-react-ui-kit';
import AlertComponent from '../form/alertFiled';
// import Navbar from '../header/navbar';
interface LoginForm {
    login: ILoginModel
};
const Login: React.FC = () => {
    const [loginState, setLogin] = useState<LoginForm>({
        login: {
            email: '',
            password: '',
        }
    })
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        setLogin({
            login: {
                ...loginState.login,
                [e.target.name]: e.target.value
            }
        })
    }
    const [validationErrors, setValidationErrors] = useState<any>({});
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false); 
        }, 1500);

        return () => clearTimeout(timer);
    }, [showAlert]);
    const handleLogin = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
        e.preventDefault();
        const errors: any = {};

        // if (!loginState.login.email.trim()) {
        //     errors.email = "Email is required";
        //     setAlertMessage("Email is required");
        //     setShowAlert(true);
        // } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(loginState.login.email)) {
        //     errors.email = "Email is not valid";
        //     setAlertMessage("Email is not valid");
        //     setShowAlert(true);
        // }

        
        // if (!loginState.login.password) {
        //     loginState.login.email
        //     errors.password = "Password is required";
        //     setAlertMessage("Password is required");
        //     setShowAlert(true);
        // } else if (loginState.login.password.length < 6) {
        //     errors.password = "Password should be at least 6 characters";
        //     setAlertMessage("Password should be at least 6 characters");
        //     setShowAlert(true);
        // }
        if (!loginState.login.email.trim() || !loginState.login.password) {
            setAlertMessage("Email and password are required.");
            setShowAlert(true);
            //sessionStorage.setItem('user',JSON.stringify(user));
            return;
        }

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(loginState.login.email)) {
            setAlertMessage("Email is not valid");
            setShowAlert(true);
            return;
        }

        setValidationErrors(errors);
        console.log("loginState.login", loginState.login)
        if (Object.keys(errors).length === 0 && errors.constructor === Object) {
            await servicePostLogin(loginState);                   
        }
    }
    const history = useHistory();
    const handleClick = () => {
        history.push('/register')
    }
    const servicePostLogin = async (data: any) => {
        const loginData = {
            email: data.login.email,
            password: data.login.password
        }
        try {
            const response = await LibraryService.login(JSON.stringify(loginData));
            if (response && response.data.status == 'success') {
                localStorage.setItem("token", response.data.token);
                history.push('/dashboard',{ successMessage: "Login successful." });                 
            }else{
                setAlertMessage("Login failed. Please check your credentials.");
                setShowAlert(true);
            }
        } catch (error) {
            setAlertMessage("User id or password is mismatch. . Please try again later.");
            setShowAlert(true);
        }
    };
    
    return (
        <>
            <form onSubmit={handleLogin}>
                <MDBContainer fluid className='h-100'>
                    <MDBRow className='g-0'>
                        <MDBCol md='8' className='mx-auto'>
                            <MDBCard className='my-4'>
                                <MDBRow className='g-0'>
                                    <MDBCol md='8' className='mx-auto'>
                                        <h4 className='text-success'>Library Management Login Form</h4>
                                        {showAlert && (
                                            <AlertComponent type="danger" message={alertMessage} />
                                        )}
                                        <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                                            <MDBInput className='mb-4' type='email' name="email" id='form1Example1' label='Email address *' onChange={handleChange} />
                                            {validationErrors.email && <p className="text-danger">{validationErrors.email}</p>}
                                            <MDBInput className='mt-4' name="password" type='password' id='form1Example2' label='Password *' onChange={handleChange} />
                                            {validationErrors.password && <p className="text-danger">{validationErrors.password}</p>}
                                            <p className='d-flex justify-content-center align-item-center mt-2 text-primary'>If your are in member please sing  or not a member please register</p>
                                            <div className="d-flex justify-content-center align-items-center mt-2">
                                                <MDBBtn type='submit' className="bg-success bg-gradient text-white">
                                                    Sign in
                                                </MDBBtn>
                                                <MDBBtn onClick={handleClick} className="mx-1 bg-primary bg-gradient text-white">
                                                    Register
                                                </MDBBtn>
                                            </div>
                                        </MDBCardBody>                                        
                                    </MDBCol>
                                </MDBRow>

                            </MDBCard>
                        </MDBCol>
                    </MDBRow>

                </MDBContainer>
            </form>
        </>
    );
}

export default Login;
