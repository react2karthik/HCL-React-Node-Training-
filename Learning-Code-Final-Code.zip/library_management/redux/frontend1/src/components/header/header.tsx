import React,{useState,useEffect} from 'react';
import {
  MDBNavbar,
  MDBBtn,
  MDBContainer,MDBNavbarBrand
} from 'mdb-react-ui-kit';
import { Link } from 'react-router-dom';
import Navbar from './navbar';
// import logo from '../../assets/logo.png'; // Import your logo file
// const logo = require('../../assets/logo.png')
const Header: React.FC = (setPassIsLoggedIn:any ) => {
  const [isLoggedIn,setIsLoggedIn] = useState(false);
  // useEffect(()=>{
  //     if(localStorage.getItem('token') != ''){
  //       setIsLoggedIn(true)
  //       console.log('111111111111111111111',isLoggedIn)
  //     }else{
  //       setIsLoggedIn(false)
  //       console.log('222222222222222222222222222222222',isLoggedIn)
  //     }
  // })
  // const [isLoggedIn, setIsLoggedIn] = useState(false);

  // useEffect(() => {
  //   const token = localStorage.getItem('token');
  //   if (token) {
  //     setIsLoggedIn(true);
  //   } else {
  //     setIsLoggedIn(false);
  //   }
  // }, []); 
 
  return (
    <MDBNavbar light bgColor='light'>
      <MDBContainer tag="form" fluid >
         <MDBNavbarBrand>
          <img src="https://th.bing.com/th/id/R.1727f4a07a80a40db16970437691db05?rik=u2J35nn8DTozPA&riu=http%3a%2f%2fassets.stickpng.com%2fimages%2f61f7cd1767553f0004c53e6e.png&ehk=lmFpoV5zZhKSPNp0UZrBtGkn4hySwbMZJyUCZ0JcIrE%3d&risl=&pid=ImgRaw&r=0" alt='Library Management Logo' height='30' className='d-inline-block align-top me-2' />
          Library Management
        </MDBNavbarBrand>
        {/* <MDBBtn outline color="success" className='me-2' type='button'>
        Main button
        </MDBBtn> */}
        {/* <MDBBtn outline color="secondary" size="sm" type='button'>
          Smaller button
        </MDBBtn> */}
        {/* {isLoggedIn && <Navbar />} */}
        <Navbar isLoggedIn={isLoggedIn} />
      </MDBContainer>
    </MDBNavbar>
  );
}
export default Header;