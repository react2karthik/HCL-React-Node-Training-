import React, { useState, useEffect } from 'react';
import { MDBInput, MDBCol, MDBRow, MDBCheckbox, MDBBtn, MDBContainer, MDBCard, MDBCardBody } from 'mdb-react-ui-kit';
import { useHistory } from 'react-router-dom';
import { IBookModuls } from '../../models/bookInventoryModuls';
import BreadCrumbFiled from '../form/breadCrumbFiled';
import axios from 'axios';
import AlertComponent from '../form/alertFiled';
import LibraryService from '../../service/serviceApi';
// const data = require('../../jsonData/bookData.json');
interface AddBookForm {
    addBook: IBookModuls
};

const AddBookInventory: React.FC = () => {
    const [addBookState, setAddBook] = useState<AddBookForm>({
        addBook: {
            author: '',
            book_name: '',
            category_name: '',
            quantity: ''
        }
    })
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        setAddBook({
            addBook: {
                ...addBookState.addBook,
                [e.target.name]: e.target.value
            }
        })
    }
    const [validationErrors, setValidationErrors] = useState<any>({});
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [stateType, setStateType] = useState('danger');
    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false);
            setStateType('danger');
        }, 1500);

        return () => clearTimeout(timer);
    }, [showAlert]);
    const handleAdd = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
        e.preventDefault();
        const errors: any = {};
        if (!addBookState.addBook.author.trim() || !addBookState.addBook.book_name.trim() || !addBookState.addBook.category_name.trim() || !addBookState.addBook.quantity) {
            // errors.author = "Author is required";
            setAlertMessage("All Input are required");
            setShowAlert(true);
            setStateType('danger');
            return;
        }
        // if (!addBookState.addBook.book_name.trim()) {
        //     errors.book_name = "Book name is required";
        // }
        // if (!addBookState.addBook.category_name.trim()) {
        //     errors.category_name = "Category name is required";
        // }
        // if (!addBookState.addBook.quantity) {
        //     errors.quantity = "Category name is required";
        // }
        setValidationErrors(errors);
        console.log("loginState.login", addBookState.addBook);
        // const x = addBookState.addBook;
        // console.log('11111111111111111111111111111111111111',x)
        if (Object.keys(errors).length === 0 && errors.constructor === Object) {
            // await servicePostLogin(loginState);
            // const formData = addBookState.addBook;         
            // history.push('/dashboard',{formData});
            // history.push('/dashboard');
            // const formData = addBookState.addBook;
            // history.push('/dashboard', { formData, data });
            await serviceAddBook(addBookState);
        }
    }
    const handleCancel = () => {
        history.push('/');
    }
    const history = useHistory();
    const serviceAddBook = async (data: any) => {
        const addBookData = {
            author: data.addBook.author,
            book_name: data.addBook.book_name,
            category_name: data.addBook.category_name,
            quantity: data.addBook.quantity
        }
        try {
            const response = await LibraryService.addBook(JSON.stringify(addBookData));
            localStorage.setItem("token", response.data.token);
            console.log('1111111111111111111111',response.data);
            console.log('000000',response.data.statue);
            if (response && response.data.statue == 'Success') {
                setStateType('success');
                setAlertMessage("Register successful.");
                setShowAlert(true);
                // setTimeout(() => {
                //     history.push('/'); // Redirect to the login page
                // }, 3000);
            }
        } catch (error) {
            setAlertMessage("Register failed.Please try again later.");
            setShowAlert(true);
            setStateType('danger');
            return error;
        }
    }
    return (
        <>
            <form onSubmit={handleAdd}>
                <MDBContainer fluid className=''>
                    <BreadCrumbFiled homeLink='/' dataLink='/dashboard' bookInventory='#' />
                    <MDBRow className='g-0'>

                        <MDBCol md='8' className='mx-auto'>
                            {showAlert && (
                                <AlertComponent type={stateType} message={alertMessage} />
                            )}
                            <MDBCard className='my-4'>

                                <MDBRow className='g-0'>

                                    <MDBCol md='8' className='mx-auto'>
                                        <h4 className='text-success'>Add New Book Form</h4>
                                        <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                                            <MDBInput className='mb-4' type='text' name="author" id='form1Example1' label='Author Name *' onChange={handleChange} />
                                            {validationErrors.author && <p className="text-danger">{validationErrors.author}</p>}
                                            <MDBInput className='mt-4' name="book_name" type='text' id='form1Example2' label='Book Name *' onChange={handleChange} />
                                            {validationErrors.book_name && <p className="text-danger">{validationErrors.book_name}</p>}
                                            <MDBInput className='mt-4' name="category_name" type='text' id='form1Example2' label='Category Name *' onChange={handleChange} />
                                            {validationErrors.category_name && <p className="text-danger">{validationErrors.category_name}</p>}
                                            <MDBInput className='mt-4' name="quantity" type='text' id='form1Example2' label='Quantity *' onChange={handleChange} />
                                            {validationErrors.quantity && <p className="text-danger">{validationErrors.quantity}</p>}
                                            <div className="d-flex justify-content-center align-items-center mt-2">
                                                <MDBBtn type='submit' className="bg-success bg-gradient text-white mx-2">
                                                    Add
                                                </MDBBtn>
                                                <MDBBtn className="bg-primary bg-gradient text-white" onClick={handleCancel}>
                                                    Cancel
                                                </MDBBtn>
                                            </div>
                                        </MDBCardBody>
                                    </MDBCol>
                                </MDBRow>

                            </MDBCard>
                        </MDBCol>
                    </MDBRow>

                </MDBContainer>
            </form>
        </>
    );
}

export default AddBookInventory;
