import React, { useState } from 'react';
import { IBookModuls } from '../../models/bookInventoryModuls';
import { MDBContainer, MDBTable, MDBTableHead, MDBTableBody, MDBRow } from 'mdb-react-ui-kit';
import { MDBDropdown, MDBDropdownMenu, MDBDropdownToggle, MDBDropdownItem, MDBBtn } from 'mdb-react-ui-kit';
const data = require('../../jsonData/borrowedBookData.json');
import { useHistory } from 'react-router-dom';
import BreadCrumbFiled from '../form/breadCrumbFiled';

const BorrowedBook: React.FC = () => {
    const usersBook: IBookModuls[] = data;

    const [bookData, setbookData] = useState(usersBook);

    const history = useHistory();
    const handleAddBook = () => {
        history.push('/addBookInventory')
    }
    return (
        <>
            <MDBContainer fluid className=''>
                <MDBRow className="mt-2 g-0 ">
                    <BreadCrumbFiled homeLink='/' dataLink='/dashboard' bookInventory='/addBookInventory' />
                    <MDBTable className="table-bordered mt-4">
                        <MDBTableHead>
                            <tr>
                                <th scope='col' className='fw-bold'>Returned By</th>
                                <th scope='col' className='fw-bold'>Borrowed Date</th>
                                <th scope='col' className='fw-bold'>Due Date</th>
                                <th scope='col' className='fw-bold'>Penalty Amount</th>
                            </tr>
                        </MDBTableHead>
                        <MDBTableBody>
                            {bookData?.map((user: any, index: number) => (
                                <tr key={index}>
                                    <td>{user?.book_returned_by}</td>
                                    <td>{user?.borrowed_date}</td>
                                    <td>{user?.due_date}</td>
                                    <td>{user?.penalty_amount}</td>
                                </tr>
                            ))}
                        </MDBTableBody>
                    </MDBTable>
                </MDBRow>
            </MDBContainer>
        </>
    )
}

export default BorrowedBook