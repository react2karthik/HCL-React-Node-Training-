import React, { useState, useEffect } from 'react';
import { MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCardImage, MDBRow, MDBCol, MDBInput, MDBRadio, MDBCheckbox, MDBIcon, MDBTabs, MDBTabsItem, MDBTabsLink, MDBTabsContent, MDBTabsPane } from 'mdb-react-ui-kit';
import { useHistory } from 'react-router-dom'
import { IRegisterModuls } from '../../models/registerModuls';
import LibraryService from '../../service/serviceApi';
import AlertComponent from '../form/alertFiled';
interface RegisterSubmitForm {
  register: IRegisterModuls
};
const Register: React.FC = () => {
  const [registerState, setRegister] = useState<RegisterSubmitForm>({
    register: {
      name: '',
      email: '',
      password: '',
      phone: ''
    }
  })
  // const [isModalOpen, setIsModalOpen] = useState(true);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [stateType, setStateType] = useState('danger');//type='danger'
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowAlert(false);
      setStateType('danger');
    }, 1500);

    return () => clearTimeout(timer);
  }, [showAlert]);
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    setRegister({
      register: {
        ...registerState.register,
        [e.target.name]: e.target.value
      }
    })
  }
  const [validationErrors, setValidationErrors] = useState<any>({});
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    console.log(JSON.stringify(registerState.register));
    const errors: any = {};
    if (!registerState.register.name.trim() || !registerState.register.email.trim() || !registerState.register.password || !registerState.register.phone) {
      setAlertMessage("Name,Email ,Password  and Phone are required.");
      setShowAlert(true);
      setStateType('danger');
      return;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(registerState.register.email) || registerState.register.password.length < 6 || registerState.register.phone.length < 6) {
      errors.email = "Email is not valid";
      errors.password = "Password should be at least 6 characters";
      errors.phone = "Phone should be at least 10 characters";
      setValidationErrors(errors);
      setAlertMessage(Object.values(errors).join(' '));
      setShowAlert(true);
      setStateType('danger');
      return;
    }
    // if (!registerState.register.name.trim()) {
    //   errors.name = "Name is required";
    // }
    // if (!registerState.register.email.trim()) {
    //   errors.email = "Email is required";
    // } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(registerState.register.email)) {
    //   errors.email = "Email is not valid";
    // }

    // if(!registerState.register.conformPassword !== registerState.register.password){
    //   errors.conformPassword = "password is not matched"
    // }
    // if (!registerState.register.password) {
    //   errors.password = "Password is required";
    // } else if (registerState.register.password.length < 6) {
    //   errors.password = "Password should be at least 6 characters";
    // }

    // if (!registerState.register.phone) {
    //   errors.phone = "Phone is required";
    // } else if (registerState.register.phone.length < 6) {
    //   errors.phone = "Phone should be at least 10 characters";
    // }
    setValidationErrors(errors);

    // if (Object.keys(errors).length === 0) {
    //   console.log(JSON.stringify(registerState.register));
    // }
    if (Object.keys(errors).length === 0 && errors.constructor === Object) {

      await servicePostRegister(registerState);
      console.log(JSON.stringify(registerState.register));
    }
    // const success = true; // or false based on the actual registration result
    // const message = success ? 'Registration successful!' : 'Registration failed. Please try again.';
    // setRegistrationResult({ success, message });
    // setShowToast(true);
  }
  //  const [showToast, setShowToast] = useState(false);
  // const [registrationResult, setRegistrationResult] = useState<{ success: boolean; message: string }>({
  //   success: false,
  //   message: '',
  // });
  // const handleCl = () =>{
  //   // toggleModal();
  //   alert("hi")
  //   setIsModalOpen(true);
  // }
  // const toggleOpen = () => {
  //   setIsModalOpen(!isModalOpen);
  // };
  const history = useHistory();
  // const handleSignClick = () => {
  //   history.push('/')
  // }

  const servicePostRegister = async (data: any) => {
    const registerData = {
      name: data.register.name,
      email: data.register.email,
      password: data.register.password,
      phone: data.register.phone
    }
    try {
      const response = await LibraryService.register(JSON.stringify(registerData));
      if (response && response.data.statue === "Success") {
        localStorage.setItem("token", response.data.token);
        // history.push('/dashboard');
        setStateType('success');
        setAlertMessage("Register successful. Redirecting to login page...");
        setShowAlert(true);
        setTimeout(() => {
          history.push('/'); // Redirect to the login page
        }, 3000);
        // setTimeout(() => { 
        //  setStateType('success');        
        //  setAlertMessage("Register successful. Redirecting to login page...");       
        //  setShowAlert(true);
        //  history.push('/');
        //  // window.location.href = '/';
        // }, 3000);
      }
    } catch (error) {
      setAlertMessage("Register failed.Please try again later.");
      setShowAlert(true);
      setStateType('danger');
      // return error;
    }
  };


  return (
    <>
      <form onSubmit={handleSubmit}>
        <MDBContainer fluid className='h-100'>
          <MDBRow className='g-0'>
            <MDBCol md='8' className='mx-auto'>
              <MDBCard className='my-4'>

                <MDBRow className='g-0'>

                  <MDBCol md='8' className='mx-auto'>
                    <h4 className='text-success'>Library Management Register Form</h4>
                    {showAlert && (
                      // <AlertComponent  type={(validationErrors.name || validationErrors.email || validationErrors.password || validationErrors.phone) === 'success' ? 'success' : 'danger'}  message={alertMessage} />
                      <AlertComponent type={stateType} message={alertMessage} />
                      //<AlertComponent type={validationErrors.email || validationErrors.password || validationErrors.phone ? 'danger' : 'success'} message={alertMessage} />

                    )}
                    {/*{showAlert ? (
                      // <AlertComponent  type={(validationErrors.name || validationErrors.email || validationErrors.password || validationErrors.phone) === 'success' ? 'success' : 'danger'}  message={alertMessage} />
                      //<AlertComponent  type='danger' message={alertMessage} />
                      //<AlertComponent type={validationErrors.email || validationErrors.password || validationErrors.phone ? 'danger' : 'success'} message={alertMessage} />

                   // ):<AlertComponent  type='success' message={alertMessage} />
                    //}*/}
                    <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                      <MDBInput className='mb-4' type='name' name="name" id='form3Example1' label='Name address *' onChange={handleChange} />
                      {validationErrors.email && <p className="text-danger">{validationErrors.name}</p>}
                      <MDBInput className='mb-4' type='email' name="email" id='form1Example2' label='Email address *' onChange={handleChange} />
                      {validationErrors.email && <p className="text-danger">{validationErrors.email}</p>}
                      <MDBInput className='mt-4' name="password" type='password' id='form1Example3' label='Password *' onChange={handleChange} />
                      {validationErrors.password && <p className="text-danger">{validationErrors.password}</p>}
                      <MDBInput className='mt-4' name="phone" type='text' id='form4Example4' label='phone *' onChange={handleChange} />
                      {validationErrors.phone && <p className="text-danger">{validationErrors.phone}</p>}

                      <div className="d-flex justify-content-center align-items-center mt-4">
                        {/* <MDBBtn onClick={handleSignClick} className="bg-primary bg-gradient text-white">
                          Sign in
                        </MDBBtn> */}
                        <MDBBtn type='submit' className="mx-1 bg-success bg-gradient text-white">
                          Add Register
                        </MDBBtn>
                      </div>
                    </MDBCardBody>
                  </MDBCol>
                </MDBRow>

              </MDBCard>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
      </form>
    </>
  );
}

export default Register;