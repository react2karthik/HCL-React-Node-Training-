export interface IBorrowedBookModuls {  
    book_returned_by:string,
    //book_id:number,
    borrowed_date:string,
    due_date:string,
    penalty_amount:number | string
}