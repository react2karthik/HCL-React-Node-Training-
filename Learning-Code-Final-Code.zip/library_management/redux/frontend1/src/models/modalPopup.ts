export interface ModalProps {
    isOpen: boolean; 
    // toggle: () => void; 
}