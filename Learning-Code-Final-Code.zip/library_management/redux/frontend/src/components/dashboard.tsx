import React, { useState, useEffect } from 'react';
import { MDBTable, MDBTableHead, MDBTableBody, MDBContainer, MDBBtn, MDBRow, MDBCol, MDBBreadcrumb, MDBBreadcrumbItem, MDBDropdownItem, MDBDropdown, MDBDropdownToggle, MDBDropdownMenu } from 'mdb-react-ui-kit';
import { useHistory, useLocation } from 'react-router-dom';
import { IBookModuls } from '../models/bookDetailModuls';
import { getBookDetailsRequest } from '../redux/action/bookDetailAction';
import {searchRequest} from '../redux/action/searchBookAction';
import { useDispatch, useSelector } from 'react-redux';

const Dashboard: React.FC = () => {
    const [bookData, setbookData] = useState<IBookModuls>({
        author: '',
        book_name: '',
        category_name: '',
        quantity: ''
    });
    const dispatch = useDispatch();
    const [searchTxt, setSearchTxt] = useState('');
    const bookDetails = useSelector((state: any) => {
        return state?.bookDetailReducer?.data
    });
    console.log('ooooooooooooooooo---',bookDetails);
    useEffect(() => {
        serviceGetBook(bookDetails)
    }, [bookDetails?.statue]);
    const serviceGetBook = (response: any) => {
        try {
            if (response && response.status === 'success') {
                localStorage.getItem(response);
            }
        } catch (error: any) {
            console.log('error', error)
        }
    };
    useEffect(()=>{
        dispatch(getBookDetailsRequest(bookDetails));
    },[])
    const searchResult = useSelector((state: any) => state.searchRequest);

    const typeChange = () => {
        const e: any = document.getElementById("searchType");
        var value = e.options[e.selectedIndex].value;
        console.log('TYPECHNAGE122222',value)
    }
    const onSearchChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        if (e.target.value == '') setbookData(bookDetails);
        setSearchTxt(e.target.value);
        console.log("SEARCH3333333333333",e.target.value);
    }
    const [searchBy, setSearchBy] = useState('');
    const onSearchClick = async () => {
        const e: any = document.getElementById("searchType");
        dispatch(searchRequest(searchBy, searchTxt));
        const x = e.options[e.selectedIndex].value;
        alert(x )
        let filteredData = bookDetails.filter((book: any) => { return book[x].toLowerCase() == searchTxt.toLowerCase() });
        console.log('ppppppppppppppppppppppp', filteredData)
        setbookData(filteredData);
    };
  

    return (
        <>
            <MDBContainer   >
                <MDBRow className="mt-2 g-0 ">
                    <MDBCol className="table-bordered ml-auto mt-2 mb-2" md='120'>
                        <div className='d-flex align-items-center'>
                            <>
                                <select className="btn btn-primary dropdown-toggle px-2" aria-label=".form-select-lg example" id="searchType" onChange={() => typeChange()}>
                                    <option value="0">Select Search By Type</option>
                                    <option value="author">author</option>
                                    <option value="book_name">book_name</option>
                                    <option value="category_name">category_name</option>
                                </select>
                            </>
                            <div className="input-group mx-2">
                                <input onChange={(e) => onSearchChange(e)} type="text" className="form-control border " placeholder="Search..." aria-label="Search" aria-describedby="basic-addon2" />
                                <button onClick={onSearchClick} type="button" id="search" className="btn btn-primary">
                                    <i className="material-icons">search</i>
                                </button>
                            </div>
                        </div>
                        <MDBTable className="table-bordered">
                            <MDBTableHead>
                                <tr>
                                    {/* <th scope='col' className='fw-bold'>Book id</th> */}
                                    <th scope='col' className='fw-bold'>Author</th>
                                    <th scope='col' className='fw-bold'>Book Name</th>
                                    <th scope='col' className='fw-bold'>Category Name</th>
                                    <th scope='col' className='fw-bold'>Quantity</th>
                                </tr>
                            </MDBTableHead>
                            <MDBTableBody>
                                {bookDetails?.map((user: any, index: number) => (
                                    <tr key={index}>
                                        {/* <td>{user?.book_id}</td> */}
                                        <td>{user?.author}</td>
                                        <td>{user?.book_name}</td>
                                        <td>{user?.category_name}</td>
                                        <td>{user?.quantity}</td>
                                    </tr>
                                ))}
                            </MDBTableBody>
                        </MDBTable>
                    </MDBCol>
                </MDBRow>
               
            </MDBContainer >
        </>
    )
}
export default Dashboard;