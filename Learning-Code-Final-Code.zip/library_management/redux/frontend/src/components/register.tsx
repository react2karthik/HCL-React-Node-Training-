import React, { useState, useEffect } from "react";
import { IRegisterModuls } from '../models/registerModuls';
import { useDispatch, useSelector } from 'react-redux';
import { registerRequest } from '../redux/action/registerAction';
import { MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCardImage, MDBRow, MDBCol, MDBInput, MDBRadio, MDBCheckbox, MDBIcon, MDBTabs, MDBTabsItem, MDBTabsLink, MDBTabsContent, MDBTabsPane } from 'mdb-react-ui-kit';
import AlertComponent from './form/alertFiled';
import { useHistory } from 'react-router-dom';
const Register: React.FC = () => {
    const [registerState, setRegister] = useState<IRegisterModuls>({
        name: '',
        email: '',
        password: '',
        phone: ''
    })
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [stateType, setStateType] = useState('danger');
    const [validationErrors, setValidationErrors] = useState<any>({});
    const dispatch = useDispatch();
    const history = useHistory();
    const registerRespons = useSelector((state: any) => {
        return state?.registerReducer?.data;
    })
    useEffect(() => {
        servicePostLogin(registerRespons)
    }, [registerRespons?.statue])
    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false); 
        }, 1500);

        return () => clearTimeout(timer);
    }, [showAlert]);
    const servicePostLogin = (response: any) => {   
        try { 
            if (response && response.statue === "Success") {               
                history.push('/');                 
            }
            
        } catch (error:any) {
            setAlertMessage("Register failed.Please try again later.");
            setShowAlert(true);
        }
    };
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
        const { name, value } = e.target;
        setRegister(prevState => ({
            ...prevState,
            [name]: value
        }))
    }
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const errors: any = {};
        if (!registerState.name.trim() || !registerState.email.trim() || !registerState.password || !registerState.phone) {
            setAlertMessage("Name,Email ,Password  and Phone are required.");
            setShowAlert(true);
            setStateType('danger');
            return;
        }
        setValidationErrors(errors);
        dispatch(registerRequest(registerState));
    }
    return (
        <>
            <form onSubmit={handleSubmit}>
                <MDBContainer fluid className='h-100'>
                    <MDBRow className='g-0'>
                        <MDBCol md='8' className='mx-auto'>
                            <MDBCard className='my-4'>

                                <MDBRow className='g-0'>

                                    <MDBCol md='8' className='mx-auto'>
                                        <h4 className='text-success'>Library Management Register Form</h4>
                                        {showAlert && (
                                            <AlertComponent type={stateType} message={alertMessage} />

                                        )}

                                        <MDBCardBody className='text-black d-flex flex-column justify-content-center'>
                                            <MDBInput className='mb-4' type='name' name="name" id='form3Example1' label='Name address *' onChange={handleChange} />
                                            {validationErrors.email && <p className="text-danger">{validationErrors.name}</p>}
                                            <MDBInput className='mb-4' type='email' name="email" id='form1Example2' label='Email address *' onChange={handleChange} />
                                            {validationErrors.email && <p className="text-danger">{validationErrors.email}</p>}
                                            <MDBInput className='mt-4' name="password" type='password' id='form1Example3' label='Password *' onChange={handleChange} />
                                            {validationErrors.password && <p className="text-danger">{validationErrors.password}</p>}
                                            <MDBInput className='mt-4' name="phone" type='text' id='form4Example4' label='phone *' onChange={handleChange} />
                                            {validationErrors.phone && <p className="text-danger">{validationErrors.phone}</p>}

                                            <div className="d-flex justify-content-center align-items-center mt-4">

                                                <MDBBtn type='submit' className="mx-1 bg-success bg-gradient text-white">
                                                    Add Register
                                                </MDBBtn>
                                            </div>
                                        </MDBCardBody>
                                    </MDBCol>
                                </MDBRow>

                            </MDBCard>
                        </MDBCol>
                    </MDBRow>
                </MDBContainer>
            </form>
        </>
    )
}
export default Register;