import {call,put,takeLatest} from 'redux-saga/effects';
import {SEARCH,searchSuccess,searchError} from '../action/searchBookAction';
import {FETCHBOOKDETAILSAPI} from '../../constant';
import apiGetService  from '../../service/getServiceApi';
import { getBookDetailsSuccess } from '../action/bookDetailAction';

function* searchBook(data: any): Generator<any, void, any> {   
  try {
      const response:any = yield call(apiGetService, FETCHBOOKDETAILSAPI);
      console.log(response);
     // yield put(searchSuccess(response.data));
      yield put(getBookDetailsSuccess(response.data));
  } catch (error:any) {
       yield put(searchError(error.message));
  }
}  

function*  searchBookSaga(){
    yield takeLatest(SEARCH,searchBook)
}
export default searchBookSaga;