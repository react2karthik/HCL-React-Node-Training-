import assert from "assert";
import { expect } from "chai";
import sinon, { SinonSpy, SinonStub } from 'sinon';
import { describe } from "mocha";
import axios from "axios";
import app from '../src/index';
import { response } from "express";
import nock from "nock";
let postLoginToken: any = {};
let URL = 'http://localhost:5000/';
describe('fetch api login data', () => {
    it('poste call api nock', async () => {
        let mockLoginData = {
            email: "sridhar@gmail.com",
            password: "sridhar"
        }
        postLoginToken = await axios.post(`${URL}users/login`, mockLoginData);
        console.log('postLoginToken', postLoginToken);
        assert.equal(postLoginToken.status, 200)
    });
    it('Authorisation key not passed', async () => {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': postLoginToken.data.data
        }
        const respData = {
           name:"joe",
           email:"joe@gemail.com",
           password:"joe",
           qualification:"M.E",
           dob:"2020-10-10",
           occupation:"CA",
           gender:"Femal"  ,
           phone:8978768547
        }
        nock(URL).get('/profiles').reply(200, respData,headers);
    })
})