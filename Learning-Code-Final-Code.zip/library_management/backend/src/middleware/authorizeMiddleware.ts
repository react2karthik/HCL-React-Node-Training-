import { Response, NextFunction } from "express";
 
function authorizeMiddleware(role: string) {
    return (req: any, res: Response, next: NextFunction) => {
        console.log(req);
        console.log("my id", req.userId, "role", role, "req role", req.role)
        if (req.role === role) {
            next();
        } else {
            res.status(403).send('Forbidden');
        }
    };
}
 
export default authorizeMiddleware;