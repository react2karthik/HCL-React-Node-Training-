import express, { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import axios from "axios";
import { usersModal } from '..//usersModal';
import constances from '../config/constant';
import { usersValidater ,usersloginValidater} from '../validater/usersValidater';
import authMiddleware from '../middleware/authMiddleware';
import authorizeMiddleware from '../middleware/authorizeMiddleware';
import { UnAuthorizedAccess } from '../error/uAutherizedUser';
import validateMiddleware from '../middleware/validateMiddleware';
import { login, searchBooks,createUser, addNewBooks ,userAddNewBooks,getAllBook} from '../service/usersService';
import logger from '../config/logger';
import {bookInventoryModal} from '../modal/bookInventoryModal';
dotenv.config();

const userRouter: express.Router = express.Router();

/**
 * user router
 * Define route handler for POST request to '/register' endpoint and validate usersValidater(), validateMiddleware
 * Extract path from request
 * Extract necessary user details from request body
 * Create user using provided details createUser
 * Log success message logger
 */
userRouter.post('/register', usersValidater(), validateMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path; 
    const { name, email, password, phone } = req.body;
    try {
        const hassedPassword = await bcrypt.hash(password, 10);
        const userDetails : usersModal = { name, email, hassedPassword, phone }
        const result = await createUser(userDetails);
        logger(path).info(constances.USER_REGISTERED_SUCCESS_MESSAGE);
        res.json({
            result,
            message: constances.USER_REGISTERED_SUCCESS_MESSAGE,
            statusCode: constances.USER_REGISTERED_SUCCESS_CODE,
            statue: constances.SUCCESS_STATUS
        });
 
    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});
/**
 * user router
 * Define route handler for POST request to '/login' endpoint
 *  Extract email and password from request body
 * Attempt to retrieve user information based on provided email
 * Check if user with provided email exists
 * If user exists, check if provided password matches the stored hashed password
 * If passwords match, generate JWT token for authentication
 */
userRouter.post('/login',usersloginValidater(), async (req: Request, res: Response, next: NextFunction) => { 
    const { email, password } = req.body;
    const result = await login(email);    
    const path: any = req.path; 
    if (result.first() != null) { 
        const { id, role } = result.first();
        const isMatching = await bcrypt.compare(password, result.first().get('password')); 
        if (isMatching) {
            const token = jwt.sign({email, userId: id, role }, process.env.SECRET_KEY || '', { expiresIn: '2h' });
            logger(path).info("success");
            // try {
            //     const url = 'https://prod-22.centralindia.logic.azure.com:443/workflows/067405cbeb4247ee8f7f271951d6a684/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=JMcI-3xRVFLRhOnmXgYlrnRRw9Lzql8oDzkcAOEGMus';
            //     const inputData = {
            //         from:'sridharbe4ui@gmail.com',
            //         to: 'sridhar_r@hcl.com',
            //     };
                
            //     const response = await axios.post(url, inputData);
                
            //     const isValid = response.data.isValid;
            //     const token = isValid;
            //     res.json({
            //         status: 'success',
            //         data: token
            //     })
            // } catch (error) {
            //     console.error('Error validating OTP:', error);
            //     throw error; 
            // }
            res.json({
                status: 'success',
                token
            })
        } else {
            try {
                throw new UnAuthorizedAccess(constances.ACCESS_DENIED_MESSAGE, constances.ACCESS_DENIED_CODE);
            } catch (error) {
               logger(path).error(error);
                next(error);
            }
        }
    } else {
        logger(path).info(constances.FAIL_STATUS);
        res.json({
            message: constances.USER_LOGIN_FAIL_MESSAGE,
            statusCode: constances.USER_LOGIN_FAIL_CODE,
            statue: constances.FAIL_STATUS,
            data: email
        })
    }
});
/**
 * Define route handler for POST request to '/:admin/inventory/book' endpoint
 * Extract userID and intrestedID from request parameters
 * Show interest between userID and intrestedID
 */

userRouter.post('/:admin/inventory/book', authMiddleware,authorizeMiddleware('admin'), async (req: Request, res: Response, next: NextFunction) => {  
    const path: any = req.path;
    const {admin } = req.params;
    const {author,book_id,book_name,category_name,quantity} :bookInventoryModal= req.body;
      const bookDetails :bookInventoryModal = {author,book_id,book_name,category_name,quantity};
    try { 
        await addNewBooks(bookDetails)
        logger(path).info(constances.USER_FECTHED_INTRESTES_MESSAGE);
        res.json({
            //result,
            message: constances.USER_FECTHED_INTRESTES_MESSAGE,
            statusCode: constances.USER_FECTHED_INTRESTES_CODE,
            statue: constances.SUCCESS_STATUS
        }); 
    } catch (error) {
       logger(path).error(error);
        next(error);
    }
});
// --------------------------
userRouter.get('/search-book/:searchby/:searchtxt', async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    const { searchtxt, searchby} = req.params;
    try {
 
        const result: any = await searchBooks(searchby, searchtxt);
       
        logger(path).info(constances.USER_FECTHED_INTRESTES_MESSAGE);
        if(result.rows) {
            res.json({
                data: result.rows,
                message: constances.USER_FECTHED_INTRESTES_MESSAGE,
                statusCode: constances.USER_FECTHED_INTRESTES_MESSAGE,
                statue: constances.SUCCESS_STATUS
            });
        } else {
            res.json({
                message: constances.USER_FECTHED_INTRESTES_MESSAGE,
                statusCode: constances.USER_FECTHED_INTRESTES_MESSAGE,
                statue: constances.FAIL_STATUS
            });
        }
    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});
userRouter.get('/getAllbook', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path;
    try {
        const data = await getAllBook();
        logger(path).info(constances.USER_FECTHED_INTRESTES_MESSAGE);
        res.json({
            data,
            statusCode: constances.USER_FECTHED_INTRESTES_MESSAGE,
            message: constances.USER_FECTHED_INTRESTES_CODE,
            status: constances.SUCCESS_STATUS
        })
    } catch (err) {
        next(err)
    }
});
// ------------------------------------
/***
 * 
 */
userRouter.post('/:user_id/book/:book_id', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {  
     const path: any = req.path;
     const {user_id,book_id } = req.params;
     const {book_return_by} = req.body;
     try { 
        await userAddNewBooks(user_id,book_id,book_return_by)
         logger(path).info(constances.USER_FECTHED_INTRESTES_MESSAGE);
         res.json({
             //result,
             message: constances.USER_FECTHED_INTRESTES_MESSAGE,
             statusCode: constances.USER_FECTHED_INTRESTES_CODE,
             statue: constances.SUCCESS_STATUS
         }); 
     } catch (error) {
        logger(path).error(error);
         next(error);
     }
 });



export default userRouter;