import client from '../config/dbConfig';
import { usersModal } from '../modal/usersModal';
import {bookInventoryModal} from '../modal/bookInventoryModal';
import { NoDataFoundError } from '../error/noDataError';
/**
 * Retrieves user information based on the provided email address.
 * @param email 
 * @returns 
 */
const login = async (email: string) => {
    const query = `select email, password, id, role from users_details where email='${email}' ALLOW FILTERING`;
    const result = await client.execute(query);
    return result;
}
/**
 * Creates a new user and inserts their details into the database.
 * @param User 
 * @returns 
 */

const createUser = async (User: usersModal) => {
    //const currentAge = await getUserAge(User.dob);
    const userID = await getNextUserId('users_details');
    const query = `insert into users_details(id,name,user_id,email, password,phone,role,registed_on) values(uuid(),
    '${User.name}',${userID},'${User.email}', '${User.hassedPassword}',${User.phone}, 'user',toTimeStamp(now()))`;
    const result = await client.execute(query);
    return result
}
/**
 * 
 * @returns 
 */
const getNextUserId = async (tableName:string) => {
    const query = `select count(id) as count from ${tableName}`;
    const result = await client.execute(query);
    return result.first().get('count')
}
/**
 * 
 * @param bookDetails 
 * @returns 
 */
const addNewBooks =  async(bookDetails:bookInventoryModal) =>{
    const nextId =  await getNextUserId('book_inventory');
    const query = `insert into book_inventory (id,book_id,author,book_name,category_name,quantity) 
    values(uuid(),${nextId},'${bookDetails.author}','${bookDetails.book_name}','${bookDetails.category_name}',${bookDetails.quantity})`
    const result = await client.execute(query);
    return result;
}
/**
 * 
 * @param bookDetails 
 * @returns 
 *///userID:string,bookId:string,returnBy:string//borrow:borrowedBookModal
const userAddNewBooks =  async(userId:string,bookId:string,returnBy:string) =>{
    const todayDate = new Date();
    const date =  new Date();
    const dueDate= new Date(date.setDate(date.getDate())+ 14);
    const formateTodate = todayDate.toISOString().split('T')[0];
    const formateDueDate = dueDate.toISOString().split('T')[0];
    const query = `insert into borrowed_book (id,user_id,book_id,borrowed_date,due_date,otp,penalty_amount,book_returned_by,status) 
    values(uuid(),${userId},${bookId},'${formateTodate}','${formateDueDate}',1454546,200,'${returnBy}','success')`
    const result = await client.execute(query);
    return result;
}


const searchBooks = async (searchBy: string, searchTxt: string) => {
    try {
        const query = `select * from book_inventory where ${searchBy}='${searchTxt}' ALLOW FILTERING`;
        const searchBookResult = await client.execute(query);
 
        if (searchBookResult.rowLength == 0) {
            throw new NoDataFoundError('No Books found for search crriteria', 10000);
        } else {
            // const generatedData = await generateData(result);
            return searchBookResult;
        }
    } catch (error) {
        console.error("Error found while search book:", error);
        return error;
    }
}
const getAllBook = async () => {
    const result = await client.execute('select author,book_id,book_name,category_name,quantity from  book_inventory');
    if (result.rowLength === 0) {
        throw new NoDataFoundError("No booknot found", 3000);
    } else
        return result.rows;
};
export { addNewBooks,userAddNewBooks,getNextUserId, login, createUser,searchBooks,getAllBook};