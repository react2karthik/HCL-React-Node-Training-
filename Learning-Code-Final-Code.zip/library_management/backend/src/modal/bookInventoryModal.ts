export interface bookInventoryModal {
    book_id:string,
    book_name:string,
    category_name:string,
    author:string,
    quantity:number
}