export interface fineRuleModal {
    number_of_days:string,
    charges:number,
    type :string
}