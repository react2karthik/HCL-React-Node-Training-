/**
 * Interface added for user deatils
 */
export interface usersModal {
    //id: string,
    email: string,
    hassedPassword:string,
    name: string,  
    phone: number,
    //password: string,
    //role:string,  
}  
export interface IUser {
    //id: string,
    dob: string,
    gender: string,
    name: string,
    //role: string,
    email: string,
    phone: number,
    // password: string,
    occupation: string,
    qualification: string,
    hassedPassword: string,
}
 
export interface IData {
    name: string,
    interest_showed_on: string,
    status: string,
    comment: string,
    age: string
}   
//id,dob,email,hassedPassword,name,occupation,phone,password,role,sex,qualification
//create table user(id uuid primary key, age int,name text, dob date, gender text,qualification text, phone bigint, email text, password text, occupation text, role text);