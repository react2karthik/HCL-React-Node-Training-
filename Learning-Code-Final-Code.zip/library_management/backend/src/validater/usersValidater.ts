import { body } from "express-validator";
/**
 * users details for users validater(email,name,password,phone,qualification,dob,occupation,role,sex,age)
 * @returns 
 */
const usersValidater = () => {
    return [
        body('email').exists().trim().withMessage('email is required'),
        body('name').exists().withMessage('name is required'),
        body('password').exists().trim().withMessage('password is required'),
        body('phone').exists().trim().withMessage('phone number is required'),
    ]
}

/**
 * login for users validater(email,password)
 * @returns 
 */
const usersloginValidater = () => {
    return [
        body('email').exists().trim().withMessage('email id is required'),
        body('password').exists().trim().withMessage('password is required'),
    ]
}
export { usersloginValidater, usersValidater };