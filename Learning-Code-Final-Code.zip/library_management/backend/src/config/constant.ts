const constants = {
  ACCESS_DENIED_MESSAGE: 'Access denied',
  ACCESS_DENIED_CODE: 4000,
  SUCCESS_STATUS: 'Success',
  FAIL_STATUS: 'Failed',

  /*-------- Profiler Start -----*/
  PROFILE_FECTHED_SUCCESS_CODE:8002,
  PROFILE_FECTHED_SUCCESS_MESSAGE:'Fetched all profile successfuly',

  PROFILE_FECTHED_ONLYUSERID_SUCCESS_MESSAGE:'Profile  fetched only user id successfuly',
  PROFILE_FECTHED_ONLYUSERID_SUCCESS_CODE:8003,
  /*--------Profielr End-----------*/
  /*-------User Start-------*/
  USER_FECTHED_SUCCESS_CODE: 8003,
  USER_FECTHED_SUCCESS_MESSAGE: 'User fetched all successfuly',
  
  USER_LOGIN_FAIL_MESSAGE:'User login failed',
  USER_LOGIN_FAIL_CODE:8004,

  USER_FECTHED_INTRESTES_MESSAGE:'User intreste list',
  USER_FECTHED_INTRESTES_CODE:8005,
  
  USER_FECTHED_INTERESTEDIN_MESSAGE:'User intrestedin fetched',
  USER_FECTHED_INTERESTEDIN_CODE:8006,

  USER_FECTHED_INTERESTEDBY_SUCCESS_MESSAGE:'User intrestedby fetched',
  USER_FECTHED_INTERESTEDBY_SUCCESS_CODE:8007,

  USER_FECTHED_COMMENTS_SUCCESS_MESSAGE:'Comments added successfuly',
  USER_FECTHED_COMMENTS_SUCCESS_CODE:8008,

  /*-------USer end ----*/
  
  //Register API
  USER_REGISTERED_SUCCESS_MESSAGE: 'User Registered Successfuly',
  USER_REGISTERED_SUCCESS_CODE: 7034,

  USER_NOT_EXIST_MESSAGE: "User not exist",
  USER_NOT_EXIT_CODE: 1032
}
export default constants;
