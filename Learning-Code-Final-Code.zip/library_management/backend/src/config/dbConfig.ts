import { Client } from 'cassandra-driver';
/**
 * Dp Client
 * DB name keyspace
 * connect 
 * shutdown
 */
const client = new Client({
   contactPoints: [process.env.HOSTNAME || "127.0.0.1"],
   localDataCenter: process.env.DATACENTER || "datacenter1",
   keyspace: process.env.KEYSPACE || "library_management"
})

client.connect(() => {
   console.log("db connected")
});
client.shutdown(() => {
   console.log("db shoutdown")
})
export default client;