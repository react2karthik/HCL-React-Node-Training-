import express from 'express';
import dotenv from 'dotenv';
import usersRouter from './../src/routers/usersRouter';
import errorMiddleware from './../src/middleware/errorMiddleware';
import cors from 'cors';
const app: express.Application = express();
app.use(express.json());
dotenv.config();
const port = process.env.PORT || 5001;
app.use(cors());
app.use('/users', usersRouter);

app.use(errorMiddleware);
app.listen(port, () => {
    console.log(`library management app listening on port ${port}`);
})
export default app;