import React, { useState, useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage, useFormik } from 'Formik';
import * as Yup from 'yup';
import { MDBContainer, MDBRow, MDBCol, MDBCard, MDBCardBody, MDBInput, MDBBtn } from 'mdb-react-ui-kit';
import { registerRequest } from '../../redux/action/registerActions';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import AlertComponent from '../form/alertFiled';
import axios from 'axios';
import callApi from '../../service/serviceApiDoc';
const imgRegister= require('../../image/register.jpg').default;
const Register: React.FC = () => {
    const initialValues = {
        name: '',
        email: '',
        password: ''
    };
    const history = useHistory();
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertType, setAlertType] = useState('danger')
    const initialValidation = Yup.object({
        name: Yup.string().required('Name is required'),
        email: Yup.string().required('Email is required').email(),
        password: Yup.string().required('Password is required').min(6, 'Password must be at least 6 characters').max(40, 'Password must not exceed 40 characters'),
        
    });
    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false);
        }, 1500);
        return () => clearTimeout(timer);
    }, [showAlert]);
    const dispatch = useDispatch();
    const registerInfo = useSelector((state: any) => state?.registerReducer?.data);
    const handleRegister = async (values: any) => {
        //dispatch(registerRequest(values));
        try {
            //const response = await callApi('http://localhost:3001/userRegistration', values, 'get');
            const response = await callApi('http://localhost:3001/userRegistration', {email:values.email}, 'get');
            if (response.length) {
                setShowAlert(true);
                setAlertType('danger');
                setAlertMessage('Email is already registered');
            } else {
                dispatch(registerRequest(values));
            }
        } catch (error) {
            console.error('Error checking email:', error);
            setShowAlert(true);
            setAlertType('danger');
            setAlertMessage('Failed to check email');
        }
    };
    useEffect(() => {
        if (registerInfo?.id) {
            setShowAlert(true)
            setAlertType('success');
            setAlertMessage("'Registration ,Redirect 10 login page");
            setTimeout(() => {
                history.push('/login');
            }, 3000);
        } else if(registerInfo?.id === 0) {
            setShowAlert(true);
            setAlertType('danger');
            setAlertMessage("Registration failed");
        }
    }, [registerInfo])
    return (
        <Formik initialValues={initialValues} validationSchema={initialValidation} onSubmit={handleRegister}>
            {({ values, handleChange }) => (
                <Form>
                    <MDBContainer fluid className=''>
                        <MDBRow className='g-0 align-items-center'>
                            <MDBCol col='6'>
                                <img src={imgRegister} className="w-100 rounded-4 shadow-4" alt="" />
                            </MDBCol>
                            <MDBCol col='6'>
                                <MDBCard className='cascading-right' style={{ background: 'hsla(0, 0%, 100%, 0.55)', backdropFilter: 'blur(30px)' }}>
                                    {showAlert && (
                                        <AlertComponent type={alertType} message={alertMessage} />
                                    )}
                                    <MDBCardBody className='p-1 shadow-5 text-center'>
                                        <MDBCol md="8" offsetMd="2" className='register_label'>
                                            <label htmlFor="name">Name *</label>
                                            <Field className='mb-4 w-100' label='Name' id='name' type='text' name='name' />
                                            <ErrorMessage name="name" component="div" className="text-danger" />
                                            <label htmlFor="email">Email *</label>
                                            <Field className='mb-4 w-100' label='Email' id='email' type='email' name='email' />
                                            <ErrorMessage name="email" component="div" className="text-danger" />
                                            <label htmlFor="Password">Password *</label>
                                            <Field className='mb-4 w-100' label='Password' id='password' type='password' name='password' />
                                            <ErrorMessage name="password" component="div" className="text-danger" />
                                            
                                            <MDBBtn className='mt-4 bg-success bg-gradient text-white' size="lg" type="submit">Register</MDBBtn>
                                        </MDBCol>
                                    </MDBCardBody>
                                </MDBCard>
                            </MDBCol>

                        </MDBRow>
                    </MDBContainer>
                </Form>
            )}
        </Formik>
    );
}

export default Register;

