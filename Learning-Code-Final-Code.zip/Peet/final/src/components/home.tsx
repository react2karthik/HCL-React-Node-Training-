import React, { useEffect, useState } from "react";
const imgHome= require('../image/homeimg.jfif').default;
const Home: React.FC = () => {
    return(
        <>            
            <img src={imgHome} alt='Logo'   className="w-100 h-20 d-inline-block align-top me-2" />
        </>
    )
} 

export default Home;