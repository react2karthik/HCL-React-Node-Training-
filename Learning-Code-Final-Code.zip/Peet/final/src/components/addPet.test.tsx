import React from "react";
import { Provider } from "react-redux";
import { shallow, mount, render, ReactWrapper } from 'enzyme';
import AddPet from './addPet';
import configureStore from 'redux-mock-store';
import { appointmentRequest, appointmentSuccess, appointmentFailure } from '../redux/action/addPeetAction';
const mockStore: any = configureStore([]);

describe('add Peet component', () => {
    let store: ReturnType<typeof mockStore>;
    let wrapper: ReactWrapper;
    beforeEach(() => {
        store = mockStore({
            auth: {
                userData: null,
            }
        });
        wrapper = mount(
            <Provider store={store}>
                <AddPet />
            </Provider>
        )
        console.log(wrapper.html());
    })
    it('test add peet from check Field', () => {
        expect(wrapper).toMatchSnapshot();
        expect(wrapper.find('Field')).toHaveLength(4);
      })
})