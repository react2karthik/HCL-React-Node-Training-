import React, { useEffect, useState } from 'react';
import {
  MDBNavbar,
  MDBContainer,
  MDBIcon,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarLink,
  MDBNavbarToggler,
  MDBNavbarBrand,
  MDBCollapse
} from 'mdb-react-ui-kit';
import axios from 'axios';

import { useSelector } from 'react-redux';
import { Link,useHistory } from 'react-router-dom';
interface NavbarProps {
  isLoggedIn?: boolean;
  onClick:any
}
const Navbar: React.FC<NavbarProps> = ({ isLoggedIn,onClick }) => {
  const [openNavColor, setOpenNavColor] = useState(false);
  const [openNavColorSecond, setOpenNavColorSecond] = useState(false);
  const [openNavColorThird, setOpenNavColorThird] = useState(false);
  const [isLogin, setIsLogin] = useState(false);
  const cart = useSelector((state: any) => state?.addCartReducer?.data);
  const [cartCount, setCartCount] = useState(0);
  useEffect(() => {
    axios.get('http://localhost:3001/cart')
      .then(response => {
        setCartCount(response.data.length);
      })
      .catch(error => {
        console.error('Error fetching pet data:', error);
      });
  }, [cart]);
  
  return (

    <>
      <div className='navBar'>
        <MDBNavbar expand='lg'>
          {/* <MDBContainer fluid> */}
          <MDBNavbarNav className='me-auto mb-2 mb-lg-0 flex-row'>
            {!isLoggedIn && (
              <>
                <MDBNavbarItem className='active'>
                  <Link aria-current='page' to='/'>
                    <MDBIcon fas icon="book" /><span className="navTex px-2">Home</span>
                  </Link>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <Link to='/login'>
                    <MDBIcon fas icon="grip-horizontal" /><span className="navTex px-2">Login</span>
                  </Link>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <Link  to='/register'>
                    <MDBIcon fas icon="plus" /><span className="navTex px-2">Register</span>
                  </Link >
                </MDBNavbarItem>
              </>
            )}
            {isLoggedIn && (
              <>
                <MDBNavbarItem>
                  <Link to='/listallPeet'>
                    <MDBIcon fas icon="plus" /><span className="navTex px-2">List all Peet</span>
                  </Link>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <Link to='/addpeet'>
                    <MDBIcon fas icon="plus" /><span className="navTex px-2">Add Peet</span>
                  </Link>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <Link to='/cartBuy'>
                    <MDBIcon fas icon="plus" /><span className="navTex px-2">Cart</span>
                  </Link>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <Link to='#' onClick={onClick}>
                    <MDBIcon fas icon="plus" /><span className="navTex px-2">LogOut</span>
                  </Link>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <MDBNavbarLink>
                    <MDBIcon fas icon="shopping-cart" value={cartCount} className='badge1' />
                  </MDBNavbarLink>
                </MDBNavbarItem>
              </>
            )}
          </MDBNavbarNav>

          {/* </MDBContainer> */}
        </MDBNavbar>
      </div>
    </>
  );
}
export default Navbar;