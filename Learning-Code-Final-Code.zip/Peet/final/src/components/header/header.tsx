import React,{useState,useEffect} from 'react';
import {
  MDBNavbar,
  MDBBtn,
  MDBContainer,MDBNavbarBrand
} from 'mdb-react-ui-kit';
import { Link,useHistory } from 'react-router-dom';
import Navbar from './navbar';
import { useDispatch, useSelector } from 'react-redux';
// import logo from '../../assets/logo.png'; // Import your logo file
// const logo = require('../../assets/logo.png')
const imgLogo = require('../../image/logo.avif').default;
const Header: React.FC = (setPassIsLoggedIn:any ) => {
  const [isLoggedIn,setIsLoggedIn] = useState(false);
  const loginInfo = useSelector((state: any) => state?.loginReducer?.data);
  useEffect(()=>{
    if (loginInfo?.length > 0) {  
      setIsLoggedIn(true);
    }
  },[loginInfo])
  const history = useHistory();
  const handleLogOut = () => {
    history.push('/');
    setIsLoggedIn(false);
  }
  return (
    <MDBNavbar light bgColor='light'>
      <MDBContainer tag="form" fluid >
         <MDBNavbarBrand>
          <img src={imgLogo} alt='Logo' height='60' className='d-inline-block align-top me-2' />         
        </MDBNavbarBrand>        
        <Navbar isLoggedIn={isLoggedIn} onClick={handleLogOut}/>
      </MDBContainer>
    </MDBNavbar>
  );
}
export default Header;