// import React, { useState, useEffect } from 'react';
// import { Formik, Form, Field, ErrorMessage, useFormik } from 'Formik';
// import * as Yup from 'yup';
// import { MDBContainer, MDBRow, MDBCol, MDBCard, MDBCardBody, MDBInput, MDBBtn } from 'mdb-react-ui-kit';
// import { appointmentRequest } from '../../src/redux/action/appointmentAction';
// import { useHistory } from 'react-router-dom';
// import axios from 'axios';
// import { useDispatch, useSelector } from 'react-redux';
// import AlertComponent from '../../src/components/form/alertFiled';
// const imgAdd = require('../image/post.jpg').default;
// const AddPet: React.FC = () => {
//     const initialValues = {
//         petname: '',
//         price: '',
//         image: '',
//         quantity: ''
//     };
//     const history = useHistory();
//     const initialValidation = Yup.object({
//         petname: Yup.string().required('pet name  is required'),
//         price: Yup.string().required('Price is required'),
//         image: Yup.string().required('Image is required'),
//         quantity: Yup.string().required('quantity is required'),
//     });
//     const dispatch = useDispatch();
//     const appointmentInfo = useSelector((state: any) => state.appointmentReducer.data);
//     console.log('appointmentInfo', appointmentInfo)
//     const handleSubmit = async (values: any) => {
//         alert(JSON.stringify(values, null, 2));
//         //dispatch(appointmentRequest(values));
//         //history.push('/appointmentforminfo');
//     };
//     return (
//         <Formik initialValues={initialValues} validationSchema={initialValidation} onSubmit={handleSubmit}>
//             {({ values, handleChange }) => (
//                 <Form>
//                     <MDBContainer fluid className=''>
//                         <MDBRow className='g-0 align-items-center'>
//                             <MDBCol col='6'>
//                                 <img src={imgAdd} className="w-100 rounded-4 shadow-4" alt="" />
//                             </MDBCol>
//                             <MDBCol col='6'>
//                                 <MDBCard className='cascading-right' style={{ background: 'hsla(0, 0%, 100%, 0.55)', backdropFilter: 'blur(30px)' }}>
//                                     <MDBCardBody className='p-1 shadow-5 text-center'>
//                                         <MDBCol md="8" offsetMd="2" className='register_label'>
//                                             <label htmlFor="petname">Pet Name *</label>
//                                             <Field className='mb-4 w-100' label='PetName' id='PetName' type='text' name='petname' />
//                                             <ErrorMessage name="petname" component="div" className="text-danger" />
//                                             <label htmlFor="quantity" className=' mt-2'>Quantity *</label>
//                                             <Field className='mb-4 w-100' type="text" id="quantity" name="quantity" />
//                                             <ErrorMessage name="quantity" component="div" className="text-danger" />
//                                             <label htmlFor="price" className=' mt-2'>Price *</label>
//                                             <Field className='mb-4 w-100' type="text" id="price" name="price" />
//                                             <ErrorMessage name="price" component="div" className="text-danger" />

//                                             {/* <Field
//                                                 name='image'
//                                                 type='file'
//                                                 onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
//                                                     if (event.currentTarget.files) {
//                                                         setFieldValue('image', event.currentTarget.files[0]); // Set image data
//                                                     }
//                                                 }}
//                                             /> */}
//                                             <MDBBtn className='mt-4 bg-success bg-gradient text-white' size="lg" type="submit">Add</MDBBtn>
//                                         </MDBCol>
//                                     </MDBCardBody>
//                                 </MDBCard>
//                             </MDBCol>
//                         </MDBRow>
//                     </MDBContainer>
//                 </Form>
//             )}
//         </Formik>
//     );
// }

// export default AddPet;
import React, { useState, useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage, useFormik } from 'Formik';
import * as Yup from 'yup';
import { MDBContainer, MDBRow, MDBCol, MDBCard, MDBCardBody, MDBInput, MDBBtn, MDBFile } from 'mdb-react-ui-kit';
import { appointmentRequest } from '../redux/action/addPeetAction';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import AlertComponent from '../components/form/alertFiled';
import axios from 'axios';
const imgAdd = require('../image/post.jpg').default;
const AddPet: React.FC = () => {
    const initialValues = {
        petName: '',
        price: '',
        quantity: '',
        image: '',
    };
    const history = useHistory();
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertType, setAlertType] = useState('danger')
    const initialValidation = Yup.object({
        petName: Yup.string().required('Pet Name is required'),
        price: Yup.string().required('Price is required'),
        quantity: Yup.string().required('Quantity is required').min(1, 'quantity must be at least 6 characters').max(40, 'quantity must not exceed 40 characters'),
        image: Yup.string().required('Image is required'),
    });
    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false);
        }, 1500);

        return () => clearTimeout(timer);
    }, [showAlert]);
    const dispatch = useDispatch();
    const peetInfo = useSelector((state: any) => state.appointmentReducer?.data);
    const handleRegister = async (values: any) => {
        alert(JSON.stringify(values, null, 2));
        dispatch(appointmentRequest(values))
        // formData.append('image', values.image as File);
        // dispatch(appointmentRequest(formData));
        // formData.append('image', values.image);
        // console.log('0000', values.image);
        // const imageType = values.image.type;
        // console.log('Image type:', imageType);
        // const imageType = `image/${values.image.name}`;
        // console.log('qqqqq,imageTypeq', imageType)
        // dispatch(appointmentRequest(imageType));
    };
    useEffect(() => {
        if (peetInfo?.id) {
            setShowAlert(true)
            setAlertType('success');
            setAlertMessage("'Added peet");
            setTimeout(() => {
                history.push('/listallPeet');
            }, 3000);
        } else if(peetInfo?.id === 0) {
            setShowAlert(true);
            setAlertType('danger');
            setAlertMessage("Added failed");
        }
    }, [peetInfo])
    const handleListPeet = (e: any) => {
        e.preventdefault;
        history.push('/listallPeet')
    }
    return (
        <Formik initialValues={initialValues} validationSchema={initialValidation} onSubmit={handleRegister}>
            {({ values, handleChange, setFieldValue }) => (
                <Form>
                    <MDBContainer fluid className=''>
                        <MDBRow className='g-0 align-items-center'>
                            <MDBCol col='6'>
                                <img src={imgAdd} className="w-100 rounded-4 shadow-4" alt="" />
                            </MDBCol>
                            <MDBCol col='6'>
                                <MDBCard className='cascading-right' style={{ background: 'hsla(0, 0%, 100%, 0.55)', backdropFilter: 'blur(30px)' }}>
                                    {showAlert && (
                                        <AlertComponent type={alertType} message={alertMessage} />
                                    )}
                                    <MDBCardBody className='p-1 shadow-5 text-center'>
                                        <MDBCol md="8" offsetMd="2" className='register_label'>
                                            <label htmlFor="petName">Pet Name *</label>
                                            <Field className='mb-4 w-100' label='Pet Name' id='petName' type='text' name='petName' />
                                            <ErrorMessage name="petName" component="div" className="text-danger" />
                                            <label htmlFor="price">Price *</label>
                                            <Field className='mb-4 w-100' label='price' id='price' type='text' name='price' />
                                            <ErrorMessage name="price" component="div" className="text-danger" />
                                            <label htmlFor="quantity">Quantity *</label>
                                            <Field className='mb-4 w-100' label='quantity' id='quantity' type='text' name='quantity' />
                                            <ErrorMessage name="quantity" component="div" className="text-danger" />
                                            <label htmlFor="image" className='mt-2'>Image Url *</label>
                                            <Field type="text" className='mb-4 w-100' id="image" name="image" />
                                            <ErrorMessage name="image" component="div" className="text-danger" />
                                            {/* <label htmlFor="image">Image *</label> */}
                                            {/* <input
                                                className='mb-4 w-100' 
                                                type='file'
                                                //onChange={handleChange}
                                                onChange={(e) => {
                                                    setFieldValue('image', e.currentTarget.files?.[0]);
                                                }}
                                            /> */}
                                            {/* <MDBFile label='image'  type='file' id='image' multiple onChange={(e) => setFieldValue('image', e.currentTarget.files?.[0])}/> */}
                                            {/* <input
                                                className='mb-4 w-100'
                                                type='file'
                                                onChange={(e) => setFieldValue('image', e.currentTarget.files?.[0])}
                                            />
                                            <ErrorMessage name="image" component="div" className="text-danger" /> */}
                                            <MDBBtn className='mt-4 bg-success bg-gradient text-white' size="lg" type="submit">Add</MDBBtn>
                                            <MDBBtn className='mt-4 bg-gradient text-white mx-2' size="lg" onClick={handleListPeet}>List Peet</MDBBtn>
                                        </MDBCol>
                                    </MDBCardBody>
                                </MDBCard>
                            </MDBCol>

                        </MDBRow>
                    </MDBContainer>
                </Form>
            )}
        </Formik>
    );
}

export default AddPet;



