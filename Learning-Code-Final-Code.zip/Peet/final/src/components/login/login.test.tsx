import React from "react";
import { useDispatch, useSelector, Provider } from 'react-redux';
import { shallow, mount, render, ReactWrapper } from 'enzyme';
import Logi from "./login";
import store from "../../redux/store";
import { ContextApiProvider } from "../context/context";
import configureStore from 'redux-mock-store';
import { loginRequest, loginSuccess, loginFailed } from '../../redux/action/loginActions'
const mockStore: any = configureStore([]);
describe('LoginForm component', () => {
  let store: ReturnType<typeof mockStore>;
  let wrapper: ReactWrapper;
  beforeEach(() => {
    store = mockStore({
      auth: {
        userData: null,
      },
    });
    wrapper = mount(
      <Provider store={store}>
        <Logi />
      </Provider>
    )
    console.log(wrapper);
    //console.log(wrapper.html());
  })
  it('test login from check Field', () => {
    // expect(wrapper).toMatchSnapshot();
    expect(wrapper.find('Field')).toHaveLength(2);
  })
  it('test loginfrom check form', () => {
    expect(wrapper.find('form')).toHaveLength(1);
  });
  it('check update email input value on change', () => {
    const emailInput = wrapper.find('input[name="email"]');
    emailInput.simulate('change', { target: { name: 'email', value: 'test@example.com' } });
    expect(wrapper.find('input[name="email"]').prop('value')).toEqual('test@example.com');
  });
  it('check update password input value on change', () => {
    const passwordInput = wrapper.find('input[name="password"]');
    passwordInput.simulate('change', { target: { name: 'password', value: 'password123' } });
    expect(wrapper.find('input[name="password"]').prop('value')).toEqual('password123');
  });
  it('check dispatch login action working', () => {
    const email = 'test@example.com';
    const password = 'password123';
    const action = loginRequest({ email, password });
    expect(action).toEqual({
      type: 'LOGIN',
      payload: { email, password },
    });
  });
  it('should handle login failure', () => {
    const action = loginFailed('Invalid credentials');
    store.dispatch(action);
    const actions = store.getActions();
    expect(actions).toEqual([action]);
  });
  it('should handle login success', () => {
    const userData = { id: 1, name: 'Siva', email: 'siva@gmail.com' };
    const action = loginSuccess(userData);
    store.dispatch(action);
    const actions = store.getActions();
    expect(actions).toEqual([action]);
  });
});