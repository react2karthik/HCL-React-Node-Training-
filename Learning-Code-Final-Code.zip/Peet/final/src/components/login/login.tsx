import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCol, MDBRow, MDBInput, MDBCheckbox, MDBIcon } from 'mdb-react-ui-kit';
import { Formik, Field, Form, ErrorMessage } from 'Formik';
import * as Yup from 'yup';
import { useHistory } from 'react-router-dom';
import { useApiContext } from '../context/context';
import AlertComponent from '../form/alertFiled';
import { loginRequest } from '../../redux/action/loginActions';
const imgLogin = require('../../image/login.jpg').default;
const Logi: React.FC = () => {
    const initialValue = {
        email: '',
        password: ''
    }
    const { login } = useApiContext();
    const initialValidation = Yup.object({
        email: Yup.string().required('Email is required').email(),
        password: Yup.string().required('Password is required').min(6, 'Password must be at least 6 characters').max(40, 'Password must not exceed 40 characters')
    })
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertType, setAlertType] = useState('danger')
    const history = useHistory();
    const dispatch = useDispatch();
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const loginInfo = useSelector((state: any) => state?.loginReducer?.data);
    const handleLogin = async (values: any) => {
        dispatch(loginRequest(values));
        //login(); 
    }    
    useEffect(() => {
        if (loginInfo?.length > 0) {
            login();
            setShowAlert(true);
            setAlertMessage("Login successful,Redirecting to peet add page...");
            setAlertType('success');
            setTimeout(() => {
                history.push('/addpeet');
            }, 3000);
        } else if(loginInfo?.length === 0){
            setShowAlert(true);
            setAlertType('danger');
            setAlertMessage("Invalid email or password");
        }        
    }, [loginInfo])
    
    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false);
        }, 3000);
        return () => clearTimeout(timer);
    }, [showAlert]);
    const handleRegister = () => {
        history.push('/register');
    }
    
    return (
        <>
            <Formik initialValues={initialValue} validationSchema={initialValidation} onSubmit={handleLogin}>
                {({ values, handleChange }) => (
                    <Form>
                        <MDBContainer className='mt-2' fluid>
                            <MDBRow className='g-0'>

                                <MDBCol md='4' className='mx-auto'>
                                    <img src={imgLogin} alt="login img" />
                                    {/* <div className="p-5 bg-image" style={{ backgroundImage: `url(https://www.shift4shop.com/2015/images/industries/pet-supplies/pet-supplies.png)`, height: '100%', width: '100%' }}></div> */}
                                </MDBCol>
                                <MDBCol md='8' className='mx-auto'>
                                    {showAlert && (
                                        <AlertComponent type={alertType} message={alertMessage} />
                                    )}
                                    <MDBCard className='mx-2 mb-2 p-2 shadow-5' style={{ background: 'hsla(0, 0%, 100%, 0.8)', backdropFilter: 'blur(30px)' }}>

                                        <MDBCardBody className='text-black d-flex flex-column justify-content-center w-50 mx-auto'>

                                            <label htmlFor="email">Email *</label>
                                            <Field type="text" id="email" name="email" className='mb-4' />
                                            <ErrorMessage name="email" component="div" className="text-danger" />
                                            <label htmlFor="email">Password *</label>
                                            <Field type="text" id="password" name="password" className='mb-4' />
                                            <ErrorMessage name="password" component="div" className="text-danger" />

                                            <p className='d-flex justify-content-center align-item-center mt-2 text-primary'>If you are an existing patient, please sign in. Otherwise, please register</p>
                                            <div className="d-flex justify-content-center align-items-center mt-2">
                                                <MDBBtn type='submit' className="bg-success bg-gradient text-white">
                                                    Sign in
                                                </MDBBtn>
                                                <MDBBtn className="bg-gradient text-white mx-3" onClick={handleRegister}>
                                                    Register
                                                </MDBBtn>
                                            </div>
                                        </MDBCardBody>
                                    </MDBCard>
                                </MDBCol>
                            </MDBRow>
                        </MDBContainer>
                    </Form>
                )}
            </Formik>
        </>
    );
}

export default Logi;