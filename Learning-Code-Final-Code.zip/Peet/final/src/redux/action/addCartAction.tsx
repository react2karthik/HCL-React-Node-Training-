export const ADDCART_REQUEST = 'ADDCART_REQUEST';
export const ADDCART_SUCCESS = 'ADDCART_SUCCESS';
export const ADDCART_FAILURE = 'ADDCART_FAILURE';

export const addcartRequest = (payload: any) => ({
  type: ADDCART_REQUEST,
  payload,
});

export const addcartSuccess = (userData: any) => ({
  type: ADDCART_SUCCESS,
  payload: userData
});

export const addcartFailure = (error: string) => ({
  type: ADDCART_FAILURE,
  payload:error
});
