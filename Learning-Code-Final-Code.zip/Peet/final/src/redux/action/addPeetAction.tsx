export const APPOINTMENT_REQUEST = 'APPOINTMENT_REQUEST';
export const APPOINTMENT_SUCCESS = 'APPOINTMENT_SUCCESS';
export const APPOINTMENT_FAILURE = 'APPOINTMENT_FAILURE';

export const appointmentRequest = (payload: any) => ({
  type: APPOINTMENT_REQUEST,
  payload,
});

export const appointmentSuccess = (userData: any) => ({
  type: APPOINTMENT_SUCCESS,
  payload: userData
});

export const appointmentFailure = (error: string) => ({
  type: APPOINTMENT_FAILURE,
  payload:error
});
