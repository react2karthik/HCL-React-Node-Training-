import { APPOINTMENT_SUCCESS, APPOINTMENT_FAILURE } from '../action/addPeetAction';
export interface appointmentState {
  data: any;
}
const initialState: appointmentState = {
  data: null
}
const appointmentReducer = (state: appointmentState = initialState, action: any) => {
  switch (action.type) {
    case APPOINTMENT_SUCCESS:
      return {
        ...state,
        data: action.payload
      }
    case APPOINTMENT_FAILURE:
      return {
        ...state,
        data: null,
      }
    default:
      return state;
  }
};

export default appointmentReducer;
