import { ADDCART_SUCCESS, ADDCART_FAILURE } from '../action/addCartAction';
export interface addCartState {
  data: any;
}
const initialState: addCartState = {
  data: null
}
const addcartReducer = (state: addCartState = initialState, action: any) => {
  switch (action.type) {
    case ADDCART_SUCCESS:
      return {
        ...state,
        data: action.payload
      }
    case ADDCART_FAILURE:
      return {
        ...state,
        data: null,
      }
    default:
      return state;
  }
};

export default addcartReducer;
