import { combineReducers } from 'redux';
import registerReducer from './registerReducer';
import loginReducer from './loginReducer';
import appointmentReducer from './addPeetReducer';
import addcartReducer from './addCartReducer';
const rootReducer = combineReducers({
    registerReducer,
    loginReducer,
    appointmentReducer,
    addcartReducer
});

export default rootReducer;