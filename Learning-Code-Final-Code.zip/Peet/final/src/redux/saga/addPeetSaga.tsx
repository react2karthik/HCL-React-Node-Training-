import { call, put, takeLatest } from 'redux-saga/effects';
import { APPOINTMENT_REQUEST, appointmentSuccess, appointmentFailure } from '../action/addPeetAction';
import { PETSADD } from '../../constant';
import callApi from '../../service/serviceApiDoc';

function* appointment(data: any): Generator<any, void, any> {
    try {
        const response: any = yield call(callApi, PETSADD, data, 'post');        
        yield put(appointmentSuccess(response));
    } catch (error: any) {       
        yield put(appointmentFailure(error.message))        
    }
}
function* appointmentSaga() {
    yield takeLatest(APPOINTMENT_REQUEST, appointment)
}
export default appointmentSaga;
