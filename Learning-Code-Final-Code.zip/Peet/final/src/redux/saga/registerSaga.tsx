import { call, put, takeLatest } from 'redux-saga/effects';
import { REGISTER_REQUEST, registerSuccess, registerFailure } from '../action/registerActions';
import { REGISTERAPI } from '../../constant';
import callApi from '../../service/serviceApiDoc';

function* register(data: any): Generator<any, void, any> {
    try {
        const response: any = yield call(callApi, REGISTERAPI, data.payload, 'post');
        yield put(registerSuccess(response));
    } catch (error: any) {
        yield put(registerFailure(error.message))
    }
}
function* registerSaga() {
    yield takeLatest(REGISTER_REQUEST, register)
}
export default registerSaga;