import { call, put, takeLatest } from 'redux-saga/effects';
import { ADDCART_REQUEST, addcartSuccess, addcartFailure } from '../action/addCartAction';
import { ADDCART } from '../../constant';
import callApi from '../../service/serviceApiDoc';

function* addCart(data: any): Generator<any, void, any> {
    try {
        const response: any = yield call(callApi, ADDCART, data, 'post');        
        yield put(addcartSuccess(response));
    } catch (error: any) {       
        yield put(addcartFailure(error.message))        
    }
}
function* addCartSaga() {
    yield takeLatest(ADDCART_REQUEST, addCart)
}
export default addCartSaga;
