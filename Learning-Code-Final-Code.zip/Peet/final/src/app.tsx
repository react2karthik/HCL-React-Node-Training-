import React, { useState } from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
// import store from './store';
import Header from './components/header/header';
import Footer from './components/footer/footer';
import { ContextApiProvider, useApiContext } from './components/context/context';
import Register from './components/register/register';
import Logi from './components/login/login';
import Home from './components/home';
import ListAllPet from './components/listAllPet';
import AddPet from './components/addPet';
import BuyCartPet from './components/buyCartPet';
const App: React.FC = () => {
    const PrivateRoute: React.FC<{ path: string, component: React.FC }> = ({ path, component }) => {    
        const { isAuthenticated } = useApiContext();
        return isAuthenticated ? <Route path={path} component={component} /> :   <Redirect to="/" />;    
    };
    return (
        <>
            <ContextApiProvider>
                <Router>
                    <Header />
                    <Switch>
                        <Route path="/" exact component={Home} />
                        <Route path="/login" component={Logi} />
                        <Route path="/register" component={Register} />
                        <PrivateRoute path='/listallPeet' component={ListAllPet} />
                        <PrivateRoute path="/addpeet" component={AddPet} />
                        <PrivateRoute path="/cartBuy" component={BuyCartPet} />
                        {/* <Route path="/listallPeet" component={ListAllPet} />
                        <Route path="/addpeet" component={AddPet} />
                        <Route path="/cartBuy" component={BuyCartPet} /> */}
                    </Switch>
                </Router>
                <Footer />
            </ContextApiProvider>
        </>
    );
};

export default App;
