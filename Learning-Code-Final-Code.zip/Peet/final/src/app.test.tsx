import React from "react";
import { useDispatch, useSelector } from 'react-redux';
import { shallow, mount, render } from 'enzyme';
import App from "./app";
import Header from "./components/header/header";

test('test',()=>{
    const wrapper = mount(<App />);
    console.log(wrapper.debug());
    expect(wrapper).toMatchSnapshot();
   // expect(wrapper.find(<Header />)).to.have.length
})



// import { mount, shallow } from "enzyme";
// import {configure} from 'enzyme';
// import React from "react";
// import App from "./app";

// describe('checking the test', () => {
//     it("test",()=>{
//         const wrapper = shallow(<App />);
//         console.log('1111111111', wrapper);
//        // expect(wrapper).toM
//     })
    
// });

// import React from "react";
// import { shallow, mount, render } from 'enzyme';
// import App from "./app";

// test('test',()=>{
//     const xxx = mount(<App />);
//     console.log(xxx);
// })
//console.log(wrapper.debug());
// test("test sample",()=>{  
// const wrapper = mount(<App />);
// console.log(wrapper.debug());
// //expect(wrapper).toMatchSnapshot();
// });