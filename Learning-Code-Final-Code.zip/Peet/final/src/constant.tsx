export const LOGINAPI = 'http://localhost:3001/userRegistration'
export const REGISTERAPI = 'http://localhost:3001/userRegistration'
export const PETSADD = 'http://localhost:3001/petsDetails'
export const ADDCART = 'http://localhost:3001/cart'
