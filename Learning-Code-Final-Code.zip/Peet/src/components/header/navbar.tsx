import React, { useEffect, useState } from 'react';
import {
  MDBNavbar,
  MDBContainer,
  MDBIcon,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarLink,
  MDBNavbarToggler,
  MDBNavbarBrand,
  MDBCollapse
} from 'mdb-react-ui-kit';
import axios from 'axios';

import { useSelector } from 'react-redux';
interface NavbarProps {
  isLoggedIn?: boolean;
}
const Navbar: React.FC<NavbarProps> = ({ isLoggedIn }) => {
  const [openNavColor, setOpenNavColor] = useState(false);
  const [openNavColorSecond, setOpenNavColorSecond] = useState(false);
  const [openNavColorThird, setOpenNavColorThird] = useState(false);
  const [isLogin, setIsLogin] = useState(false);
  const cart = useSelector((state: any) => state?.addCartReducer?.data);
  const [cartCount, setCartCount] = useState(0);
  useEffect(() => {
    axios.get('http://localhost:3001/cart')
      .then(response => {
        setCartCount(response.data.length);
      })
      .catch(error => {
        console.error('Error fetching pet data:', error);
      });
  }, [cart]);
  return (

    <>
      <div className='navBar'>
        <MDBNavbar expand='lg'>
          {/* <MDBContainer fluid> */}
          <MDBNavbarNav className='me-auto mb-2 mb-lg-0 flex-row'>
            {!isLoggedIn && (
              <>
                <MDBNavbarItem className='active'>
                  <MDBNavbarLink aria-current='page' href='/'>
                    <MDBIcon fas icon="book" /><span className="navTex px-2">Home</span>
                  </MDBNavbarLink>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <MDBNavbarLink href='/login'>
                    <MDBIcon fas icon="grip-horizontal" /><span className="navTex px-2">Login</span>
                  </MDBNavbarLink>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <MDBNavbarLink href='/register'>
                    <MDBIcon fas icon="plus" /><span className="navTex px-2">Register</span>
                  </MDBNavbarLink>
                </MDBNavbarItem>
              </>
            )}
            {isLoggedIn && (
              <>
                <MDBNavbarItem>
                  <MDBNavbarLink href='/listallPeet'>
                    <MDBIcon fas icon="plus" /><span className="navTex px-2">List all Peet</span>
                  </MDBNavbarLink>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <MDBNavbarLink href='/addpeet'>
                    <MDBIcon fas icon="plus" /><span className="navTex px-2">Add Peet</span>
                  </MDBNavbarLink>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <MDBNavbarLink href='/cartBuy'>
                    <MDBIcon fas icon="plus" /><span className="navTex px-2">Cart</span>
                  </MDBNavbarLink>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <MDBNavbarLink>
                    <MDBIcon fas icon="plus" /><span className="navTex px-2">LogOut</span>
                  </MDBNavbarLink>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <MDBNavbarLink>
                    <MDBIcon fas icon="shopping-cart" value={cartCount} className='badge1' />
                  </MDBNavbarLink>
                </MDBNavbarItem>
              </>
            )}
          </MDBNavbarNav>

          {/* </MDBContainer> */}
        </MDBNavbar>
      </div>
    </>
  );
}
export default Navbar;