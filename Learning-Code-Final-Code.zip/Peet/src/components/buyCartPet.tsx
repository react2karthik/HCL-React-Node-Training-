import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { MDBContainer, MDBRow, MDBCol, MDBCard, MDBCardBody, MDBCardImage, MDBCardTitle, MDBCardText, MDBBtn } from 'mdb-react-ui-kit';
import Pagination from 'react-js-pagination';
import { toast } from 'react-toastify';
import { useHistory } from 'react-router';
const BuyCartPet: React.FC = () => {
    const [cartBuy, setCartBuy] = useState<any[]>([]);
    const [totalPrice, setTotalPrice] = useState<number>(0);

    useEffect(() => {
        axios.get('http://localhost:3001/cart')
            .then(response => {
                setCartBuy(response.data);
            })
            .catch(error => {
                console.error('Error fetching pet data:', error);
            });
    }, []);

    useEffect(() => {
        // Calculate total price
        let totalPrice = 0;
        cartBuy.forEach(item => {
            totalPrice += parseFloat(item?.payload?.payload?.price) || 0;
        });
        setTotalPrice(totalPrice);
    }, [cartBuy]);
    const [activePage, setActivePage] = useState(1);
    const itemsPerPage = 10;
    const indexOfLastItem = activePage + itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = cartBuy.slice(indexOfFirstItem, indexOfLastItem)
    const totalPages = Math.ceil(cartBuy.length / itemsPerPage);
    const isLastPage = activePage === totalPages;
    const handlePageChange = (pageNumber: number) => {
        setActivePage(pageNumber);
    }
    const [showToast, setShowToast] = useState(false);
    const history = useHistory();
    const handleBuy = () => {
        setShowToast(true);
        setTimeout(() => {
            setShowToast(false);
            history.push('/');
        }, 3000);
    };
    return (
        <MDBContainer className="mt-4">
            {showToast && (
                <div className="toast show bg-success mx-auto" role="alert" aria-live="assertive" aria-atomic="true">
                    <div className="toast-body text-light">
                        You bought pets for a total pets :{cartBuy.length} and total amount of Rs.{totalPrice}. Transaction successful!
                    </div>
                </div>
            )}
            <MDBRow className="row-cols-1 row-cols-md-6 g-4">
                {currentItems.map((cartItem, index) => (
                    <MDBCol key={index}>
                        <MDBCard className="h-100">
                            <MDBCardImage className="w-25" src={cartItem?.payload?.payload?.image} alt={cartItem?.payload?.payload?.petName} position='top' />
                            <MDBCardBody>
                                <MDBCardTitle>{cartItem?.payload?.payload?.petName}</MDBCardTitle>
                                <MDBCardText>Price: {cartItem?.payload?.payload?.price}</MDBCardText>
                            </MDBCardBody>
                        </MDBCard>
                    </MDBCol>
                ))}
            </MDBRow>
            <MDBRow className="mt-4">
                <MDBCol>
                    {/* <div className="fw-bold">Total Price: {totalPrice}</div> */}
                    {isLastPage && <div className="fw-bold">Total Price: {totalPrice}</div>}
                </MDBCol>
            </MDBRow>
            <MDBRow className="mt-4">
                <MDBCol>
                    <MDBBtn onClick={handleBuy}>Buy</MDBBtn>
                </MDBCol>
            </MDBRow>
            <div className="d-flex justify-content-center mt-3">
                <Pagination
                    activePage={activePage}
                    itemsCountPerPage={itemsPerPage}
                    totalItemsCount={cartBuy.length}
                    onChange={handlePageChange}
                    itemClass="page-item"
                    linkClass="page-link"
                />
            </div>
        </MDBContainer>
    );
}

export default BuyCartPet;



// import axios from 'axios';
// import { MDBBtn, MDBCard, MDBCardBody, MDBCol, MDBContainer, MDBIcon, MDBRow, MDBTable, MDBTableBody, MDBTableHead } from 'mdb-react-ui-kit';
// import React, { useState, useEffect } from 'react';

// const BuyCartPet: React.FC = () => {
//     const [cartBuy, setCartBuy] = useState<any[]>([]);
//     const [totalPrice, setTotalPrice] = useState<number>(0);
//     useEffect(() => {
//         axios.get('http://localhost:3001/cart')
//             .then(response => {
//                 setCartBuy(response.data);
//             })
//             .catch(error => {
//                 console.error('Error fetching pet data:', error);
//             });
//     }, []);
//     useEffect(() => {
//         // Calculate total price
//         let totalPrice = 0;
//         cartBuy.forEach(item => {
//             totalPrice += parseFloat(item?.payload?.payload?.price) || 0;
//         });
//         setTotalPrice(totalPrice);
//     }, [cartBuy]);
//     return (
//         <>
//             <MDBContainer>
//                 <MDBRow className="mt-2 g-0">
//                     <MDBCol className="table-bordered ml-auto mt-2 mb-2" md='12'>
//                         <MDBTable className="table-bordered border rounded-5 w-50 mx-auto" bordered borderColor="primary" responsive>
//                             <MDBTableHead>
//                                 <tr>
//                                     <th scope='col' className='fw-bold'>Id</th>
//                                     <th scope='col' className='fw-bold'>Image</th>
//                                     <th scope='col' className='fw-bold'>Pet Name </th>
//                                     <th scope='col' className='fw-bold'>Price</th>
//                                 </tr>
//                             </MDBTableHead>
//                             <MDBTableBody>
//                                 {cartBuy.map((cartBuy, index) => (
//                                     <tr key={index}>
//                                         <td className='fw-bold text-muted p-0'>{cartBuy.id}</td>
//                                         <td className='fw-bold text-muted'>
//                                             <img className="imgWid" src={cartBuy?.payload?.payload?.image} alt="pet" />
//                                         </td>
//                                         <td className='fw-bold text-muted p-0'>{cartBuy?.payload?.payload?.petName}</td>
//                                         <td className='fw-bold text-muted p-0'>{cartBuy?.payload?.payload?.price}</td>
//                                     </tr>
//                                 ))}
//                             </MDBTableBody>
//                             <tfoot>
//                                 <tr>
//                                     <td colSpan={3}></td>
//                                     <td className='fw-bold'>Total: {totalPrice}</td>
//                                 </tr>
//                             </tfoot>
//                         </MDBTable>
//                     </MDBCol>
//                 </MDBRow>
//                 <MDBRow>

//                 </MDBRow>

//             </MDBContainer>
//         </>
//     )
// }

// export default BuyCartPet;