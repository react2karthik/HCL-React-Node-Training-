import axios from "axios";
const callApi = async (url: string, payload: any, method: any) => {
    try {
        let response: any;
        if (method === 'post') {
            response = await axios.post(url, payload)
        } else if (method === 'get') {
            url = `http://localhost:3001/userRegistration?email=${payload.email}&password=${payload.password}`
            response = await axios.get(url,{params:payload});
            //response = await axios.get(url);
        } else {
            response = await axios.get(url);
        }
        return response.data
    } catch (error: any) {
        throw new Error(error.message);
    }
}

export default callApi;