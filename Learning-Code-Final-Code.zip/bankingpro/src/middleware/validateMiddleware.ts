import { Request, Response, NextFunction } from "express";
import { validationResult } from "express-validator";
/**
 * 
 * @param req 
 * @param res 
 * @param next 
 * @returns 
 * validate middleware is passing succes and error message 
 */
const validateMiddleware = (req: Request, res: Response, next: NextFunction) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        next()
    } else {
        const errorMsg: Array<string> = [];
        errors.array().map(err => errorMsg.push(
            err.msg
        ))
        return res.status(422).json({
            error: errorMsg
        })
    }
}
export default validateMiddleware;