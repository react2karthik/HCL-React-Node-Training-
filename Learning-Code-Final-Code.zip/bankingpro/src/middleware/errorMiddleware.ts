import { Request, Response, NextFunction } from "express";
/**
 * Error object properties for using name ,status ,code and path name
 * error status msg from dynamic getting
 * statusCode from dynamic getting
 * path where it's
 */
interface IErrorObject {
    message: string,
    status: string,
    statusCode: number,
    // data:null,
    path: string
}
// eslint-disable-next-line
const errorMiddleware = (err: any, req: Request, res: Response, next: NextFunction) => {
    const errObject: IErrorObject = {
        message: err.message,
        status: 'failure',
        statusCode: err.statusCode,
        // data:null,
        path: req.path
    }
    res.status(500).json(errObject);
    next();

}
export default errorMiddleware;