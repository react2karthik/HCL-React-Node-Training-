import { Request, Response, NextFunction } from "express";
import dotenv from 'dotenv';
import { UnAuthorizedAccess } from "../error/uAutherizedUser";
import constants from "../config/constant";
import jwt from 'jsonwebtoken';
dotenv.config();
/**
 * SECRET_KEY:Secret key we get by .env file  for name
 * constants : access issues message 
 * jwt token code genterated for loign
 * UnAuthorizedAccess :un know access
 */
const SECRET_KEY = process.env.SECRET_KEY || 'sridhar';
const autherMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const token = req.header('Authorization');
  if (!token) {
    throw new UnAuthorizedAccess(constants.ACCESS_DENIED_MESSAGE, constants.ACCESS_DENIED_CODE)
  } else {
    try {
      const decode = jwt.verify(token, SECRET_KEY);
      console.log("decode", decode);
      next();
    } catch (err) {

      throw new UnAuthorizedAccess(constants.ACCESS_DENIED_MESSAGE, constants.ACCESS_DENIED_CODE)
    }
  }

}
export default autherMiddleware;