import client from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import { beneficiarieDetailsModal } from './../modal/beneficiarieDdetailsModal';
/**
 * Get all beneficiarie data 
 * @returns 
 */
const getAllBeneficiarieDetails = async () => {
    const result = await client.execute('select beneficiarie_account_number,beneficiarie_bank,beneficiarie_ifsc_code,beneficiarie_name,is_active from  beneficiarie_details');
    if (result.rowLength === 0) {
        throw new NoDataFoundError("No beneficiarie found", 3000);
    } else
        return result.rows;
};
/**
 * 
 * @param userDetailsRouter 
 * @returns 
 */
const createBeneficiarieDetails = async (beneficiarie: beneficiarieDetailsModal) => {
    //const usermodal= {name,customer_id,email,phone,hassedPassword };
    const query = `insert into beneficiarie_details(id,customer_id,beneficiarie_account_number,beneficiarie_name,beneficiarie_bank,beneficiarie_ifsc_code,is_active) values(uuid(),${beneficiarie.customer_id},${beneficiarie.beneficiarie_account_number},'${beneficiarie.beneficiarie_name}','${beneficiarie.beneficiarie_bank}','${beneficiarie.beneficiarie_ifsc_code}',${beneficiarie.is_active})`;
    const result = await client.execute(query);
    return result;
}
/**
 * 
 * @param id 
 * @returns 
 */
const getBeneficiarieDetailsById = async (id: string | number) => {
    const query = `select count(id) as count from beneficiarie_details where id=${id}`;
    const result = await client.execute(query);
    return result.first();
}
/**
 * 
 * @param beneficiarie 
 * @returns 
 */
const putBeneficiarieDetails = async (beneficiarie: beneficiarieDetailsModal) => {
    const query = `update beneficiarie_details set 
    customer_id=${beneficiarie.customer_id},beneficiarie_account_number=${beneficiarie.beneficiarie_account_number},beneficiarie_name='${beneficiarie.beneficiarie_name}',
    beneficiarie_bank='${beneficiarie.beneficiarie_bank}',beneficiarie_ifsc_code='${beneficiarie.beneficiarie_ifsc_code}',is_active=${beneficiarie.is_active} where id=${beneficiarie.id}`;
    const result = await client.execute(query);
    return result.first();
}
/**
 * 
 * @param search 
 * @returns 
 */
const searchBeneficiarieName = async (search: string) => {
    const result = await client.execute(`select beneficiarie_account_number,beneficiarie_bank,beneficiarie_ifsc_code,beneficiarie_name  from beneficiarie_details where beneficiarie_name='${search}' ALLOW FILTERING`);
    return result.rows;
}
/**
 * 
 * @param id 
 */
const deleteBeneficiarieById = async (id: string | number) => {
    const query = `update beneficiarie_details set is_active=false where id=${id}`;//`delete from beneficiarie_details where id=${id} `;
    await client.execute(query)
}
export { getAllBeneficiarieDetails, createBeneficiarieDetails, getBeneficiarieDetailsById, putBeneficiarieDetails, searchBeneficiarieName, deleteBeneficiarieById }