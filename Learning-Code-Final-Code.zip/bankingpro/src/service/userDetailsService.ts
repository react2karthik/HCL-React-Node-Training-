import client from '../config/dbConfig';
import { NoDataFoundError } from './../error/noDataError';
import { userDetailsModal } from "./../modal/userDetailsModal";
const getAllUserDetailsRouter = async () => {
    const result = await client.execute('select * from userdetails');
    if (result.rowLength === 0) {
        throw new NoDataFoundError("No Category found", 1000);
    } else
        return result.rows;
};
const searchUserName = async (search: string) => {
    const result = await client.execute(`select * from userdetails where name='${search}' ALLOW FILTERING`);
    return result.rows;
}
const createUserDetails = async (userDetailsRouter: userDetailsModal) => {
    const query = `insert into userdetails(id,accountnumber,email,name,phone,psw) values(uuid(),${userDetailsRouter.accountnumber},'${userDetailsRouter.email}','${userDetailsRouter.name}',${userDetailsRouter.phone},'${userDetailsRouter.psw}')`;
    const result = await client.execute(query);
    return result;
}
const getUserDetailsById = async (id: string | number) => {
    const query = `select count(id) as count from userdetails where id=${id}`;
    const result = await client.execute(query);
    return result.first();
}
const putUserDetails = async (userdetails: userDetailsModal) => {
    const query = `update userdetails set accountnumber=${userdetails.accountnumber},email='${userdetails.email}',status='${userdetails.name}',phone='${userdetails.phone}',psw='${userdetails.psw}' where id=${userdetails.id}`;
    const result = await client.execute(query);
    return result.first();
}
export { getAllUserDetailsRouter, searchUserName, createUserDetails, getUserDetailsById, putUserDetails }