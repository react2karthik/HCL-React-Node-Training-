import client from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import { accountDetailsModal } from './../modal/accountDetailsModal';
/**
 * Get all accountdetails data 
 * @returns 
 */
const getAllAccDetails = async () => {
    const result = await client.execute('select * from  account_details');
    if (result.rowLength === 0) {
        throw new NoDataFoundError("No accountdetails found", 3000);
    } else
        return result.rows;
};
/**
* Search accountdetails data  by using accnumber
* @param search 
* @returns 
*/
const getAllAccDetByAccNum = async (search: number) => {
    const result = await client.execute(`select account_number,account_type,user_address,acount_opened_on,branch,ifsc_code from account_details where account_number=${search} ALLOW FILTERING`);
    return result.rows;
}

/**
 * Created new accountdetails data  by using 
 * @param account 
 */
const createAccountDetails = async (account: accountDetailsModal) => {
    const query = `insert into account_details (id,name,account_number,acount_opened_on,balance,bank_name,branch,ifsc_code,user_address,customer_id,status,account_type,is_active) 
    values(uuid(),'${account.name}',${account.account_number},'${account.acount_opened_on}',${account.balance},'${account.bank_name}','${account.branch}','${account.ifsc_code}',
    '${account.user_address}',${account.customer_id},'${account.status}','${account.account_type}',${account.is_active})`;
    const result = await client.execute(query);
    console.log("resultresultresult", result);
    return result;
}
/**
 * Edit and update accountdetails data  by using id
 * @param id 
 * @returns 
 */
const getAccDetById = async (id: string | number) => {
    const query = `select count(id) as count from account_details where id=${id}`;
    const result = await client.execute(query);
    return result.first();
}
/**
 * Edit and update account details data  by using id
 * @param product 
 */
const putAccDetails = async (account: accountDetailsModal) => {
    const query = `update account_details set account_number=${account.account_number},acount_opened_on='${account.acount_opened_on}',balance=${account.balance},bank_name='${account.bank_name}',branch='${account.branch}',ifsc_code='${account.ifsc_code}',
    user_address='${account.user_address}',customer_id=${account.customer_id},status='${account.status}',account_type='${account.account_type}',is_active=${account.is_active} where id=${account.id};`;
    const result = await client.execute(query);
    console.log("putAccDetailsputAccDetails", result);
    return result.first();
}
/**
 * Delete account details  
 * @param id 
 */
const deleteAccDetById = async (id: string | number) => {
    const query = `delete from account_details where id=${id} `;
    await client.execute(query)
}
export { getAllAccDetails, getAllAccDetByAccNum, createAccountDetails, getAccDetById, putAccDetails, deleteAccDetById };