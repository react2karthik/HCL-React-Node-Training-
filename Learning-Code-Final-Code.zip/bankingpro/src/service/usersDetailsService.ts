import client from '../config/dbConfig';
import { NoDataFoundError } from './../error/noDataError';
import { usersDetailsModal } from "./../modal/usersDetailsModal";
/**
 * 
 * @returns 
 */

const getAllUserDetailsRouter = async () => {
    const result = await client.execute('select customer_id,email,name,phone from user_details');
    if (result.rowLength === 0) {
        throw new NoDataFoundError("No Category found", 1000);
    } else
        return result.rows;
};
/**
 * 
 * @param search 
 * @returns 
 */
const searchUserName = async (search: string) => {
    const result = await client.execute(`select customer_id,email,name,phone from user_details where name='${search}' ALLOW FILTERING`);
    return result.rows;
}
/**
 * 
 * @param userDetailsRouter 
 * @returns 
 */
const createUserDetails = async (name: string, customer_id: number, email: string, phone: number, hassedPassword: string) => {
    //const usermodal= {name,customer_id,email,phone,hassedPassword };
    const query = `insert into user_details(id,email,name,phone,password,customer_id) 
    values(uuid(),'${email}','${name}',${phone},'${hassedPassword}',${customer_id})`;
    const result = await client.execute(query);
    return result;
}
/**
 * 
 * @param id 
 * @param beneficiaries 
 * @returns 
 */
// const createUserBeneficiary = async(id:string,beneficiaries: any)=>{
//     const beneficiariesObj = JSON.stringify(beneficiaries)
//     .replace(/"(\w+)":/g, '$1:')
//     .replace(/"(\d+)"/g, '$1')
//     .replace(/"/g, "'");
//     const query = `update usersDetailsRouter set beneficiaries=${beneficiariesObj} where id=${id}`
//     const result = await client.execute(query);
//     return result;
// }
/**
 * 
 * @param id 
 * @returns 
 */
const getUserDetailsById = async (id: string | number) => {
    const query = `select count(id) as count from user_details where id=${id}`;
    const result = await client.execute(query);
    return result.first();
}
const putUserDetails = async (userdetails: usersDetailsModal) => {
    const query = `update user_details set email='${userdetails.email}',name='${userdetails.name}',phone=${userdetails.phone},password='${userdetails.password}',customer_id=${userdetails.customer_id} where id=${userdetails.id}`;
    const result = await client.execute(query);
    return result.first();
}

/**
 * 
 * @param id 
 */
const deleteUsersById = async (id: string | number) => {
    const query = `delete from user_details where id=${id} `;
    await client.execute(query)
}
// /**
//  * Created new registeruser data  by using 
//  */

// const registerUser = async (id: number, name: string, email: string, psw: string) => {
//     const result = await client.execute(`insert into user_details(id,name,email,psw) values(${id},'${name}','${email}','${psw}')`)
//     return result;
// }
/**
 * Created new loginuser data  by using 
 * @param email 
 * @returns 
 */
const loginUser = async (email: string) => {
    const result = await client.execute(`select email , password from user_details where email='${email}' allow filtering`);
    return result;
}
export { loginUser, getAllUserDetailsRouter, searchUserName, createUserDetails,/*createUserBeneficiary,*/ getUserDetailsById, deleteUsersById, putUserDetails }