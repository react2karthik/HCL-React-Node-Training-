// import { UUID } from 'crypto';
import client from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import { transactionDetailsModal } from './../modal/transactionDetailsModal';
import { fundsTransitionDetailsModal } from '../modal/fundsTransitionDetailsModal';
import { minBalaceError } from '../error/minBalaceError';
import dotenv from 'dotenv';
dotenv.config();
/**
 * Get all Transaction data 
 * @returns 
 */
const getAllTransaction = async () => {
    const result = await client.execute('select * from transaction_details');
    if (result.rowLength === 0) {
        throw new NoDataFoundError("No Transaction not found", 1000);
    } else
        return result.rows;
};
/**
 * Search Transaction data  by using userfromaccnum(accountnumber)
 * @param search 
 * @returns 
 */
const getAllTransactionByAccountNumber = async (search: number) => {
    const result = await client.execute(`select credit_to,amount,to_account_no,to_bank_name,to_isfc,from_account_no,transaction_date from transaction_details where credit_to='${search}' ALLOW FILTERING`);
    return result.rows;
}
/**
 * Edit and update transaction data  by using id 
 * @param id 
 * @returns 
 */
const getTransactionById = async (id: string | number) => {
    const query = `select count(id) as count from transaction_details where id=${id}`;
    const result = await client.execute(query);
    return result.first();
}
/**
 * Created new transaction data by using 
 * @param transaction 
 */
const createTransaction = async (transaction: transactionDetailsModal) => {
    const query = `insert into transaction_details(id,amount,credit_to,debit_from,from_account_no,from_bank_name,from_ifsc,status,status_message,to_account_no,to_bank_name,to_isfc,comments,transaction_type,transaction_date)  
    values(uuid(),${transaction.amount},'${transaction.credit_to}','${transaction.debit_from}',${transaction.from_account_no},'${transaction.from_bank_name}','${transaction.from_ifsc}','${transaction.status}','${transaction.status_message}',${transaction.to_account_no},'${transaction.to_bank_name}','${transaction.to_isfc}','${transaction.comments}','${transaction.transaction_type}',toTimestamp(now()))`;
    await client.execute(query)
}
/**
 * edit and update transaction data  by using id
 * @param transaction 
 */
const putTransaction = async (transaction: transactionDetailsModal) => {
    const query = `update transaction_details set amount=${transaction.amount},credit_to='${transaction.credit_to}',debit_from='${transaction.debit_from}',from_account_no=${transaction.from_account_no},from_bank_name='${transaction.from_bank_name}',from_ifsc='${transaction.from_ifsc}',status='${transaction.status}',status_message='${transaction.status_message}',to_account_no=${transaction.to_account_no},to_bank_name='${transaction.to_bank_name}',to_isfc='${transaction.to_isfc}',comments='${transaction.comments}',
    transaction_type='${transaction.transaction_type}', transaction_date='${transaction.transaction_date}'  where id=${transaction.id}`;
    const result = await client.execute(query);
    return result.first();
}
/**
 * Delete transaction
 * @param id 
 */
const deleteTransactionById = async (id: string | number) => {
    const query = `delete from transaction_details where id=${id} `;
    await client.execute(query)
}
/**
 * fund transaction
 * @param id 
 */
// const getDetailsAccount = async (accNumber: number, ifseCode: string) => {
//     const query = `select bank_name,name ,balance,account_type from account_details where ifsc_code='${ifseCode}' and account_number=${accNumber} ALLOW FILTERING`;
//     // console.log("queryqueryqueryquery",query);
//     const result = await client.execute(query);
//     return result.first();
// }
// const updateAccBalace = async (ifscCode: string, accNumber: number, amount: any, isDebit: boolean, fund: fundsTransitionDetailsModal) => {
//     // console.log("65657566765uytutyyutyutuytyut")
//     let query = `select id,balance,account_type from account_details where ifsc_code='${ifscCode}' and account_number=${accNumber} ALLOW FILTERING`;
//     // console.log("query",query);
//     const result = await client.execute(query);
//     // console.log("result",result);
//     try {
//         if (result.first().count != 0) {
//             const { id, balance } = result.first();
//             const newBalance = isDebit ? (parseInt(balance) - parseInt(amount)) : (parseInt(balance) + parseInt(amount));
//             console.log("newBalance57656576576576",newBalance);
//             query = `update account_details set balance=${newBalance} where id=${id}`;
//             console.log("newBalancequeryqueryghgfhghgfhgfgfhgfhgfhgfgh",query);
//             await client.execute(query);
//             console.log("newBalancequeryquery",query);
//         }
//     } catch {
//         if (isDebit === false) {
//           await updateAccBalace(fund.from_ifsc_code,fund.from_account_no,fund.amount,false,fund);
//         }
//         throw new NoDataFoundError(`Account details not found for ifsc_code:'${ifscCode}' and account_number:${accNumber}`,1111);
//     }
// }
// const fundValidateTransactionAmount = async (funds: fundsTransitionDetailsModal) => {
//     const bankDetails = await getDetailsAccount(funds.from_account_no,funds.from_ifsc_code);
//     if(bankDetails != null){
//         const {name,bank_name,account_type,balance} = bankDetails;
//         const minBalance = (account_type == 'saving' ? process.env.SAVINGS_BLANCE_AMOUNT_MIN : process.env.SAVINGS_BLANCE_AMOUNT);
//         const availaBalance = balance - Number(minBalance);
//         if(availaBalance - funds.amount < 0){
//            throw new minBalaceError(`You have insufficient amount from account_number:${funds.from_account_no}`,1222);
//         }else{
//             const result = await getDetailsAccount(funds.to_account_no,funds.to_ifsc_code);
//             console.log("result",result);
//             await updateAccBalace(funds.from_ifsc_code,funds.from_account_no,funds.amount,true,funds);
//             await updateAccBalace(funds.to_ifsc_code,funds.to_account_no,funds.amount,false,funds);
//             const query = `insert into transaction_details(id,amount,credit_to,debit_from,from_account_no,
//                 from_bank_name,from_ifsc,status,status_message,to_account_no,to_bank_name,to_isfc,comments,transaction_type,
//                 transaction_date)  
//             values(uuid(),${funds.amount},
//             '${result.name}',
//             '${name}',
//             ${result.from_account_no},'${bank_name}',
//             '${result.from_bank_name}','${funds.from_ifsc_code}',
//             'succ','succ',
//             ${funds.to_account_no},'${result.to_bank_name}','${result.to_isfc}',
//             '${funds.comments}','debit',to(now()))`;
//             console.log("else123queryqueryquery",query);
//           await client.execute(query)
//         }

//     }else{
//         throw new NoDataFoundError(`no account details found ifsc_code:${funds.from_ifsc_code} and accound_number:${funds.from_account_no}`,1234);
//     }    
// }

const getBankDetails = async (accountNo: number, ifscCode: string) => {
    const query = `select name, bank_name, balance, account_type from account_details where ifsc_code='${ifscCode}' and account_number=${accountNo}  ALLOW FILTERING`;
    const result = await client.execute(query);
    return result.first();
}

const updateAccountBalance = async (ifscCode: string, accountNo: number, amount: any, isDebit: boolean, F: fundsTransitionDetailsModal) => {
    //console.log('fggggf')
    let query = `select id, balance from account_details where ifsc_code='${ifscCode}' and account_number=${accountNo} ALLOW FILTERING`;
    //console.log('updta', query);
    const result = await client.execute(query);
    //console.log('updta', result);
    try {
        if (result.first().count != 0) {
            const { id, balance } = result.first();
            const newBalance = isDebit ? (parseInt(balance) - parseInt(amount)) : (parseInt(balance) + parseInt(amount));
            //console.log('newBalance', newBalance);
            query = `update account_details set balance=${newBalance} where id=${id}`;
            //console.log('newBalancequery', query);
            await client.execute(query);
        }
    } catch {
        if (isDebit == false) {
            await updateAccountBalance(F.from_ifsc_code, F.from_account_no, F.amount, false, F);
        }
        throw new NoDataFoundError(`No account details found for IFSC_Code: ${ifscCode} and account_number: ${accountNo}`, 10000);
    }
}
const fundTranfer = async (F: fundsTransitionDetailsModal) => {
      console.log("bvbcvcbvcbvcbcbvcbv")
    const bankDetails = await getBankDetails(F.from_account_no, F.from_ifsc_code);
     //console.log('bankDetails',bankDetails);
    if (bankDetails != null) {
        //console.log('hhhhhhhhh')
        const { name, bank_name, balance, account_type } = bankDetails;
        console.log('lllll',name,bank_name, balance, account_type);
        const minimumBalance = (account_type == 'savings' ? process.env.SAVINGS_BLANCE_AMOUNT_MIN : process.env.CURRENT_BLANCE_AMOUNT);
        const availableBalance = balance - Number(minimumBalance);
        //console.log('availableBalance', availableBalance);
        if (availableBalance - F.amount < 0) {
            throw new minBalaceError(`Insufficient Balance for fund transfer from account_number: ${F.from_account_no}`, 20000);
        } else {
            const result = await getBankDetails(F.to_account_no, F.to_ifsc_code);
            await updateAccountBalance(F.from_ifsc_code, F.from_account_no, F.amount, true, F);
            await updateAccountBalance(F.to_ifsc_code, F.to_account_no, F.amount, false, F);
            const query = `insert into transaction_details (id, amount, credit_to, debit_from, from_account_no, from_bank_name, from_ifsc, status,
                status_message, to_account_no, to_bank_name, to_isfc, transaction_date, comments) values(uuid(), ${F.amount},
                '${result.name}', '${name}', ${F.from_account_no}, '${bank_name}', '${F.from_ifsc_code}', 'Suu', 'Suu',
                 ${F.to_account_no}, '${result.bank_name}', '${F.to_ifsc_code}', toTimeStamp(now()), '${F.comments}')`;
            console.log('availableBalancequery', query);
            await client.execute(query);
        }
    } else {
        throw new NoDataFoundError(`No account details found for IFSC_Code: ${F.from_ifsc_code} and account_number: ${F.from_account_no}`, 10000);
    }
}

export { getAllTransaction, createTransaction, getAllTransactionByAccountNumber, getTransactionById, deleteTransactionById, putTransaction, fundTranfer };
