import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import usersDetailsRouter from './../src/routers/usersDetailsRouter';
import transactionDetailsRouter from './../src/routers/transactionDetailsRouter';
import accountDetailsRouter from './../src/routers/accountDetailsRouter';
import beneficiarieDetailsRouter from './../src/routers/beneficiarieDetailsRouter';
import errorMiddleware from './../src/middleware/errorMiddleware';
const app: express.Application = express();
app.use(express.json());
dotenv.config();
const port = process.env.PORT || 7005;
app.use('/usersdetails', usersDetailsRouter);
app.use('/transactiondetails', transactionDetailsRouter);
app.use('/accountdetails', accountDetailsRouter);
app.use('/beneficiariedetails', beneficiarieDetailsRouter);

app.use(errorMiddleware)
app.listen(port, () => {
    console.log(`Banking app listening on port ${port}`);
})