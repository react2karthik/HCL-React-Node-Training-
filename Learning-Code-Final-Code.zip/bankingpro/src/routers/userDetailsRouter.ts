import express from 'express';
// import express, { Request, Response, NextFunction } from 'express';
// import { getAllUserDetailsRouter, createUserDetails, searchUserName, getUserDetailsById, putUserDetails } from './../service/userDetailsService';
// import { userDetailsModal } from './../modal/userDetailsModal';
// import constants from '../config/constant';

const userDetailsRouter: express.Router = express.Router();
// userDetailsRouter.get('/', async (req: Request, res: Response, next: NextFunction) => {
//     try {
//         const data = await getAllUserDetailsRouter();
//         res.json({
//             data,
//             statusCode: constants.USERDETAILS_FECTHED_SUCCESS_CODE,
//             message: constants.USERDETAILS_FECTHED_SUCCESS_MESSAGE,
//             status: constants.USERDETAILS_SUCCESS_STATUS
//         })
//     } catch (err) {
//         next(err)
//     }
// });
// userDetailsRouter.get('/search', async (req: Request, res: Response, next: NextFunction) => {
//     // eslint-disable-next-line
//     const search: any = req.query.search || "";
//     try {
//         const data = await searchUserName(search);
//         console.log("datadatadatadatadata", data);
//         res.json({
//             data,
//             statusCode: constants.USERDETAILS_SEARCH_SUCCESS_CODE,
//             message: constants.USERDETAILS_SEARCH_SUCCESS_MESSAGE,
//             status: constants.SUCCESS_STATUS
//         })
//     } catch (error) {
//         next(error)
//     }
// });
// userDetailsRouter.post('/', async (req: Request, res: Response, next: NextFunction) => {
//     const { id, accountnumber, email, name, phone, psw } = req.body;
//     const usermodal: userDetailsModal = { id, accountnumber, email, name, phone, psw };
//     try {
//         await createUserDetails(usermodal);
//         res.json({
//             statusCode: constants.USERDETAILS_POST_SUCCESS_CODE,
//             message: constants.USERDETAILS_POST_SUCCESS_MESSAGE,
//             status: constants.USERDETAILS_SUCCESS_STATUS
//         })
//     } catch (error) {
//         next(error)
//     }
// });
// userDetailsRouter.put('/update/:id', async (req: Request, res: Response, next: NextFunction) => {
//     const { id } = req.params;
//     const { accountnumber, email, name, phone, psw }: userDetailsModal = req.body;
//     const transaction: userDetailsModal = { id, accountnumber, email, name, phone, psw };
//     const data = await getUserDetailsById(id);
//     try {
//         if (data.count != 0) {
//             await putUserDetails(transaction);
//             res.json({
//                 statusCode: constants.TRANSCATION_UPDATE_SUCCESS_CODE,
//                 message: constants.TRANSCATION_UPDATE_SUCCESS_MESSAGE,
//                 status: constants.TRANSCATION_UPDATE_SUCCESS_STATUS
//             })
//         } else {
//             res.json({
//                 statusCode: constants.TRANSCATION_NOTUPDATE_FOUND_CODE,
//                 message: constants.TRANSCATION_NOTUPDATE_FOUND_MESSAGE,
//                 status: constants.SUCCESS_NOTUPDATE_STATUS
//             })
//         }
//     } catch (error) {
//         next(error)
//     }
// });
export default userDetailsRouter;