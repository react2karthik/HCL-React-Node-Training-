import express, { NextFunction, Request, Response } from 'express';
import dotenv from 'dotenv';
import { getAllBeneficiarieDetails, createBeneficiarieDetails, getBeneficiarieDetailsById, putBeneficiarieDetails, searchBeneficiarieName, deleteBeneficiarieById } from './../service/beneficiarieDetailsService';
import { beneficiarieDetailsModal } from './../modal/beneficiarieDdetailsModal';
import constants from '../config/constant';
import validateMiddleware from './../middleware/validateMiddleware';
import beneficiarieDetailsValidater from './../validater/beneficiarieDetailsValidater';
import autherMiddleware from './../middleware/authMiddleware';
dotenv.config();
/**
 * Router created by beneficiarie details
 */
const beneficiarieDetailsRouter: express.Router = express.Router();
/**
 * Get all data in the table
 * Get all data in beneficiarie table using to created getAllBeneficiarieDetails this  methoded used in accountDetailsService file  in service folder
 */
beneficiarieDetailsRouter.get('/', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
        const data = await getAllBeneficiarieDetails();
        res.json({
            data,
            statusCode: constants.BENEFICIARIE_FECTHED_SUCCESS_CODE,
            message: constants.BENEFICIARIE_FECTHED_SUCCESS_MESSAGE,
            status: constants.SUCCESS_STATUS
        })
    } catch (err) {
        next(err)
    }
});
/**
 * Get post new  data in the table
 * Get post new data in the beneficiarie table using to created createBeneficiarieDetails this methoded used in beneficiarieDetailsService file  in service folder
 */
beneficiarieDetailsRouter.post('/', beneficiarieDetailsValidater(), validateMiddleware, autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id, customer_id, beneficiarie_account_number, beneficiarie_name, beneficiarie_bank, beneficiarie_ifsc_code, is_active } = req.body;
    const beneficiarie: beneficiarieDetailsModal = { id, customer_id, beneficiarie_account_number, beneficiarie_name, beneficiarie_bank, beneficiarie_ifsc_code, is_active };
    try {
        await createBeneficiarieDetails(beneficiarie);
        res.json({
            statusCode: constants.BENEFICIARIE_POST_SUCCESS_CODE,
            message: constants.BENEFICIARIE_POST_SUCCESS_MESSAGE,
            status: constants.SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Gt edit  data  in the table
 * get edit the data in the beneficiarie table using to created beneficiarieDetailsModal and getBeneficiarieDetailsById this methoded used in beneficiarieDetailsService file  in service folder
 */
beneficiarieDetailsRouter.put('/update/:id', beneficiarieDetailsValidater(), validateMiddleware, autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    const { customer_id, beneficiarie_account_number, beneficiarie_name, beneficiarie_bank, beneficiarie_ifsc_code, is_active }: beneficiarieDetailsModal = req.body;
    const beneficiarie: beneficiarieDetailsModal = { id, customer_id, beneficiarie_account_number, beneficiarie_name, beneficiarie_bank, beneficiarie_ifsc_code, is_active };
    const data = await getBeneficiarieDetailsById(id);
    try {
        if (data.count != 0) {
            await putBeneficiarieDetails(beneficiarie);
            res.json({
                statusCode: constants.BENEFICIARIE_UPDATE_SUCCESS_CODE,
                message: constants.BENEFICIARIE_UPDATE_SUCCESS_MESSAGE,
                status: constants.SUCCESS_STATUS
            })
        } else {
            res.json({
                statusCode: constants.BENEFICIARIE_NOTUPDATE_FOUND_CODE,
                message: constants.BENEFICIARIE_NOTUPDATE_FOUND_MESSAGE,
                status: constants.FAIL_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
/**
 * Search by beneficiarie only  beneficiarie_name
 * Get search data in the beneficiarie table using to created searchBeneficiarieName this  methoded used in beneficiarieDetailsService file  in service folder
 */
beneficiarieDetailsRouter.get('/search', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    // eslint-disable-next-line
    const search: any = req.query.search || "";
    try {
        const data = await searchBeneficiarieName(search);
        res.json({
            data,
            statusCode: constants.BENEFICIARIE_SEARCH_SUCCESS_CODE,
            message: constants.BENEFICIARIE_SEARCH_SUCCESS_MESSAGE,
            status: constants.SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Get delete data  in the table by id 
 * Get delete the data in the beneficiarie table using to created getBeneficiarieDetailsById and deleteBeneficiarieById this methoded used in beneficiarieDetailsService file  in service folder
 */
beneficiarieDetailsRouter.delete('/:id', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    try {
        const data = await getBeneficiarieDetailsById(id);
        if (data.count != 0) {
            await deleteBeneficiarieById(id);
            res.json({
                statusCode: constants.DELETE_BENEFICIARIE_SUCCESS_CODE,
                message: constants.DELETE_BENEFICIARIE_SUCCESS_MESSAGE,
                status: constants.SUCCESS_STATUS
            });
        }
        else {
            res.json({
                statusCode: constants.DELETE_BENEFICIARIE_NOT_FOUNT_CODE,
                message: constants.DELETE_BENEFICIARIE_NOT_FOUNT_MESSAGE,
                status: constants.FAIL_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
export default beneficiarieDetailsRouter;