import express, { Request, Response, NextFunction } from 'express';
import { getAllAccDetails, getAllAccDetByAccNum, createAccountDetails, getAccDetById, putAccDetails, deleteAccDetById } from '../service/accountDetailsService';
import constants from '../config/constant';
import accountDetailsValidater from '../validater/accountDetailsValidater';
import validateMiddleware from '../middleware/validateMiddleware';
import { accountDetailsModal } from '../modal/accountDetailsModal';
import autherMiddleware from './../middleware/authMiddleware';
/**
 * Router created by products
 */
const accountDetailsRouter: express.Router = express.Router();
/**
 * Get all data in the table
 * Get all data in account table using to created getAllAccDetails this  methoded used in accountDetailsService file  in service folder
 * Error msg getting authermiddleware
 */
accountDetailsRouter.get('/', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
        const data = await getAllAccDetails();
        res.json({
            data,
            statusCode: constants.ACCOUNT_FECTHED_SUCCESS_CODE,
            message: constants.ACCOUNT_FECTHED_SUCCESS_CODE,
            status: constants.SUCCESS_STATUS
        })
    } catch (err) {
        next(err)
    }
});
/**
 * Search by accnumber only  
 * Get search data in the account table using to created getAllAccDetByAccNum this  methoded used in accountDetailsService file  in service folder
 * Error msg getting authermiddleware
 */
accountDetailsRouter.get('/accountnumber', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    // eslint-disable-next-line
    const search: any = req.query.search || "";
    try {
        const data = await getAllAccDetByAccNum(search);
        res.json({
            data,
            statusCode: constants.ACCOUNT_SEARCH_SUCCESS_CODE,
            message: constants.ACCOUNT_SEARCH_SUCCESS_MESSAGE,
            status: constants.SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Get post new  data in the table
 * Get post new data in the account table using to created createAccountDetails this methoded used in accountDetailsService file  in service folder
 * Error msg getting authermiddleware
 * Account for productsValidaters(id,accnumber,accountopendate,balace,banckname,branch,ifcecode,name,useradderess)
 */
accountDetailsRouter.post('/', accountDetailsValidater(), validateMiddleware, autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id, name, account_number, acount_opened_on, balance, bank_name, branch, ifsc_code, user_address, customer_id, status, account_type, is_active } = req.body;
    const account: accountDetailsModal = { id, name, account_number, acount_opened_on, balance, bank_name, branch, ifsc_code, user_address, customer_id, status, account_type, is_active };

    try {
        await createAccountDetails(account);
        res.json({
            statusCode: constants.ACCOUNT_POST_SUCCESS_CODE,
            message: constants.ACCOUNT_POST_SUCCESS_MESSAGE,
            status: constants.SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Gt edit  data  in the table
 * get edit the data in the account table using to created accountDetailsModal and putProduct this methoded used in accountDetailsService file  in service folder
 * Error msg getting authermiddleware
 */

accountDetailsRouter.put('/update/:id', accountDetailsValidater(), validateMiddleware, autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    const { name, account_number, acount_opened_on, balance, bank_name, branch, ifsc_code, user_address, customer_id, status, account_type, is_active }: accountDetailsModal = req.body;
    const account: accountDetailsModal = { id, name, account_number, acount_opened_on, balance, bank_name, branch, ifsc_code, user_address, customer_id, status, account_type, is_active };
    const data = await getAccDetById(id);
    try {
        if (data.count != 0) {
            await putAccDetails(account);
            res.json({
                statusCode: constants.ACCOUNT_UPDATE_SUCCESS_CODE,
                message: constants.ACCOUNT_UPDATE_SUCCESS_MESSAGE,
                status: constants.SUCCESS_STATUS
            })
        } else {
            res.json({
                statusCode: constants.ACCOUNT_NOTUPDATE_FOUND_CODE,
                message: constants.ACCOUNT_NOTUPDATE_FOUND_MESSAGE,
                status: constants.FAIL_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
/**
 * Get delete data  in the table by id 
 * Get delete the data in the account table using to created getAccDetById and deleteAccDetById this methoded used in accountDetailsService file  in service folder
 * Error msg getting authermiddleware
 */
accountDetailsRouter.delete('/:id', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    try {
        const data = await getAccDetById(id);
        if (data.count != 0) {
            await deleteAccDetById(id);
            res.json({
                statusCode: constants.DELETE_ACCOUNT_SUCCESS_CODE,
                message: constants.DELETE_ACCOUNT_SUCCESS_MESSAGE,
                status: constants.SUCCESS_STATUS
            });
        }
        else {
            res.json({
                statusCode: constants.DELETE_ACCOUNT_NOT_FOUNT_CODE,
                message: constants.DELETE_ACCOUNT_NOT_FOUNT_MESSAGE,
                status: constants.FAIL_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});

export default accountDetailsRouter;