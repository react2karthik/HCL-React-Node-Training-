import express, { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import { getAllUserDetailsRouter, searchUserName, createUserDetails, loginUser,/*createUserBeneficiary,*/putUserDetails, getUserDetailsById, deleteUsersById } from './../service/usersDetailsService';
import { usersDetailsModal } from './../modal/usersDetailsModal';
import constants from '../config/constant';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { UnAuthorizedAccess } from './../error/uAutherizedUser';
import autherMiddleware from './../middleware/authMiddleware';
import usersDetailsValidater from '../validater/usersDetailsValidater';
import validateMiddleware from '../middleware/validateMiddleware';
import loginValidater from '../validater/loginValidatar';
dotenv.config();
const usersDetailsRouter: express.Router = express.Router();
/**
 * user page login get email and psw using jwt sign method   and bcrypt is convert the possword
 * get all data login  method using to created loginUser this  methoded used in userService file  in service folder
 * Logi for loginValidator(email,psw)
 * Error msg getting authermiddleware
 */
usersDetailsRouter.post('/login', loginValidater(),validateMiddleware,async (req: Request, res: Response, next: NextFunction) => {
    const { email, password } = req.body;
    const result = await loginUser(email);
    if (result.first() != null) {
        const isMatching = await bcrypt.compare(password, result.first().get('password'))
        if (isMatching) {
            const token = jwt.sign({ email: email }, process.env.SECRET_KEY || "", { expiresIn: '2h' });
            res.json({
                status: constants.SUCCESS_STATUS,
                data: token
            })
        } else {
            try {
                throw new UnAuthorizedAccess(constants.ACCESS_DENIED_MESSAGE, constants.ACCESS_DENIED_CODE)
            } catch (err) {
                next(err)
            }
        }
    } else {
        res.json({
            message: constants.USER_NOT_EXIST_MESSAGE,
            code: constants.USER_NOT_EXIT_CODE,
            status: constants.FAIL_STATUS,
            data: email
        })
    }
})
/**
 * 
 */
usersDetailsRouter.get('/', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
        const data = await getAllUserDetailsRouter();
        res.json({
            data,
            statusCode: constants.USER_FECTHED_SUCCESS_CODE,
            message: constants.USER_FECTHED_SUCCESS_MESSAGE,
            status: constants.SUCCESS_STATUS
        })
    } catch (err) {
        next(err)
    }
});

/**
 * 
 */
usersDetailsRouter.get('/search', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const search: any = req.query.search || "";
    try {
        const data = await searchUserName(search);
        res.json({
            data,
            statusCode: constants.USER_SEARCH_SUCCESS_CODE,
            message: constants.USER_SEARCH_SUCCESS_MESSAGE,
            status: constants.SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * 
 */
usersDetailsRouter.post('/', usersDetailsValidater(), validateMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { name, customer_id, email, phone, password } = req.body;
    const hassedPassword = await bcrypt.hash(password, 10);
    //const usermodal= {name,customer_id,email,phone,hassedPassword };
    try {
        await createUserDetails(name, customer_id, email, phone, hassedPassword);
        res.json({
            statusCode: constants.USER_POST_SUCCESS_CODE,
            message: constants.USER_POST_SUCCESS_MESSAGE,
            status: constants.SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * 
 */
// usersDetailsRouter.post('/beneficiary/:id', async (req: Request, res: Response, next: NextFunction) => {
//     const { id } = req.params;
//     const { beneficiaries } = req.body;
//     try {
//         const result = await createUserBeneficiary(id,beneficiaries);
//         res.json({
//             result,
//             statusCode: constants.USERDETAILS_POST_SUCCESS_CODE,
//             message: constants.USERDETAILS_POST_SUCCESS_MESSAGE,
//             status: constants.SUCCESS_STATUS
//         })
//     } catch (error) {
//         next(error)
//     }
// });
usersDetailsRouter.put('/update/:id', usersDetailsValidater(), validateMiddleware, autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    const { email, customer_id, name, phone, password }: usersDetailsModal = req.body;
    const transaction: usersDetailsModal = { id, email, customer_id, name, phone, password };
    const data = await getUserDetailsById(id);
    try {
        if (data.count != 0) {
            await putUserDetails(transaction);
            res.json({
                statusCode: constants.USER_UPDATE_SUCCESS_CODE,
                message: constants.USER_UPDATE_SUCCESS_MESSAGE,
                status: constants.SUCCESS_STATUS
            })
        } else {
            res.json({
                statusCode: constants.NO_USER_FOUND_CODE,
                message: constants.NO_USER_FOUND_MESSAGE,
                status: constants.FAIL_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
/**
 * Get delete data  in the table by id 
 * Get the data in the transaction table by using to created getTransactionById and deleteTransactionById this methoded used in transactionDetailsServices file  in service folder
 * Error msg getting authermiddleware
*/
usersDetailsRouter.delete('/:id', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    try {
        const data = await getUserDetailsById(id);
        if (data.count != 0) {
            await deleteUsersById(id);
            res.json({
                statusCode: constants.DELETE_USER_SUCCESS_CODE,
                message: constants.DELETE_USER_SUCCESS_MESSAGE,
                status: constants.SUCCESS_STATUS
            });
        }
        else {
            res.json({
                statusCode: constants.NO_USERDELETE_NO_FOUND_CODE,
                message: constants.NO_USERDELETE_NO_FOUND_MESSAGE,
                status: constants.FAIL_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
export default usersDetailsRouter;