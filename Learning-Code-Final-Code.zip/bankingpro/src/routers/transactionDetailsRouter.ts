import express, { NextFunction, Request, Response } from 'express';
import { transactionDetailsModal } from './../modal/transactionDetailsModal';
import {fundsTransitionDetailsModal} from '../modal/fundsTransitionDetailsModal';
import { getAllTransaction, createTransaction, getAllTransactionByAccountNumber, getTransactionById, deleteTransactionById, putTransaction ,fundTranfer} from './../service/transactionDetailsService';
import transactionValidator from './../validater/transactionDetailsValidater';
import validateMiddleware from './../middleware/validateMiddleware';
import fundsTransitionDetailsValidater from '../validater/fundsTransitionDetailsValidater';
import autherMiddleware from './../middleware/authMiddleware';
import constants from '../config/constant';
/**
 * Router created by transaction details
 */
const transactiondetailsRouter: express.Router = express.Router();
/**
 * Get all data in the table
 * Get the data in the Transaction table by using to created getAllTransaction this methoded used in transactionDetailsServices file  in service folder
 * Error msg getting authermiddleware
*/
transactiondetailsRouter.get('/', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
        const data = await getAllTransaction();
        res.json({
            data,
            statusCode: constants.TRANSACTION_FECTHED_SUCCESS_CODE,
            message: constants.TRANSACTION_FECTHED_SUCCESS_CODE,
            status: constants.TRANSACTION_FECTHED_SUCCESS_CODE
        })
    } catch (err) {
        next(err)
    }
});
/**
 * Get search data in the table by userfromaccnum only
 * Get the data in the transaction table by using to created getAllTransactionByAccountNumber this methoded used in transactionDetailsServices file  in service folder
 * Error msg getting authermiddleware
*/
transactiondetailsRouter.get('/search', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    // eslint-disable-next-line
    const search: any = req.query.search || "";
    try {
        const data = await getAllTransactionByAccountNumber(search);
        res.json({
            data,
            statusCode: constants.TRANSACTION_SEARCH_SUCCESS_CODE,
            message: constants.TRANSACTION_SEARCH_SUCCESS_MESSAGE,
            status: constants.SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Get post new  data in the table
 * Get the data in the transaction table by using to created createTransaction this methoded used in transactionDetailsServices file  in service folder
 * Error msg getting authermiddleware
*/
// transactiondetailsRouter.post('/', transactionValidator(), validateMiddleware, autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
//     const { id, amount, credit_to, debit_from, from_account_no, from_bank_name, from_ifsc, status, status_message, to_account_no, to_bank_name, to_isfc, comments, transaction_type, transaction_date } = req.body;
//     const transaction: transactionDetailsModal = { id, amount, credit_to, debit_from, from_account_no, from_bank_name, from_ifsc, status, status_message, to_account_no, to_bank_name, to_isfc, comments, transaction_type, transaction_date };
//     try {
//         await createTransaction(transaction);
//         res.json({
//             statusCode: constants.TRANSCATION_POST_SUCCESS_CODE,
//             message: constants.TRANSCATION_POST_SUCCESS_MESSAGE,
//             status: constants.SUCCESS_STATUS
//         })
//     } catch (error) {
//         next(error)
//     }
// });
/**
 * Gt edit  data  in the table
 * Get the data in the transaction table by using to created getCategoriesById and putCategories this methoded used in transactionDetailsServices file  in service folder
 * Error msg getting authermiddleware
*/
transactiondetailsRouter.put('/update/:id', transactionValidator(), validateMiddleware, autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    const { amount, credit_to, debit_from, from_account_no, from_bank_name, from_ifsc, status, status_message, to_account_no, to_bank_name, to_isfc, comments, transaction_type, transaction_date }: transactionDetailsModal = req.body;
    const transaction: transactionDetailsModal = { id, amount, credit_to, debit_from, from_account_no, from_bank_name, from_ifsc, status, status_message, to_account_no, to_bank_name, to_isfc, comments, transaction_type, transaction_date };
    const data = await getTransactionById(id);
    try {
        if (data.count != 0) {
            await putTransaction(transaction);
            res.json({
                statusCode: constants.ACCOUNT_UPDATE_SUCCESS_CODE,
                message: constants.ACCOUNT_UPDATE_SUCCESS_MESSAGE,
                status: constants.SUCCESS_STATUS
            })
        } else {
            res.json({
                statusCode: constants.ACCOUNT_NOTUPDATE_FOUND_CODE,
                message: constants.ACCOUNT_NOTUPDATE_FOUND_MESSAGE,
                status: constants.FAIL_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
/**
 * Get delete data  in the table by id 
 * Get the data in the transaction table by using to created getTransactionById and deleteTransactionById this methoded used in transactionDetailsServices file  in service folder
 * Error msg getting authermiddleware
*/
transactiondetailsRouter.delete('/:id', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    try {
        const data = await getTransactionById(id);
        if (data.count != 0) {
            await deleteTransactionById(id);
            res.json({
                statusCode: constants.DELETE_TRANSCATION_SUCCESS_CODE,
                message: constants.DELETE_TRANSCATION_SUCCESS_MESSAGE,
                status: constants.SUCCESS_STATUS
            });
        }
        else {
            res.json({
                statusCode: constants.DELETE_TRANSCATION_NOT_FOUNT_CODE,
                message: constants.DELETE_TRANSCATION_NOT_FOUNT_MESSAGE,
                status: constants.FAIL_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
/**
 * Get post new  data in the table
 * Get the data in the transaction table by using to created createTransaction this methoded used in transactionDetailsServices file  in service folder
 * Error msg getting authermiddleware
*/
transactiondetailsRouter.post('/transactions', fundsTransitionDetailsValidater(), validateMiddleware, autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const {amount,comments,customer_id,from_ifsc_code,from_account_no,to_ifsc_code,to_account_no} = req.body;
    const fundstransaction: fundsTransitionDetailsModal = {amount,comments,customer_id,from_ifsc_code,from_account_no,to_ifsc_code,to_account_no};
    try {
       const result =  await fundTranfer(fundstransaction);
        res.json({
            statusCode: constants.TRANSCATION_POST_SUCCESS_CODE,
            message: constants.TRANSCATION_POST_SUCCESS_MESSAGE,
            status: constants.SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});

export default transactiondetailsRouter




