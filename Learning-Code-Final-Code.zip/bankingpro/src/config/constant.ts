const constants = {
  ACCESS_DENIED_MESSAGE: 'Access denied',
  ACCESS_DENIED_CODE: 4000,
  SUCCESS_STATUS: 'Success',
  FAIL_STATUS: 'Failed',
  /*----------Transaction START--------------*/
  TRANSACTION_FECTHED_SUCCESS_CODE: 7006,
  TRANSACTION_FECTHED_SUCCESS_MESSAGE: 'Transaction fetched all successfuly',
  /**
   * @Search
   */
  TRANSACTION_SEARCH_SUCCESS_CODE: 7007,
  TRANSACTION_SEARCH_SUCCESS_MESSAGE: 'Transaction Search fetched successfuly',
  /**
   * @post
  */
  TRANSCATION_POST_SUCCESS_CODE: 7008,
  TRANSCATION_POST_SUCCESS_MESSAGE: 'New Post Transaction added  successfuly',
  /**
   * @upate
   */
  TRANSCATION_UPDATE_SUCCESS_CODE: 7009,
  TRANSCATION_UPDATE_SUCCESS_MESSAGE: 'Update Transaction successfuly',

  TRANSCATION_NOTUPDATE_FOUND_CODE: 7010,
  TRANSCATION_NOTUPDATE_FOUND_MESSAGE: 'Transaction Not Update',
  /**
   * @deleted
   */
  DELETE_TRANSCATION_SUCCESS_CODE: 7011,
  DELETE_TRANSCATION_SUCCESS_MESSAGE: 'Delete Categories successfuly',

  DELETE_TRANSCATION_NOT_FOUNT_CODE: 7012,
  DELETE_TRANSCATION_NOT_FOUNT_MESSAGE: 'Delete Categories successfuly',

  /*----------Transaction END--------------*/
  /*----------Account Start -------------*/

  ACCOUNT_FECTHED_SUCCESS_CODE: 7013,
  ACCOUNT_FECTHED_SUCCESS_MESSAGE: 'Account fetched all successfuly',
  /**
   * @Search
   */
  ACCOUNT_SEARCH_SUCCESS_CODE: 7014,
  ACCOUNT_SEARCH_SUCCESS_MESSAGE: 'Account Search fetched successfuly',
  /**
   * @post
  */
  ACCOUNT_POST_SUCCESS_CODE: 7015,
  ACCOUNT_POST_SUCCESS_MESSAGE: 'New account added successfuly',
  /**
   * @upate
   */
  ACCOUNT_UPDATE_SUCCESS_CODE: 7016,
  ACCOUNT_UPDATE_SUCCESS_MESSAGE: 'Update account successfuly',

  ACCOUNT_NOTUPDATE_FOUND_CODE: 7017,
  ACCOUNT_NOTUPDATE_FOUND_MESSAGE: 'Account  Not Update',
  /**
   * @deleted
   */
  DELETE_ACCOUNT_SUCCESS_CODE: 7018,
  DELETE_ACCOUNT_SUCCESS_MESSAGE: 'Delete Account successfuly',

  DELETE_ACCOUNT_NOT_FOUNT_CODE: 7019,
  DELETE_ACCOUNT_NOT_FOUNT_MESSAGE: 'Delete Account successfuly',

  /*----------Account End -------------*/
  /*---------- Beneficiarie Start -----*/
  /**
   * @Beneficiarie  BENEFICIARIE
   */

  BENEFICIARIE_FECTHED_SUCCESS_CODE: 7020,
  BENEFICIARIE_FECTHED_SUCCESS_MESSAGE: 'Beneficiaries details fetched all successfuly',
  /**
   * @Get
   */
  BENEFICIARIE_SEARCH_SUCCESS_CODE: 7021,
  BENEFICIARIE_SEARCH_SUCCESS_MESSAGE: 'Beneficiaries search successfuly',
  /**
    * @Post
    */
  BENEFICIARIE_POST_SUCCESS_CODE: 7022,
  BENEFICIARIE_POST_SUCCESS_MESSAGE: 'Beneficiaries details Post successfuly',

  /**
   * @upate
   */
  BENEFICIARIE_UPDATE_SUCCESS_CODE: 7023,
  BENEFICIARIE_UPDATE_SUCCESS_MESSAGE: 'Update Beneficiaries successfuly',

  BENEFICIARIE_NOTUPDATE_FOUND_CODE: 7024,
  BENEFICIARIE_NOTUPDATE_FOUND_MESSAGE: 'Beneficiaries Not Update',

  /**
   * @deleted
   */
  DELETE_BENEFICIARIE_SUCCESS_CODE: 7025,
  DELETE_BENEFICIARIE_SUCCESS_MESSAGE: 'Delete Beneficiaries successfuly',

  DELETE_BENEFICIARIE_NOT_FOUNT_CODE: 7026,
  DELETE_BENEFICIARIE_NOT_FOUNT_MESSAGE: 'Delete Beneficiaries successfuly',

  /*---------- Beneficiarie End -----*/
  /*---------USER START --------*/
  /**
   * @USER
   */
  USER_FECTHED_SUCCESS_CODE: 7027,
  USER_FECTHED_SUCCESS_MESSAGE: 'User fetched all successfuly',

  USER_SEARCH_SUCCESS_CODE: 7028,
  USER_SEARCH_SUCCESS_MESSAGE: 'User Search successfuly',

  /**
 * @Post
 */
  USER_POST_SUCCESS_CODE: 7029,
  USER_POST_SUCCESS_MESSAGE: 'User Data posted edited successfuly',

  /**
 * @Put
 */
  USER_UPDATE_SUCCESS_CODE: 7030,
  USER_UPDATE_SUCCESS_MESSAGE: 'User details edit update successfult',

  NO_USER_FOUND_CODE: 7031,
  NO_USER_FOUND_MESSAGE: 'User details not update fail',

  /**
  * @Delete
  */
  DELETE_USER_SUCCESS_CODE: 7032,
  DELETE_USER_SUCCESS_MESSAGE: 'User details deleted successfuly',

  NO_USERDELETE_NO_FOUND_CODE: 7033,
  NO_USERDELETE_NO_FOUND_MESSAGE: 'User details not deleted',

  /*-------- USER ENT -------*/
  //Register API
  USER_REGISTERED_SUCCESS_MESSAGE: 'User Registered Successfuly',
  USER_REGISTERED_SUCCESS_CODE: 7034,

  USER_NOT_EXIST_MESSAGE: "User not exist",
  USER_NOT_EXIT_CODE: 1032
}
export default constants;
