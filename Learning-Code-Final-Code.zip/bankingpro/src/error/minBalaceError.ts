/**
 * balace less send error message 
 */
export class minBalaceError extends Error {
    statusCode: number;
    constructor(msg: string, code: number) {
        super();
        this.message = msg;
        this.statusCode = code;
    }
}