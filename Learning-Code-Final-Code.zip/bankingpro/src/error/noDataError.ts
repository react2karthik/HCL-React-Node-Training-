/**
 * Data is not there error message send for dynamic
 */
export class NoDataFoundError extends Error {
    statusCode: number;
    constructor(msg: string, code: number) {
        super();
        this.message = msg;
        this.statusCode = code;
    }
}