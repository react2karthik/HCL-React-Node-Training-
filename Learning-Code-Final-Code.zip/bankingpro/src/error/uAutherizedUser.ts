/**
 * If added daata is wrong we send some access issues login or other data missesd
 */
export class UnAuthorizedAccess extends Error {
    status: number;
    constructor(message: string, status: number) {
        super();
        this.message = message;
        this.status = status;
    }
}