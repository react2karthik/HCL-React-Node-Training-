import { body } from "express-validator";
/**
 * Transaction for transaction validater(id,amount,credit_to,debit_from,from_bank_name,from_ifsc,status,status_message,to_bank_name,to_isfc,comments,transaction_type,transaction_date)
 * @returns 
 */
const transactionValidator = () => {
    return [
        body('amount').exists().trim().withMessage('amount is required'),
        body('credit_to').exists().trim().withMessage('credit to is required'),
        body('debit_from').exists().trim().withMessage('debit from is required'),
        body('from_account_no').exists().trim().withMessage('from account no is required '),
        body('from_bank_name').exists().withMessage('from bank name is required'),
        body('from_ifsc').exists().trim().withMessage('ifsc is required'),
        body('status').exists().trim().withMessage('status is required'),
        body('status_message').exists().trim().withMessage('Status message is required'),
        body('to_account_no').exists().trim().withMessage('to account number is required'),
        body('to_bank_name').exists().trim().withMessage('to bank name is required'),
        body('to_isfc').exists().trim().withMessage('ifce code is required'),
        body('comments').exists().trim().withMessage('Cooment need'),
        body('transaction_type').exists().trim().withMessage('transaction type is required'),
        body('transaction_date').exists().trim().withMessage('date of transaction is required')
    ]
}
export default transactionValidator;