import { body } from "express-validator";
/**
 * Transaction for transaction validater(id,amount,credit_to,debit_from,from_bank_name,from_ifsc,status,status_message,to_bank_name,to_isfc,comments,transaction_type,transaction_date)
 * @returns 
 */
const fundsTransitionDetailsValidater = () => {
    return [
        body('amount').exists().trim().withMessage('amount is required'),
        body('comments').exists().trim().withMessage('Cooment need'),
        body('customer_id').exists().trim().withMessage('credit to is required'),
        body('from_account_no').exists().trim().withMessage('from account no is required '),
        body('from_ifsc_code').exists().trim().withMessage('ifsc is required'),        
        body('to_ifsc_code').exists().trim().withMessage('ifce code is required'),        
        body('to_account_no').exists().trim().withMessage('to account number is required')
    ]
}
export default fundsTransitionDetailsValidater;
