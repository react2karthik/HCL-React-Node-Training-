import { body } from "express-validator";
/**
 * account details for account validater(account_number,account_type,acount_opened_on,balance,bank_name,branch,customer_id,ifsc_code,is_active,name,status,user_address)
 * @returns 
 */
const accountDetailsValidater = () => {
    return [
        body('account_number').exists().isLength({ min: 9 }).withMessage('account is min length').trim().withMessage('enter account is required'),
        body('account_type').exists().trim().withMessage('enter account type date is required'),
        body('acount_opened_on').exists().trim().withMessage('enter account open on is required'),
        body('balance').exists().trim().withMessage('balance is required'),
        body('bank_name').exists().withMessage('bank name is required'),
        body('branch').exists().trim().withMessage('branch name is required'),
        body('customer_id').exists().trim().withMessage('customer id is required'),
        body('ifsc_code').exists().trim().withMessage('ifsc code is required'),
        body('is_active').exists().trim().withMessage('is active is required'),
        body('name').exists().trim().withMessage('name is required'),
        body('status').exists().trim().withMessage('status is required'),
        body('user_address').exists().trim().withMessage('user adderess is required'),
    ]
}
export default accountDetailsValidater;