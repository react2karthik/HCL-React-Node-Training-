import { body } from "express-validator";
/**
 * users details for users validater(customer_id,email,name,password,phone)
 * @returns 
 */
const usersDetailsValidater = () => {
    return [
        body('customer_id').exists().trim().withMessage('enter cutomer id  is required'),
        body('email').exists().trim().withMessage('email id is required'),
        body('name').exists().withMessage('name is required'),
        body('password').exists().trim().withMessage('password is required'),
        body('phone').exists().trim().withMessage('phone number is required'),
    ]
}
export default usersDetailsValidater;