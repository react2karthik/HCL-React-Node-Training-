import { body } from "express-validator";
/**
 * users login for users validater(email,password)
 * @returns 
 */
const loginValidater = () => {
    return [
        body('email').exists().trim().withMessage('email id is required'),
        body('password').exists().trim().withMessage('password is required'),
    ]
}
export default loginValidater;