import { body } from "express-validator";
/**
 * beneficiarie details for account validater(id,beneficiarie_account_number,beneficiarie_bank,beneficiarie_ifsc_code,beneficiarie_name,customer_id,is_active)
 * @returns 
 */

const beneficiarieDetailsValidater = () => {
    return [
        body('beneficiarie_account_number').exists().isLength({ min: 6 }).withMessage('account is min length').trim().withMessage('enter account number'),
        body('beneficiarie_bank').exists().trim().withMessage('enter bank name for beneficiarie'),
        body('beneficiarie_ifsc_code').exists().trim().withMessage('ifsc code  required'),
        body('beneficiarie_name').exists().withMessage('beneficiarie name required'),
        body('customer_id').exists().trim().withMessage('customer id'),
        body('is_active').exists().trim().withMessage('is active required id'),
    ]
}
export default beneficiarieDetailsValidater;