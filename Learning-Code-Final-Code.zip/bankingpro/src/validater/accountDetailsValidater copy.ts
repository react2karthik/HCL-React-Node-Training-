import { body } from "express-validator";
/**
 * account details for account validater(id,accnumber,accountopendate,balace,banck,name,branch,ifcecode,useradderess )
 * @returns 
 */
const accountDetailsValidater = () => {
    return [
        body('id').exists().withMessage('categories id need'),
        body('accnumber').exists().isLength({ min: 3 }).trim().withMessage('enter accnumber'),
        body('accountopendate').exists().trim().withMessage('enter account created date'),
        body('balace').exists().trim().withMessage('enter balace'),
        body('banck').exists().trim().withMessage('banck name'),
        body('name').exists().withMessage('name need'),
        body('branch').exists().isLength({ min:7 }).trim().withMessage('branch name'),
        body('ifcecode').exists().trim().withMessage('enter ifcecode code'),
        body('useradderess').exists().isLength({ min:7 }).trim().withMessage('useradderess'),
    ]
}
export default accountDetailsValidater;