/**
 * Interface added for user deatils
 */
export interface userDetailsModal {
    id: string,
    accountnumber: number,
    email: string,
    name: string,
    phone: number,
    psw: string
}
//create table user_details(id uuid primary key, name text,customer_id int, email text, password text, phone bigint);