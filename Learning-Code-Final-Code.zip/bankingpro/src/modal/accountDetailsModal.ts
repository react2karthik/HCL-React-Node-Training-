/**
 * Interface added for account deatils
 */
export interface accountDetailsModal {
    id: string,
    name: number,
    account_number: number,
    acount_opened_on: string,
    balance: string,
    bank_name: string,
    branch: string,
    ifsc_code: string,
    user_address: string,
    customer_id: number,
    status: string,
    account_type: string,
    is_active: boolean
}

// id,accnumber,accountopendate,balace,banck,name,branch,ifcecode,name,useradderess
// create table account_details(id uuid primary key, name text, account_number int, acount_opened_on date, balance int, bank_name text, branch text, ifsc_code text, user_address text,customer_id int,status text,account_type text,is_active boolean);
//id , name , account_number , acount_opened_on, balance, bank_name, branch, ifsc_code, user_address,customer_id,status,account_type,is_active