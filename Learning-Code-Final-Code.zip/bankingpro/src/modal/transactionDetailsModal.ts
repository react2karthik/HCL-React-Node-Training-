/**
 * Interface added for transaction deatils
 */
export interface transactionDetailsModal {
    id: string,
    amount: number,
    credit_to: string,
    debit_from: string,
    from_account_no: number,
    from_bank_name: string,
    from_ifsc: string,
    status: string,
    status_message: string,
    to_account_no: number,
    to_bank_name: string,
    to_isfc: string,
    comments: string,
    transaction_type: string,
    transaction_date: string
}
//drop table beneficiarie_details
//create table transaction_details(id uuid primary key,amount int,credit_to text, debit_from text,from_account_no bigint,from_bank_name text,from_ifsc_code text,status text,status_message text,to_account_no bigint,to_bank_name text,to_isfc_code text, comments text,transaction_type text,transaction_date timeStamp)

//id,amount,credit_to,debit_from,from_account_no,from_bank_name,from_ifsc_code,status,status_message,to_account_no,to_bank_name,to_isfc_code,comments,transaction_type,