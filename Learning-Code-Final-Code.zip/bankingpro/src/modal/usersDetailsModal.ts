/**
 * Interface added for user deatils
 */
export interface usersDetailsModal {
    id: string,
    customer_id: number,
    email: string,
    name: string,
    phone: number,
    password: string,
}