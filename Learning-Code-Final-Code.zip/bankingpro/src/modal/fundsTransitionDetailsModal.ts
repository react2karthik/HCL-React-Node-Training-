/**
 * Interface added for funds transition deatils
 */
export interface fundsTransitionDetailsModal {
    amount:number,
    customer_id:number,
    to_ifsc_code:string,
    to_account_no:number,
    comments:string,   
    from_ifsc_code:string,
    from_account_no:number
}

// from_ifsc_code,from_account_no,to_ifsc_code,to_account_no,comments,amount,customer_id
// create table account_details(from_ifsc_code,from_account_no,to_ifsc_code,to_account_no,comments,amount,customer_id);
