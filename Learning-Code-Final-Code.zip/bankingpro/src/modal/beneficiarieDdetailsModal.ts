/**
 * Interface added for beneficiarie deatils
 */
export interface beneficiarieDetailsModal {
    id: string,
    customer_id: number,
    beneficiarie_account_number: number,
    beneficiarie_name: string,
    beneficiarie_bank: string,
    beneficiarie_ifsc_code: string,
    is_active: boolean
}

//id,name,customer_id,beneficiarie_account_number,beneficiarie_name,beneficiarie_bank,beneficiarie_ifsc_code,is_active
//create type beneficiarie_details(id uuid primary key, name text, customer_id int, beneficiarie_account_number int, beneficiarie_name text, beneficiarie_bank text, beneficiarie_ifsc_code text,is_active boolean);