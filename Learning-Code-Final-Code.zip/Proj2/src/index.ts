import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import myMiddleware from './middleware/my-middleware';
import errorMiddleware from './middleware/errorMiddleware';
import categoriesRouter from './routers/categoriesRouter';
// import externalApiRouter from './routers/externalApiRouter'
import productsRouter from './routers/productsRouter';
import userRoter from './routers/userRouter';
import cartRoter from './routers/cartRouter';
import orderTableRouter from './routers/orderTableRouter';
import errorRouter from './routers/errorRouter';
const app: express.Application = express();
/**
 * .env file getting value
 */
dotenv.config();
/**
 * port number 
 */
const port = process.env.PORT || 3003;
/**
 * Express json value
 */
app.use(express.json());
/**
 * Application level middle
 */
app.use(myMiddleware);
/**
 * Get method
 */

app.get('/', (req: Request, res: Response) => {
   res.send('Hell world')
})
/**
 * Routes for all 
 */
app.use('/categories', categoriesRouter);
//  app.use('/external-api',externalApiRouter);
app.use('/produts', productsRouter);
app.use('/user', userRoter);
app.use('/cart', cartRoter);
app.use('/orderTable', orderTableRouter)
app.use('/error', errorRouter);
/**
 * Error middleware calling
 */
app.use(errorMiddleware);
/**
 * Port number listen
 */
app.listen(port, () => {
   console.log(`Example app listening on port ${port}`)
})









