import express, { NextFunction, Request, Response } from 'express';
import request from 'request';
import { NoDataFoundError } from '../error/noDataError';
/**
 * Router created by Error
 */
const errorRouter: express.Router = express.Router();

errorRouter.get('/sync', (req: Request, res: Response) => {
    throw new Error("Sync code");
    res.send("syn code");
})
errorRouter.get('/async/:id', (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    // eslint-disable-next-line
    request(`https://reqres.in/api/users/${id}`, function (_error: any, response) {
        const data = JSON.parse(response.body);
        try {
            if (Object.keys(data).length === 0) {
                res.json({
                    message: "no data found",
                    status: "success",
                    StatusCode: 2001,
                    data: null
                })
            } else {
                res.json({
                    message: "Data fetched successfuly",
                    status: "success",
                    StatusCode: 2002,
                    data
                })
            }
        } catch (error) {
            next(error)
        }
    })
})
errorRouter.get('/test', (req: Request, res: Response, next: NextFunction) => {
    setTimeout(() => {
        try {
            throw new NoDataFoundError('not founde error', 3003);
        } catch (err) {
            next(err)
        }
    })
})
export default errorRouter;