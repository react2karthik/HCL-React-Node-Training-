import express, { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import { getAllUserRouter, getAllUserByCatrgoryName, getUserById, createUser, putUsers, deleteUserById, registerUser, loginUser } from '../service/userService';
import constants from '../config/constant';
import userValidator from '../validater/userValidater';
import { userModal } from '../modal/userModal';
import registerValidator from './../validater/registerValidater';
import loginValidator from './../validater/loginValidator';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { UnAuthorizedAccess } from './../error/uAutherizedUser';
dotenv.config();
/**
 * Router created by user
 */
const userRouter: express.Router = express.Router();
/**
 * user page login get email and psw using jwt sign method   and bcrypt is convert the possword
 * get all data login  method using to created loginUser this  methoded used in userService file  in service folder
 * Logi for loginValidator(email,psw)
 * Error msg getting authermiddleware
 */
userRouter.post('/login', loginValidator(), async (req: Request, res: Response, next: NextFunction) => {
    const { email, psw } = req.body;
    const result = await loginUser(email);
    if (result.first() != null) {
        const isMatching = await bcrypt.compare(psw, result.first().get('psw'))
        if (isMatching) {
            const token = jwt.sign({ email: email }, process.env.SECRET_KEY || "", { expiresIn: '2h' });
            res.json({
                status: constants.ORDERTABLE_SUCCESS_STATUS,
                data: token
            })
        } else {
            try {
                throw new UnAuthorizedAccess(constants.ACCESS_DENIED_MESSAGE, constants.ACCESS_DENIED_CODE)
            } catch (err) {
                next(err)
            }
        }
    } else {
        res.json({
            message: constants.USER_NOT_EXIST_MESSAGE,
            code: constants.USER_NOT_EXIT_CODE,
            status: constants.CART_FAIL_STATUS,
            data: email
        })
    }
})
/**
 * Get post new  data in the table
 * User page register get name, email, id and psw and bcrypt is convert the possword
 * Get all data register  method using to created registerUser this  methoded used in userService file  in service folder
 * Register for registerValidator(name, email, id,psw)
 */

userRouter.post('/register', registerValidator(), async (req: Request, res: Response, next: NextFunction) => {
    const { id, name, email, psw } = req.body;
    try {
        const hashedPwd = await bcrypt.hash(psw, 10);
        await registerUser(id, name, email, hashedPwd);
        res.json({
            message: constants.USER_REGISTERED_SUCCESS_MESSAGE,
            code: constants.USER_REGISTERED_SUCCESS_CODE,
            status: constants.CATEGORY_SUCCESS_STATUS
        })
    } catch (err) {
        next(err);
    }
})
/**
 * User page register get all the details
 * Get all data method using to created getAllUserRouter this  methoded used in userService file  in service folder
 */

userRouter.get('/', async (req: Request, res: Response, next: NextFunction) => {
    try {
        let data = await getAllUserRouter();
        res.json({
            data,
            statusCode: constants.USER_FECTHED_SUCCESS_CODE,
            message: constants.USER_FECTHED_SUCCESS_MESSAGE,
            status: constants.USER_SUCCESS_STATUS
        })
    } catch (err) {
        next(err)
    }
});
/**
 * Search details using name only
 * Get search method using to created getAllUserByCatrgoryName this  methoded used in userService file  in service folder
 */

userRouter.get('/search', async (req: Request, res: Response, next: NextFunction) => {
    const search: any = req.query.search || "";
    try {
        let data = await getAllUserByCatrgoryName(search);
        res.json({
            data,
            statusCode: constants.USER_SEARCH_SUCCESS_CODE,
            message: constants.USER_SEARCH_SUCCESS_MESSAGE,
            status: constants.USER_SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * New register data post  details created 
 * Post method using to created this file  createUser this  methoded used in userService file  in service folder
 */
userRouter.post('/', userValidator(), async (req: Request, res: Response, next: NextFunction) => {
    const { id, email, name, phone, psw, } = req.body;
    const usermodal: userModal = { id, email, name, phone, psw };
    try {
        await createUser(usermodal);
        res.json({
            statusCode: constants.USER_POST_SUCCESS_CODE,
            message: constants.USER_POST_SUCCESS_MESSAGE,
            status: constants.USER_SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Update or edit the any information  by using id only 
 * Here we used update the getUserById and putUsers this two methoded used in userService file  in service folder
 */
userRouter.put('/putUpdate/:id', async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    const { email, name, phone, psw }: userModal = req.body;
    const usermodal: userModal = { id, email, name, phone, psw };
    const data = await getUserById(id);
    try {
        if (data.count != 0) {
            await putUsers(usermodal);
            res.json({
                statusCode: constants.USER_UPDATE_SUCCESS_CODE,
                message: constants.USER_UPDATE_SUCCESS_MESSAGE,
                status: constants.USER_SUCCESS_STATUS
            })
        } else {
            res.json({
                statusCode: constants.NO_USER_FOUND_CODE,
                message: constants.NO_USER_FOUND_MESSAGE,
                status: constants.USER_FAIL_SUCCESS_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
/**
 * dDelete date from db information 
 * This two method using to delete the data getUserById and deleteUserById  methoded used in userService file  in service folder
 */
userRouter.delete('/:id', async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    try {
        const data = await getUserById(id);
        if (data.count != 0) {
            await deleteUserById(id);
            res.json({
                statusCode: constants.DELETE_USER_SUCCESS_CODE,
                message: constants.DELETE_USER_SUCCESS_MESSAGE,
                status: constants.USER_SUCCESS_STATUS
            });
        }
        else {
            res.json({
                statusCode: constants.NO_USERDELETE_NO_FOUND_CODE,
                message: constants.NO_USERDELETE_NO_FOUND_MESSAGE,
                status: constants.USER_FAIL_SUCCESS_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});

export default userRouter;