// import { UUID } from 'crypto';
import client  from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import {Category} from './../modal/categoryModal';
/**
 * Get all categories data 
 * @returns 
 */
const getAllCategories = async()=>{
    const result = await client.execute('select * from category');
    console.log('getAllCategoriesgetAllCategories-------------------',getAllCategories,result)
    if(result.rowLength === 0){
        throw new NoDataFoundError("No Category found", 1000);
        console.log('getAllCategoriesgetAllCategories-------------------',getAllCategories)
    }else
    return result.rows;
    console.log('result.rows-------------------',result.rows)
};
/**
 * Search categories data  by using category_name
 * @param search 
 * @returns 
 */
const getAllCategoriesByCatrgoryName=async(search:string)=>{
    const result = await client.execute(`select * from category where category_name='${search}' ALLOW FILTERING`);
    return result.rows;
}
/**
 * Edit and update categories data  by using id 
 * @param id 
 * @returns 
 */
const getCategoriesById=async(id:string | number)=>{
    const query = `select count(id) as count from category where id=${id}`;
    const result = await client.execute(query);
    return result.first();
}
/*
//created new categories data  by using 
*/
const createCategory = async(category:Category)=>{
    const query = `insert into category(id,category_name,category_description) values(uuid(),'${category.category_name}','${category.category_description}')`;
    await client.execute(query)
}
/*
//edit and update categories data  by using id
*/
const putCategories = async(category:Category)=>{
    const query = `update category set category_name='${category.category_name}',
    category_description='${category.category_description}' where id=${category.id}`;
    await client.execute(query)
}
/*
//delete categories  
 */
const deleteCategoriesById=async(id:string | number)=>{
    const query = `delete from category where id=${id} `;
    await client.execute(query)
}
export {getAllCategories,getAllCategoriesByCatrgoryName,getCategoriesById,createCategory,putCategories,deleteCategoriesById};