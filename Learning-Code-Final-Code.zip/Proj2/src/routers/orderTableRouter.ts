import express, { Request, Response, NextFunction } from 'express';
import { getAllOrterTableRouter, getAllOrderTableByName, getOrderTableById, createOrderTable, putOrderTable, deleteOrderTableById } from '../service/orderTableService';
import constants from '../config/constant';
import autherMiddleware from './../middleware/authMiddleware';
import { orderTableModal } from '../modal/orderTableModal';
/**
 * Router crated by ordertable
 */
const orderTableRouter: express.Router = express.Router();
/**
 * Get all data in the table
 * Get the data in the orderTable by using to created getAllOrterTableRouter this methoded used in orderTableServices file  in service folder
 * Error msg getting authermiddleware
 */
orderTableRouter.get('/', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
        const data = await getAllOrterTableRouter();
        res.json({
            data,
            statusCode: constants.ORDERTABLE_FECTHED_SUCCESS_CODE,
            message: constants.ORDERTABLE_FECTHED_SUCCESS_MESSAGE,
            status: constants.ORDERTABLE_SUCCESS_STATUS
        })
    } catch (err) {
        next(err)
    }
});
/**
 * Search data in the table  using category_id only
 * Search the data in the orderTable by using to created getAllOrderTableByName this methoded used in orderTableServices file  in service folder
 * Error msg getting authermiddleware
 */
orderTableRouter.get('/search', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    // eslint-disable-next-line
    const search: any = req.query.search || "";
    try {
        const data = await getAllOrderTableByName(search);
        res.json({
            data,
            statusCode: constants.ORDERTABLE_SEARCH_SUCCESS_CODE,
            message: constants.ORDERTABLE_SEARCH_SUCCESS_MESSAGE,
            status: constants.ORDERTABLE_SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Created new  the table
 * Get new the data in the orderTable by using to created createOrderTable this methoded used in orderTableServices file  in service folder
 * Error msg getting authermiddleware
 */
orderTableRouter.post('/', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id, category_id, order_by, order_on, prod_id, status, trans_id } = req.body;
    const orderTableModal: orderTableModal = { id, category_id, order_by, order_on, prod_id, status, trans_id };
    try {
        await createOrderTable(orderTableModal);
        res.json({
            statusCode: constants.ORDERTABLE_POST_SUCCESS_CODE,
            message: constants.ORDERTABLE_POST_SUCCESS_MESSAGE,
            status: constants.ORDERTABLE_SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Update the table by using id only
 * Get edit  the data in the orderTable by using to created getOrderTableById and putOrderTable this methoded used in orderTableServices file  in service folder
 * Error msg getting authermiddleware
 */
orderTableRouter.put('/putUpdate/:id', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    const { category_id, order_by, order_on, prod_id, status, trans_id }: orderTableModal = req.body;
    const orderTableModal: orderTableModal = { id, category_id, order_by, order_on, prod_id, status, trans_id };
    const data = await getOrderTableById(id);
    try {
        if (data.count != 0) {
            await putOrderTable(orderTableModal);
            res.json({
                statusCode: constants.ORDERTABLE_PUT_SUCCESS_CODE,
                message: constants.ORDERTABLE_PUT_SUCCESS_MESSAGE,
                status: constants.ORDERTABLE_SUCCESS_STATUS
            })
        } else {
            res.json({
                statusCode: constants.NO_ORDERTABLE_PUT_CODE,
                message: constants.NO_ORDERTABLE_PUT_MESSAGE,
                status: constants.ORDERTABLE_FAIL_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
/**
 * Delete the table by using id only 
 * Get delete the data in the orderTable by using to created getOrderTableById and deleteOrderTableById this methoded used in orderTableServices file  in service folder
 * Error msg getting authermiddleware
 */
orderTableRouter.delete('/:id', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    try {
        const data = await getOrderTableById(id);
        if (data.count != 0) {
            await deleteOrderTableById(id);
            res.json({
                statusCode: constants.DELETE_ORDERTABLE_SUCCESS_CODE,
                message: constants.DELETE_ORDERTABLE_SUCCESS_MESSAGE,
                status: constants.ORDERTABLE_SUCCESS_STATUS
            });
        }
        else {
            res.json({
                statusCode: constants.NO_ORDERTABLEDELETE_NO_FOUND_CODE,
                message: constants.NO_ORDERTABLEDELETE_NO_FOUND_MESSAGE,
                status: constants.ORDERTABLE_FAIL_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});

export default orderTableRouter;