import express, { Request, Response, NextFunction } from 'express';
import { getAllProducts, getAllProductsByProductsName, createProduct, getProductById, putProduct, deleteProductById } from '../service/productsServices';
import constants from '../config/constant';

import productsValidaters from '../validater/productsValidator';
import { Prod } from '../modal/prodModal';
import autherMiddleware from './../middleware/authMiddleware';
/**
 * Router created by products
 */
const productsRouter: express.Router = express.Router();
/**
 * Get all data in the table
 * Get all data in products table using to created getAllProducts this  methoded used in productsServices file  in service folder
 * Error msg getting authermiddleware
 */
productsRouter.get('/', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
        const data = await getAllProducts();
        res.json({
            data,
            statusCode: constants.PRODUCTS_FECTHED_SUCCESS_CODE,
            message: constants.PRODUCTS_FECTHED_SUCCESS_MESSAGE,
            status: constants.PRODUCTS_SUCCESS_STATUS
        })
    } catch (err) {
        next(err)
    }
});
/**
 * Search by prod_name only  
 * Get search data in the products table using to created getAllProductsByProductsName this  methoded used in productsServices file  in service folder
 * Error msg getting authermiddleware
 */
productsRouter.get('/search', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    // eslint-disable-next-line
    const search: any = req.query.search || "";
    try {
        const data = await getAllProductsByProductsName(search);
        res.json({
            data,
            statusCode: constants.PRODUCTS_SEARCH_SUCCESS_CODE,
            message: constants.PRODUCTS_SEARCH_SUCCESS_MESSAGE,
            status: constants.PRODUCTS_SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Get post new  data in the table
 * Get post new data in the products table using to created createProduct this methoded used in productsServices file  in service folder
 * Error msg getting authermiddleware
 * Products for productsValidaters(pro_id,cat_id,exp_date,manu_date,prod_name,quantity)
 */
productsRouter.post('/', productsValidaters(), autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { pro_id, cat_id, exp_date, manu_date, prod_name, quantity } = req.body;
    const product: Prod = { pro_id, cat_id, exp_date, manu_date, prod_name, quantity };
    try {
        await createProduct(product);
        res.json({
            statusCode: constants.PRODUCTS_POST_SUCCESS_CODE,
            message: constants.PRODUCTS_POST_SUCCESS_MESSAGE,
            status: constants.PRODUCTS_SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Gt edit  data  in the table
 * get edit the data in the products table using to created getProductById and putProduct this methoded used in productsServices file  in service folder
 * Error msg getting authermiddleware
 */

productsRouter.put('/putUpdate/:pro_id', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { pro_id } = req.params;
    const { cat_id, exp_date, manu_date, prod_name, quantity }: Prod = req.body;
    const product: Prod = { pro_id, cat_id, exp_date, manu_date, prod_name, quantity };
    const data = await getProductById(pro_id);
    try {
        if (data.count != 0) {
            await putProduct(product);
            res.json({
                statusCode: constants.PRODUCTS_UPDATE_SUCCESS_CODE,
                message: constants.PRODUCTS_UPDATE_SUCCESS_MESSAGE,
                status: constants.PRODUCTS_SUCCESS_STATUS
            })
        } else {
            res.json({
                statusCode: constants.NO_PRODUCTS_UPDATE_CODE,
                message: constants.NO_PRODUCTS_UPDATE_MESSAGE,
                status: constants.PRODUCTS__UPDATE_SUCCESS_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
/**
 * Get delete data  in the table by id 
 * Get delete the data in the products table using to created getProductById and deleteProductById this methoded used in productsServices file  in service folder
 * Error msg getting authermiddleware
 */

productsRouter.delete('/:pro_id', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { pro_id } = req.params;
    try {
        const data = await getProductById(pro_id);
        if (data.count != 0) {
            await deleteProductById(pro_id);
            res.json({
                statusCode: constants.DELETE_PRODUCT_FOUNT_SUCCESS_CODE,
                message: constants.DELETE_PRODUCT_FOUNT_SUCCESS_MESSAGE,
                status: constants.DELETE_SUCCESS_STATUS
            });
        }
        else {
            res.json({
                statusCode: constants.NO_PRODUCTSDELETE_NO_FOUND_CODE,
                message: constants.NO_PRODUCTSDELETE_NO_FOUND_MESSAGE,
                status: constants.NO_PRODUCTS_SUCCESS_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});

export default productsRouter;