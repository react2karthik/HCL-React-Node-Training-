import express, { Request, Response } from 'express';
import request from 'request';
const externalApiRouter: express.Router = express.Router();
/**
 * This dynamic data creating tabel 
 */

externalApiRouter.get('/', async (req: Request, res: Response) => {
    // eslint-disable-next-line
    await request('https://reqres.in/api/user?page=2', function (_error: any, response) {
        res.send(JSON.parse(response.body))
    })
    res.end();
})
export default externalApiRouter;