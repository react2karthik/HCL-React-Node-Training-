import express, { NextFunction, Request, Response } from 'express';
import { getAllCategories, getAllCategoriesByCatrgoryName, getCategoriesById, deleteCategoriesById, createCategory, putCategories } from '../service/categoryServices';
import constants from '../config/constant';
import categoriesValidator from '../validater/categoriesValidator';
import { Category } from '../modal/categoryModal';
import autherMiddleware from './../middleware/authMiddleware';
/**
 * Router created by categories
 */
const categoriesRouter: express.Router = express.Router();
/**
 * Get all data in the table
 * Get the data in the categorie table by using to created getAllCategories this methoded used in categoryServices file  in service folder
 * Error msg getting authermiddleware
*/
categoriesRouter.get('/', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    try {
        const data = await getAllCategories();
        res.json({
            data,
            statusCode: constants.CATEGORY_FECTHED_SUCCESS_CODE,
            message: constants.CATEGORY_FECTHED_SUCCESS_MESSAGE,
            status: constants.CATEGORY_SUCCESS_STATUS
        })
    } catch (err) {
        next(err)
    }
});
/**
 * Get search data in the table by category_name only
 * Get the data in the categorie table by using to created getAllCategoriesByCatrgoryName this methoded used in categoryServices file  in service folder
 * Error msg getting authermiddleware
*/
categoriesRouter.get('/search', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    // eslint-disable-next-line
    const search: any = req.query.search || "";
    try {
        const data = await getAllCategoriesByCatrgoryName(search);
        res.json({
            data,
            statusCode: constants.CATEGORY_SEARCH_SUCCESS_CODE,
            message: constants.CATEGORY_SEARCH_SUCCESS_MESSAGE,
            status: constants.CATEGORY_SEARCH_SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Get post new  data in the table
 * Get the data in the categorie table by using to created createCategory this methoded used in categoryServices file  in service folder
 * Error msg getting authermiddleware
*/
categoriesRouter.post('/', categoriesValidator(), autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    console.log('req.body,req.method,req.path',req.body,req.method,req.path)
    const { id, category_name, category_description } = req.body;
    const category1: Category = { id, category_name, category_description };
    try {
        await createCategory(category1);
        res.json({
            statusCode: constants.CATEGORY_POST_SUCCESS_CODE,
            message: constants.CATEGORY_POST_SUCCESS_MESSAGE,
            status: constants.CATEGORY_POST_SUCCESS_STATUS
        })
    } catch (error) {
        next(error)
    }
});
/**
 * Gt edit  data  in the table
 * Get the data in the categorie table by using to created getCategoriesById and putCategories this methoded used in categoryServices file  in service folder
 * Error msg getting authermiddleware
*/
categoriesRouter.put('/putUpdate/:id', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    const { category_name, category_description }: Category = req.body;
    const category: Category = { id, category_description, category_name };
    const data = await getCategoriesById(id);
    try {
        if (data.count != 0) {
            await putCategories(category);
            res.json({
                statusCode: constants.CATEGORY_UPDATE_SUCCESS_CODE,
                message: constants.CATEGORY_UPDATE_SUCCESS_MESSAGE,
                status: constants.CATEGORY_UPDATE_SUCCESS_STATUS
            })
        } else {
            res.json({
                statusCode: constants.CATEGORY_NOTUPDATE_FOUND_CODE,
                message: constants.CATEGORY_NOTUPDATE_FOUND_MESSAGE,
                status: constants.SUCCESS_NOTUPDATE_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});
/**
 * Get delete data  in the table by id 
 * Get the data in the categorie table by using to created getCategoriesById and deleteCategoriesById this methoded used in categoryServices file  in service folder
 * Error msg getting authermiddleware
*/
categoriesRouter.delete('/:id', autherMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { id } = req.params;
    try {
        const data = await getCategoriesById(id);
        if (data.count != 0) {
            await deleteCategoriesById(id);
            res.json({
                statusCode: constants.DELETE_CATEGORY_SUCCESS_CODE,
                message: constants.DELETE_CATEGORY_SUCCESS_MESSAGE,
                status: constants.SUCCESS_STATUS
            });
        }
        else {
            res.json({
                statusCode: constants.DELETE_CATEGORY_NOT_FOUNT_CODE,
                message: constants.DELETE_CATEGORY_NOT_FOUNT_MESSAGE,
                status: constants.SUCCESS_NOT_FOUNT_STATUS
            })
        }
    } catch (error) {
        next(error)
    }
});

export default categoriesRouter




