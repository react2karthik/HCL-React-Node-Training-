/*
//login and register modal interface using(id,email,name,phone,psw)
 */
export interface userModal{
    id:string;
    email:string;
    name:string;
    phone:number;
    psw:string;
}