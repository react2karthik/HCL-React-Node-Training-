/**
 * Product modal interface using(pro_id,cat_id,exp_date,manu_date,prod_name,quantity)
 */
export interface Prod{
    pro_id:string;
    cat_id:string;
    exp_date:number;
    manu_date:number;
    prod_name:string;
    quantity:number;
    // description:string;
}