/**
 * OrderTableModal modal interface using(id,category_id,order_by,order_on,prod_id,status,trans_id)
 */
export interface orderTableModal {
    id: string;
    category_id: string;
    order_by: number;
    order_on: number;
    prod_id: number;
    status: string;
    trans_id: number
}


