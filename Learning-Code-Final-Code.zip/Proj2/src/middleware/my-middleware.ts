import { Request, Response, NextFunction } from "express";
/**
 * 
 * @param req 
 * @param res 
 * @param next 
 * custome middleware
 */
const myMiddleware = (req: Request, res: Response, next: NextFunction) => {
   const requestTime = Date.now();
   next();
}
export default myMiddleware;