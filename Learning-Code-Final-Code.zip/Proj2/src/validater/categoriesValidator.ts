import { body } from "express-validator";
/**
 * Categories for uservalidater(id,category_name,category_description)
 * @returns 
 */
const categoriesValidator = () => {
    return [
        body('id').exists().withMessage('categories id need'),
        body('category_name').exists().isLength({ min: 5 }).trim().withMessage('categories name need'),
        body('category_description').exists().isLength({ min: 5 }).trim().withMessage('categories name need')
    ]
}
export default categoriesValidator;