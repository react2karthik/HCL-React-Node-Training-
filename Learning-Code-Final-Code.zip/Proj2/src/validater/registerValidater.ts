import { body } from 'express-validator';
/**
 * Register for uservalidater(name,email,psw)
 * @returns 
 */
const registerValidator = () => {
    return [
        body("name").exists().bail().isLength({ min: 5 }).trim().withMessage('name is required'),
        body("email").exists().bail().withMessage("email is required").isEmail().withMessage('Invalid emailId please enter correct'),
        body("psw").exists().bail().withMessage('Psw will be alphanumeric only').bail().isAlphanumeric().withMessage("PSW will be  apl").isLength({ min: 3, max: 8 }).withMessage("psw should be min 3 and max 8"),
    ]
}
export default registerValidator;