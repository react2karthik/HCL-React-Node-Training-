import { body } from "express-validator";
/*
//login for uservalidater(id)
*/
const employeeValidator = () => {
   return [
      body('id').exists().withMessage("categories id need"),
   ]
}
export default employeeValidator;
