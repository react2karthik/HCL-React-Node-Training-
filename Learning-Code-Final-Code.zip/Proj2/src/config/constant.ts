const constants = {
    ACCESS_DENIED_MESSAGE: 'Access denied',
    ACCESS_DENIED_CODE: 4000,
    /*----------CATEGORY START--------------*/
    CATEGORY_FECTHED_SUCCESS_CODE: 1000,
    CATEGORY_FECTHED_SUCCESS_MESSAGE: 'Categories fetched all successfuly',
    CATEGORY_SUCCESS_STATUS: 'Success',
    /**
     * @Search
     */
    CATEGORY_SEARCH_SUCCESS_CODE: 1001,
    CATEGORY_SEARCH_SUCCESS_MESSAGE: 'Category Search fetched successfuly',
    CATEGORY_SEARCH_SUCCESS_STATUS: 'fetched successfuly',
    /**
     * @post
    */
    CATEGORY_POST_SUCCESS_CODE: 1002,
    CATEGORY_POST_SUCCESS_MESSAGE: 'New Post Categories added  successfuly',
    CATEGORY_POST_SUCCESS_STATUS: 'Post added successfuly',
    /**
     * @upate
     */
    CATEGORY_UPDATE_SUCCESS_CODE: 1003,
    CATEGORY_UPDATE_SUCCESS_MESSAGE: 'Update Categories successfuly',
    CATEGORY_UPDATE_SUCCESS_STATUS: 'Update successfuly',

    CATEGORY_NOTUPDATE_FOUND_CODE: 1004,
    CATEGORY_NOTUPDATE_FOUND_MESSAGE: 'Categories Not Update',
    SUCCESS_NOTUPDATE_STATUS: 'Not Update',
    /**
     * @deleted
     */
    DELETE_CATEGORY_SUCCESS_CODE: 1005,
    DELETE_CATEGORY_SUCCESS_MESSAGE: 'Delete Categories successfuly',
    SUCCESS_STATUS: 'Delete successfuly',

    DELETE_CATEGORY_NOT_FOUNT_CODE: 1006,
    DELETE_CATEGORY_NOT_FOUNT_MESSAGE: 'Delete Categories successfuly',
    SUCCESS_NOT_FOUNT_STATUS: 'Fail',

    /*----------CATEGORY END--------------*/

    /*----------PRODUCTS START--------------*/
    /**
     * @PRODUCTS
     */

    PRODUCTS_FECTHED_SUCCESS_CODE: 1007,
    PRODUCTS_FECTHED_SUCCESS_MESSAGE: 'Products fetched all successfuly',
    /**
     * @Get
     */
    PRODUCTS_SEARCH_SUCCESS_CODE: 1008,
    PRODUCTS_SEARCH_SUCCESS_MESSAGE: 'Products search successfuly',
    /**
      * @Post
      */
    PRODUCTS_POST_SUCCESS_CODE: 1009,
    PRODUCTS_POST_SUCCESS_MESSAGE: 'Products Post successfuly',
    /**
      * @Update
      */
    PRODUCTS_UPDATE_SUCCESS_CODE: 1010,
    PRODUCTS_UPDATE_SUCCESS_MESSAGE: 'Products Update successfuly',
    PRODUCTS_SUCCESS_STATUS: 'Success',


    NO_PRODUCTS_UPDATE_CODE: 1011,
    NO_PRODUCTS_UPDATE_MESSAGE: 'Products No Update',
    PRODUCTS__UPDATE_SUCCESS_STATUS: 'Fail',
    /**
      * @Deleted
      */
    DELETE_PRODUCT_FOUNT_SUCCESS_CODE: 1012,
    DELETE_PRODUCT_FOUNT_SUCCESS_MESSAGE: 'Products Deleted  successfuly',
    DELETE_SUCCESS_STATUS: 'successfuly',

    NO_PRODUCTSDELETE_NO_FOUND_CODE: 1013,
    NO_PRODUCTSDELETE_NO_FOUND_MESSAGE: 'Products No Found',
    NO_PRODUCTS_SUCCESS_STATUS: 'Fail',
    /*----------PRODUCTS END--------------*/

    /*---------USER START --------*/
    /**
     * @USER
     */
    USER_FECTHED_SUCCESS_CODE: 1014,
    USER_FECTHED_SUCCESS_MESSAGE: 'User fetched all successfuly',
    USER_SUCCESS_STATUS: 'successfuly',

    USER_SEARCH_SUCCESS_CODE: 1015,
    USER_SEARCH_SUCCESS_MESSAGE: 'User Search successfuly',

    /**
   * @Post
   */
    USER_POST_SUCCESS_CODE: 1015,
    USER_POST_SUCCESS_MESSAGE: 'User Data posted edited successfuly',

    /**
   * @Put
   */
    USER_UPDATE_SUCCESS_CODE: 1016,
    USER_UPDATE_SUCCESS_MESSAGE: 'User details edit update successfult',

    NO_USER_FOUND_CODE: 1017,
    NO_USER_FOUND_MESSAGE: 'User details not update fail',
    USER_FAIL_SUCCESS_STATUS: 'Fail',

    /**
    * @Delete
    */
    DELETE_USER_SUCCESS_CODE: 1018,
    DELETE_USER_SUCCESS_MESSAGE: 'User details deleted successfuly',

    NO_USERDELETE_NO_FOUND_CODE: '1019',
    NO_USERDELETE_NO_FOUND_MESSAGE: 'User details not deleted',

    /*-------- USER ENT -------*/

    /*-------- ORDER START -------*/

    /**
     * @Order
     */
    ORDERTABLE_FECTHED_SUCCESS_CODE: 1019,
    ORDERTABLE_FECTHED_SUCCESS_MESSAGE: 'Order fetched all successfuly',
    ORDERTABLE_SUCCESS_STATUS: 'Success',
    /**
     * @Order
     */
    ORDERTABLE_SEARCH_SUCCESS_CODE: 1020,
    ORDERTABLE_SEARCH_SUCCESS_MESSAGE: 'Order Search date get successfuly',

    /**
     * @Post
     */
    ORDERTABLE_POST_SUCCESS_CODE: '1020',
    ORDERTABLE_POST_SUCCESS_MESSAGE: 'Order  data  added successfuly',
    /**
   * @Put
   */
    ORDERTABLE_PUT_SUCCESS_CODE: 1021,
    ORDERTABLE_PUT_SUCCESS_MESSAGE: 'Order data edit and update successfuly',

    NO_ORDERTABLE_PUT_CODE: '1022',
    NO_ORDERTABLE_PUT_MESSAGE: 'No Data',
    ORDERTABLE_FAIL_STATUS: 'Fail',
    /**
     * @Delete
     */
    DELETE_ORDERTABLE_SUCCESS_CODE: '1023',
    DELETE_ORDERTABLE_SUCCESS_MESSAGE: 'Order data successfuly',
    NO_ORDERTABLEDELETE_NO_FOUND_CODE: 1024,
    NO_ORDERTABLEDELETE_NO_FOUND_MESSAGE: 'Order Not deleted',
    /*-------- ORDER ENT -------*/

    /*------CART START-----*/
    /**
     * @Cart
     */
    CART_FECTHED_SUCCESS_CODE: 1024,
    CART_FECTHED_SUCCESS_MESSAGE: 'Cart fetched all successfuly',
    CART_SUCCESS_STATUS: 'successfuly',

    CART_SEARCH_SUCCESS_CODE: 1025,
    CART_SEARCH_SUCCESS_MESSAGE: 'Cart Search successfuly',
    /**
     * @Post
     */
    CART_POST_SUCCESS_CODE: 1026,
    CART_POST_SUCCESS_MESSAGE: 'Cart Data added successfuly',
    /**
     * @Put
     */

    CART_UPDATE_SUCCESS_CODE: 1027,
    CART_UPDATE_SUCCESS_MESSAGE: 'Cart Data Update successfuly',

    NO_CART_UPDATE_CODE: 1028,
    NO_CART_UPDATE__MESSAGE: 'Not founded',
    CART_FAIL_STATUS: 'Fail',
    /**
         * @Delete
         */
    DELETE_CART_SUCCESS_CODE: 1029,
    DELETE_CART_SUCCESS_MESSAGE: 'Cart deleted successfuly',

    NO_CARTDELETE_NO_FOUND_CODE: 1030,
    NO_CARTDELETE_NO_FOUND_MESSAGE: 'Cart not deleted',
    /*-----CART END ----*/

    //Register API
    USER_REGISTERED_SUCCESS_MESSAGE: 'User Registered Successfuly',
    USER_REGISTERED_SUCCESS_CODE: 1031,

    USER_NOT_EXIST_MESSAGE: "User not exist",
    USER_NOT_EXIT_CODE: 1032
}
export default constants;
