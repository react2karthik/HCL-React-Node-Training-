import dotenv from 'dotenv';
import { Client } from 'cassandra-driver';
dotenv.config();
/**
 * Dp Client 
 * DB name keyspace,datacenter,host
 * connect
 * shutdown
 */
const client = new Client({
   contactPoints: [process.env.HOSTNAME || ""],
   localDataCenter: process.env.DATACENTER || "",
   keyspace: process.env.KEYSPACE || ""
})

client.connect(() => {
   console.log("db connected")
});
client.shutdown(() => {
   console.log("db shoutdown")
})
export default client;