/**
 * @nodatafound 
 * msg :  message et from dynmaic
 * status:Status code get from dynmaic
 */
export class NoDataFoundError extends Error {
    statusCode: number;
    constructor(msg: string, code: number) {
        super();
        this.message = msg;
        this.statusCode = code;
    }
}