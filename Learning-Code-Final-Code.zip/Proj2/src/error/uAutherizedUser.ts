/**
 * Unknow entery we send error message
 * message : message et from dynmaic
 * status :Status code get from dynmai
 */

export class UnAuthorizedAccess extends Error {
    status: number;
    constructor(message: string, status: number) {
        super();
        this.message = message;
        this.status = status;
    }
}