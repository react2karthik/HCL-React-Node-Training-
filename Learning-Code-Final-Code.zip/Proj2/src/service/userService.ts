import client from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import { userModal } from './../modal/userModal';
/**
 * Get all userrouter data
 * @returns 
 */
const getAllUserRouter = async () => {
    const result = await client.execute('select * from userrouter');
    if (result.rowLength === 0) {
        throw new NoDataFoundError("No Category found", 1000);
    } else
        return result.rows;
};
/**
 * Search userrouter data  by using name
 */
/**
 * Search userrouter data  by using name
 */
const getAllUserByCatrgoryName = async (search: string) => {
    const result = await client.execute(`select * from userrouter where name='${search}' ALLOW FILTERING`);
    return result.rows;
}
/**
 * Edit and update userservice data  by using id
 * @param id 
 * @returns 
 */
const getUserById = async (id: string | number) => {
    const query = `select count(id) as count from userrouter where id=${id}`;
    const result = await client.execute(query);
    return result.first();
}
/**
 * Created new userrouter data  by using 
 * @param userrouter 
 */
const createUser = async (userrouter: userModal) => {
    const query = `insert into userrouter(id,name,email,phone,psw) values(${userrouter.id},'${userrouter.name}','${userrouter.email}',${userrouter.phone},'${userrouter.psw}')`;
    await client.execute(query)
}
/**
 * Edit and update categories data  by using id
 * @param userrouter 
 */

const putUsers = async (userrouter: userModal) => {
    const query = `update userrouter set name='${userrouter.name}',
    email='${userrouter.email}',psw='${userrouter.psw}',phone='${userrouter.phone}' where id=${userrouter.id};`;
    await client.execute(query)
}
/**
 * Delete userrouter 
 * @param id 
 */
const deleteUserById = async (id: string | number) => {
    const query = `delete from userrouter where id=${id} `;
    await client.execute(query)
}
/**
 * Created new registeruser data  by using 
 */

const registerUser = async (id: number, name: string, email: string, psw: string) => {
    const result = await client.execute(`insert into userrouter(id,name,email,psw) values(${id},'${name}','${email}','${psw}')`)
    return result;
}
/**
 * Created new loginuser data  by using 
 * @param email 
 * @returns 
 */
const loginUser = async (email: string) => {
    const result = await client.execute(`select email , psw from userrouter where email='${email}' allow filtering`);
    return result;
}
export { getAllUserRouter, getAllUserByCatrgoryName, getUserById, createUser, putUsers, deleteUserById, registerUser, loginUser };