import client from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import { orderTableModal } from './../modal/orderTableModal';
/**
 * Get all order table data 
 * @returns 
 */
const getAllOrterTableRouter = async () => {
    const result = await client.execute('select * from order_table');
    if (result.rowLength === 0) {
        throw new NoDataFoundError("No Order found", 1000);
    } else
        return result.rows;
};
/**
 * Search order table data  by using category_id
 * @param search 
 * @returns 
 */
const getAllOrderTableByName = async (search: string) => {
    const result = await client.execute(`select * from order_table where category_id=${search} ALLOW FILTERING`);
    return result.rows;
}
/**
 * Edit and update order table data  by using id
 * @param id 
 * @returns 
 */
const getOrderTableById = async (id: string | number) => {
    const query = `select count(id) as count from order_table where id=${id}`;
    const result = await client.execute(query);
    return result.first();
}
/**
 * Created new order table data  by using
 * @param orderTablerouter 
 */
const createOrderTable = async (orderTablerouter: orderTableModal) => {
    const query = `insert into order_table(id,category_id,order_by,order_on,prod_id,status,trans_id) values(${orderTablerouter.id},${orderTablerouter.category_id},'${orderTablerouter.order_by}','${orderTablerouter.order_on}',${orderTablerouter.prod_id},'${orderTablerouter.status}',${orderTablerouter.trans_id})`;
    await client.execute(query)
}
/**
 * Edit and update orderTabel data  by using id
 * @param orderTablerouter 
 */
const putOrderTable = async (orderTablerouter: orderTableModal) => {
    const query = `update order_table set category_id=${orderTablerouter.category_id},order_by='${orderTablerouter.order_by}',order_on='${orderTablerouter.order_on}',prod_id=${orderTablerouter.prod_id},status='${orderTablerouter.status}',trans_id=${orderTablerouter.trans_id} where id=${orderTablerouter.id};`;
    await client.execute(query)
}
/**
 * Delete order table 
 * @param id 
 */
const deleteOrderTableById = async (id: string | number) => {
    const query = `delete from order_table where id=${id} `;
    await client.execute(query)
}
export { getAllOrterTableRouter, getAllOrderTableByName, getOrderTableById, createOrderTable, putOrderTable, deleteOrderTableById };