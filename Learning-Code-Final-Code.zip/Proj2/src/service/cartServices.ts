import client from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import { cartModal } from './../modal/cartModal';

/**
 * Cart get all data in table to show
 * @returns 
 * NoDataFoundError for error message
 */
const getAllCartRouter = async () => {
    const result = await client.execute('select * from cart');
    if (result.rowLength === 0) {
        throw new NoDataFoundError("No Category found", 1000);
    } else
        return result.rows;
};
/**
 * Cart search data for using product_id
 * @param search 
 * @returns 
 */
const getAllUserByCardName = async (search: string) => {
    const result = await client.execute(`select * from cart where product_id=${search} ALLOW FILTERING`);
    return result.rows;
}
/**
 * Cart edit by using id data
 * @param id 
 * @returns 
 */
const getCartById = async (id: string | number) => {
    const query = `select count(id) as count from cart where id=${id}`;
    const result = await client.execute(query);
    return result.first();
}
/**
 * Added new data in table
 * @param cartrouter 
 */
const createCart = async (cartrouter: cartModal) => {
    const query = `insert into cart(id,added_by,added_on,category_id,price,product_id,quantity) values(${cartrouter.id},'${cartrouter.added_by}','${cartrouter.added_on}',${cartrouter.category_id},${cartrouter.price},${cartrouter.product_id},${cartrouter.quantity})`;
    await client.execute(query)
}
/**
 * Edit  and update cart data 
 * @param cartrouter 
 */
const putCart = async (cartrouter: cartModal) => {
    const query = `update cart set added_by='${cartrouter.added_by}',added_on='${cartrouter.added_on}',category_id=${cartrouter.category_id},price=${cartrouter.price},product_id=${cartrouter.product_id},quantity=${cartrouter.quantity} where id=${cartrouter.id};`;
    await client.execute(query)
}
/**
 * Delete cart
 * @param id 
 */
const deleteCartById = async (id: string | number) => {
    const query = `delete from cart where id=${id} `;
    await client.execute(query)
}
export { getAllCartRouter, getAllUserByCardName, getCartById, createCart, putCart, deleteCartById };