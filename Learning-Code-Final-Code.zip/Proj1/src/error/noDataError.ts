export class NoDataFoundError extends Error{
    statusCode:Number;
    constructor(msg:string,code:Number){
        super();
        this.message = msg;
        this.statusCode = code;
    }
}