export class UnAuthorizedAccess extends Error {
    status:Number;
    constructor(message:string,status:Number){
        super();
        this.message  = message;
        this.status = status;
    }
}