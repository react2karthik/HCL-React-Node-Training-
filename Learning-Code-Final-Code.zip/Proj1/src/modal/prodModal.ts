export interface Prod{
    pro_id:string;
    cat_id:string;
    exp_date:number;
    manu_date:number;
    prod_name:string;
    quantity:number;
    // description:string;
}