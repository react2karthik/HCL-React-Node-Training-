export interface Category{
    id:string;
    name:string;
}
export interface employe{
    id:string;
    productName:string;
    price:number;
    emdescription:string;
    image:string
}