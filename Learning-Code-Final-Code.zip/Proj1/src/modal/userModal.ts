export interface userModal{
    id:string;
    email:string;
    name:string;
    phone:number;
    psw:string;
}