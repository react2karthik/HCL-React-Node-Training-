export interface Category{
    //id:string;
    category_name:string;
    category_description:string
}