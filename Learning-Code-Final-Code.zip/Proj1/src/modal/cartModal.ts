export interface cartModal{
    id:string;
    added_by:string;
    added_on:number;
    category_id:number;
    price:number;
    product_id:number;
    quantity:number
}
