export interface employe{
    id:string;
    productName:string;
    age:number;
    salary:number;
    empCode:string;
    reportsTo:string
}