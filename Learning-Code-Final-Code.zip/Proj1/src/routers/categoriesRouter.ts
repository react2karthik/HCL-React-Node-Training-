import express,{NextFunction, Request,Response} from 'express';
// import {Client} from 'cassandra-driver';
import {getAllCategories,getAllCategoriesByCatrgoryName,getCategoriesById,deleteCategoriesById,createCategory,putCategories} from '../service/categoryServices';
import constants from '../config/constant';
import client from '../config/dbConfig';
import myMiddleware from '../middleware/my-middleware';
import request from 'request';
import  categoriesValidator from '../validater/categoriesValidator';
import validateMiddleware from '../middleware/validateMiddleware';
import {Category} from '../modal/categoryModal';
import { NoDataFoundError } from '../error/noDataError';
import autherMiddleware from './../middleware/authMiddleware';
const data = require('../../jsondata/categoriesData.json');
const fs = require('fs');

const categoriesRouter:express.Router = express.Router();
const Categories:Array<Category> =data;
categoriesRouter.get('/',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{  
    // let data = await getAllCategories(next);
    // res.send(data);
    try{
        let data = await getAllCategories();
        res.json({
            data,
            statusCode:constants.CATEGORY_FECTHED_SUCCESS_CODE,
            message:constants.CATEGORY_FECTHED_SUCCESS_MESSAGE,
            status:constants.CATEGORY_SUCCESS_STATUS
        })       
    }catch(err){
        next(err)
    }
});
categoriesRouter.get('/search',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{
    const search:any = req.query.search || "";
    try{
        let data = await getAllCategoriesByCatrgoryName(search);
        res.json({
            data,
            statusCode:constants.CATEGORY_SEARCH_SUCCESS_CODE,
            message:constants.CATEGORY_SEARCH_SUCCESS_MESSAGE,
            status:constants.CATEGORY_SEARCH_SUCCESS_STATUS
        })   
    }catch(error){
        next(error)
    }   
});
categoriesRouter.post('/',categoriesValidator(),autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{
    const {id,category_name,category_description} = req.body;
    const category1:Category = {category_name,category_description};
    try{
        await createCategory(category1);
        res.json({
            statusCode:constants.CATEGORY_POST_SUCCESS_CODE,
            message:constants.CATEGORY_POST_SUCCESS_MESSAGE,
            status:constants.CATEGORY_POST_SUCCESS_STATUS
        })
    }catch(error){
        next(error)
    }  
});
categoriesRouter.put('/putUpdate/:id',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{
    const {id} = req.params;
    const {category_name,category_description} :Category= req.body;
    const category:Category = {category_description,category_name};
    const data = await getCategoriesById(id);
    try{
       if(data.count != 0){
         await putCategories(category);
         res.json({
            statusCode:constants.CATEGORY_UPDATE_SUCCESS_CODE,
            message:constants.CATEGORY_UPDATE_SUCCESS_MESSAGE,
            status:constants.CATEGORY_UPDATE_SUCCESS_STATUS
        })
       }else{
        res.json({
            statusCode:constants.CATEGORY_NOTUPDATE_FOUND_CODE,
            message:constants.CATEGORY_NOTUPDATE_FOUND_MESSAGE,
            status:constants.SUCCESS_NOTUPDATE_STATUS 
        })   
       }
    }catch(error){
        next(error)
    }      
});
categoriesRouter.delete('/:id',autherMiddleware,async (req:Request,res:Response,next:NextFunction) => {
    const {id} = req.params;
    try{
        const data = await getCategoriesById(id);
        if(data.count !=0){
            await deleteCategoriesById(id);
            res.json({
                statusCode:constants.DELETE_CATEGORY_SUCCESS_CODE,
                message:constants.DELETE_CATEGORY_SUCCESS_MESSAGE,
                status:constants.SUCCESS_STATUS
            });
        }
        else{
            res.json({
            statusCode:constants.DELETE_CATEGORY_NOT_FOUNT_CODE,
            message:constants.DELETE_CATEGORY_NOT_FOUNT_MESSAGE,
            status:constants.SUCCESS_NOT_FOUNT_STATUS 
        })       
        } 
    }catch(error){
        next(error)
    }   
});

// categoriesRouter.get('/search',async(req:Request,res:Response,next:NextFunction)=>{
//     const {search} = req.query;
//     try{
//         let result = await client.execute(`select * from category where category_name ='${search}' `);
//         console.log("result",result);
//         res.send(result.rows);
//         if(result.rowLength === 0) {
//             throw new NoDataFoundError('No Category found for given search criteria',1001);        
//         }else{
//             res.send(result.rows);
//         }
//     }catch(error){
//         next(error)
//     }   
// });
// categoriesRouter.get('/:id',(req:Request,res:Response)=>{
//     const {id} = req.params;
//     const data = Categories.filter((item)=> item.id == id);
//     res.send(data);
//     res.end();
// });
// categoriesRouter.put('/:id',(req:Request,res:Response)=>{
//     const {id} = req.params;
//     const data = Categories.filter((item)=> item.id != id);
//     const categoriePut=[...data,req.body];
//     const jsonCatPut = JSON.stringify(categoriePut,null,1);
//     fs.writeFile('./jsondata/categoriesData.json',jsonCatPut,(err:any)=>{
//         if(err){
//             console.log(err);
//         }else{
//             console.log(`Categorie ${id} Update Successfully`);
//         }
//         res.send(categoriePut);
//     })
// });
// categoriesRouter.post('/',categoriesValidator(),validateMiddleware,(req:Request,res:Response)=>{
//     // const {id} = req.params;
//     // const data = Categories.filter((item)=> item.id != id);
//     const dataCate= Object.assign([...Categories,req.body]);
//     const jsonCatPut = JSON.stringify(dataCate,null,1);
//     fs.writeFile('./jsondata/categoriesData.json',jsonCatPut,(err:any)=>{
//         if(err){
//             console.log(err);
//         }else{
//             console.log(`Categorie te Successfully`);
//         }
//         res.send(dataCate);
//         res.end();
//     })
// });
// categoriesRouter.delete('/:id',(req:Request,res:Response)=>{
//     const {id} = req.params;
//     const data = Categories.filter((item)=> item.id != id);
//     const jsonCategories = JSON.stringify(data,null,1);
//     fs.writeFile('./jsondata/categoriesData.json',jsonCategories,(err:any)=>{
//         if(err){
//             console.log(err);
//         }else{
//             console.log(`deleted Successfully`);
//         }
//         res.send(jsonCategories);
//     })
// });

export default categoriesRouter




