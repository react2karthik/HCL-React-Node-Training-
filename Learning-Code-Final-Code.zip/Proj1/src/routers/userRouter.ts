import express,{Request,Response,NextFunction} from 'express';
import {getAllUserRouter,getAllUserByCatrgoryName,getUserById,createUser,putUsers,deleteUserById,registerUser,loginUser} from '../service/userService';
import constants from '../config/constant';
import validateMiddleware from '../middleware/validateMiddleware';
import userValidator from '../validater/userValidater';
import {userModal} from '../modal/userModal';
import { register } from 'module';
import registerValidator from './../validater/registerValidater';
import loginValidator from './../validater/loginValidator';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import {UnAuthorizedAccess} from './../error/uAutherizedUser';
import autherMiddleware from './../middleware/authMiddleware';

const userRouter : express.Router= express.Router();

userRouter.post('/login',loginValidator(),async(req:Request,res:Response,next:NextFunction)=>{
    const {email,psw} =req.body;
    const result =  await loginUser(email);
    if(result.first() != null){
        const isMatching= await bcrypt.compare(psw,result.first().get('psw'))
        if(isMatching){
            const token = jwt.sign({email},'sridhar',{expiresIn:'2h'});
            res.json({
                status:constants.ORDERTABLE_SUCCESS_STATUS,
                data:token
            })
        }else{
            try{
                throw new UnAuthorizedAccess(constants.ACCESS_DENIED_MESSAGE,constants.ACCESS_DENIED_CODE)
            }catch(err){
                next(err)
            }            
        }
    }else{
        res.json({
            message:constants.USER_NOT_EXIST_MESSAGE,
            code:constants.USER_NOT_EXIT_CODE,
            status:constants.CART_FAIL_STATUS,
            data:email
        })
    }
})
userRouter.post('/register',registerValidator(),async(req:Request,res:Response,next:NextFunction)=>{
    const {id,name,email,psw} = req.body;
    try{
        const hashedPwd = await bcrypt.hash(psw,10);
        console.log(hashedPwd);
        const data = await registerUser(id,name,email,hashedPwd);
        res.json({
            message:constants.USER_REGISTERED_SUCCESS_MESSAGE,
            code:constants.USER_REGISTERED_SUCCESS_CODE,
            status:constants.CATEGORY_SUCCESS_STATUS
        })
    }catch(err){
        next(err);
    }
})
// userRouter.get('/',async(req:Request,res:Response,next:NextFunction)=>{  
//     try{
//         let data = await getAllUserRouter();
//         res.json({
//             data,
//             statusCode:constants.USER_FECTHED_SUCCESS_CODE,
//             message:constants.USER_FECTHED_SUCCESS_MESSAGE,
//             status:constants.USER_SUCCESS_STATUS
//         })       
//     }catch(err){
//         next(err)
//     }
// });
// userRouter.get('/search',async(req:Request,res:Response,next:NextFunction)=>{
//     const search:any = req.query.search || "";    
//     try{
//         let data = await getAllUserByCatrgoryName(search);
//         res.json({
//             data,
//             statusCode:constants.USER_SEARCH_SUCCESS_CODE,
//             message:constants.USER_SEARCH_SUCCESS_MESSAGE,
//             status:constants.USER_SUCCESS_STATUS
//         })   
//     }catch(error){
//         next(error)
//     }   
// });
// userRouter.post('/',userValidator(),async(req:Request,res:Response,next:NextFunction)=>{
//     const {id,email,name,phone,psw,} = req.body;
//     const usermodal:userModal = {id,email,name,phone,psw};
//     try{
//         await createUser(usermodal);
//         res.json({
//             statusCode:constants.USER_POST_SUCCESS_CODE,
//             message:constants.USER_POST_SUCCESS_MESSAGE,
//             status:constants.USER_SUCCESS_STATUS
//         })
//     }catch(error){
//         next(error)
//     }  
// });
// userRouter.put('/putUpdate/:id',async(req:Request,res:Response,next:NextFunction)=>{
//     const {id} = req.params;
//     const {email,name,phone,psw} :userModal= req.body;
//     const usermodal:userModal = {id,email,name,phone,psw};
//     const data = await getUserById(id);
//     try{
//        if(data.count != 0){
//          await putUsers(usermodal);
//          res.json({
//             statusCode:constants.USER_UPDATE_SUCCESS_CODE,
//             message:constants.USER_UPDATE_SUCCESS_MESSAGE,
//             status:constants.USER_SUCCESS_STATUS
//         })
//        }else{
//         res.json({
//             statusCode:constants.NO_USER_FOUND_CODE,
//             message:constants.NO_USER_FOUND_MESSAGE,
//             status:constants.USER_FAIL_SUCCESS_STATUS 
//         })   
//        }
//     }catch(error){
//         next(error)
//     }      
// });
// userRouter.delete('/:id',async (req:Request,res:Response,next:NextFunction) => {
//     const {id} = req.params;
//     try{
//         const data = await getUserById(id);
//         if(data.count !=0){
//             await deleteUserById(id);
//             res.json({
//                 statusCode:constants.DELETE_USER_SUCCESS_CODE,
//                 message:constants.DELETE_USER_SUCCESS_MESSAGE,
//                 status:constants.USER_SUCCESS_STATUS
//             });
//         }
//         else{
//             res.json({
//             statusCode:constants.NO_USERDELETE_NO_FOUND_CODE,
//             message:constants.NO_USERDELETE_NO_FOUND_MESSAGE,
//             status:constants.USER_FAIL_SUCCESS_STATUS 
//         })       
//         } 
//     }catch(error){
//         next(error)
//     }   
// });

export default userRouter;