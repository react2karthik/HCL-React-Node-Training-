import express,{Request,Response} from 'express';
import myMiddleware from '../middleware/my-middleware';
import  employeeValidator from '../validater/employeeValidator';
import {employe} from '../modal/employeeModal';
import validateMiddleware from '../middleware/validateMiddleware';
const data = require('../../jsondata/data.json');
const fs = require('fs');

const employeeRouter:express.Router = express.Router();
const Employees:Array<employe> =data;
employeeRouter.get('/',myMiddleware,(req:Request,res:Response)=>{
    res.send(Employees);
    res.end();
});
employeeRouter.get('/:id',(req:Request,res:Response)=>{
    const {id} = req.params;
    const data = Employees.filter((item)=> item.id == id);
    res.send(data);
    res.end();
});
employeeRouter.put('/:id',(req:Request,res:Response)=>{
    const {id} = req.params;
    const data = Employees.filter((item)=> item.id != id);
    const employPut=[...data,req.body];
    const jsonCatPut = JSON.stringify(employPut,null,1);
    fs.writeFile('./jsondata/productsData.json',jsonCatPut,(err:any)=>{
        if(err){
            console.log(err);
        }else{
            console.log(`put ${id} Update Successfully`);
        }
        res.send(employPut);
    })
});
employeeRouter.post('/',employeeValidator(),validateMiddleware,(req:Request,res:Response)=>{
    const dataEmplo= Object.assign([...Employees,req.body]);
    const jsonEmploye = JSON.stringify(dataEmplo,null,1);
    fs.writeFile('./jsondata/data.json',jsonEmploye,(err:any)=>{
        if(err){
            console.log(err);
        }else{
            console.log(`file created  Successfully`);
        }
        res.send(dataEmplo);
        res.end();
    })
});
employeeRouter.delete('/:id',(req:Request,res:Response)=>{
    const {id} = req.params;
    const dataEmp = Employees.filter((item)=> item.id != id);
    const jsonEmployeeDelete = JSON.stringify(data,null,1);
    fs.writeFile('./jsondata/EmployeesData.json',jsonEmployeeDelete,(err:any)=>{
        if(err){
            console.log(err);
        }else{
            console.log(`deleted Successfully`);
        }
        res.send(jsonEmployeeDelete);
    })
});

export default employeeRouter;