import express,{Request,Response,NextFunction} from 'express';
import {getAllCartRouter,getAllUserByCardName,getCartById,createCart,putCart,deleteCartById} from '../service/cartServices';
import constants from '../config/constant';
import autherMiddleware from './../middleware/authMiddleware';


import {cartModal} from '../modal/cartModal';
const cartRouter : express.Router= express.Router();
cartRouter.get('/',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{  
    try{
        let data = await getAllCartRouter();
        res.json({
            data,
            statusCode:constants.CART_FECTHED_SUCCESS_CODE,
            message:constants.CART_FECTHED_SUCCESS_MESSAGE,
            status:constants.CART_SUCCESS_STATUS
        })       
    }catch(err){
        next(err)
    }
});
cartRouter.get('/search',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{
    const search:any = req.query.search || "";    
    try{
        let data = await getAllUserByCardName(search);
        res.json({
            data,
            statusCode:constants.CART_SEARCH_SUCCESS_CODE,
            message:constants.CART_SEARCH_SUCCESS_MESSAGE,
            status:constants.CART_SUCCESS_STATUS
        })   
    }catch(error){
        next(error)
    }   
});
cartRouter.post('/',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{
    const {id,added_by,added_on,category_id,price,product_id,quantity} = req.body;
    const cartmodal:cartModal = {id,added_by,added_on,category_id,price,product_id,quantity};
    try{
        await createCart(cartmodal);
        res.json({
            statusCode:constants.CART_POST_SUCCESS_CODE,
            message:constants.CART_POST_SUCCESS_MESSAGE,
            status:constants.CART_SUCCESS_STATUS
        })
    }catch(error){
        next(error)
    }  
});
cartRouter.put('/putUpdate/:id',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{
    const {id} = req.params;
    const {added_by,added_on,category_id,price,product_id,quantity} :cartModal= req.body;
    const cartmodal:cartModal = {id,added_by,added_on,category_id,price,product_id,quantity};
    const data = await getCartById(id);
    try{
       if(data.count != 0){
         await putCart(cartmodal);
         res.json({
            statusCode:constants.CART_UPDATE_SUCCESS_CODE,
            message:constants.CART_UPDATE_SUCCESS_MESSAGE,
            status:constants.CART_SUCCESS_STATUS
        })
       }else{
        res.json({
            statusCode:constants.NO_CART_UPDATE_CODE,
            message:constants.NO_CART_UPDATE__MESSAGE,
            status:constants.CART_FAIL_STATUS 
        })   
       }
    }catch(error){
        next(error)
    }      
});
cartRouter.delete('/:id',autherMiddleware,async (req:Request,res:Response,next:NextFunction) => {
    const {id} = req.params;
    try{
        const data = await getCartById(id);
        if(data.count !=0){
            await deleteCartById(id);
            res.json({
                statusCode:constants.DELETE_CART_SUCCESS_CODE,
                message:constants.DELETE_CART_SUCCESS_MESSAGE,
                status:constants.CART_SUCCESS_STATUS
            });
        }
        else{
            res.json({
            statusCode:constants.NO_CARTDELETE_NO_FOUND_CODE,
            message:constants.NO_CARTDELETE_NO_FOUND_MESSAGE,
            status:constants.CART_FAIL_STATUS 
        })       
        } 
    }catch(error){
        next(error)
    }   
});

export default cartRouter;