import express,{Request,Response} from 'express';
import request from 'request';
const externalApiRouter:express.Router = express.Router();
externalApiRouter.get('/',async(req:Request,res:Response)=>{
    await request('https://reqres.in/api/user?page=2',function(_error:any,response:any,_body:any){
       res.send(JSON.parse(response.body)) 
    })
    res.end();
})
export default externalApiRouter;