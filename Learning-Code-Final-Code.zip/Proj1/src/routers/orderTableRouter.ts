import express,{Request,Response,NextFunction} from 'express';
import {getAllOrterTableRouter,getAllOrderTableByName,getOrderTableById,createOrderTable,putOrderTable,deleteOrderTableById} from '../service/orderTableService';
import constants from '../config/constant';
import autherMiddleware from './../middleware/authMiddleware';
import { orderTableModal } from '../modal/orderTableModal';
const orderTableRouter : express.Router= express.Router();
orderTableRouter.get('/',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{  
    try{
        let data = await getAllOrterTableRouter();
        res.json({
            data,
            statusCode:constants.ORDERTABLE_FECTHED_SUCCESS_CODE,
            message:constants.ORDERTABLE_FECTHED_SUCCESS_MESSAGE,
            status:constants.ORDERTABLE_SUCCESS_STATUS
        })       
    }catch(err){
        next(err)
    }
});
orderTableRouter.get('/search',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{
    const search:any = req.query.search || "";    
    try{
        let data = await getAllOrderTableByName(search);
        res.json({
            data,
            statusCode:constants.ORDERTABLE_SEARCH_SUCCESS_CODE,
            message:constants.ORDERTABLE_SEARCH_SUCCESS_MESSAGE,
            status:constants.ORDERTABLE_SUCCESS_STATUS
        })   
    }catch(error){
        next(error)
    }   
});
orderTableRouter.post('/',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{
    const {id,category_id,order_by,order_on,prod_id,status,trans_id} = req.body;
    const orderTableModal:orderTableModal = {id,category_id,order_by,order_on,prod_id,status,trans_id};
    try{
        await createOrderTable(orderTableModal);
        res.json({
            statusCode:constants.ORDERTABLE_POST_SUCCESS_CODE,
            message:constants.ORDERTABLE_POST_SUCCESS_MESSAGE,
            status:constants.ORDERTABLE_SUCCESS_STATUS
        })
    }catch(error){
        next(error)
    }  
});
orderTableRouter.put('/putUpdate/:id',autherMiddleware,async(req:Request,res:Response,next:NextFunction)=>{
    const {id} = req.params;
    const {category_id,order_by,order_on,prod_id,status,trans_id} :orderTableModal= req.body;
    const orderTableModal:orderTableModal = {id,category_id,order_by,order_on,prod_id,status,trans_id};
    const data = await getOrderTableById(id);
    try{
       if(data.count != 0){
         await putOrderTable(orderTableModal);
         res.json({
            statusCode:constants.ORDERTABLE_PUT_SUCCESS_CODE,
            message:constants.ORDERTABLE_PUT_SUCCESS_MESSAGE,
            status:constants.ORDERTABLE_SUCCESS_STATUS
        })
       }else{
        res.json({
            statusCode:constants.NO_ORDERTABLE_PUT_CODE,
            message:constants.NO_ORDERTABLE_PUT_MESSAGE,
            status:constants.ORDERTABLE_FAIL_STATUS 
        })   
       }
    }catch(error){
        next(error)
    }      
});
orderTableRouter.delete('/:id',autherMiddleware,async (req:Request,res:Response,next:NextFunction) => {
    const {id} = req.params;
    try{
        const data = await getOrderTableById(id);
        if(data.count !=0){
            await deleteOrderTableById(id);
            res.json({
                statusCode:constants.DELETE_ORDERTABLE_SUCCESS_CODE,
                message:constants.DELETE_ORDERTABLE_SUCCESS_MESSAGE,
                status:constants.ORDERTABLE_SUCCESS_STATUS
            });
        }
        else{
            res.json({
            statusCode:constants.NO_ORDERTABLEDELETE_NO_FOUND_CODE,
            message:constants.NO_ORDERTABLEDELETE_NO_FOUND_MESSAGE,
            status:constants.ORDERTABLE_FAIL_STATUS 
        })       
        } 
    }catch(error){
        next(error)
    }   
});

export default orderTableRouter;