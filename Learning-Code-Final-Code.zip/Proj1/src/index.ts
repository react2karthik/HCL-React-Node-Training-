import express,{Request,Response} from 'express';
import myMiddleware from './middleware/my-middleware';
import errorMiddleware from './middleware/errorMiddleware';
import categoriesRouter from './routers/categoriesRouter';
// import externalApiRouter from './routers/externalApiRouter'
import productsRouter from './routers/productsRouter';
import userRoter from './routers/userRouter';
import cartRoter from './routers/cartRouter';
import employeeRouter from './routers/employeeRouter';
import orderTableRouter  from './routers/orderTableRouter';
import errorRouter from './routers/errorRouter';
import dotenv from 'dotenv';
const app:express.Application = express();
//port number 
dotenv.config();

const port  = process.env.PORT || 2003;
 app.use(express.json());
 app.use(myMiddleware);//application level middle
 //get method
 app.get('/',(req:Request,res:Response) => {
    res.send('Hell world')
 })
 //routes 
 app.use('/categories',categoriesRouter);
//  app.use('/external-api',externalApiRouter);
 app.use('/produts',productsRouter);
 app.use('/user',userRoter);
 app.use('/cart',cartRoter);
 app.use('/employees',employeeRouter);
 app.use('/orderTable',orderTableRouter)
 app.use('/error',errorRouter);

 app.use(errorMiddleware);
 app.listen(port,()=>{
    console.log(`Example app listening on port ${port}`)
 })
    
    
    
    
    
    
    
    
    
    