import { Request,Response,NextFunction } from "express";
import { UnAuthorizedAccess } from "../error/uAutherizedUser";
import constants from "../config/constant";
import jwt from 'jsonwebtoken';
const autherMiddleware = (req:Request,res:Response,next:NextFunction)=>{
   const token = req.header('Authorization');
   if(!token){
     throw new UnAuthorizedAccess(constants.ACCESS_DENIED_MESSAGE,constants.ACCESS_DENIED_CODE)
   }else{
    try{
        const decode = jwt.verify(token,"sridhar");   
        next();
    }catch(err){
        throw new UnAuthorizedAccess(constants.ACCESS_DENIED_MESSAGE,constants.ACCESS_DENIED_CODE)
    }
   }
    
}
export default autherMiddleware;