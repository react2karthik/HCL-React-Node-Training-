import { Request,Response,NextFunction } from "express";
interface IErrorObject{
    message:String,
    status:String,
    statusCode:Number,
    // data:null,
    path:String
}
const errorMiddleware = (err:any,req:Request,res:Response,next:NextFunction) => {
    console.log(err)
    let errObject:IErrorObject = {
        message:err.message,
        status:'failure',
        statusCode:err.statusCode,
        // data:null,
        path:req.path
    }
    res.status(500).json(errObject);
    next();

}
export default errorMiddleware;