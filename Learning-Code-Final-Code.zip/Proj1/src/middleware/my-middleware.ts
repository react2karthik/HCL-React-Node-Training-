import { Request,Response,NextFunction } from "express";
//custome middleware

const myMiddleware = (req:Request,res:Response,next:NextFunction)=>{
   console.log("myMiddleware");
   const requestTime = Date.now();
   console.log('requestTime',requestTime);
   next();
}
export default myMiddleware;