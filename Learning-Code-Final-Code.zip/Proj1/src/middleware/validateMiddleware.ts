import { Request,Response,NextFunction } from "express";
import { validationResult } from "express-validator";

const validateMiddleware = (req:Request,res:Response,next:NextFunction) => {
   const errors =validationResult(req);
   if(errors.isEmpty()){
    next()
   }else{
    const errorMsg : Array<String> = [];
    errors.array().map(err=>errorMsg.push(
        err.msg
    ))
    return res.status(422).json({
        error:errorMsg
    })
   }
}
export default validateMiddleware;