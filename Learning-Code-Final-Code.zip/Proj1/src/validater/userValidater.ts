import {body} from 'express-validator';
const userValidator = () => {
    return[
        body('id').exists().withMessage('categories id need'),
        body("name").exists().bail().isLength({min:5}).trim().withMessage('name is required'),
        body("phone").exists().bail().isLength({max:10}).trim().bail().isNumeric().withMessage('phone is required'),
        body("email").exists().bail().withMessage("email is required").isEmail().withMessage('Invalid emailId please enter correct'),
        body("psw").exists().bail().withMessage('Psw will be alp').bail().isLength({min:3,max:8}).withMessage("psw should be min 3 and max 8"),
    ]
}
export default userValidator;