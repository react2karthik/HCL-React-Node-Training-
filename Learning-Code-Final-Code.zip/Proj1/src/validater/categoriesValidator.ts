import { body } from "express-validator";
const categoriesValidator = () => {
    return[
        //body('id').exists().withMessage('categories id need'),
        body('category_name').exists().isLength({min:5}).trim().withMessage('categories name need'),
        body('category_description').exists().isLength({min:5}).trim().withMessage('categories name need')
    ]
}
export default categoriesValidator;