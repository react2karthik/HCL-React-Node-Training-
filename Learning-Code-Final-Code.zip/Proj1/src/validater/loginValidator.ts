import {body} from 'express-validator';

const loginValidator = () => {
    return[
        body("email").exists().bail().withMessage('Eamil is required').isEmail().withMessage('Invalid emaild please enter correct email'),
        body("psw").exists().bail().withMessage('psw is required').bail().isAlphanumeric().withMessage("Psw will be alphanumeric only").bail().isLength({min:3,max:8}).withMessage("PSW should be min 3 and max 8 char")
    ]
}

export default loginValidator;