import { body } from "express-validator";

const employeeValidator = () => {
   return[
    body('id').exists().withMessage("categories id need"),
   ]
}
export default employeeValidator;
