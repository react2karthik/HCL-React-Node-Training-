import {body} from 'express-validator';

const productsValidaters = () => {
    // function isImg(url:string){
    //  if(typeof url !== 'string') return false;
    //   return(url.match(/^http[^2\?]*.(jpg|jpeg|gif|png|tiff|bmp)(\?(.*))?$/gmi) != null);
    // }
    return[
        body('pro_id').exists().withMessage('product id need'),
        body('cat_id').exists().withMessage('product id need'),
        body('exp_date').exists().withMessage('product id need'),
        body('manu_date').exists().withMessage('product id need'),
        body('prod_name').exists().trim().withMessage('product name need'),
        body('quantity').exists().isLength({min:1}).trim().withMessage('product name need')
        ]
}
export default productsValidaters;