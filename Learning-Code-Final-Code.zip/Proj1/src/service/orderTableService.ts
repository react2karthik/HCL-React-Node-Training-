import client  from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import {orderTableModal} from './../modal/orderTableModal';

const getAllOrterTableRouter = async()=>{
    let result = await client.execute('select * from order_table');
    console.log(result);
    if(result.rowLength === 0){
        throw new NoDataFoundError("No Order found", 1000);
    }else
    return result.rows;
};
const getAllOrderTableByName=async(search:String)=>{
    let result = await client.execute(`select * from order_table where category_id=${search} ALLOW FILTERING`);
    return result.rows;
}
const getOrderTableById=async(id:String | Number)=>{
    const query = `select count(id) as count from order_table where id=${id}`;
    let result = await client.execute(query);
    return result.first();
}
const createOrderTable = async(orderTablerouter:orderTableModal)=>{
    const query = `insert into order_table(id,category_id,order_by,order_on,prod_id,status,trans_id) values(${orderTablerouter.id},${orderTablerouter.category_id},'${orderTablerouter.order_by}','${orderTablerouter.order_on}',${orderTablerouter.prod_id},'${orderTablerouter.status}',${orderTablerouter.trans_id})`;
    await client.execute(query)
}
const putOrderTable = async(orderTablerouter:orderTableModal)=>{
    const query = `update order_table set category_id=${orderTablerouter.category_id},order_by='${orderTablerouter.order_by}',order_on='${orderTablerouter.order_on}',prod_id=${orderTablerouter.prod_id},status='${orderTablerouter.status}',trans_id=${orderTablerouter.trans_id} where id=${orderTablerouter.id};`;
    await client.execute(query)
}
const deleteOrderTableById=async(id:String | Number)=>{
    let query = `delete from order_table where id=${id} `;
    await client.execute(query)
}
export {getAllOrterTableRouter,getAllOrderTableByName,getOrderTableById,createOrderTable,putOrderTable,deleteOrderTableById};