import client  from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import {cartModal} from './../modal/cartModal';

const getAllCartRouter = async()=>{
    let result = await client.execute('select * from cart');
    if(result.rowLength === 0){
        throw new NoDataFoundError("No Category found", 1000);
    }else
    return result.rows;
};
const getAllUserByCardName=async(search:String)=>{
    let result = await client.execute(`select * from cart where product_id='${search}' ALLOW FILTERING`);
    return result.rows;
}
const getCartById=async(id:String | Number)=>{
    const query = `select count(id) as count from cart where id=${id}`;
    let result = await client.execute(query);
    return result.first();
}
const createCart = async(cartrouter:cartModal)=>{
    const query = `insert into cart(id,added_by,added_on,category_id,price,product_id,quantity) values(${cartrouter.id},'${cartrouter.added_by}','${cartrouter.added_on}',${cartrouter.category_id},${cartrouter.price},${cartrouter.product_id},${cartrouter.quantity})`;
    await client.execute(query)
}
const putCart = async(cartrouter:cartModal)=>{
    const query = `update cart set added_by='${cartrouter.added_by}',added_on='${cartrouter.added_on}',category_id=${cartrouter.category_id},price=${cartrouter.price},product_id=${cartrouter.product_id},quantity=${cartrouter.quantity} where id=${cartrouter.id};`;
    await client.execute(query)
}
const deleteCartById=async(id:String | Number)=>{
    let query = `delete from cart where id=${id} `;
    await client.execute(query)
}
export {getAllCartRouter,getAllUserByCardName,getCartById,createCart,putCart,deleteCartById};