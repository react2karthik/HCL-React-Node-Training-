import { UUID } from 'crypto';
import client  from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import {Category} from './../modal/categoryModal';

const getAllCategories = async()=>{
    let result = await client.execute('select * from category');
    if(result.rowLength === 0){
        throw new NoDataFoundError("No Category found", 1000);
    }else
    return result.rows;
};
const getAllCategoriesByCatrgoryName=async(search:String)=>{
    let result = await client.execute(`select * from category where category_name='${search}' ALLOW FILTERING`);
    return result.rows;
    //let result = await client.execute(` select id ,category_name from category where category_name ='${search}'`);
    // console.log("result",result);   
    // if(result.rowLength === 0) {
    //     throw new NoDataFoundError('No Category found for given search criteria',1001);        
    // }else{
    //     return result.rows;
    // }
}
const getCategoriesById=async(id:String | Number)=>{
    const query = `select count(id) as count from category where id=${id}`;
    let result = await client.execute(query);
    return result.first();
}
const createCategory = async(category:Category)=>{
    const query = `insert into category(id,category_name,category_description) values(uuid(),'${category.category_name}','${category.category_description}')`;
    await client.execute(query)
}
// const putCategories = async(id:String | Number)=>{
const putCategories = async(category:Category)=>{
    const query = `update category set category_name='${category.category_name}',
    category_description='${category.category_description}' where id=${category.category_name};`;
    //const query = `SELECT count(id) as count from category where id=${category.id};`;
    // const query= `SELECT * FROM category where Category=(id ,category_name,category_description)`;
    await client.execute(query)
}
const deleteCategoriesById=async(id:String | Number)=>{
    let query = `delete from category where id=${id} `;
    await client.execute(query)
}
export {getAllCategories,getAllCategoriesByCatrgoryName,getCategoriesById,createCategory,putCategories,deleteCategoriesById};