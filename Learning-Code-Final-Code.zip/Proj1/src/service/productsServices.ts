import client  from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import {Prod} from './../modal/prodModal';
const getAllProducts = async()=>{
    let result = await client.execute('select * from  product');
    console.log(result);
    if(result.rowLength === 0){
        throw new NoDataFoundError("No Product found", 3000);
    }else
    return result.rows;
};
const getAllProductsByProductsName=async(search:String)=>{
    let result = await client.execute(`select * from product where prod_name='${search}' ALLOW FILTERING`);
    console.log('res---',result);
    return result.rows;
}
const createProduct = async(product:Prod)=>{
    const query = `insert into product (pro_id,cat_id,exp_date,manu_date,prod_name,quantity) values(${product.pro_id},${product.cat_id},'${product.exp_date}','${product.manu_date}','${product.prod_name}',${product.quantity})`;
    console.log('post res---',query);
    await client.execute(query)
}
const getProductById=async(pro_id:String | Number)=>{
    const query = `select count(pro_id) as count from product where pro_id=${pro_id}`;
    let result = await client.execute(query);
    return result.first();
}
const putProduct = async(product:Prod)=>{
    const query = `update product set cat_id=${product.cat_id},
    exp_date='${product.exp_date}', manu_date='${product.manu_date}',prod_name='${product.prod_name}',
    quantity=${product.quantity} where pro_id=${product.pro_id};`;
    await client.execute(query)
}
const deleteProductById=async(pro_id:String | Number)=>{
    let query = `delete from product where pro_id=${pro_id} `;
    await client.execute(query)
}
export {getAllProducts,getAllProductsByProductsName,createProduct,getProductById,putProduct,deleteProductById};