import client  from '../config/dbConfig';
import { NoDataFoundError } from '../error/noDataError';
import {userModal} from './../modal/userModal';

const getAllUserRouter = async()=>{
    let result = await client.execute('select * from userrouter');
    console.log(result);
    if(result.rowLength === 0){
        throw new NoDataFoundError("No Category found", 1000);
    }else
    return result.rows;
};
const getAllUserByCatrgoryName=async(search:String)=>{
    let result = await client.execute(`select * from userrouter where name='${search}' ALLOW FILTERING`);
    return result.rows;
}
const getUserById=async(id:String | Number)=>{
    const query = `select count(id) as count from userrouter where id=${id}`;
    let result = await client.execute(query);
    return result.first();
}
const createUser = async(userrouter:userModal)=>{
    const query = `insert into userrouter(id,name,email,phone,psw) values(${userrouter.id},'${userrouter.name}','${userrouter.email}',${userrouter.phone},'${userrouter.psw}')`;
    await client.execute(query)
}
const putUsers = async(userrouter:userModal)=>{
    const query = `update userrouter set name='${userrouter.name}',
    email='${userrouter.email}',psw='${userrouter.psw}',phone='${userrouter.phone}' where id=${userrouter.id};`;
    console.log("query--hghghjgjh-----",query);
    await client.execute(query)
}
const deleteUserById=async(id:String | Number)=>{
    let query = `delete from userrouter where id=${id} `;
    await client.execute(query)
}
const registerUser = async(id:Number,name:String,email:String,psw:String)=>{
    const result = await client.execute(`insert into userrouter(id,name,email,psw) values(${id},'${name}','${email}','${psw}')`)
     return result;
}
const loginUser = async(email:String) =>{
    const result  = await client.execute(`select email , psw from userrouter where email='${email}' allow filtering`);
    return result;
}
export {getAllUserRouter,getAllUserByCatrgoryName,getUserById,createUser,putUsers,deleteUserById,registerUser,loginUser};