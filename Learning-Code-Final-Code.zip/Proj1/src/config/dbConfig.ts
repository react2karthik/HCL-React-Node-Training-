import {Client} from 'cassandra-driver';
/*
//Dp Client 
//DB name keyspace
//connect 
//shutdown
*/
const client = new Client({
    contactPoints:['127.0.0.1'],
    localDataCenter:'datacenter1',
    keyspace:'shoping_cart' 
 })

 client.connect(()=>{
    console.log("db connected")
 });
 client.shutdown(()=>{
    console.log("db shoutdown")
 })
 export default client;