import { assert,expect } from "chai";
import sinon,{SinonSpy,SinonStub} from 'sinon';
import { describe } from "mocha";
import axios from "../node_modules/axios/index";
import nock from '../node_modules/nock/types/index';

describe('fetch  api data',()=>{
    it('spies mock and stub',async()=>{
        const baseURl = "https://jsonplaceholder.typicode.com";
        let mockData= {
            "userId":1,
            "id":1
        }
        nock(baseURl).get('/todos/1').reply(200,mockData);
        let postResultData = await axios.get('https://jsonplaceholder.typicode.com/todos/1');
        console.log("resultresult");
        console.log("resultresult",postResultData);
        assert.deepEqual(postResultData.status,200);
        expect(postResultData).to.be.ok;
    })
})