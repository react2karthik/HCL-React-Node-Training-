// import { expect  } from "chai";
// import {Category} from '../src/modal/categoryModal';
// describe("chai categories",()=>{
//     it("expect categories",()=>{
//         const category_name:string = "clothing1";
//         const category_description:string = "dress for kids";
//         const objectData:Object={category_name:"clothing1",category_description:"dress for kids"};
//         //act
//         //assert
//         expect(category_name).to.be.ok;//undefined or null
//         expect(category_name).to.be.equal("clothing1");
//         expect(category_name).to.be.a("string");
//         expect(objectData).to.have.property("category_name").equal("clothing1");
//     })
// })