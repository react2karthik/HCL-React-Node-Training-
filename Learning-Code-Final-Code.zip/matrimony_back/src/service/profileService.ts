import client from '../config/dbConfig';
import { NoDataFoundError } from "../error/noDataError";
/**
 * Retrieves all profiles from the database.
 * Execute query to select profile details from the 'user' table
 * Array containing profiles retrieved from the database.
 * Thrown if no profile details are found in the database.
 * @returns 
 */
const getAllProfiles = async () => {
    const result = await client.execute(`select name, age, gender, occupation, dob, email, phone, qualification from user`);
    console.log("getAllProfiles",result)
    if (result.rowLength === 0)
        throw new NoDataFoundError('No Profile details found', 10000);
    else
        return result.rows;
}

/**
 * Retrieves profiles based on the opposite gender of the user's gender.
 * Retrieve user's gender from the database
 * Construct query to select profiles of opposite gender
 * Retrieve user's gender from the database
 * @returns 
 */
const getProfileBasedOnMyGender = async (userId: string) => {
    let result = await client.execute(`select gender from user where id=${userId}`);
    const gender = result.first().get('gender') == 'male' ? 'female' : 'male';
    const query = `select name, age, gender, occupation, dob, email, phone, qualification from user where gender='${gender}' and role='user' ALLOW FILTERING`;
    console.log(query);
    result = await client.execute(query);
    console.log("resultgetProfileBasedOnMyGender",result)
    if (result.rowLength === 0)
        throw new NoDataFoundError('No Profile details found', 10000);
    else
        return result.rows;
}

/**
 * Retrieves profile details based on the provided user ID.
 * Construct query to select profile details based on the provided user ID
 * @param id - Profile ID
 */
const getProfileBasedOnId = async (userId: string) => {
    const query = `select name, age, gender, occupation, dob, email, phone, qualification from user where id=${userId} ALLOW FILTERING`;
    const result = await client.execute(query);
    if (result.rowLength === 0)
        throw new NoDataFoundError('No Profile details found', 10000);
    else
        return result.rows;
}


export { getAllProfiles, getProfileBasedOnId, getProfileBasedOnMyGender };