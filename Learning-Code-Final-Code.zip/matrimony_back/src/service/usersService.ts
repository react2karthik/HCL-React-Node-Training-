import client from '../config/dbConfig';
import { usersModal,IData } from '../modal/usersModal';
import { NoDataFoundError } from "../error/noDataError";
import { types } from 'cassandra-driver';

/**
 * Retrieves user information based on the provided email address.
 * @param email 
 * @returns 
 */
const login = async (email: string) => {
    const query = `select email, password, id, role from user where email='${email}' ALLOW FILTERING`;
    const result = await client.execute(query);
    return result;
}
/**
 * Creates a new user and inserts their details into the database.
 * @param User 
 * @returns 
 */
const createUser = async (User: usersModal) => {
    const currentAge = await getUserAge(User.dob);
    const query = `insert into user(id, name, age, gender, email, password, dob, phone, occupation, qualification, role) values(uuid(),
    '${User.name}', ${currentAge}, '${User.gender}', '${User.email}', '${User.hassedPassword}', '${User.dob}', ${User.phone}, '${User.occupation}', '${User.qualification}', 'user')`;
     const result = await client.execute(query);
    return result;
}
/**
 * Records a user's interest in another user and inserts the interaction details into the database.
 * @param userID 
 * @param intrestedID 
 * @returns 
 */
const showIntrest = async (userID: string, intrestedID: string) => {
    const query = `insert into  showing_interest_details(id, user_id, showed_interested_on, interested_in, comments, status) values(uuid(),
    ${userID}, toTimestamp(now()), ${intrestedID}, 'I liked your profile', 'PENDING')`;
    const result = await client.execute(query);
    return result;
}
/**
 * Retrieves profiles that the specified user is interested in.
 * @param userID 
 * @returns 
 */
const getinterestedInProfile = async (userID: string) => {
    const query = `select interested_in, comments, status, showed_interested_on from  showing_interest_details where user_id=${userID} allow filtering`;
    const result = await client.execute(query);
    if (result.rowLength === 0)
        throw new NoDataFoundError('No Profile details found', 10000);
    else {
        const generatedData = await generateData(result);
        return generatedData;
    }

}
/**
 * Retrieves profiles of users who are interested in the specified user.
 * @param userID 
 * @returns 
 */

const getinterestedByProfile = async (userID: string) => {
    const query = `select user_id, comments, status,showed_interested_on from  showing_interest_details where interested_in=${userID} allow filtering`;
    const result = await client.execute(query);
    console.log("getinterestedByProfile",result);
    if (result.rowLength === 0)
        throw new NoDataFoundError('No Profile details found', 10000);
    else {
        const generatedData = await generateData(result);
        return generatedData;
    }

}
/**
 * Calculates the age of a user based on their date of birth.
 * @param dob 
 * @returns 
 */
const getUserAge = async (dob: any) => {
    const from = dob.split("-");
    const birthdateTimeStamp: any = new Date(from[0], from[1] - 1, from[2]);
    const currentDate: any = new Date();
    const diff = currentDate - birthdateTimeStamp;
    // This is the difference in milliseconds
    const currentAge = Math.floor(diff / 31557600000);
    return currentAge;
}
/**
 * Retrieves user details based on the provided user ID.
 * @param userID 
 * @returns 
 */

const getUserByID = async (userID: string) => {
    const query = `select name, age, dob, email, gender, occupation, qualification, phone from user where id=${userID} ALLOW FILTERING`;
    const result = await client.execute(query);
    return result;
}
/**
 * Sends a comment and updates status for a specific interaction between two users.
 * @param userID 
 * @param toUserID 
 * @param comment 
 * @param statusTxt 
 * @returns 
 */
const sendCommend = async (userID: string, toUserID: string, comment: string, statusTxt: string) => {
    const query = `select id from  showing_interest_details where user_id=${toUserID} and interested_in=${userID} ALLOW FILTERING`;
    const result = await client.execute(query);
    console.log("sendCommend",result);
    if (result.rowLength === 0)
        throw new NoDataFoundError('No Profile details found', 10000);
    else {
        const { id } = result.first();
        const query = `update  showing_interest_details set comments='${comment}', status='${statusTxt}' where id=${id}`;
        const result1 = await client.execute(query);
        return result1;
    }
}
/**
 * Generate formatted data based on the result from a database query.
 * Initialize an array to store formatted data
 * @param result 
 * @returns 
 */
const generateData = async (result: types.ResultSet) => {
    let data: IData[] = [];
    for (const row of result.rows) {
        const userData: IData = {name: '', interest_showed_on: '',status: '',comment: '', age: ''};
        const date = new Date(row.get('showed_interested_on')); 
        userData.interest_showed_on = date.toLocaleString();
        userData.status = row.get('status');
        userData.comment = row.get('comments');
        const userid = row.get('interested_in') == undefined ? row.get('user_id') : row.get('interested_in')
        const userResult = await getUserByID(userid)
       userData.name = userResult.first().get('name');
        userData.age = userResult.first().get('age');
        data = [...data, userData];
    }
    return data;
}
export {login,createUser,showIntrest,generateData, sendCommend,getinterestedInProfile,getinterestedByProfile};