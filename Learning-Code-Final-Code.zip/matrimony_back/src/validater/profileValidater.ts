import { body } from "express-validator";
/**
 * profile for profile validater(id,user_id,interested_in,status,comments,showed_interested_on
 * @returns 
 */
const profileValidator = () => {
    return [
        body('user_id').exists().trim().withMessage('user if is required'),
        body('interested_in').exists().trim().withMessage('interested to is required'),
        body('status').exists().trim().withMessage('status is required'),
        body('comments').exists().trim().withMessage('Cooment need'),
        body('showed_interested_on').exists().trim().withMessage('show interested from is required'),
    ]
}
export default profileValidator;