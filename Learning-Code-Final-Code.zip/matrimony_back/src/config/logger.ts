import * as winston from 'winston';
import "winston-daily-rotate-file";

const transport = new winston.transports.DailyRotateFile(
    {
        dirname:"log",
        datePattern:'yyyy-mm-dd-hh',
        filename:'matrimony.log'
    }
)
const logger = (path: string) => winston.createLogger({
  transports:[
       transport
  ],
  format:winston.format.combine(
    winston.format.timestamp(),
    winston.format.simple(),
    winston.format.printf((info) => `[${info.timestamp}] [${info.service}] ${info.level}: ${info.message}`)
),
defaultMeta: {
    service:path
}
})

export default logger;