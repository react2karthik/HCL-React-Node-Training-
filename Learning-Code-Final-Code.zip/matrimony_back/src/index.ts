import express from 'express';
import dotenv from 'dotenv';
import usersRouter from './../src/routers/usersRouter';
import profileRouter from './../src/routers/profileRouter';
import errorMiddleware from './../src/middleware/errorMiddleware';
const app: express.Application = express();
app.use(express.json());
dotenv.config();
const port = process.env.PORT || 8001;
app.use('/users', usersRouter);
app.use('/profiles', profileRouter);

app.use(errorMiddleware)
app.listen(port, () => {
    console.log(`matrimony app listening on port ${port}`);
})
export default app;