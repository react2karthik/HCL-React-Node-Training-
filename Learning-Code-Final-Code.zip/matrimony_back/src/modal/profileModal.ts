/**
 * Interface added for profile 
 */
export interface profileModal {
    id: string,
    user_id: string,
    interested_in: string,
    status: string,
    comments: string,
    showed_interested_on: string,
}
//create table  showing_interest_details(id uuid primary key,user_id text,interested_in text,status text,comments text,showed_interested_on date);