import express, {  Response, NextFunction } from 'express';

import constances from '../config/constant';
import authMiddleware from '../middleware/authMiddleware';
import { getAllProfiles, getProfileBasedOnId, getProfileBasedOnMyGender } from '../service/profileService';
import logger from '../config/logger';
const profileRouter: express.Router = express.Router();
/**
 * profile Router
 * this GET method is used to get all profile information from user_details table.
 * Import authMiddleware modules and middleware
 * Fetch profile based on the user's gender getProfileBasedOnMyGender
 * If the user is an admin, fetch all profiles getAllProfiles
 * Respond with JSON containing fetched data and status information
 */
profileRouter.get('/',authMiddleware, async (req: any, res: Response, next: NextFunction) => {
    const { userId, role } = req;
    const path: any = req.path; 
    try {
        let data;
        if(role != 'admin') {
            data = await getProfileBasedOnMyGender(userId);
        } else {
            data = await getAllProfiles();
        }
        logger(path).info(constances.PROFILE_FECTHED_SUCCESS_MESSAGE);
        res.json({
            data,
            message: constances.PROFILE_FECTHED_SUCCESS_MESSAGE,
            statusCode: constances.PROFILE_FECTHED_SUCCESS_CODE,
            statue: constances.SUCCESS_STATUS
        })
    } catch (error) {
       logger(path).error(error);
        next(error);
    }
});
 /**
  * Define route handler for GET request to '/:userID' endpoint
  * Fetch profile based on the provided userID getProfileBasedOnId
  * Respond with JSON containing fetched data and status information
  * Fetched data
  */
profileRouter.get('/:userID',authMiddleware, async (req: any, res: Response, next: NextFunction) => {
    const { userID } = req.params; 
    const path: any = req.path; 
    try {
        const data = await getProfileBasedOnId(userID);
        logger(path).info(constances.PROFILE_FECTHED_SUCCESS_MESSAGE);
        res.json({
            data,
            message: constances.PROFILE_FECTHED_ONLYUSERID_SUCCESS_MESSAGE,
            statusCode: constances.PROFILE_FECTHED_ONLYUSERID_SUCCESS_CODE,
            statue: constances.SUCCESS_STATUS
        })
    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});
 


export default profileRouter