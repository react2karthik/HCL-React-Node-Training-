import express, { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';

import { usersModal } from '../modal/usersModal';
import constances from '../config/constant';
import { usersValidater ,usersloginValidater} from '../validater/usersValidater';
import authMiddleware from '../middleware/authMiddleware';
// import authorizeMiddleware from '../middleware/authorizeMiddleware';
import { UnAuthorizedAccess } from '../error/uAutherizedUser';
import validateMiddleware from '../middleware/validateMiddleware';
import { login, createUser, showIntrest, getinterestedInProfile, getinterestedByProfile,sendCommend } from '../service/usersService';
import logger from '../config/logger';

dotenv.config();

const userRouter: express.Router = express.Router();

/**
 * user router
 * Define route handler for POST request to '/register' endpoint and validate usersValidater(), validateMiddleware
 * Extract path from request
 * Extract necessary user details from request body
 * Create user using provided details createUser
 * Log success message logger
 */
userRouter.post('/register', usersValidater(), validateMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const path: any = req.path; 
    const { name, dob, gender, email, qualification, occupation, password, phone } = req.body;
    try {
        const hassedPassword = await bcrypt.hash(password, 10);
        const userDetails : usersModal = { name, dob, gender, email, qualification, hassedPassword, phone, occupation }
        const result = await createUser(userDetails);
        logger(path).info(constances.USER_REGISTERED_SUCCESS_MESSAGE);
        res.json({
            result,
            message: constances.USER_REGISTERED_SUCCESS_MESSAGE,
            statusCode: constances.USER_REGISTERED_SUCCESS_CODE,
            statue: constances.SUCCESS_STATUS
        });
 
    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});
/**
 * user router
 * Define route handler for POST request to '/login' endpoint
 *  Extract email and password from request body
 * Attempt to retrieve user information based on provided email
 * Check if user with provided email exists
 * If user exists, check if provided password matches the stored hashed password
 * If passwords match, generate JWT token for authentication
 */
userRouter.post('/login',usersloginValidater(), async (req: Request, res: Response, next: NextFunction) => { 
    const { email, password } = req.body;
    const result = await login(email);    
    const path: any = req.path; 
    if (result.first() != null) { 
        const { id, role } = result.first();
        const isMatching = await bcrypt.compare(password, result.first().get('password')); 
        if (isMatching) {
            const token = jwt.sign({email, userId: id, role }, process.env.SECRET_KEY || '', { expiresIn: '1h' });
            logger(path).info("success");
            res.json({
                status: 'success',
                data: token
            })
        } else {
            try {
                throw new UnAuthorizedAccess(constances.ACCESS_DENIED_MESSAGE, constances.ACCESS_DENIED_CODE);
            } catch (error) {
               logger(path).error(error);
                next(error);
            }
        }
    } else {
        logger(path).info(constances.FAIL_STATUS);
        res.json({
            message: constances.USER_LOGIN_FAIL_MESSAGE,
            statusCode: constances.USER_LOGIN_FAIL_CODE,
            statue: constances.FAIL_STATUS,
            data: email
        })
    }
});
/**
 * Define route handler for POST request to '/:userID/intrests/:intrestedID' endpoint
 * Extract userID and intrestedID from request parameters
 * Show interest between userID and intrestedID
 */
userRouter.post('/:userID/intrests/:intrestedID',  async (req: Request, res: Response, next: NextFunction) => {   
    const { userID, intrestedID } = req.params;
    const path: any = req.path;
    try { 
        const result = await showIntrest(userID, intrestedID);
        logger(path).info(constances.USER_FECTHED_INTRESTES_MESSAGE);
        res.json({
            result,
            message: constances.USER_FECTHED_INTRESTES_MESSAGE,
            statusCode: constances.USER_FECTHED_INTRESTES_CODE,
            statue: constances.SUCCESS_STATUS
        }); 
    } catch (error) {
       logger(path).error(error);
        next(error);
    }
});
/**
 * Define route handler for GET request to '/:userID/interested-in' endpoint
 * Extract userID from request parameters
 * Retrieve profiles that the specified userID is interested in
 */
userRouter.get('/:userID/interested-in', authMiddleware, async (req: Request, res: Response, next: NextFunction) => {
    const { userID } = req.params;
    const path: any = req.path;
    try { 
        const result = await getinterestedInProfile(userID);
        logger(path).info(constances.USER_FECTHED_INTERESTEDIN_MESSAGE);
        res.json({
            data: result,
            message: constances.USER_FECTHED_INTERESTEDIN_MESSAGE,
            statusCode: constances.USER_FECTHED_INTERESTEDIN_CODE,
            statue: constances.SUCCESS_STATUS,
        }); 
    } catch (error) {
       logger(path).error(error);
        next(error);
    }
});
/**
 * Define route handler for PUT request to '/:userID/comment/:toUserID' endpoint
 * Extract userID and toUserID from request parameters
 * Extract comments and status from request body
 * Send comment from userID to toUserID with specified comments and status
 */
 
userRouter.put('/:userID/comment/:toUserID', authMiddleware, async (req: Request, res: Response, next: NextFunction) => { 
    const { userID, toUserID } = req.params;
    const { comments, status } = req.body; 
    const path: any = req.path; 
    try {
         const result = await sendCommend(userID, toUserID, comments, status); 
         logger(path).info(constances.USER_FECTHED_COMMENTS_SUCCESS_MESSAGE);
        res.json({
            result,
            message: constances.USER_FECTHED_COMMENTS_SUCCESS_MESSAGE,
            statusCode: constances.USER_FECTHED_COMMENTS_SUCCESS_CODE,
            statue: constances.SUCCESS_STATUS
        }); 
    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});
 /**
  * Define route handler for GET request to '/:userID/interested-by' endpoint
  * Extract userID from request parameters
  * Retrieve profiles that are interested in the specified userID getinterestedByProfile
  */
userRouter.get('/:userID/interested-by', authMiddleware, async (req: Request, res: Response, next: NextFunction) => { 
    const { userID } = req.params; 
    const path: any = req.path; 
    try { 
        const result = await getinterestedByProfile(userID);
        logger(path).info(constances.USER_FECTHED_INTERESTEDBY_SUCCESS_MESSAGE);
        res.json({
            data: result,
            message: constances.USER_FECTHED_INTERESTEDBY_SUCCESS_MESSAGE,
            statusCode: constances.USER_FECTHED_INTERESTEDBY_SUCCESS_CODE,
            statue: constances.SUCCESS_STATUS,
        });
 
    } catch (error) {
        logger(path).error(error);
        next(error);
    }
});



export default userRouter;