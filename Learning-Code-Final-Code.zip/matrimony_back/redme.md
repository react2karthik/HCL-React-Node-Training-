step1 : explain about use case
step2 : explain feature and use case 
step3:what is the tech stack using - typescript,express,cassandra, chai and macho,nodejs
strp 4 : what are feature 
    1.while talking about user registeraion show validation message
    2.Enter valid enter info and register
    3.after registration explain success response 
    4.if your register same user details throw error saying user alread exist
    5.explain bycrpt  from password hashing
step 5: explain whit invalid login credentail and show validation messages 
      1.explain profile api 
      2.explain male user 
      3.explain female user profile view
      4.explain admin profile view
step 6
    1.explain what are the best practices we followed in our project
    2.explain validator ,error handling,logger winston modulefor logger ,eslint rules
    3. external thirdpart API
    4.any question




//register post  http://localhost:8000/users/register -- working

//login post http://localhost:8000/users/login -- working

//user
//post  http://localhost:8000/users/userID/intrests/:intrestedID --- working user/c38543ac-6b93-4f90-b863-738eda0d7830/intrests/3ad978db-c860-41ff-b187-6c3c77a5b5d3
//get http://localhost:8000/users/userID/interested-in --- working users/c38543ac-6b93-4f90-b863-738eda0d7830/interested-in
//put http://localhost:8000/users/userID/comment/:toUserID ---working users/3ad978db-c860-41ff-b187-6c3c77a5b5d3/comment/c38543ac-6b93-4f90-b863-738eda0d7830
//get http://localhost:8000/users/userID/interested-by --- working users/3ad978db-c860-41ff-b187-6c3c77a5b5d3/interested-by

//profile 
// get http://localhost:8000/profiles/ -- working
// get http://localhost:8000/profiles/id -- working

create table  showing_interest_details(id uuid primary key,user_id text,interested_in text,status text,comments text,showed_interested_on timestamp);
{
 "name":"joe",
 "email":"joe@gemail.com",
 "password":"joe",
 "qualification":"M.E",
 "dob":"2020-10-10",
 "occupation":"CA",
 "gender":"Femal"  ,
 "phone":8978768547
}
 const headers =  {
            'Content-Type':'application/json',
            'Authorization':`Bearer ${postLoginToken}`
        }      
        let retun = axios.post('http://localhost:8000/users/register',mockRegisterData,{headers:headers})
        .then((response)=>{
            console.log(response)
        }).catch((error)=>{
            console.log(error)
        })

// Define the two dates
const startDate = new Date('2022-01-01T12:00:00Z'); // Assuming UTC time
const endDate = new Date(); // Current date and time

// Calculate the time difference in milliseconds
const timeDifference = endDate - startDate;

// Convert the time difference to hours and minutes
const hoursDifference = Math.floor(timeDifference / (1000 * 60 * 60));
const minutesDifference = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));

// Display the time difference in different time zones
const optionsUTC = { timeZone: 'UTC' };
const optionsNewYork = { timeZone: 'America/New_York' };
const optionsTokyo = { timeZone: 'Asia/Tokyo' };

console.log('Time difference (UTC):', timeDifference.toLocaleString('en-US', optionsUTC));
console.log('Time difference (New York):', timeDifference.toLocaleString('en-US', optionsNewYork));
console.log('Time difference (Tokyo):', timeDifference.toLocaleString('en-US', optionsTokyo));

console.log('Time difference in hours:', hoursDifference, 'hours');
console.log('Time difference in minutes:', minutesDifference, 'minutes');




































RESTAPI
Representational State Transfer Application Programming Interface.
Simplicity and ease of use, Scalability,flexibility,statelessness,
interoperability,cacheability,uniform interface,reduced latency,ease of integration,security.

describe('DELETE /users/:id', () => {
    it('should delete a user by ID', async () => {
        // Define the user ID you want to delete (replace 'userID' with an actual ID)
        const userID = 'userID';

        try {
            // Make DELETE request to delete a user by ID
            const response = await axios.delete(`/users/${userID}`);

            // Assert that the response status is 204 (No Content) or 200 (OK) if it's appropriate for your API
            assert.isTrue(response.status === 204 || response.status === 200);
        } catch (error) {
            // If there's an error, fail the test with the error message
            assert.fail('err');
        }
    });
});