import assert from "assert";
import { expect } from "chai";
import sinon, { SinonSpy, SinonStub } from 'sinon';
import { describe } from "mocha";
import axios from "axios";
import app from '../src/index';
import { response } from "express";
import nock from "nock";
// const request = require('supertest');
let postLoginToken: any = {};
let URL = 'http://localhost:8000/';
describe('fetch api login data', () => {
    it('poste call api', async () => {
        let mockLoginData = {
            email: "mano@gmail.com",
            password: "mano"
        }
        postLoginToken = await axios.post(`${URL}users/login`, mockLoginData);
        assert.equal(postLoginToken.status, 200)
    });
    it('poste call api', async () => {
        let mockRegisterData = {
            email: "chandra@gmail.com",
            password: "chandra",
            name: "chandra",
            phone: 987654912,
            qualification: "B.E",
            dob: "1989-02-02",
            occupation: "Technical Architect",
            gender: "Male"
        }
        let postRegister = await axios.post(`${URL}users/register`, mockRegisterData);
        assert.equal(postRegister.status, 200)
    })
    it('get profile call api', async () => {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': postLoginToken.data.data
        }
        let result = await axios.get(`${URL}profiles/`, { headers: headers })   
           .then((response) => {
               assert.equal(response.data.message, 'profile data show success');
               assert.equal(response.data.status, 'success');
               assert.equal(response.data.statusCode, 8080);
           }).catch((error) => {
                console.log(error)
           })
    });
    it('get profile id api', async () => {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': postLoginToken.data.data
        }
        let result = await axios.get(`${URL}profiles/c38543ac-6b93-4f90-b863-738eda0d7830`, { headers: headers })   
           .then((response) => {
               assert.equal(response.data.message, 'profile id fect data success');
               assert.equal(response.data.status, 'success');
               assert.equal(response.data.statusCode, 8081);
           }).catch((error) => {
                console.log(error)
           })
    })
    it('post user with id and intrested id api', async () => {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': postLoginToken.data.data
        }
        let result = await axios.post(`${URL}users/c38543ac-6b93-4f90-b863-738eda0d7830/intrests/3ad978db-c860-41ff-b187-6c3c77a5b5d3`, { headers: headers })   
           .then((response) => {
               assert.equal(response.data.message, 'profile id fect data success');
               assert.equal(response.data.status, 'success');
               assert.equal(response.data.statusCode, 8082);
           }).catch((error) => {
                console.log(error)
           })
    })
    it('get user with in intrestsin api', async () => {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': postLoginToken.data.data
        }
        let result = await axios.get(`${URL}users/c38543ac-6b93-4f90-b863-738eda0d7830/interested-in`, { headers: headers })   
           .then((response) => {
               assert.equal(response.data.message, 'interested-in fect data success');
               assert.equal(response.data.status, 'success');
               assert.equal(response.data.statusCode, 8083);
           }).catch((error) => {
                console.log(error)
           })
    })

    it('get user with in intrestsby api', async () => {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': postLoginToken.data.data
        }
        let result = await axios.get(`${URL}users/3ad978db-c860-41ff-b187-6c3c77a5b5d3/interested-by`, { headers: headers })   
           .then((response) => {
               assert.equal(response.data.message, 'interested-in fect data success');
               assert.equal(response.data.status, 'success');
               assert.equal(response.data.statusCode, 8083);
           }).catch((error) => {
                console.log(error)
           })
    })
})
