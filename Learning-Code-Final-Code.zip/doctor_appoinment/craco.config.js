const path = require('path');

module.exports = {
  webpack: {
    configure: (webpackConfig) => {
      // Add file-loader to handle image files
      webpackConfig.module.rules.push({
        test: /\.(png|jpe?g|gif|svg)$/i,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[name].[ext]',
              outputPath: 'images/'
            }
          }
        ]
      });
      return webpackConfig;
    }
  }
};
