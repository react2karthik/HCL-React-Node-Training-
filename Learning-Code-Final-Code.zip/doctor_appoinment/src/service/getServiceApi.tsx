import axios, { AxiosResponse } from 'axios';
import { put, takeLatest, call } from 'redux-saga/effects';
const baseUrl = 'http://localhost:5000/users/';
const headers = {
    'Cache-Control': 'no-cache',
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': 'http://localhost:5000/users/login',
    'Authorization': localStorage.getItem('token') || ''
};
async function apiGetService(url: string) { 
    try {
        const config = {
            headers:headers,
        };
        const response:AxiosResponse =  await axios.get(url,config)
        //const response: AxiosResponse = yield call(axios.post, `${baseUrl}login`, payload, config);//await axios.post(baseUrl + 'login', payload);
        return response.data;
    } catch (error) {
        throw error;
    }
};
export default apiGetService
