import axios from "axios";
const callApi = async (url: string, payload: any, method: any) => {
    try {
        let response: any;
        console.log('11111111111111112',response)
        if (method == 'post') {
            response = await axios.post(url, payload)
            console.log('2222222222222222222222222222123212-url',url);
            console.log('546666666666666666666666666666666666666-payload',payload);
            console.log('5555555555555555555',response);
        } else if (method == 'get') {
            url = `http://localhost:3000/patientDetails?email=${payload.email}&password=${payload.password}`
            response = await axios.get(url);
        } else {
            response = await axios.get(url);
        }
        return response.data
    } catch (error: any) {
        console.log('77777777777777777777',error);
        throw new Error(error.message);
        console.log('666666666666666666666666666666666',error.message)
    }
}

export default callApi;