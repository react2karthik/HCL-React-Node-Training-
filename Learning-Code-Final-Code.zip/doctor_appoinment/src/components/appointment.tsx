import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCol, MDBRow, MDBInput, MDBCheckbox, MDBIcon } from 'mdb-react-ui-kit';
import { Formik, Field, Form, ErrorMessage } from 'Formik';
import * as Yup from 'yup';
import { useHistory } from 'react-router-dom';

const Appointment: React.FC = () => {
    const initialValues = {
        patientName: '',
        doctorName: '',
        appointmentDate: new Date().toISOString().slice(0, 16),
        reason: ''
    }
    const validationSchema = Yup.object({
        patientName: Yup.string().required('Patient name is required'),
        doctorName: Yup.string().required('Doctor name is required'),
        appointmentDate: Yup.date().required('Appointment date is required').min(new Date(), 'Appointment date must be in the future'),
        reason: Yup.string().required('Reason for appointment is required')
    });
    const history = useHistory();
    const handleSubmit = async (values: any,{ resetForm }: { resetForm: () => void }) => {
        alert(JSON.stringify(values, null, 2));
        try {
            const response = await fetch('http://localhost:3000/appoinmentDetails', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(values),
            });
            alert(JSON.stringify(response, null, 2));
            if (response.ok) {
                alert('Appointment successful');
                resetForm();
                //history.push('/appointmentforminfo');
            } else {
                alert('Appointment  failed');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred');
        }
    };
    return (
        <>
            <div>
                <h2 className='text-center mt-4 text-success'>Doctor Appointment Details</h2>
                <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
                    {({ values, handleChange }) => (
                        <Form>
                            <MDBContainer>
                                <MDBRow className='g-0'>
                                    <MDBCol md='12' className='mx-auto'>
                                        <MDBCard className='mx-2 mb-2 p-2 shadow-5'>
                                            <MDBCardBody className='text-black d-flex flex-column justify-content-center w-50 mx-auto'>
                                                <label htmlFor="patientName" className=''>Patient Name *</label>
                                                <Field type="text" id="patientName" name="patientName" />
                                                <ErrorMessage name="patientName" component="div" className="text-danger" />
                                                <label htmlFor="doctorName" className=' mt-2'>Doctor Name*</label>
                                                <Field type="text" id="doctorName" name="doctorName" />
                                                <ErrorMessage name="doctorName" component="div" className="text-danger" />
                                                <label htmlFor="appointmentDate" className=' mt-2'>Appointment Date *</label>
                                                <Field type="datetime-local" id="appointmentDate" name="appointmentDate" />
                                                <ErrorMessage name="appointmentDate" component="div" className="text-danger" />
                                                <label htmlFor="reason" className=' mt-2'>Reason for Appointment*</label>
                                                <Field as="textarea" id="reason" name="reason" />
                                                <ErrorMessage name="reason" component="div" className="text-danger" />
                                                <MDBBtn className='w-100 mt-4 bg-success bg-gradient text-white' size="lg" type="submit">Book Appointment</MDBBtn>
                                            </MDBCardBody>
                                        </MDBCard>
                                    </MDBCol>
                                </MDBRow>
                            </MDBContainer>
                        </Form>
                    )}
                </Formik>
            </div>
        </>
    )
}

export default Appointment