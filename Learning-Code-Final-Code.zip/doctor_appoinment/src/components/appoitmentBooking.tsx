import React, { useState, useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage, useFormik } from 'Formik';
import * as Yup from 'yup';
import { MDBContainer, MDBRow, MDBCol, MDBCard, MDBCardBody, MDBInput, MDBBtn } from 'mdb-react-ui-kit';
import { appointmentRequest } from '../../src/redux/action/appointmentAction';
import { useHistory } from 'react-router-dom';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import AlertComponent from '../../src/components/form/alertFiled';
const AppointmentBooking: React.FC = () => {
    const initialValues = {
        patientName: '',
        doctorName: '',
        appointmentDate: new Date().toISOString().slice(0, 16),
        reason: '',
    };
    const history = useHistory();
    const initialValidation = Yup.object({
        patientName: Yup.string().required('patientName  is required'),
        doctorName: Yup.string().required('doctorName is required'),
        appointmentDate: Yup.date().required('Appointment date is required').min(new Date(), 'Appointment date must be in the future'),
        reason: Yup.string().required('Reason is required'),        
    });
    const dispatch = useDispatch();  
    const [list, setDrList] = useState('');      
    const appointmentInfo = useSelector((state: any) => state.appointmentReducer.data);
    console.log('appointmentInfo',appointmentInfo)
    const handleSubmit = async (values: any) => {
        dispatch(appointmentRequest(values));
        history.push('/appointmentforminfo');
    };
    
    useEffect(() => {
        axios.get('http://localhost:3000/doctorDetails').then((res) => {
            const drNames = res.data.map((x: any) => <option value={x.drName} key={x.drName}>{x.drName}  {`   -   [  ${x.expertIn}  ]`} </option>);
            setDrList(drNames);
        })
    }, []);
    return (
        <Formik initialValues={initialValues} validationSchema={initialValidation} onSubmit={handleSubmit}>
            {({ values, handleChange }) => (
                <Form>
                    <MDBContainer fluid className=''>
                        <MDBRow className='g-0 align-items-center'>
                            <MDBCol col='6'>
                                <MDBCard className='cascading-right' style={{ background: 'hsla(0, 0%, 100%, 0.55)', backdropFilter: 'blur(30px)' }}>
                                   
                                    <MDBCardBody className='p-1 shadow-5 text-center'>
                                        <MDBCol md="8" offsetMd="2" className='register_label'>
                                            <h2 className="fw-bold mb-5">Doctor Appointment Details</h2>
                                            <label htmlFor="name">PatientName *</label> 
                                            <Field className='mb-4 w-100' label='PatientName' id='patientName' type='text' name='patientName' />
                                            <ErrorMessage name="patientName" component="div" className="text-danger" />
                                            <label htmlFor="doctorName">DoctorName *</label>
                                            <div className="mb-3 w-100">
                                                <select className="form-select" name="doctorName"  onChange={handleChange}>
                                                    <option value="">Select Doctor</option>
                                                        {list}
                                                </select>
                                                <ErrorMessage name="doctorName" component="div" className="text-danger" />
                                            </div>                                            
                                            <label htmlFor="appointmentDate" className=' mt-2'>Appointment Date *</label>
                                            <Field className='mb-4 w-100' type="datetime-local" id="appointmentDate" name="appointmentDate" />
                                            <ErrorMessage name="appointmentDate" component="div" className="text-danger" />
                                            <label htmlFor="age">Reason *</label>
                                            <Field className='mb-4 w-100' label='Reason' id='text' type='text' name='reason' />
                                            <ErrorMessage name="reason" component="div" className="text-danger" />
                                            
                                            
                                            
                                            <MDBBtn className='w-100 mt-4 bg-success bg-gradient text-white' size="lg" type="submit">Register</MDBBtn>
                                        </MDBCol>
                                    </MDBCardBody>
                                </MDBCard>
                            </MDBCol>
                            <MDBCol col='6'>
                                <img src="https://th.bing.com/th/id/OIP.5mKhC6-deRJDTnpQe77LugAAAA?rs=1&pid=ImgDetMain" className="w-100 rounded-4 shadow-4" alt="" />
                            </MDBCol>
                        </MDBRow>
                    </MDBContainer>
                </Form>
            )}
        </Formik>
    );
}

export default AppointmentBooking;

