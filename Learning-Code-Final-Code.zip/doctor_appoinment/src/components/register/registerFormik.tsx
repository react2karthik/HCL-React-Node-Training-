import React,{useState,useEffect} from 'react';
import { Formik, Form, Field, ErrorMessage, useFormik } from 'Formik';
import * as Yup from 'yup';
import { MDBContainer, MDBRow, MDBCol, MDBCard, MDBCardBody, MDBInput, MDBBtn } from 'mdb-react-ui-kit';
// import { register1Request } from '../../redux/action/register1Actions';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import AlertComponent from '../form/alertFiled';
const RegisterUI: React.FC = () => {
  const initialValues = {
    name: '',
    email: '', 
    password: '', 
    phone: '', 
    age: '', 
};
const [showAlert, setShowAlert] = useState(false);
const [alertMessage, setAlertMessage] = useState('');
const [alertType,setAlertType] = useState('danger')
const history = useHistory();
  const initialValidation = Yup.object({
    name: Yup.string().required('Name is required'),
    email: Yup.string().required('Email is required').email(),
    password: Yup.string().required('Password is required').min(6, 'Password must be at least 6 characters').max(40, 'Password must not exceed 40 characters'),
    phone: Yup.string().required('Phone number is required').max(10, 'Phone number must not exceed 10 characters'),
    age: Yup.string().required('Age is required'),
    //gender: Yup.string().required('Gender is required')
  });
  //const dispatch = useDispatch();
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowAlert(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, [showAlert]);
  const handleRegister = async (values: any) => {
    //alert(JSON.stringify(values, null, 2));
    try {
      const response = await fetch('http://localhost:3000/patientDetails', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });
      //alert(JSON.stringify(response, null, 2));
      if (response.ok) {
        setShowAlert(true);
        setAlertMessage("Registration successful,Redirecting to login page...");
        setAlertType('success');
        setTimeout(() => {
          //history.push('/');
          history.push('/');
      }, 3000);
      } else {
        setShowAlert(true);
        setAlertMessage("Registration failed");
        setAlertType('danger');
      }
    } catch (error) {
      console.error('Error:', error);
      setShowAlert(true);
      setAlertMessage("Registration failed");
      setAlertType('danger');
    }
  };
  return (
    <Formik initialValues={initialValues} validationSchema={initialValidation} onSubmit={handleRegister}>
      {({values,handleChange}) => (
        <Form>
        <MDBContainer fluid className='my-2'>
          <MDBRow className='g-0 align-items-center'>
            <MDBCol col='6'>
              <MDBCard className='my-5 cascading-right' style={{ background: 'hsla(0, 0%, 100%, 0.55)', backdropFilter: 'blur(30px)' }}>
              {showAlert && (
                                        <AlertComponent type={alertType} message={alertMessage} />
                                    )}
                <MDBCardBody className='p-5 shadow-5 text-center'>
                  <MDBCol md="8" offsetMd="2" className='register_label'>
                    <h2 className="fw-bold mb-5">Register</h2>
                    <label htmlFor="name">Name *</label>
                    <Field className='mb-4 w-100' label='Name' id='name' type='text' name='name' />
                    <ErrorMessage name="name" component="div" className="text-danger" />
                    <label htmlFor="email">Email *</label>
                    <Field className='mb-4 w-100' label='Email' id='email' type='email' name='email' />
                    <ErrorMessage name="email" component="div" className="text-danger" />
                    <label htmlFor="Password">Password *</label>
                    <Field className='mb-4 w-100' label='Password' id='password' type='password' name='password' />
                    <ErrorMessage name="password" component="div" className="text-danger" />
                    <label htmlFor="age">Age *</label>
                    <Field className='mb-4 w-100' label='Age' id='age' type='age' name='age' />
                    <ErrorMessage name="age" component="div" className="text-danger" />
                    <label htmlFor="phone">Phone *</label>
                    <Field className='mb-4 w-100' label='Phone' id='phone' type='number' name='phone' />
                    <ErrorMessage name="phone" component="div" className="text-danger" />
                    <div className="mb-3 w-100">
                      <select className="form-select" name="gender">
                        <option value="">Select Gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                      <ErrorMessage name="gender" component="div" className="text-danger" />
                    </div>
                    <MDBBtn className='w-100 mt-4 bg-success bg-gradient text-white' size="lg" type="submit">Register</MDBBtn>
                  </MDBCol>
                </MDBCardBody>
              </MDBCard>
            </MDBCol>
            <MDBCol col='6'>
              <img src="https://cdn.dribbble.com/users/1520330/screenshots/4085172/____.jpg" className="w-100 rounded-4 shadow-4" alt="" />
            </MDBCol>
          </MDBRow>
        </MDBContainer>
      </Form>
      )}
    </Formik>
  );
}

export default RegisterUI;


// import React, { useState } from 'react';
// import { MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBInput, MDBIcon, MDBRow, MDBCol, MDBCheckbox } from 'mdb-react-ui-kit';
// import { Formik, Field, Form, ErrorMessage, useFormik } from 'Formik';
// import * as Yup from 'yup';
// const RegisterUI: React.FC = () => {
//   // const registerFormik = {
//   //   name: '', email: '', password: '', phone: '', age: '', gender: ''
//   // }
//   const registerFormik = useFormik({
//     initialValues: {
//         name: '',
//         email: '',
//         password: '',
//         phone: '',
//         gender:'',
//         age:''
//     },
//     onSubmit: values => {
//         alert(JSON.stringify(values, null, 2));
//     },
// });
//   console.log('99999999999999999', registerFormik)
//   const validationRegister = Yup.object({
//     name: Yup.string().required('Name is required'),
//     email: Yup.string().required('Email is required').email(),
//     password: Yup.string().required('Password is required').min(6, 'Password must be at least 6 characters').max(40, 'Password must not exceed 40 characters'),
//     phone: Yup.string().required('Phone number is required').max(10, 'Phone number must not exceed 10 characters'),
//     age: Yup.string().required('Age is required'),
//     gender: Yup.string().required('Gender is required')
//   });
//   const handleRegister = async (values: any) => {
//     try {
//       const response = await fetch('http://localhost:3000/patientDetails', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json'
//         },
//         body: JSON.stringify(values)
//       });
  
//       if (response.ok) {
//         alert('Registration successful');
//       } else {
//         alert('Registration failed');
//       }
//     } catch (error) {
//       console.error('Error:', error);
//       alert('An error occurred');
//     }
//   };
  
//   return (
//     <Formik initialValues={registerFormik.initialValues} validationSchema={validationRegister} onSubmit={handleRegister}>
//       {({ values, handleChange }) => (
//         <Form>
//           <MDBContainer fluid className='my-2'>

//             <MDBRow className='g-0 align-items-center'>
//               <MDBCol col='6'>

//                 <MDBCard className='my-5 cascading-right' style={{ background: 'hsla(0, 0%, 100%, 0.55)', backdropFilter: 'blur(30px)' }}>
//                   <MDBCardBody className='p-5 shadow-5 text-center'>
//                     <MDBCol md="8" offsetMd="2">
//                       <h2 className="fw-bold mb-5">Sign Up Now</h2>
//                       <MDBInput wrapperClass='mb-4  w-100' name="name" label='Name' id='name' type='text'  />
//                       <ErrorMessage name="name" component="div" className="text-danger" />
//                       <MDBInput wrapperClass='mb-4  w-100' name="email" label='Email' id='email' type='email'  />
//                       <ErrorMessage name="email" component="div" className="text-danger" />
//                       <MDBInput wrapperClass='mb-4  w-100' name="password" label='Password' id='password' type='password' />
//                       <ErrorMessage name="password" component="div" className="text-danger" />
//                       <MDBInput wrapperClass='mb-4  w-100' name="age" label='Age' id='age' type='age'  />
//                       <ErrorMessage name="age" component="div" className="text-danger" />
//                       <MDBInput wrapperClass='mb-4  w-100' name="phone" label='Phone' id='phone' type='number'  />
//                       <ErrorMessage name="phone" component="div" className="text-danger" />
//                       <div className="mb-3  w-100">
//                         <select
//                           className="form-select"
//                           name="gender"
//                           //onChange={registerFormik.handleChange}
                        
//                         >
//                           <option value="">Select Gender</option>
//                           <option value="male">Male</option>
//                           <option value="female">Female</option>
//                           <option value="other">Other</option>
//                         </select>
//                         <ErrorMessage name="gender" component="div" className="text-danger" />
//                       </div>
//                       <MDBBtn className=' w-100 mb-4' size="lg" type="submit">sign up</MDBBtn>
//                     </MDBCol>
//                   </MDBCardBody>
//                 </MDBCard>
//               </MDBCol>

//               <MDBCol col='6'>
//                 <img src="https://cdn.dribbble.com/users/1520330/screenshots/4085172/____.jpg" className="w-100 rounded-4 shadow-4"
//                   alt="" />
//               </MDBCol>

//             </MDBRow>

//           </MDBContainer>
//         </Form>
//       )}
//     </Formik>
//   );
// }

// export default RegisterUI;