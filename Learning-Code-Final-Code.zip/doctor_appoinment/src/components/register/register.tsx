import React, { useState, useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage, useFormik } from 'Formik';
import * as Yup from 'yup';
import { MDBContainer, MDBRow, MDBCol, MDBCard, MDBCardBody, MDBInput, MDBBtn } from 'mdb-react-ui-kit';
import { registerRequest } from '../../redux/action/registerActions';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import AlertComponent from '../form/alertFiled';
const Register: React.FC = () => {
    const initialValues = {
        name: '',
        email: '',
        password: '',
        phone: '',
        age: '',
        gender: ''
    };
    const history = useHistory();
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertType,setAlertType] = useState('danger')
    const initialValidation = Yup.object({
        name: Yup.string().required('Name is required'),
        email: Yup.string().required('Email is required').email(),
        password: Yup.string().required('Password is required').min(6, 'Password must be at least 6 characters').max(40, 'Password must not exceed 40 characters'),
        phone: Yup.string().required('Phone number is required').max(10, 'Phone number must not exceed 10 characters'),
        age: Yup.string().required('Age is required'),
        gender: Yup.string().required('Gender is required')
    });
    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false);
        }, 1500);

        return () => clearTimeout(timer);
    }, [showAlert]);
    const dispatch = useDispatch();        
    const registerInfo = useSelector((state: any) => state.registerReducer.data);
    const handleRegister = async (values: any) => {
        dispatch(registerRequest(values));
    };
    useEffect(() => {
        if (registerInfo?.id) {
            setShowAlert(true)
            setAlertType('success');
            setAlertMessage("'Registration ,Redirect 10 login page");
            setTimeout(() => {
                history.push('/');
            }, 3000);
        } else {
            setShowAlert(true);
                setAlertType('danger');
                setAlertMessage("Registration failed");
        }
    }, [registerInfo])
    return (
        <Formik initialValues={initialValues} validationSchema={initialValidation} onSubmit={handleRegister}>
            {({ values, handleChange }) => (
                <Form>
                    <MDBContainer fluid className=''>
                        <MDBRow className='g-0 align-items-center'>
                            <MDBCol col='6'>
                                <MDBCard className='cascading-right' style={{ background: 'hsla(0, 0%, 100%, 0.55)', backdropFilter: 'blur(30px)' }}>
                                    {showAlert && (
                                        <AlertComponent type={alertType} message={alertMessage} />
                                    )}
                                    <MDBCardBody className='p-1 shadow-5 text-center'>
                                        <MDBCol md="8" offsetMd="2" className='register_label'>
                                            <h2 className="fw-bold mb-5">Register</h2>
                                            <label htmlFor="name">Name *</label>
                                            <Field className='mb-4 w-100' label='Name' id='name' type='text' name='name' />
                                            <ErrorMessage name="name" component="div" className="text-danger" />
                                            <label htmlFor="email">Email *</label>
                                            <Field className='mb-4 w-100' label='Email' id='email' type='email' name='email' />
                                            <ErrorMessage name="email" component="div" className="text-danger" />
                                            <label htmlFor="Password">Password *</label>
                                            <Field className='mb-4 w-100' label='Password' id='password' type='password' name='password' />
                                            <ErrorMessage name="password" component="div" className="text-danger" />
                                            <label htmlFor="age">Age *</label>
                                            <Field className='mb-4 w-100' label='Age' id='age' type='age' name='age' />
                                            <ErrorMessage name="age" component="div" className="text-danger" />
                                            <label htmlFor="phone">Phone *</label>
                                            <Field className='mb-4 w-100' label='Phone' id='phone' type='number' name='phone' />
                                            <ErrorMessage name="phone" component="div" className="text-danger" />
                                            <div className="mb-3 w-100">
                                                <select className="form-select" name="gender"  onChange={handleChange}>
                                                    <option value="">Select Gender</option>
                                                    <option value="male">Male</option>
                                                    <option value="female">Female</option>
                                                    <option value="other">Other</option>
                                                </select>
                                                <ErrorMessage name="gender" component="div" className="text-danger" />
                                            </div>
                                            <MDBBtn className='w-100 mt-4 bg-success bg-gradient text-white' size="lg" type="submit">Register</MDBBtn>
                                        </MDBCol>
                                    </MDBCardBody>
                                </MDBCard>
                            </MDBCol>
                            <MDBCol col='6'>
                                <img src="https://cdn.dribbble.com/users/1520330/screenshots/4085172/____.jpg" className="w-100 rounded-4 shadow-4" alt="" />
                            </MDBCol>
                        </MDBRow>
                    </MDBContainer>
                </Form>
            )}
        </Formik>
    );
}

export default Register;

