import React, { useState, useEffect } from 'react';
import { MDBTable, MDBTableHead, MDBTableBody, MDBContainer, MDBRow, MDBCol, MDBBtn, MDBIcon } from 'mdb-react-ui-kit';
import axios from 'axios';
import { IAppointmentModuls } from 'src/models/appointmentInfoModuls';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import Modal from './form/modal';
const AppointmentInfo: React.FC = () => {
    const [appointments, setAppointments] = useState<IAppointmentModuls[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage] = useState(5);
    const dispatch = useDispatch();
    const history = useHistory();
    useEffect(() => {
        axios.get<IAppointmentModuls[]>('http://localhost:3000/appoinmentDetails')
            .then(response => {
                console.log('mmmmmmmmmmmmmmmm...................', response.data)
                setAppointments(response.data);
            })
            .catch(error => {
                console.error('Error fetching appointments:', error);
            });
    }, []);

    const totalPages = Math.ceil(appointments.length / itemsPerPage);
    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = appointments.slice(indexOfFirstItem, indexOfLastItem);
    const [cancelConfirmationId, setCancelConfirmationId] = useState<number | null>(null); // State to manage appointment id for cancel confirmation
    const [isCancelConfirmationOpen, setIsCancelConfirmationOpen] = useState(false); // State to manage modal visibility

    const cancelAppointment = (id: number) => {      
        const updatedAppointments = appointments.filter(appointment => appointment.id !== id);
        setCancelConfirmationId(id);
        setIsCancelConfirmationOpen(true);
        // alert(id);
        // const updatedAppointments = appointments.filter(appointment => appointment.id !== id);
        // setAppointments(updatedAppointments);
    };
    const handleCancelConfirmation = (id: number) => {
        // setIsCancelConfirmationOpen(false);
        // const updatedAppointments = appointments.filter(appointment => appointment.id !== cancelConfirmationId);
        // setAppointments(updatedAppointments);
        if (isCancelConfirmationOpen === true) {
            const updatedAppointments = appointments.filter(appointment => appointment.id !== cancelConfirmationId);
            setAppointments(updatedAppointments);
        }
        setIsCancelConfirmationOpen(false); 
    };
    return (
        <MDBContainer>
            <MDBRow className="mt-2 g-0">
                <MDBCol className="table-bordered ml-auto mt-2 mb-2" md='12'>
                    <MDBTable className="table-bordered border rounded-5" bordered borderColor="primary" responsive>
                        <MDBTableHead>
                            <tr>
                                <th scope='col' className='fw-bold'>Id</th>
                                <th scope='col' className='fw-bold'>Patient Name</th>
                                <th scope='col' className='fw-bold'>Doctor Info</th>
                                <th scope='col' className='fw-bold'>Appointment Date</th>
                                <th scope='col' className='fw-bold'>Reason</th>
                                <th scope='col' className='fw-bold'>Cancel</th>
                            </tr>
                        </MDBTableHead>
                        <MDBTableBody>
                            {currentItems.map((appointment, index) => (
                                <tr key={index}>
                                    <td className='fw-bold text-muted'>{appointment.id}</td>
                                    <td className='fw-bold text-muted'>{appointment?.payload?.patientName}</td>
                                    <td className='fw-bold text-muted'>{appointment?.payload?.doctorName}</td>
                                    <td className='fw-bold text-muted'>{appointment?.payload?.appointmentDate}</td>
                                    <td className='fw-bold text-muted'>{appointment?.payload?.reason}</td>
                                    <td className='fw-bold text-muted'>
                                        <MDBBtn onClick={() => cancelAppointment(appointment.id)}><MDBIcon far icon="times-circle" /></MDBBtn>
                                    </td>
                                </tr>
                            ))}
                        </MDBTableBody>
                    </MDBTable>
                </MDBCol>
            </MDBRow>
            <MDBRow>
                <MDBCol className="text-center">
                    <nav>
                        <ul className="pagination justify-content-center">
                            {Array.from({ length: totalPages }, (_, index) => (
                                <li key={index} className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}>
                                    <button className="page-link" onClick={() => handlePageChange(index + 1)}>
                                        {index + 1}
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </nav>
                </MDBCol>
            </MDBRow>
            <Modal
                modalTitleText="Cancel Appointment"
                toggleOpen={() => setIsCancelConfirmationOpen(isCancelConfirmationOpen)}
                isOpen={isCancelConfirmationOpen}
                confirmAction={handleCancelConfirmation}
            >
                Are you sure you want to cancel this appointment?
            </Modal>
        </MDBContainer>
    );
}

export default AppointmentInfo;
