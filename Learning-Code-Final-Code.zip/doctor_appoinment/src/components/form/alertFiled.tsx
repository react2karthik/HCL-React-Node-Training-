import React from 'react';
import {AlertModuls} from './../../models/alertModuls'; 

const AlertComponent: React.FC<AlertModuls> = ({ type, message }) => {
  return (
    <div className={`alert alert-${type} w-50 mx-auto`} role="alert">
      {message}
    </div>
  );
}

export default AlertComponent;
