import React from 'react';
import { MDBModal, MDBModalDialog, MDBModalContent, MDBModalHeader, MDBModalTitle, MDBModalBody, MDBModalFooter, MDBBtn } from 'mdb-react-ui-kit';

interface ModalProps {
  modalTitleText: string;
  toggleOpen: () => void;
  isOpen: boolean; // Change setOpen to isOpen to match state variable name
  children:React.ReactNode;
  confirmAction: (id: any) => void;
}

const Modal: React.FC<ModalProps> = ({ modalTitleText, toggleOpen, isOpen, children,confirmAction }) => {
  return (
    <MDBModal open={isOpen} setOpen={toggleOpen} tabIndex='-1'>
      <MDBModalDialog>
        <MDBModalContent>
          <MDBModalHeader>
            <MDBModalTitle className='fw-bold'>{modalTitleText}</MDBModalTitle>
            <MDBBtn className='btn-close' color='none' onClick={toggleOpen}></MDBBtn>
          </MDBModalHeader>
          <MDBModalBody className='fw-bold'>
            {children}
          </MDBModalBody>
          <MDBModalFooter>
            <MDBBtn color='secondary' onClick={toggleOpen} className='fw-bold'>
              No
            </MDBBtn>
            <MDBBtn onClick={() => confirmAction(1)} className='fw-bold'>Yes</MDBBtn>
          </MDBModalFooter>
        </MDBModalContent>
      </MDBModalDialog>
    </MDBModal>
  );
}

export default Modal;
