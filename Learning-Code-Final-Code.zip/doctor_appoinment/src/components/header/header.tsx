import React,{useState,useEffect} from 'react';
import {
  MDBNavbar,
  MDBBtn,
  MDBContainer,MDBNavbarBrand
} from 'mdb-react-ui-kit';
import { Link } from 'react-router-dom';
import Navbar from './navbar';
// import logo from '../../assets/logo.png'; // Import your logo file
// const logo = require('../../assets/logo.png')
const Header: React.FC = (setPassIsLoggedIn:any ) => {
  const [isLoggedIn,setIsLoggedIn] = useState(false);
 
  return (
    <MDBNavbar light bgColor='light'>
      <MDBContainer tag="form" fluid >
         <MDBNavbarBrand>
          <img src="https://images.rawpixel.com/image_png_800/czNmcy1wcml2YXRlL3Jhd3BpeGVsX2ltYWdlcy93ZWJzaXRlX2NvbnRlbnQvbHIvdjk4Ny0xOGEucG5n.png" alt='Logo' height='60' className='d-inline-block align-top me-2' />
         
        </MDBNavbarBrand>
        {/* <MDBBtn outline color="success" className='me-2' type='button'>
        Main button
        </MDBBtn> */}
        {/* <MDBBtn outline color="secondary" size="sm" type='button'>
          Smaller button
        </MDBBtn> */}
        {/* {isLoggedIn && <Navbar />} */}
        <Navbar isLoggedIn={isLoggedIn} />
      </MDBContainer>
    </MDBNavbar>
  );
}
export default Header;