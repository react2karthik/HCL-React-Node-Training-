import React, { useEffect, useState } from 'react';
import {
  MDBNavbar,
  MDBContainer,
  MDBIcon,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarLink,
  MDBNavbarToggler,
  MDBNavbarBrand,
  MDBCollapse
} from 'mdb-react-ui-kit';
interface NavbarProps {
  isLoggedIn?: boolean;
}
const Navbar: React.FC<NavbarProps> = ({ isLoggedIn })  => {
  const [openNavColor, setOpenNavColor] = useState(false);
  const [openNavColorSecond, setOpenNavColorSecond] = useState(false);
  const [openNavColorThird, setOpenNavColorThird] = useState(false);
  const [isLogin,setIsLogin] = useState(false);
  return (
   
    <>
      <div className='navBar'>
        <MDBNavbar expand='lg'>
          {/* <MDBContainer fluid> */}

          <MDBNavbarNav className='me-auto mb-2 mb-lg-0 flex-row'>
            <MDBNavbarItem className='active'>
              <MDBNavbarLink aria-current='page' href='/'>
              <MDBIcon fas icon="book" /><span className="navTex px-2">Home</span>
              {/* Home */}
              </MDBNavbarLink>
            </MDBNavbarItem>
            <MDBNavbarItem>            
              <MDBNavbarLink href='/dashboard'>
              <MDBIcon fas icon="grip-horizontal" /><span className="navTex px-2">Dashboard</span>
                {/* Features */}
                </MDBNavbarLink>
            </MDBNavbarItem>
            <MDBNavbarItem>
            
              <MDBNavbarLink href='/addbook'>
              <MDBIcon fas icon="plus" /><span className="navTex px-2">Add Book</span>
                {/* Pricing */}
                </MDBNavbarLink>
            </MDBNavbarItem>
            <MDBNavbarItem>
               <MDBNavbarLink href='/borrowedBook'>
                <MDBIcon fas icon="clipboard-list" /><span className="navTex px-2">Borrowed Book</span>
              
                </MDBNavbarLink>  
                      
                {/* {isLogin ? (
                  <MDBNavbarLink href='/borrowedBook'>
                    <MDBIcon fas icon='clipboard-list' />
                    <span className='navTex px-2'>Borrowed Book</span>
                  </MDBNavbarLink>
                ) : ''} */}

            </MDBNavbarItem>
          </MDBNavbarNav>

          {/* </MDBContainer> */}
        </MDBNavbar>
      </div>
    </>
  );
}
export default Navbar;