import React from "react";
import { useDispatch, useSelector, Provider } from 'react-redux';
import { shallow, mount, render, ReactWrapper } from 'enzyme';
// import RegisterUI from "./registerFormik";
import configureStore from 'redux-mock-store';
import AppointmentBooking from "./appoitmentBooking";
const mockStore = configureStore([]);
jest.mock('../../src/service/serviceApiDoc', () => {
    return {
        ...jest.requireActual('../../src/service/serviceApiDoc'),
        appoitmentBooking: jest.fn(),
    }
})
describe('AppointmentInfo Form component', () => {
    let store: ReturnType<typeof mockStore>;
    let wrapper: ReactWrapper;
    beforeEach(() => {
        store = mockStore({
            auth: {
                userData: null,
            },
        });
        wrapper = mount(
            <Provider store={store}>
                <AppointmentBooking />
            </Provider>
        )
        console.log(wrapper);
        //console.log(wrapper.html());
    })
    it('test appointment from ', () => {
        expect(wrapper.find('MDBTable')).toHaveLength(1);
    })
    it('has bootstrap form controls', () => {
        expect(wrapper.find('text-danger')).toHaveLength(2);
    });
    it("Test click event", () => {
        const mockCallBack = jest.fn();
        const button1 = shallow((<button onClick={mockCallBack}>Submit</button>));
        button1.find('button').simulate('click');
        expect(mockCallBack.mock.calls.length).toEqual(1);
    });
});

