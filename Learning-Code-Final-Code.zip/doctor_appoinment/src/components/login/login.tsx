import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MDBBtn, MDBContainer, MDBCard, MDBCardBody, MDBCol, MDBRow, MDBInput, MDBCheckbox, MDBIcon } from 'mdb-react-ui-kit';
import { Formik, Field, Form, ErrorMessage } from 'Formik';
import * as Yup from 'yup';
import { useHistory } from 'react-router-dom';
import { useApiContext } from '../context/context';
import AlertComponent from '../form/alertFiled';
import { loginRequest } from '../../redux/action/loginActions';

// const loginImg = require('../../image/login.jpg');
const Logi: React.FC = () => {
    const initialValue = {
        email: '',
        password: ''
    }
    const initialValidation = Yup.object({
        email: Yup.string().required('Email is required').email(),
        password: Yup.string().required('Password is required').min(6, 'Password must be at least 6 characters').max(40, 'Password must not exceed 40 characters')
    })
    const [showAlert, setShowAlert] = useState(true);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertType, setAlertType] = useState('danger')
    const history = useHistory();
    const dispatch = useDispatch();
    useEffect(() => {
        const timer = setTimeout(() => {
            setShowAlert(false);
        }, 3000);
        return () => clearTimeout(timer);
    }, [showAlert]);

    const loginInfo = useSelector((state: any) => state.loginReducer.data);
    const handleLogin = async (values: any) => {
        dispatch(loginRequest(values));
    }
    useEffect(() => {
        if (loginInfo?.length > 0) {
            setShowAlert(true);
            setAlertMessage("Login successful,Redirecting to appointment  booking page...");
            setAlertType('success');
            setTimeout(() => {
                history.push('/appointmentform');
            }, 3000);
        } else {
            setShowAlert(true);
            setAlertType('danger');
            setAlertMessage("Invalid email or password");
        }
    }, [loginInfo])
    const handleRegister = () => {
        history.push('/register');
    }
    return (
        <>
            <Formik initialValues={initialValue} validationSchema={initialValidation} onSubmit={handleLogin}>
                {({ values, handleChange }) => (
                    <Form>
                        <MDBContainer className='mt-2'>
                            <MDBRow className='g-0'>
                                {showAlert && (
                                    <AlertComponent type={alertType} message={alertMessage} />
                                )}
                                <MDBCol md='12' className='mx-auto'>
                                    <div className="p-5 bg-image" style={{ backgroundImage: `url(https://cdn2.iconfinder.com/data/icons/jetflat-buildings/90/008_010_hospital_clinic_building-512.png)`, height: '70%', width: '35%', margin: '0 auto' }}></div>

                                    <MDBCard className='mx-2 mb-2 p-2 shadow-5' style={{ background: 'hsla(0, 0%, 100%, 0.8)', backdropFilter: 'blur(30px)', transform: 'translateY(-45%)' }}>

                                        <MDBCardBody className='text-black d-flex flex-column justify-content-center w-50 mx-auto'>

                                            <label htmlFor="email">Email *</label>
                                            <Field type="text" id="email" name="email" className='mb-4' />
                                            <ErrorMessage name="email" component="div" className="text-danger" />
                                            <label htmlFor="email">Password *</label>
                                            <Field type="text" id="password" name="password" className='mb-4' />
                                            <ErrorMessage name="password" component="div" className="text-danger" />

                                            <p className='d-flex justify-content-center align-item-center mt-2 text-primary'>If you are an existing patient, please sign in. Otherwise, please register</p>
                                            <div className="d-flex justify-content-center align-items-center mt-2">
                                                <MDBBtn type='submit' className="bg-success bg-gradient text-white">
                                                    Sign in
                                                </MDBBtn>
                                                <MDBBtn className="bg-gradient text-white mx-3" onClick={handleRegister}>
                                                    Register
                                                </MDBBtn>
                                            </div>
                                        </MDBCardBody>
                                    </MDBCard>
                                </MDBCol>
                            </MDBRow>
                        </MDBContainer>
                    </Form>
                )}
            </Formik>
        </>
    );
}

export default Logi;