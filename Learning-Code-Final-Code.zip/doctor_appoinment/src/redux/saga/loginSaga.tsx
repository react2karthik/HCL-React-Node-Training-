import { call, put, takeLatest } from 'redux-saga/effects'; //takeevery
import { LOGIN, loginSuccess, loginFailed } from '../action/loginActions';
import { LOGINAPI } from '../../constant';
import callApi from '../../service/serviceApiDoc';
 
function* login(data: any):Generator<any, void, any> {
  try {
    const response:any = yield call(callApi, LOGINAPI, data.payload, 'get');
    yield put(loginSuccess(response));
  } catch (error) {
    yield put(loginFailed(error));
  }
}
 
function* loginSaga() {
  yield takeLatest(LOGIN, login);
}
 
export default loginSaga;