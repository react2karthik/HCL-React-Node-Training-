import { call, put, takeLatest } from 'redux-saga/effects';
import { APPOINTMENT_REQUEST, appointmentSuccess, appointmentFailure } from '../action/appointmentAction';
import { APPOINMENTDETAILSAPI } from '../../constant';
import apiService from '../../service/serviceApiDoc';

function* appointment(data: any): Generator<any, void, any> {
    try {
        const response: any = yield call(apiService, APPOINMENTDETAILSAPI, data, 'post');//APPOINMENTDETAILSAPI
        yield put(appointmentSuccess(response));
    } catch (error: any) {
        yield put(appointmentFailure(error.message))
    }
}
function* appointmentSaga() {
    yield takeLatest(APPOINTMENT_REQUEST, appointment)
}
export default appointmentSaga;
