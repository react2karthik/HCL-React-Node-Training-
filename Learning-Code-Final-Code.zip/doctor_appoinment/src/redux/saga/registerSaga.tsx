import { call, put, takeLatest } from 'redux-saga/effects';
import { REGISTER_REQUEST, registerSuccess, registerFailure } from '../action/registerActions';
import { REGISTERAPI } from '../../constant';
import callApi from '../../service/serviceApiDoc';

function* register(data: any): Generator<any, void, any> {
    try {
        const response: any = yield call(callApi, REGISTERAPI, data.payload, 'post');
        yield put(registerSuccess(response));
    } catch (error: any) {
        yield put(registerFailure(error.message))
    }
}
function* registerSaga() {
    yield takeLatest(REGISTER_REQUEST, register)
}
export default registerSaga;

// import { call, put, takeEvery } from 'redux-saga/effects';
// import { REGISTER_REQUEST, registerSuccess, registerFailure } from '../action/registerActions';

// function* handleRegister(action: any): Generator<any, void, any>  {
//   try {
//     const response = yield call(fetch, 'http://localhost:3000/patientDetails', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json'
//       },
//       body: JSON.stringify(action.payload)
//     });

//     if (response.ok) {
//       yield put(registerSuccess());
//       alert('Registration successful');
//     } else {
//       yield put(registerFailure('Registration failed'));
//       alert('Registration failed');
//     }
//   } catch (error) {
//     //yield put(registerFailure);
//     console.error('Error:', error);
//     alert('An error occurred');
//   }
// }

// function* registerSaga() {
//   yield takeEvery(REGISTER_REQUEST, handleRegister);
// }

// export default registerSaga;
