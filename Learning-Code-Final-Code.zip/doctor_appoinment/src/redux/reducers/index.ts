import { combineReducers } from 'redux';
import registerReducer from './registerReducer';
import loginReducer from './loginReducer';
import appointmentReducer from './appointmentReducer';
const rootReducer = combineReducers({
    registerReducer,
    loginReducer,
    appointmentReducer
});

export default rootReducer;