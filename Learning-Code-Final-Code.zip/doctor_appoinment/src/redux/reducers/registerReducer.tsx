import { REGISTER_SUCCESS, REGISTER_FAILURE } from '../action/registerActions';

// const initialState = {
//   loading: false,
//   error: null,
// };
export interface registerState {
  data: any;
}
const initialState: registerState = {
  data: null
}
const registerReducer = (state: registerState = initialState, action: any) => {
  switch (action.type) {
    case REGISTER_SUCCESS:
      return {
        ...state,
        data: action.payload
      }
    case REGISTER_FAILURE:
      return {
        ...state,
        data: null,
      }
    default:
      return state;
  }
};

export default registerReducer;
