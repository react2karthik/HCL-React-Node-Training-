
import { LOGIN_SUCCESS, LOGIN_FAILED} from '../action/loginActions';
export interface loginState {
  data: any; 
}
const initialState: loginState = {
  data: null
};
 
const loginReducer = (state: loginState = initialState, action:any) => {
  switch (action.type) {
    case LOGIN_SUCCESS:
      return {
        ...state,
        data: action.payload,
      };
    case LOGIN_FAILED:
      return {
        ...state,
        data: null, 
      };
    default:
      return state; 
  }
};
 
export default loginReducer;
 