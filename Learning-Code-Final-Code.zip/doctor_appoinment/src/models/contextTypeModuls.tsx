export interface ContextType {
    isAuthenticated: boolean;
    login: () => void;
    logout: () => void;
    teamColor: string;
    setTeamColor: (color: string) => void;
    textTeamColor:string;
    setTextTeamColor: (color: string) => void;
}