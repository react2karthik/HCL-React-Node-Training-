export interface IAppointmentModuls {
    payload: any;  
    id:any,
    patientName: string;
    doctorName: string;
    appointmentDate: string;
    reason: string;
}