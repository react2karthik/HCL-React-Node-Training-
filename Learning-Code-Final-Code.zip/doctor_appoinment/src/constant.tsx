export const LOGINAPI = 'http://localhost:3000/patientDetails'
export const REGISTERAPI = 'http://localhost:3000/patientDetails'
export const APPOINMENTDETAILSAPI = 'http://localhost:3000/appoinmentDetails'
console.log('0111111111111111111111p----',APPOINMENTDETAILSAPI);
